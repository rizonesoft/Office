﻿Namespace CustomDrawExample
    Partial Public Class Form1
        ''' <summary>
        ''' Required designer variable.
        ''' </summary>
        Private components As System.ComponentModel.IContainer = Nothing

        ''' <summary>
        ''' Clean up any resources being used.
        ''' </summary>
        ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

#Region "Windows Form Designer generated code"

        ''' <summary>
        ''' Required method for Designer support - do not modify
        ''' the contents of this method with the code editor.
        ''' </summary>
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim SpreadsheetCommandGalleryItemGroup1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim GalleryItemGroup1 As DevExpress.XtraBars.Ribbon.GalleryItemGroup = New DevExpress.XtraBars.Ribbon.GalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem41 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem42 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem43 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem44 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem45 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem46 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem47 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem48 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem49 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem50 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem51 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem52 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem53 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem54 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem55 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem56 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem57 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem58 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem59 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem60 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem61 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem62 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem63 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem64 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem65 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem66 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem67 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem68 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem69 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem70 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem71 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem72 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem73 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem74 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem75 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem76 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem77 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem78 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem79 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem80 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem81 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem82 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem83 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem84 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem85 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem86 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem87 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem88 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem89 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem90 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem91 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem92 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem93 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem94 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem95 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem96 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem97 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem98 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem99 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem100 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem101 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem102 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem103 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem104 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem105 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem106 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem107 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem108 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem109 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem110 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem111 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem112 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem113 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem114 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem115 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem116 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem117 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem118 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem119 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem120 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem121 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem122 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem123 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem124 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem125 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem126 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem127 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem128 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem129 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem130 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem131 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem132 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem133 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem134 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem135 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem136 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem137 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem138 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem139 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem140 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem141 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem142 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem143 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem144 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem145 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem146 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem147 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem148 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem149 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem150 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem151 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem152 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem153 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem154 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem155 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem156 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem157 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem158 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem159 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem160 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem161 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem162 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem163 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem164 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem165 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem166 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem167 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem168 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem169 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem170 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem171 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem172 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem173 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem174 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem175 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem176 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem177 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem178 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem179 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem180 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem181 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem182 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem183 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem184 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup41 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem185 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItem186 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup42 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem187 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup43 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem188 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Dim SpreadsheetCommandGalleryItemGroup44 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
            Dim SpreadsheetCommandGalleryItem189 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
            Me.spreadsheetCommandBarSubItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarSubItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem43 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem44 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem45 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem46 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem47 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem48 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem49 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem50 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem51 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem52 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem53 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem54 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem55 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonGalleryDropDownItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown2 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.ribbonControl1 = New DevExpress.XtraBars.Ribbon.RibbonControl()
            Me.spreadsheetCommandBarButtonItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.barButtonGroup1 = New DevExpress.XtraBars.BarButtonGroup()
            Me.changeFontNameItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem()
            Me.repositoryItemFontEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemFontEdit()
            Me.changeFontSizeItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem()
            Me.repositoryItemSpreadsheetFontSizeEdit1 = New DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit()
            Me.spreadsheetControl1 = New DevExpress.XtraSpreadsheet.SpreadsheetControl()
            Me.spreadsheetCommandBarButtonItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.barButtonGroup2 = New DevExpress.XtraBars.BarButtonGroup()
            Me.spreadsheetCommandBarCheckItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.barButtonGroup3 = New DevExpress.XtraBars.BarButtonGroup()
            Me.spreadsheetCommandBarSubItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem25 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem26 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem27 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem28 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.changeBorderLineColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem()
            Me.changeBorderLineStyleItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem()
            Me.commandBarGalleryDropDown1 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.barButtonGroup4 = New DevExpress.XtraBars.BarButtonGroup()
            Me.changeCellFillColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem()
            Me.changeFontColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem()
            Me.barButtonGroup5 = New DevExpress.XtraBars.BarButtonGroup()
            Me.spreadsheetCommandBarCheckItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.barButtonGroup6 = New DevExpress.XtraBars.BarButtonGroup()
            Me.spreadsheetCommandBarCheckItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.barButtonGroup7 = New DevExpress.XtraBars.BarButtonGroup()
            Me.spreadsheetCommandBarButtonItem29 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem30 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarCheckItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarSubItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarCheckItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarButtonItem31 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem32 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem33 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.barButtonGroup8 = New DevExpress.XtraBars.BarButtonGroup()
            Me.changeNumberFormatItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem()
            Me.repositoryItemPopupGalleryEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit()
            Me.barButtonGroup9 = New DevExpress.XtraBars.BarButtonGroup()
            Me.spreadsheetCommandBarSubItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem34 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem35 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem36 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem37 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem38 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem119 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem39 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem40 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.barButtonGroup10 = New DevExpress.XtraBars.BarButtonGroup()
            Me.spreadsheetCommandBarButtonItem41 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem42 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonGalleryDropDownItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown3 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown4 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonItem56 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem57 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.galleryFormatAsTableItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem()
            Me.commandBarGalleryDropDown5 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.galleryChangeStyleItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem()
            Me.spreadsheetCommandBarSubItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem58 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem59 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem60 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem122 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem123 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem124 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem125 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem126 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem61 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem62 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem63 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem127 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem128 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem129 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem64 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem65 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem66 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem67 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem68 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem69 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem70 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem71 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem72 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem130 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem131 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem132 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem133 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.ChangeSheetTabColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem()
            Me.SpreadsheetCommandBarButtonItem134 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarCheckItem32 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarButtonItem135 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem73 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem74 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem75 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem76 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem77 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem78 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem79 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem80 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem81 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem82 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem83 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem84 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem85 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem86 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem87 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem88 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem89 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonGalleryDropDownItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown6 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown7 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown8 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown9 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown10 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown11 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown12 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonItem90 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarCheckItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarButtonItem147 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarCheckItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.pageSetupPaperKindItem1 = New DevExpress.XtraSpreadsheet.UI.PageSetupPaperKindItem()
            Me.spreadsheetCommandBarSubItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem91 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem92 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem93 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem94 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.functionsFinancialItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsFinancialItem()
            Me.functionsLogicalItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsLogicalItem()
            Me.functionsTextItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsTextItem()
            Me.functionsDateAndTimeItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsDateAndTimeItem()
            Me.functionsLookupAndReferenceItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsLookupAndReferenceItem()
            Me.functionsMathAndTrigonometryItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsMathAndTrigonometryItem()
            Me.spreadsheetCommandBarSubItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.functionsStatisticalItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsStatisticalItem()
            Me.functionsEngineeringItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsEngineeringItem()
            Me.functionsInformationItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsInformationItem()
            Me.functionsCompatibilityItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsCompatibilityItem()
            Me.functionsWebItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsWebItem()
            Me.spreadsheetCommandBarCheckItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarButtonItem100 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem101 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarCheckItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarButtonItem102 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem103 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem104 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem105 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem106 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem107 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarCheckItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarButtonItem108 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem109 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem110 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarSubItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonItem111 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem112 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem113 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem114 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem115 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem116 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.galleryChartLayoutItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryChartLayoutItem()
            Me.galleryChartStyleItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryChartStyleItem()
            Me.spreadsheetCommandBarButtonGalleryDropDownItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown13 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarSubItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonGalleryDropDownItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown14 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown15 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown16 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown17 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarSubItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonGalleryDropDownItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown18 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown19 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarSubItem25 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.spreadsheetCommandBarButtonGalleryDropDownItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown20 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown21 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown22 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown23 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.spreadsheetCommandBarButtonGalleryDropDownItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.commandBarGalleryDropDown24 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.barStaticItem1 = New DevExpress.XtraBars.BarStaticItem()
            Me.renameTableItem1 = New DevExpress.XtraSpreadsheet.UI.RenameTableItem()
            Me.repositoryItemTextEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemTextEdit()
            Me.spreadsheetCommandBarCheckItem25 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem26 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem27 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem28 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem29 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem30 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.spreadsheetCommandBarCheckItem31 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.galleryTableStylesItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryTableStylesItem()
            Me.SpreadsheetCommandBarButtonItem117 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem118 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem120 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem121 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem26 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarCheckItem33 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarButtonItem136 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem137 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem27 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem138 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem139 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem140 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem141 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem142 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem143 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem144 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem145 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.CommandBarGalleryDropDown25 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
            Me.CommandBarGalleryDropDown26 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
            Me.SpreadsheetCommandBarButtonItem146 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem28 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem148 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem149 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem150 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem151 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarCheckItem34 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarCheckItem35 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarButtonItem152 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem153 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.DefinedNameListItem1 = New DevExpress.XtraSpreadsheet.UI.DefinedNameListItem()
            Me.SpreadsheetCommandBarButtonItem154 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem29 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarCheckItem36 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarCheckItem37 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarButtonItem155 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem156 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem30 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem157 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem158 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem159 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem31 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem160 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem161 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem32 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem162 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem163 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem164 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem165 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem166 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem167 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem168 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem169 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem170 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem171 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem172 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem173 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem174 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem175 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem176 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem177 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.RenameTableItemCaption1 = New DevExpress.XtraSpreadsheet.UI.RenameTableItemCaption()
            Me.SpreadsheetCommandBarButtonItem178 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem179 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem180 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem181 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem182 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem183 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem184 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem33 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem185 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem186 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem187 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem34 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem188 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem189 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem35 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem190 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem191 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem192 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem193 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem36 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem194 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem195 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem196 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem197 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarCheckItem38 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarCheckItem39 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarCheckItem40 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarSubItem37 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem198 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem199 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem200 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem38 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem201 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem202 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem203 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem204 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem39 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem205 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem206 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem207 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem208 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem209 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarSubItem40 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
            Me.SpreadsheetCommandBarButtonItem210 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarButtonItem211 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetCommandBarCheckItem41 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarCheckItem42 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarCheckItem43 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.SpreadsheetCommandBarCheckItem44 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
            Me.GalleryPivotStylesItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryPivotStylesItem()
            Me.fileRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.FileRibbonPage()
            Me.commonRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.CommonRibbonPageGroup()
            Me.InfoRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.InfoRibbonPageGroup()
            Me.spreadsheetBarController1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController(Me.components)
            Me.spreadsheetCommandBarButtonItem95 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem96 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem97 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem98 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.spreadsheetCommandBarButtonItem99 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
            Me.SpreadsheetFormulaBar1 = New DevExpress.XtraSpreadsheet.SpreadsheetFormulaBar()
            Me.SplitterControl2 = New DevExpress.XtraEditors.SplitterControl()
            CType(Me.commandBarGalleryDropDown2, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.ribbonControl1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.repositoryItemFontEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.repositoryItemSpreadsheetFontSizeEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.repositoryItemPopupGalleryEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown3, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown4, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown5, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown6, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown7, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown8, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown9, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown10, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown11, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown12, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown13, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown14, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown15, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown16, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown17, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown18, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown19, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown20, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown21, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown22, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown23, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.commandBarGalleryDropDown24, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.repositoryItemTextEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.CommandBarGalleryDropDown25, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.CommandBarGalleryDropDown26, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.spreadsheetBarController1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'spreadsheetCommandBarSubItem4
            '
            Me.spreadsheetCommandBarSubItem4.CommandName = "ConditionalFormattingCommandGroup"
            Me.spreadsheetCommandBarSubItem4.Id = 75
            Me.spreadsheetCommandBarSubItem4.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarSubItem5), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarSubItem6), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem2), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem3), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarSubItem7), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem120), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem121)})
            Me.spreadsheetCommandBarSubItem4.Name = "spreadsheetCommandBarSubItem4"
            '
            'spreadsheetCommandBarSubItem5
            '
            Me.spreadsheetCommandBarSubItem5.CommandName = "ConditionalFormattingHighlightCellsRuleCommandGroup"
            Me.spreadsheetCommandBarSubItem5.Id = 83
            Me.spreadsheetCommandBarSubItem5.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem43), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem44), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem45), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem46), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem47), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem48), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem49)})
            Me.spreadsheetCommandBarSubItem5.Name = "spreadsheetCommandBarSubItem5"
            '
            'spreadsheetCommandBarButtonItem43
            '
            Me.spreadsheetCommandBarButtonItem43.CommandName = "ConditionalFormattingGreaterThanRuleCommand"
            Me.spreadsheetCommandBarButtonItem43.Id = 76
            Me.spreadsheetCommandBarButtonItem43.Name = "spreadsheetCommandBarButtonItem43"
            Me.spreadsheetCommandBarButtonItem43.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem44
            '
            Me.spreadsheetCommandBarButtonItem44.CommandName = "ConditionalFormattingLessThanRuleCommand"
            Me.spreadsheetCommandBarButtonItem44.Id = 77
            Me.spreadsheetCommandBarButtonItem44.Name = "spreadsheetCommandBarButtonItem44"
            Me.spreadsheetCommandBarButtonItem44.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem45
            '
            Me.spreadsheetCommandBarButtonItem45.CommandName = "ConditionalFormattingBetweenRuleCommand"
            Me.spreadsheetCommandBarButtonItem45.Id = 78
            Me.spreadsheetCommandBarButtonItem45.Name = "spreadsheetCommandBarButtonItem45"
            Me.spreadsheetCommandBarButtonItem45.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem46
            '
            Me.spreadsheetCommandBarButtonItem46.CommandName = "ConditionalFormattingEqualToRuleCommand"
            Me.spreadsheetCommandBarButtonItem46.Id = 79
            Me.spreadsheetCommandBarButtonItem46.Name = "spreadsheetCommandBarButtonItem46"
            Me.spreadsheetCommandBarButtonItem46.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem47
            '
            Me.spreadsheetCommandBarButtonItem47.CommandName = "ConditionalFormattingTextContainsRuleCommand"
            Me.spreadsheetCommandBarButtonItem47.Id = 80
            Me.spreadsheetCommandBarButtonItem47.Name = "spreadsheetCommandBarButtonItem47"
            Me.spreadsheetCommandBarButtonItem47.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem48
            '
            Me.spreadsheetCommandBarButtonItem48.CommandName = "ConditionalFormattingDateOccurringRuleCommand"
            Me.spreadsheetCommandBarButtonItem48.Id = 81
            Me.spreadsheetCommandBarButtonItem48.Name = "spreadsheetCommandBarButtonItem48"
            Me.spreadsheetCommandBarButtonItem48.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem49
            '
            Me.spreadsheetCommandBarButtonItem49.CommandName = "ConditionalFormattingDuplicateValuesRuleCommand"
            Me.spreadsheetCommandBarButtonItem49.Id = 82
            Me.spreadsheetCommandBarButtonItem49.Name = "spreadsheetCommandBarButtonItem49"
            Me.spreadsheetCommandBarButtonItem49.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarSubItem6
            '
            Me.spreadsheetCommandBarSubItem6.CommandName = "ConditionalFormattingTopBottomRuleCommandGroup"
            Me.spreadsheetCommandBarSubItem6.Id = 90
            Me.spreadsheetCommandBarSubItem6.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem50), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem51), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem52), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem53), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem54), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem55)})
            Me.spreadsheetCommandBarSubItem6.Name = "spreadsheetCommandBarSubItem6"
            '
            'spreadsheetCommandBarButtonItem50
            '
            Me.spreadsheetCommandBarButtonItem50.CommandName = "ConditionalFormattingTop10RuleCommand"
            Me.spreadsheetCommandBarButtonItem50.Id = 84
            Me.spreadsheetCommandBarButtonItem50.Name = "spreadsheetCommandBarButtonItem50"
            Me.spreadsheetCommandBarButtonItem50.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem51
            '
            Me.spreadsheetCommandBarButtonItem51.CommandName = "ConditionalFormattingTop10PercentRuleCommand"
            Me.spreadsheetCommandBarButtonItem51.Id = 85
            Me.spreadsheetCommandBarButtonItem51.Name = "spreadsheetCommandBarButtonItem51"
            Me.spreadsheetCommandBarButtonItem51.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem52
            '
            Me.spreadsheetCommandBarButtonItem52.CommandName = "ConditionalFormattingBottom10RuleCommand"
            Me.spreadsheetCommandBarButtonItem52.Id = 86
            Me.spreadsheetCommandBarButtonItem52.Name = "spreadsheetCommandBarButtonItem52"
            Me.spreadsheetCommandBarButtonItem52.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem53
            '
            Me.spreadsheetCommandBarButtonItem53.CommandName = "ConditionalFormattingBottom10PercentRuleCommand"
            Me.spreadsheetCommandBarButtonItem53.Id = 87
            Me.spreadsheetCommandBarButtonItem53.Name = "spreadsheetCommandBarButtonItem53"
            Me.spreadsheetCommandBarButtonItem53.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem54
            '
            Me.spreadsheetCommandBarButtonItem54.CommandName = "ConditionalFormattingAboveAverageRuleCommand"
            Me.spreadsheetCommandBarButtonItem54.Id = 88
            Me.spreadsheetCommandBarButtonItem54.Name = "spreadsheetCommandBarButtonItem54"
            Me.spreadsheetCommandBarButtonItem54.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem55
            '
            Me.spreadsheetCommandBarButtonItem55.CommandName = "ConditionalFormattingBelowAverageRuleCommand"
            Me.spreadsheetCommandBarButtonItem55.Id = 89
            Me.spreadsheetCommandBarButtonItem55.Name = "spreadsheetCommandBarButtonItem55"
            Me.spreadsheetCommandBarButtonItem55.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem1
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem1.CommandName = "ConditionalFormattingDataBarsCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem1.DropDownControl = Me.commandBarGalleryDropDown2
            Me.spreadsheetCommandBarButtonGalleryDropDownItem1.Id = 91
            Me.spreadsheetCommandBarButtonGalleryDropDownItem1.Name = "spreadsheetCommandBarButtonGalleryDropDownItem1"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'commandBarGalleryDropDown2
            '
            '
            '
            '
            Me.commandBarGalleryDropDown2.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup1.CommandName = "ConditionalFormattingDataBarsGradientFillCommandGroup"
            SpreadsheetCommandGalleryItem1.CommandName = "ConditionalFormattingDataBarGradientBlue"
            SpreadsheetCommandGalleryItem2.CommandName = "ConditionalFormattingDataBarGradientGreen"
            SpreadsheetCommandGalleryItem3.CommandName = "ConditionalFormattingDataBarGradientRed"
            SpreadsheetCommandGalleryItem4.CommandName = "ConditionalFormattingDataBarGradientOrange"
            SpreadsheetCommandGalleryItem5.CommandName = "ConditionalFormattingDataBarGradientLightBlue"
            SpreadsheetCommandGalleryItem6.CommandName = "ConditionalFormattingDataBarGradientPurple"
            SpreadsheetCommandGalleryItemGroup1.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem1, SpreadsheetCommandGalleryItem2, SpreadsheetCommandGalleryItem3, SpreadsheetCommandGalleryItem4, SpreadsheetCommandGalleryItem5, SpreadsheetCommandGalleryItem6})
            SpreadsheetCommandGalleryItemGroup2.CommandName = "ConditionalFormattingDataBarsSolidFillCommandGroup"
            SpreadsheetCommandGalleryItem7.CommandName = "ConditionalFormattingDataBarSolidBlue"
            SpreadsheetCommandGalleryItem8.CommandName = "ConditionalFormattingDataBarSolidGreen"
            SpreadsheetCommandGalleryItem9.CommandName = "ConditionalFormattingDataBarSolidRed"
            SpreadsheetCommandGalleryItem10.CommandName = "ConditionalFormattingDataBarSolidOrange"
            SpreadsheetCommandGalleryItem11.CommandName = "ConditionalFormattingDataBarSolidLightBlue"
            SpreadsheetCommandGalleryItem12.CommandName = "ConditionalFormattingDataBarSolidPurple"
            SpreadsheetCommandGalleryItemGroup2.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem7, SpreadsheetCommandGalleryItem8, SpreadsheetCommandGalleryItem9, SpreadsheetCommandGalleryItem10, SpreadsheetCommandGalleryItem11, SpreadsheetCommandGalleryItem12})
            Me.commandBarGalleryDropDown2.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup1, SpreadsheetCommandGalleryItemGroup2})
            Me.commandBarGalleryDropDown2.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown2.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown2.Name = "commandBarGalleryDropDown2"
            Me.commandBarGalleryDropDown2.Ribbon = Me.ribbonControl1
            '
            'ribbonControl1
            '
            Me.ribbonControl1.ExpandCollapseItem.Id = 0
            Me.ribbonControl1.Items.AddRange(New DevExpress.XtraBars.BarItem() {Me.ribbonControl1.ExpandCollapseItem, Me.ribbonControl1.SearchEditItem, Me.spreadsheetCommandBarButtonItem1, Me.spreadsheetCommandBarButtonItem2, Me.spreadsheetCommandBarButtonItem3, Me.spreadsheetCommandBarButtonItem4, Me.spreadsheetCommandBarButtonItem5, Me.spreadsheetCommandBarButtonItem6, Me.spreadsheetCommandBarButtonItem7, Me.spreadsheetCommandBarButtonItem8, Me.spreadsheetCommandBarButtonItem9, Me.spreadsheetCommandBarButtonItem10, Me.spreadsheetCommandBarButtonItem11, Me.spreadsheetCommandBarButtonItem12, Me.spreadsheetCommandBarButtonItem13, Me.barButtonGroup1, Me.changeFontNameItem1, Me.changeFontSizeItem1, Me.spreadsheetCommandBarButtonItem14, Me.spreadsheetCommandBarButtonItem15, Me.barButtonGroup2, Me.spreadsheetCommandBarCheckItem1, Me.spreadsheetCommandBarCheckItem2, Me.spreadsheetCommandBarCheckItem3, Me.spreadsheetCommandBarCheckItem4, Me.barButtonGroup3, Me.spreadsheetCommandBarSubItem1, Me.spreadsheetCommandBarButtonItem16, Me.spreadsheetCommandBarButtonItem17, Me.spreadsheetCommandBarButtonItem18, Me.spreadsheetCommandBarButtonItem19, Me.spreadsheetCommandBarButtonItem20, Me.spreadsheetCommandBarButtonItem21, Me.spreadsheetCommandBarButtonItem22, Me.spreadsheetCommandBarButtonItem23, Me.spreadsheetCommandBarButtonItem24, Me.spreadsheetCommandBarButtonItem25, Me.spreadsheetCommandBarButtonItem26, Me.spreadsheetCommandBarButtonItem27, Me.spreadsheetCommandBarButtonItem28, Me.changeBorderLineColorItem1, Me.changeBorderLineStyleItem1, Me.barButtonGroup4, Me.changeCellFillColorItem1, Me.changeFontColorItem1, Me.barButtonGroup5, Me.spreadsheetCommandBarCheckItem5, Me.spreadsheetCommandBarCheckItem6, Me.spreadsheetCommandBarCheckItem7, Me.barButtonGroup6, Me.spreadsheetCommandBarCheckItem8, Me.spreadsheetCommandBarCheckItem9, Me.spreadsheetCommandBarCheckItem10, Me.barButtonGroup7, Me.spreadsheetCommandBarButtonItem29, Me.spreadsheetCommandBarButtonItem30, Me.spreadsheetCommandBarCheckItem11, Me.spreadsheetCommandBarSubItem2, Me.spreadsheetCommandBarCheckItem12, Me.spreadsheetCommandBarButtonItem31, Me.spreadsheetCommandBarButtonItem32, Me.spreadsheetCommandBarButtonItem33, Me.barButtonGroup8, Me.changeNumberFormatItem1, Me.barButtonGroup9, Me.spreadsheetCommandBarSubItem3, Me.spreadsheetCommandBarButtonItem34, Me.spreadsheetCommandBarButtonItem35, Me.spreadsheetCommandBarButtonItem36, Me.spreadsheetCommandBarButtonItem37, Me.spreadsheetCommandBarButtonItem38, Me.spreadsheetCommandBarButtonItem39, Me.spreadsheetCommandBarButtonItem40, Me.barButtonGroup10, Me.spreadsheetCommandBarButtonItem41, Me.spreadsheetCommandBarButtonItem42, Me.spreadsheetCommandBarSubItem4, Me.spreadsheetCommandBarButtonItem43, Me.spreadsheetCommandBarButtonItem44, Me.spreadsheetCommandBarButtonItem45, Me.spreadsheetCommandBarButtonItem46, Me.spreadsheetCommandBarButtonItem47, Me.spreadsheetCommandBarButtonItem48, Me.spreadsheetCommandBarButtonItem49, Me.spreadsheetCommandBarSubItem5, Me.spreadsheetCommandBarButtonItem50, Me.spreadsheetCommandBarButtonItem51, Me.spreadsheetCommandBarButtonItem52, Me.spreadsheetCommandBarButtonItem53, Me.spreadsheetCommandBarButtonItem54, Me.spreadsheetCommandBarButtonItem55, Me.spreadsheetCommandBarSubItem6, Me.spreadsheetCommandBarButtonGalleryDropDownItem1, Me.spreadsheetCommandBarButtonGalleryDropDownItem2, Me.spreadsheetCommandBarButtonGalleryDropDownItem3, Me.spreadsheetCommandBarButtonItem56, Me.spreadsheetCommandBarButtonItem57, Me.spreadsheetCommandBarSubItem7, Me.galleryFormatAsTableItem1, Me.galleryChangeStyleItem1, Me.spreadsheetCommandBarSubItem8, Me.spreadsheetCommandBarButtonItem58, Me.spreadsheetCommandBarButtonItem59, Me.spreadsheetCommandBarButtonItem60, Me.spreadsheetCommandBarSubItem9, Me.spreadsheetCommandBarButtonItem61, Me.spreadsheetCommandBarButtonItem62, Me.spreadsheetCommandBarButtonItem63, Me.spreadsheetCommandBarSubItem10, Me.spreadsheetCommandBarButtonItem64, Me.spreadsheetCommandBarButtonItem65, Me.spreadsheetCommandBarButtonItem66, Me.spreadsheetCommandBarButtonItem67, Me.spreadsheetCommandBarButtonItem68, Me.spreadsheetCommandBarButtonItem69, Me.spreadsheetCommandBarButtonItem70, Me.spreadsheetCommandBarButtonItem71, Me.spreadsheetCommandBarSubItem11, Me.spreadsheetCommandBarButtonItem72, Me.spreadsheetCommandBarSubItem12, Me.spreadsheetCommandBarButtonItem73, Me.spreadsheetCommandBarButtonItem74, Me.spreadsheetCommandBarButtonItem75, Me.spreadsheetCommandBarButtonItem76, Me.spreadsheetCommandBarButtonItem77, Me.spreadsheetCommandBarSubItem13, Me.spreadsheetCommandBarButtonItem78, Me.spreadsheetCommandBarButtonItem79, Me.spreadsheetCommandBarButtonItem80, Me.spreadsheetCommandBarButtonItem81, Me.spreadsheetCommandBarSubItem14, Me.spreadsheetCommandBarButtonItem82, Me.spreadsheetCommandBarButtonItem83, Me.spreadsheetCommandBarButtonItem84, Me.spreadsheetCommandBarButtonItem85, Me.spreadsheetCommandBarButtonItem86, Me.spreadsheetCommandBarButtonItem87, Me.spreadsheetCommandBarButtonItem88, Me.spreadsheetCommandBarButtonItem89, Me.spreadsheetCommandBarButtonGalleryDropDownItem4, Me.spreadsheetCommandBarButtonGalleryDropDownItem5, Me.spreadsheetCommandBarButtonGalleryDropDownItem6, Me.spreadsheetCommandBarButtonGalleryDropDownItem7, Me.spreadsheetCommandBarButtonGalleryDropDownItem8, Me.spreadsheetCommandBarButtonGalleryDropDownItem9, Me.spreadsheetCommandBarButtonGalleryDropDownItem10, Me.spreadsheetCommandBarButtonItem90, Me.spreadsheetCommandBarSubItem15, Me.spreadsheetCommandBarCheckItem13, Me.spreadsheetCommandBarCheckItem14, Me.spreadsheetCommandBarCheckItem15, Me.spreadsheetCommandBarSubItem16, Me.spreadsheetCommandBarCheckItem16, Me.spreadsheetCommandBarCheckItem17, Me.pageSetupPaperKindItem1, Me.spreadsheetCommandBarSubItem17, Me.spreadsheetCommandBarButtonItem91, Me.spreadsheetCommandBarButtonItem92, Me.spreadsheetCommandBarSubItem18, Me.spreadsheetCommandBarButtonItem93, Me.spreadsheetCommandBarButtonItem94, Me.spreadsheetCommandBarSubItem19, Me.functionsFinancialItem1, Me.functionsLogicalItem1, Me.functionsTextItem1, Me.functionsDateAndTimeItem1, Me.functionsLookupAndReferenceItem1, Me.functionsMathAndTrigonometryItem1, Me.spreadsheetCommandBarSubItem20, Me.functionsStatisticalItem1, Me.functionsEngineeringItem1, Me.functionsInformationItem1, Me.functionsCompatibilityItem1, Me.functionsWebItem1, Me.spreadsheetCommandBarCheckItem18, Me.spreadsheetCommandBarButtonItem100, Me.spreadsheetCommandBarButtonItem101, Me.spreadsheetCommandBarCheckItem19, Me.spreadsheetCommandBarCheckItem20, Me.spreadsheetCommandBarCheckItem21, Me.spreadsheetCommandBarButtonItem102, Me.spreadsheetCommandBarButtonItem103, Me.spreadsheetCommandBarButtonItem104, Me.spreadsheetCommandBarSubItem21, Me.spreadsheetCommandBarButtonItem105, Me.spreadsheetCommandBarButtonItem106, Me.spreadsheetCommandBarButtonItem107, Me.spreadsheetCommandBarCheckItem22, Me.spreadsheetCommandBarCheckItem23, Me.spreadsheetCommandBarCheckItem24, Me.spreadsheetCommandBarButtonItem108, Me.spreadsheetCommandBarButtonItem109, Me.spreadsheetCommandBarButtonItem110, Me.spreadsheetCommandBarSubItem22, Me.spreadsheetCommandBarButtonItem111, Me.spreadsheetCommandBarButtonItem112, Me.spreadsheetCommandBarButtonItem113, Me.spreadsheetCommandBarButtonItem114, Me.spreadsheetCommandBarButtonItem115, Me.spreadsheetCommandBarButtonItem116, Me.galleryChartLayoutItem1, Me.galleryChartStyleItem1, Me.spreadsheetCommandBarButtonGalleryDropDownItem11, Me.spreadsheetCommandBarSubItem23, Me.spreadsheetCommandBarButtonGalleryDropDownItem12, Me.spreadsheetCommandBarButtonGalleryDropDownItem13, Me.spreadsheetCommandBarButtonGalleryDropDownItem14, Me.spreadsheetCommandBarButtonGalleryDropDownItem15, Me.spreadsheetCommandBarSubItem24, Me.spreadsheetCommandBarButtonGalleryDropDownItem16, Me.spreadsheetCommandBarButtonGalleryDropDownItem17, Me.spreadsheetCommandBarSubItem25, Me.spreadsheetCommandBarButtonGalleryDropDownItem18, Me.spreadsheetCommandBarButtonGalleryDropDownItem19, Me.spreadsheetCommandBarButtonGalleryDropDownItem20, Me.spreadsheetCommandBarButtonGalleryDropDownItem21, Me.spreadsheetCommandBarButtonGalleryDropDownItem22, Me.barStaticItem1, Me.renameTableItem1, Me.spreadsheetCommandBarCheckItem25, Me.spreadsheetCommandBarCheckItem26, Me.spreadsheetCommandBarCheckItem27, Me.spreadsheetCommandBarCheckItem28, Me.spreadsheetCommandBarCheckItem29, Me.spreadsheetCommandBarCheckItem30, Me.spreadsheetCommandBarCheckItem31, Me.galleryTableStylesItem1, Me.SpreadsheetCommandBarButtonItem117, Me.SpreadsheetCommandBarButtonItem118, Me.SpreadsheetCommandBarButtonItem119, Me.SpreadsheetCommandBarButtonItem120, Me.SpreadsheetCommandBarButtonItem121, Me.SpreadsheetCommandBarButtonItem122, Me.SpreadsheetCommandBarButtonItem123, Me.SpreadsheetCommandBarButtonItem124, Me.SpreadsheetCommandBarButtonItem125, Me.SpreadsheetCommandBarButtonItem126, Me.SpreadsheetCommandBarButtonItem127, Me.SpreadsheetCommandBarButtonItem128, Me.SpreadsheetCommandBarButtonItem129, Me.SpreadsheetCommandBarButtonItem130, Me.SpreadsheetCommandBarButtonItem131, Me.SpreadsheetCommandBarButtonItem132, Me.SpreadsheetCommandBarButtonItem133, Me.ChangeSheetTabColorItem1, Me.SpreadsheetCommandBarButtonItem134, Me.SpreadsheetCommandBarCheckItem32, Me.SpreadsheetCommandBarButtonItem135, Me.SpreadsheetCommandBarSubItem26, Me.SpreadsheetCommandBarCheckItem33, Me.SpreadsheetCommandBarButtonItem136, Me.SpreadsheetCommandBarButtonItem137, Me.SpreadsheetCommandBarSubItem27, Me.SpreadsheetCommandBarButtonItem138, Me.SpreadsheetCommandBarButtonItem139, Me.SpreadsheetCommandBarButtonItem140, Me.SpreadsheetCommandBarButtonItem141, Me.SpreadsheetCommandBarButtonItem142, Me.SpreadsheetCommandBarButtonItem143, Me.SpreadsheetCommandBarButtonItem144, Me.SpreadsheetCommandBarButtonItem145, Me.SpreadsheetCommandBarButtonGalleryDropDownItem23, Me.SpreadsheetCommandBarButtonGalleryDropDownItem24, Me.SpreadsheetCommandBarButtonItem146, Me.SpreadsheetCommandBarButtonItem147, Me.SpreadsheetCommandBarSubItem28, Me.SpreadsheetCommandBarButtonItem148, Me.SpreadsheetCommandBarButtonItem149, Me.SpreadsheetCommandBarButtonItem150, Me.SpreadsheetCommandBarButtonItem151, Me.SpreadsheetCommandBarCheckItem34, Me.SpreadsheetCommandBarCheckItem35, Me.SpreadsheetCommandBarButtonItem152, Me.SpreadsheetCommandBarButtonItem153, Me.DefinedNameListItem1, Me.SpreadsheetCommandBarButtonItem154, Me.SpreadsheetCommandBarSubItem29, Me.SpreadsheetCommandBarCheckItem36, Me.SpreadsheetCommandBarCheckItem37, Me.SpreadsheetCommandBarButtonItem155, Me.SpreadsheetCommandBarButtonItem156, Me.SpreadsheetCommandBarSubItem30, Me.SpreadsheetCommandBarButtonItem157, Me.SpreadsheetCommandBarButtonItem158, Me.SpreadsheetCommandBarButtonItem159, Me.SpreadsheetCommandBarSubItem31, Me.SpreadsheetCommandBarButtonItem160, Me.SpreadsheetCommandBarButtonItem161, Me.SpreadsheetCommandBarSubItem32, Me.SpreadsheetCommandBarButtonItem162, Me.SpreadsheetCommandBarButtonItem163, Me.SpreadsheetCommandBarButtonItem164, Me.SpreadsheetCommandBarButtonItem165, Me.SpreadsheetCommandBarButtonItem166, Me.SpreadsheetCommandBarButtonItem167, Me.SpreadsheetCommandBarButtonItem168, Me.SpreadsheetCommandBarButtonItem169, Me.SpreadsheetCommandBarButtonItem170, Me.SpreadsheetCommandBarButtonItem171, Me.SpreadsheetCommandBarButtonItem172, Me.SpreadsheetCommandBarButtonItem173, Me.SpreadsheetCommandBarButtonItem174, Me.SpreadsheetCommandBarButtonItem175, Me.SpreadsheetCommandBarButtonItem176, Me.SpreadsheetCommandBarButtonItem177, Me.RenameTableItemCaption1, Me.SpreadsheetCommandBarButtonItem178, Me.SpreadsheetCommandBarButtonItem179, Me.SpreadsheetCommandBarButtonItem180, Me.SpreadsheetCommandBarButtonItem181, Me.SpreadsheetCommandBarButtonItem182, Me.SpreadsheetCommandBarButtonItem183, Me.SpreadsheetCommandBarButtonItem184, Me.SpreadsheetCommandBarSubItem33, Me.SpreadsheetCommandBarButtonItem185, Me.SpreadsheetCommandBarButtonItem186, Me.SpreadsheetCommandBarButtonItem187, Me.SpreadsheetCommandBarSubItem34, Me.SpreadsheetCommandBarButtonItem188, Me.SpreadsheetCommandBarButtonItem189, Me.SpreadsheetCommandBarSubItem35, Me.SpreadsheetCommandBarButtonItem190, Me.SpreadsheetCommandBarButtonItem191, Me.SpreadsheetCommandBarButtonItem192, Me.SpreadsheetCommandBarButtonItem193, Me.SpreadsheetCommandBarSubItem36, Me.SpreadsheetCommandBarButtonItem194, Me.SpreadsheetCommandBarButtonItem195, Me.SpreadsheetCommandBarButtonItem196, Me.SpreadsheetCommandBarButtonItem197, Me.SpreadsheetCommandBarCheckItem38, Me.SpreadsheetCommandBarCheckItem39, Me.SpreadsheetCommandBarCheckItem40, Me.SpreadsheetCommandBarSubItem37, Me.SpreadsheetCommandBarButtonItem198, Me.SpreadsheetCommandBarButtonItem199, Me.SpreadsheetCommandBarButtonItem200, Me.SpreadsheetCommandBarSubItem38, Me.SpreadsheetCommandBarButtonItem201, Me.SpreadsheetCommandBarButtonItem202, Me.SpreadsheetCommandBarButtonItem203, Me.SpreadsheetCommandBarButtonItem204, Me.SpreadsheetCommandBarSubItem39, Me.SpreadsheetCommandBarButtonItem205, Me.SpreadsheetCommandBarButtonItem206, Me.SpreadsheetCommandBarButtonItem207, Me.SpreadsheetCommandBarButtonItem208, Me.SpreadsheetCommandBarButtonItem209, Me.SpreadsheetCommandBarSubItem40, Me.SpreadsheetCommandBarButtonItem210, Me.SpreadsheetCommandBarButtonItem211, Me.SpreadsheetCommandBarCheckItem41, Me.SpreadsheetCommandBarCheckItem42, Me.SpreadsheetCommandBarCheckItem43, Me.SpreadsheetCommandBarCheckItem44, Me.GalleryPivotStylesItem1})
            Me.ribbonControl1.Location = New System.Drawing.Point(0, 0)
            Me.ribbonControl1.Margin = New System.Windows.Forms.Padding(19)
            Me.ribbonControl1.MaxItemId = 366
            Me.ribbonControl1.Name = "ribbonControl1"
            Me.ribbonControl1.OptionsMenuMinWidth = 1834
            Me.ribbonControl1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.fileRibbonPage1})
            Me.ribbonControl1.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.repositoryItemFontEdit1, Me.repositoryItemSpreadsheetFontSizeEdit1, Me.repositoryItemPopupGalleryEdit1, Me.repositoryItemTextEdit1})
            Me.ribbonControl1.Size = New System.Drawing.Size(1148, 193)
            '
            'spreadsheetCommandBarButtonItem1
            '
            Me.spreadsheetCommandBarButtonItem1.CommandName = "FileNew"
            Me.spreadsheetCommandBarButtonItem1.Id = 1
            Me.spreadsheetCommandBarButtonItem1.Name = "spreadsheetCommandBarButtonItem1"
            '
            'spreadsheetCommandBarButtonItem2
            '
            Me.spreadsheetCommandBarButtonItem2.CommandName = "FileOpen"
            Me.spreadsheetCommandBarButtonItem2.Id = 2
            Me.spreadsheetCommandBarButtonItem2.Name = "spreadsheetCommandBarButtonItem2"
            '
            'spreadsheetCommandBarButtonItem3
            '
            Me.spreadsheetCommandBarButtonItem3.CommandName = "FileSave"
            Me.spreadsheetCommandBarButtonItem3.Id = 3
            Me.spreadsheetCommandBarButtonItem3.Name = "spreadsheetCommandBarButtonItem3"
            '
            'spreadsheetCommandBarButtonItem4
            '
            Me.spreadsheetCommandBarButtonItem4.CommandName = "FileSaveAs"
            Me.spreadsheetCommandBarButtonItem4.Id = 4
            Me.spreadsheetCommandBarButtonItem4.Name = "spreadsheetCommandBarButtonItem4"
            '
            'spreadsheetCommandBarButtonItem5
            '
            Me.spreadsheetCommandBarButtonItem5.CommandName = "FileQuickPrint"
            Me.spreadsheetCommandBarButtonItem5.Id = 5
            Me.spreadsheetCommandBarButtonItem5.Name = "spreadsheetCommandBarButtonItem5"
            '
            'spreadsheetCommandBarButtonItem6
            '
            Me.spreadsheetCommandBarButtonItem6.CommandName = "FilePrint"
            Me.spreadsheetCommandBarButtonItem6.Id = 6
            Me.spreadsheetCommandBarButtonItem6.Name = "spreadsheetCommandBarButtonItem6"
            '
            'spreadsheetCommandBarButtonItem7
            '
            Me.spreadsheetCommandBarButtonItem7.CommandName = "FilePrintPreview"
            Me.spreadsheetCommandBarButtonItem7.Id = 7
            Me.spreadsheetCommandBarButtonItem7.Name = "spreadsheetCommandBarButtonItem7"
            '
            'spreadsheetCommandBarButtonItem8
            '
            Me.spreadsheetCommandBarButtonItem8.CommandName = "FileUndo"
            Me.spreadsheetCommandBarButtonItem8.Id = 8
            Me.spreadsheetCommandBarButtonItem8.Name = "spreadsheetCommandBarButtonItem8"
            '
            'spreadsheetCommandBarButtonItem9
            '
            Me.spreadsheetCommandBarButtonItem9.CommandName = "FileRedo"
            Me.spreadsheetCommandBarButtonItem9.Id = 9
            Me.spreadsheetCommandBarButtonItem9.Name = "spreadsheetCommandBarButtonItem9"
            '
            'spreadsheetCommandBarButtonItem10
            '
            Me.spreadsheetCommandBarButtonItem10.CommandName = "PasteSelection"
            Me.spreadsheetCommandBarButtonItem10.Id = 20
            Me.spreadsheetCommandBarButtonItem10.Name = "spreadsheetCommandBarButtonItem10"
            Me.spreadsheetCommandBarButtonItem10.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem11
            '
            Me.spreadsheetCommandBarButtonItem11.CommandName = "CutSelection"
            Me.spreadsheetCommandBarButtonItem11.Id = 21
            Me.spreadsheetCommandBarButtonItem11.Name = "spreadsheetCommandBarButtonItem11"
            Me.spreadsheetCommandBarButtonItem11.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarButtonItem12
            '
            Me.spreadsheetCommandBarButtonItem12.CommandName = "CopySelection"
            Me.spreadsheetCommandBarButtonItem12.Id = 22
            Me.spreadsheetCommandBarButtonItem12.Name = "spreadsheetCommandBarButtonItem12"
            Me.spreadsheetCommandBarButtonItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarButtonItem13
            '
            Me.spreadsheetCommandBarButtonItem13.CommandName = "ShowPasteSpecialForm"
            Me.spreadsheetCommandBarButtonItem13.Id = 23
            Me.spreadsheetCommandBarButtonItem13.Name = "spreadsheetCommandBarButtonItem13"
            Me.spreadsheetCommandBarButtonItem13.RibbonStyle = CType((DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText Or DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText), DevExpress.XtraBars.Ribbon.RibbonItemStyles)
            '
            'barButtonGroup1
            '
            Me.barButtonGroup1.Id = 10
            Me.barButtonGroup1.ItemLinks.Add(Me.changeFontNameItem1)
            Me.barButtonGroup1.ItemLinks.Add(Me.changeFontSizeItem1)
            Me.barButtonGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem14)
            Me.barButtonGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem15)
            Me.barButtonGroup1.Name = "barButtonGroup1"
            Me.barButtonGroup1.Tag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}"
            '
            'changeFontNameItem1
            '
            Me.changeFontNameItem1.Edit = Me.repositoryItemFontEdit1
            Me.changeFontNameItem1.Id = 24
            Me.changeFontNameItem1.Name = "changeFontNameItem1"
            '
            'repositoryItemFontEdit1
            '
            Me.repositoryItemFontEdit1.AutoHeight = False
            Me.repositoryItemFontEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
            Me.repositoryItemFontEdit1.Name = "repositoryItemFontEdit1"
            '
            'changeFontSizeItem1
            '
            Me.changeFontSizeItem1.Edit = Me.repositoryItemSpreadsheetFontSizeEdit1
            Me.changeFontSizeItem1.Id = 25
            Me.changeFontSizeItem1.Name = "changeFontSizeItem1"
            '
            'repositoryItemSpreadsheetFontSizeEdit1
            '
            Me.repositoryItemSpreadsheetFontSizeEdit1.AutoHeight = False
            Me.repositoryItemSpreadsheetFontSizeEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
            Me.repositoryItemSpreadsheetFontSizeEdit1.Control = Me.spreadsheetControl1
            Me.repositoryItemSpreadsheetFontSizeEdit1.Name = "repositoryItemSpreadsheetFontSizeEdit1"
            '
            'spreadsheetControl1
            '
            Me.spreadsheetControl1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.spreadsheetControl1.Location = New System.Drawing.Point(0, 235)
            Me.spreadsheetControl1.Margin = New System.Windows.Forms.Padding(4)
            Me.spreadsheetControl1.MenuManager = Me.ribbonControl1
            Me.spreadsheetControl1.Name = "spreadsheetControl1"
            Me.spreadsheetControl1.Size = New System.Drawing.Size(1148, 455)
            Me.spreadsheetControl1.TabIndex = 0
            Me.spreadsheetControl1.Text = "spreadsheetControl1"
            '
            'spreadsheetCommandBarButtonItem14
            '
            Me.spreadsheetCommandBarButtonItem14.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}"
            Me.spreadsheetCommandBarButtonItem14.CommandName = "FormatIncreaseFontSize"
            Me.spreadsheetCommandBarButtonItem14.Id = 26
            Me.spreadsheetCommandBarButtonItem14.Name = "spreadsheetCommandBarButtonItem14"
            Me.spreadsheetCommandBarButtonItem14.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarButtonItem15
            '
            Me.spreadsheetCommandBarButtonItem15.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}"
            Me.spreadsheetCommandBarButtonItem15.CommandName = "FormatDecreaseFontSize"
            Me.spreadsheetCommandBarButtonItem15.Id = 27
            Me.spreadsheetCommandBarButtonItem15.Name = "spreadsheetCommandBarButtonItem15"
            Me.spreadsheetCommandBarButtonItem15.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'barButtonGroup2
            '
            Me.barButtonGroup2.Id = 11
            Me.barButtonGroup2.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem1)
            Me.barButtonGroup2.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem2)
            Me.barButtonGroup2.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem3)
            Me.barButtonGroup2.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem4)
            Me.barButtonGroup2.Name = "barButtonGroup2"
            Me.barButtonGroup2.Tag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
            '
            'spreadsheetCommandBarCheckItem1
            '
            Me.spreadsheetCommandBarCheckItem1.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
            Me.spreadsheetCommandBarCheckItem1.CommandName = "FormatFontBold"
            Me.spreadsheetCommandBarCheckItem1.Id = 28
            Me.spreadsheetCommandBarCheckItem1.Name = "spreadsheetCommandBarCheckItem1"
            Me.spreadsheetCommandBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarCheckItem2
            '
            Me.spreadsheetCommandBarCheckItem2.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
            Me.spreadsheetCommandBarCheckItem2.CommandName = "FormatFontItalic"
            Me.spreadsheetCommandBarCheckItem2.Id = 29
            Me.spreadsheetCommandBarCheckItem2.Name = "spreadsheetCommandBarCheckItem2"
            Me.spreadsheetCommandBarCheckItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarCheckItem3
            '
            Me.spreadsheetCommandBarCheckItem3.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
            Me.spreadsheetCommandBarCheckItem3.CommandName = "FormatFontUnderline"
            Me.spreadsheetCommandBarCheckItem3.Id = 30
            Me.spreadsheetCommandBarCheckItem3.Name = "spreadsheetCommandBarCheckItem3"
            Me.spreadsheetCommandBarCheckItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarCheckItem4
            '
            Me.spreadsheetCommandBarCheckItem4.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
            Me.spreadsheetCommandBarCheckItem4.CommandName = "FormatFontStrikeout"
            Me.spreadsheetCommandBarCheckItem4.Id = 31
            Me.spreadsheetCommandBarCheckItem4.Name = "spreadsheetCommandBarCheckItem4"
            Me.spreadsheetCommandBarCheckItem4.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'barButtonGroup3
            '
            Me.barButtonGroup3.Id = 12
            Me.barButtonGroup3.ItemLinks.Add(Me.spreadsheetCommandBarSubItem1)
            Me.barButtonGroup3.Name = "barButtonGroup3"
            Me.barButtonGroup3.Tag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}"
            '
            'spreadsheetCommandBarSubItem1
            '
            Me.spreadsheetCommandBarSubItem1.ButtonGroupTag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}"
            Me.spreadsheetCommandBarSubItem1.CommandName = "FormatBordersCommandGroup"
            Me.spreadsheetCommandBarSubItem1.Id = 32
            Me.spreadsheetCommandBarSubItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem16), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem17), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem18), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem19), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem20), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem21), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem22), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem23), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem24), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem25), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem26), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem27), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem28), New DevExpress.XtraBars.LinkPersistInfo(Me.changeBorderLineColorItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.changeBorderLineStyleItem1)})
            Me.spreadsheetCommandBarSubItem1.Name = "spreadsheetCommandBarSubItem1"
            Me.spreadsheetCommandBarSubItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarButtonItem16
            '
            Me.spreadsheetCommandBarButtonItem16.CommandName = "FormatBottomBorder"
            Me.spreadsheetCommandBarButtonItem16.Id = 33
            Me.spreadsheetCommandBarButtonItem16.Name = "spreadsheetCommandBarButtonItem16"
            '
            'spreadsheetCommandBarButtonItem17
            '
            Me.spreadsheetCommandBarButtonItem17.CommandName = "FormatTopBorder"
            Me.spreadsheetCommandBarButtonItem17.Id = 34
            Me.spreadsheetCommandBarButtonItem17.Name = "spreadsheetCommandBarButtonItem17"
            '
            'spreadsheetCommandBarButtonItem18
            '
            Me.spreadsheetCommandBarButtonItem18.CommandName = "FormatLeftBorder"
            Me.spreadsheetCommandBarButtonItem18.Id = 35
            Me.spreadsheetCommandBarButtonItem18.Name = "spreadsheetCommandBarButtonItem18"
            '
            'spreadsheetCommandBarButtonItem19
            '
            Me.spreadsheetCommandBarButtonItem19.CommandName = "FormatRightBorder"
            Me.spreadsheetCommandBarButtonItem19.Id = 36
            Me.spreadsheetCommandBarButtonItem19.Name = "spreadsheetCommandBarButtonItem19"
            '
            'spreadsheetCommandBarButtonItem20
            '
            Me.spreadsheetCommandBarButtonItem20.CommandName = "FormatNoBorders"
            Me.spreadsheetCommandBarButtonItem20.Id = 37
            Me.spreadsheetCommandBarButtonItem20.Name = "spreadsheetCommandBarButtonItem20"
            '
            'spreadsheetCommandBarButtonItem21
            '
            Me.spreadsheetCommandBarButtonItem21.CommandName = "FormatAllBorders"
            Me.spreadsheetCommandBarButtonItem21.Id = 38
            Me.spreadsheetCommandBarButtonItem21.Name = "spreadsheetCommandBarButtonItem21"
            '
            'spreadsheetCommandBarButtonItem22
            '
            Me.spreadsheetCommandBarButtonItem22.CommandName = "FormatOutsideBorders"
            Me.spreadsheetCommandBarButtonItem22.Id = 39
            Me.spreadsheetCommandBarButtonItem22.Name = "spreadsheetCommandBarButtonItem22"
            '
            'spreadsheetCommandBarButtonItem23
            '
            Me.spreadsheetCommandBarButtonItem23.CommandName = "FormatThickBorder"
            Me.spreadsheetCommandBarButtonItem23.Id = 40
            Me.spreadsheetCommandBarButtonItem23.Name = "spreadsheetCommandBarButtonItem23"
            '
            'spreadsheetCommandBarButtonItem24
            '
            Me.spreadsheetCommandBarButtonItem24.CommandName = "FormatBottomDoubleBorder"
            Me.spreadsheetCommandBarButtonItem24.Id = 41
            Me.spreadsheetCommandBarButtonItem24.Name = "spreadsheetCommandBarButtonItem24"
            '
            'spreadsheetCommandBarButtonItem25
            '
            Me.spreadsheetCommandBarButtonItem25.CommandName = "FormatBottomThickBorder"
            Me.spreadsheetCommandBarButtonItem25.Id = 42
            Me.spreadsheetCommandBarButtonItem25.Name = "spreadsheetCommandBarButtonItem25"
            '
            'spreadsheetCommandBarButtonItem26
            '
            Me.spreadsheetCommandBarButtonItem26.CommandName = "FormatTopAndBottomBorder"
            Me.spreadsheetCommandBarButtonItem26.Id = 43
            Me.spreadsheetCommandBarButtonItem26.Name = "spreadsheetCommandBarButtonItem26"
            '
            'spreadsheetCommandBarButtonItem27
            '
            Me.spreadsheetCommandBarButtonItem27.CommandName = "FormatTopAndThickBottomBorder"
            Me.spreadsheetCommandBarButtonItem27.Id = 44
            Me.spreadsheetCommandBarButtonItem27.Name = "spreadsheetCommandBarButtonItem27"
            '
            'spreadsheetCommandBarButtonItem28
            '
            Me.spreadsheetCommandBarButtonItem28.CommandName = "FormatTopAndDoubleBottomBorder"
            Me.spreadsheetCommandBarButtonItem28.Id = 45
            Me.spreadsheetCommandBarButtonItem28.Name = "spreadsheetCommandBarButtonItem28"
            '
            'changeBorderLineColorItem1
            '
            Me.changeBorderLineColorItem1.ActAsDropDown = True
            Me.changeBorderLineColorItem1.Id = 46
            Me.changeBorderLineColorItem1.Name = "changeBorderLineColorItem1"
            '
            'changeBorderLineStyleItem1
            '
            Me.changeBorderLineStyleItem1.DropDownControl = Me.commandBarGalleryDropDown1
            Me.changeBorderLineStyleItem1.Id = 47
            Me.changeBorderLineStyleItem1.Name = "changeBorderLineStyleItem1"
            '
            'commandBarGalleryDropDown1
            '
            '
            '
            '
            Me.commandBarGalleryDropDown1.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown1.Gallery.ColumnCount = 1
            Me.commandBarGalleryDropDown1.Gallery.DrawImageBackground = False
            Me.commandBarGalleryDropDown1.Gallery.ImageSize = New System.Drawing.Size(65, 46)
            Me.commandBarGalleryDropDown1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
            Me.commandBarGalleryDropDown1.Gallery.ItemSize = New System.Drawing.Size(170, 32)
            Me.commandBarGalleryDropDown1.Gallery.RowCount = 14
            Me.commandBarGalleryDropDown1.Gallery.ShowGroupCaption = False
            Me.commandBarGalleryDropDown1.Gallery.ShowItemText = True
            Me.commandBarGalleryDropDown1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown1.Name = "commandBarGalleryDropDown1"
            Me.commandBarGalleryDropDown1.Ribbon = Me.ribbonControl1
            '
            'barButtonGroup4
            '
            Me.barButtonGroup4.Id = 13
            Me.barButtonGroup4.ItemLinks.Add(Me.changeCellFillColorItem1)
            Me.barButtonGroup4.ItemLinks.Add(Me.changeFontColorItem1)
            Me.barButtonGroup4.Name = "barButtonGroup4"
            Me.barButtonGroup4.Tag = "{C2275623-04A3-41E8-8D6A-EB5C7F8541D1}"
            '
            'changeCellFillColorItem1
            '
            Me.changeCellFillColorItem1.Id = 48
            Me.changeCellFillColorItem1.Name = "changeCellFillColorItem1"
            '
            'changeFontColorItem1
            '
            Me.changeFontColorItem1.Id = 49
            Me.changeFontColorItem1.Name = "changeFontColorItem1"
            '
            'barButtonGroup5
            '
            Me.barButtonGroup5.Id = 14
            Me.barButtonGroup5.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem5)
            Me.barButtonGroup5.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem6)
            Me.barButtonGroup5.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem7)
            Me.barButtonGroup5.Name = "barButtonGroup5"
            Me.barButtonGroup5.Tag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
            '
            'spreadsheetCommandBarCheckItem5
            '
            Me.spreadsheetCommandBarCheckItem5.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
            Me.spreadsheetCommandBarCheckItem5.CommandName = "FormatAlignmentTop"
            Me.spreadsheetCommandBarCheckItem5.Id = 50
            Me.spreadsheetCommandBarCheckItem5.Name = "spreadsheetCommandBarCheckItem5"
            Me.spreadsheetCommandBarCheckItem5.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarCheckItem6
            '
            Me.spreadsheetCommandBarCheckItem6.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
            Me.spreadsheetCommandBarCheckItem6.CommandName = "FormatAlignmentMiddle"
            Me.spreadsheetCommandBarCheckItem6.Id = 51
            Me.spreadsheetCommandBarCheckItem6.Name = "spreadsheetCommandBarCheckItem6"
            Me.spreadsheetCommandBarCheckItem6.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarCheckItem7
            '
            Me.spreadsheetCommandBarCheckItem7.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
            Me.spreadsheetCommandBarCheckItem7.CommandName = "FormatAlignmentBottom"
            Me.spreadsheetCommandBarCheckItem7.Id = 52
            Me.spreadsheetCommandBarCheckItem7.Name = "spreadsheetCommandBarCheckItem7"
            Me.spreadsheetCommandBarCheckItem7.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'barButtonGroup6
            '
            Me.barButtonGroup6.Id = 15
            Me.barButtonGroup6.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem8)
            Me.barButtonGroup6.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem9)
            Me.barButtonGroup6.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem10)
            Me.barButtonGroup6.Name = "barButtonGroup6"
            Me.barButtonGroup6.Tag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
            '
            'spreadsheetCommandBarCheckItem8
            '
            Me.spreadsheetCommandBarCheckItem8.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
            Me.spreadsheetCommandBarCheckItem8.CommandName = "FormatAlignmentLeft"
            Me.spreadsheetCommandBarCheckItem8.Id = 53
            Me.spreadsheetCommandBarCheckItem8.Name = "spreadsheetCommandBarCheckItem8"
            Me.spreadsheetCommandBarCheckItem8.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarCheckItem9
            '
            Me.spreadsheetCommandBarCheckItem9.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
            Me.spreadsheetCommandBarCheckItem9.CommandName = "FormatAlignmentCenter"
            Me.spreadsheetCommandBarCheckItem9.Id = 54
            Me.spreadsheetCommandBarCheckItem9.Name = "spreadsheetCommandBarCheckItem9"
            Me.spreadsheetCommandBarCheckItem9.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarCheckItem10
            '
            Me.spreadsheetCommandBarCheckItem10.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
            Me.spreadsheetCommandBarCheckItem10.CommandName = "FormatAlignmentRight"
            Me.spreadsheetCommandBarCheckItem10.Id = 55
            Me.spreadsheetCommandBarCheckItem10.Name = "spreadsheetCommandBarCheckItem10"
            Me.spreadsheetCommandBarCheckItem10.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'barButtonGroup7
            '
            Me.barButtonGroup7.Id = 16
            Me.barButtonGroup7.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem29)
            Me.barButtonGroup7.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem30)
            Me.barButtonGroup7.Name = "barButtonGroup7"
            Me.barButtonGroup7.Tag = "{A5E37DED-106E-44FC-8044-CE3824C08225}"
            '
            'spreadsheetCommandBarButtonItem29
            '
            Me.spreadsheetCommandBarButtonItem29.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}"
            Me.spreadsheetCommandBarButtonItem29.CommandName = "FormatDecreaseIndent"
            Me.spreadsheetCommandBarButtonItem29.Id = 56
            Me.spreadsheetCommandBarButtonItem29.Name = "spreadsheetCommandBarButtonItem29"
            Me.spreadsheetCommandBarButtonItem29.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarButtonItem30
            '
            Me.spreadsheetCommandBarButtonItem30.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}"
            Me.spreadsheetCommandBarButtonItem30.CommandName = "FormatIncreaseIndent"
            Me.spreadsheetCommandBarButtonItem30.Id = 57
            Me.spreadsheetCommandBarButtonItem30.Name = "spreadsheetCommandBarButtonItem30"
            Me.spreadsheetCommandBarButtonItem30.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarCheckItem11
            '
            Me.spreadsheetCommandBarCheckItem11.CommandName = "FormatWrapText"
            Me.spreadsheetCommandBarCheckItem11.Id = 58
            Me.spreadsheetCommandBarCheckItem11.Name = "spreadsheetCommandBarCheckItem11"
            Me.spreadsheetCommandBarCheckItem11.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarSubItem2
            '
            Me.spreadsheetCommandBarSubItem2.CommandName = "EditingMergeCellsCommandGroup"
            Me.spreadsheetCommandBarSubItem2.Id = 59
            Me.spreadsheetCommandBarSubItem2.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem12), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem31), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem32), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem33)})
            Me.spreadsheetCommandBarSubItem2.Name = "spreadsheetCommandBarSubItem2"
            Me.spreadsheetCommandBarSubItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarCheckItem12
            '
            Me.spreadsheetCommandBarCheckItem12.CommandName = "EditingMergeAndCenterCells"
            Me.spreadsheetCommandBarCheckItem12.Id = 60
            Me.spreadsheetCommandBarCheckItem12.Name = "spreadsheetCommandBarCheckItem12"
            '
            'spreadsheetCommandBarButtonItem31
            '
            Me.spreadsheetCommandBarButtonItem31.CommandName = "EditingMergeCellsAcross"
            Me.spreadsheetCommandBarButtonItem31.Id = 61
            Me.spreadsheetCommandBarButtonItem31.Name = "spreadsheetCommandBarButtonItem31"
            '
            'spreadsheetCommandBarButtonItem32
            '
            Me.spreadsheetCommandBarButtonItem32.CommandName = "EditingMergeCells"
            Me.spreadsheetCommandBarButtonItem32.Id = 62
            Me.spreadsheetCommandBarButtonItem32.Name = "spreadsheetCommandBarButtonItem32"
            '
            'spreadsheetCommandBarButtonItem33
            '
            Me.spreadsheetCommandBarButtonItem33.CommandName = "EditingUnmergeCells"
            Me.spreadsheetCommandBarButtonItem33.Id = 63
            Me.spreadsheetCommandBarButtonItem33.Name = "spreadsheetCommandBarButtonItem33"
            '
            'barButtonGroup8
            '
            Me.barButtonGroup8.Id = 17
            Me.barButtonGroup8.ItemLinks.Add(Me.changeNumberFormatItem1)
            Me.barButtonGroup8.Name = "barButtonGroup8"
            Me.barButtonGroup8.Tag = "{0B3A7A43-3079-4ce0-83A8-3789F5F6DC9F}"
            '
            'changeNumberFormatItem1
            '
            Me.changeNumberFormatItem1.Edit = Me.repositoryItemPopupGalleryEdit1
            Me.changeNumberFormatItem1.Id = 64
            Me.changeNumberFormatItem1.Name = "changeNumberFormatItem1"
            '
            'repositoryItemPopupGalleryEdit1
            '
            Me.repositoryItemPopupGalleryEdit1.AutoHeight = False
            Me.repositoryItemPopupGalleryEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
            '
            '
            '
            Me.repositoryItemPopupGalleryEdit1.Gallery.AllowFilter = False
            Me.repositoryItemPopupGalleryEdit1.Gallery.AutoFitColumns = False
            Me.repositoryItemPopupGalleryEdit1.Gallery.ColumnCount = 1
            Me.repositoryItemPopupGalleryEdit1.Gallery.FixedImageSize = False
            SpreadsheetCommandGalleryItem13.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem13.CaptionAsValue = True
            SpreadsheetCommandGalleryItem13.Checked = True
            SpreadsheetCommandGalleryItem13.CommandName = "FormatNumberGeneral"
            SpreadsheetCommandGalleryItem13.IsEmptyHint = True
            SpreadsheetCommandGalleryItem14.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem14.CaptionAsValue = True
            SpreadsheetCommandGalleryItem14.CommandName = "FormatNumberDecimal"
            SpreadsheetCommandGalleryItem14.IsEmptyHint = True
            SpreadsheetCommandGalleryItem15.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem15.CaptionAsValue = True
            SpreadsheetCommandGalleryItem15.CommandName = "FormatNumberAccountingCurrency"
            SpreadsheetCommandGalleryItem15.IsEmptyHint = True
            SpreadsheetCommandGalleryItem16.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem16.CaptionAsValue = True
            SpreadsheetCommandGalleryItem16.CommandName = "FormatNumberAccountingRegular"
            SpreadsheetCommandGalleryItem16.IsEmptyHint = True
            SpreadsheetCommandGalleryItem17.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem17.CaptionAsValue = True
            SpreadsheetCommandGalleryItem17.CommandName = "FormatNumberShortDate"
            SpreadsheetCommandGalleryItem17.IsEmptyHint = True
            SpreadsheetCommandGalleryItem18.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem18.CaptionAsValue = True
            SpreadsheetCommandGalleryItem18.CommandName = "FormatNumberLongDate"
            SpreadsheetCommandGalleryItem18.IsEmptyHint = True
            SpreadsheetCommandGalleryItem19.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem19.CaptionAsValue = True
            SpreadsheetCommandGalleryItem19.CommandName = "FormatNumberTime"
            SpreadsheetCommandGalleryItem19.IsEmptyHint = True
            SpreadsheetCommandGalleryItem20.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem20.CaptionAsValue = True
            SpreadsheetCommandGalleryItem20.CommandName = "FormatNumberPercentage"
            SpreadsheetCommandGalleryItem20.IsEmptyHint = True
            SpreadsheetCommandGalleryItem21.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem21.CaptionAsValue = True
            SpreadsheetCommandGalleryItem21.CommandName = "FormatNumberFraction"
            SpreadsheetCommandGalleryItem21.IsEmptyHint = True
            SpreadsheetCommandGalleryItem22.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem22.CaptionAsValue = True
            SpreadsheetCommandGalleryItem22.CommandName = "FormatNumberScientific"
            SpreadsheetCommandGalleryItem22.IsEmptyHint = True
            SpreadsheetCommandGalleryItem23.AlwaysUpdateDescription = True
            SpreadsheetCommandGalleryItem23.CaptionAsValue = True
            SpreadsheetCommandGalleryItem23.CommandName = "FormatNumberText"
            SpreadsheetCommandGalleryItem23.IsEmptyHint = True
            GalleryItemGroup1.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem13, SpreadsheetCommandGalleryItem14, SpreadsheetCommandGalleryItem15, SpreadsheetCommandGalleryItem16, SpreadsheetCommandGalleryItem17, SpreadsheetCommandGalleryItem18, SpreadsheetCommandGalleryItem19, SpreadsheetCommandGalleryItem20, SpreadsheetCommandGalleryItem21, SpreadsheetCommandGalleryItem22, SpreadsheetCommandGalleryItem23})
            Me.repositoryItemPopupGalleryEdit1.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {GalleryItemGroup1})
            Me.repositoryItemPopupGalleryEdit1.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.repositoryItemPopupGalleryEdit1.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.repositoryItemPopupGalleryEdit1.Gallery.RowCount = 11
            Me.repositoryItemPopupGalleryEdit1.Gallery.ShowGroupCaption = False
            Me.repositoryItemPopupGalleryEdit1.Gallery.ShowItemText = True
            Me.repositoryItemPopupGalleryEdit1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Hide
            Me.repositoryItemPopupGalleryEdit1.Gallery.StretchItems = True
            Me.repositoryItemPopupGalleryEdit1.Name = "repositoryItemPopupGalleryEdit1"
            Me.repositoryItemPopupGalleryEdit1.ShowButtons = False
            Me.repositoryItemPopupGalleryEdit1.ShowPopupCloseButton = False
            Me.repositoryItemPopupGalleryEdit1.ShowSizeGrip = False
            '
            'barButtonGroup9
            '
            Me.barButtonGroup9.Id = 18
            Me.barButtonGroup9.ItemLinks.Add(Me.spreadsheetCommandBarSubItem3)
            Me.barButtonGroup9.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem39)
            Me.barButtonGroup9.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem40)
            Me.barButtonGroup9.Name = "barButtonGroup9"
            Me.barButtonGroup9.Tag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
            '
            'spreadsheetCommandBarSubItem3
            '
            Me.spreadsheetCommandBarSubItem3.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
            Me.spreadsheetCommandBarSubItem3.CommandName = "FormatNumberAccountingCommandGroup"
            Me.spreadsheetCommandBarSubItem3.Id = 65
            Me.spreadsheetCommandBarSubItem3.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem34), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem35), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem36), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem37), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem38), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem119)})
            Me.spreadsheetCommandBarSubItem3.Name = "spreadsheetCommandBarSubItem3"
            Me.spreadsheetCommandBarSubItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarButtonItem34
            '
            Me.spreadsheetCommandBarButtonItem34.CommandName = "FormatNumberAccountingUS"
            Me.spreadsheetCommandBarButtonItem34.Id = 66
            Me.spreadsheetCommandBarButtonItem34.Name = "spreadsheetCommandBarButtonItem34"
            '
            'spreadsheetCommandBarButtonItem35
            '
            Me.spreadsheetCommandBarButtonItem35.CommandName = "FormatNumberAccountingUK"
            Me.spreadsheetCommandBarButtonItem35.Id = 67
            Me.spreadsheetCommandBarButtonItem35.Name = "spreadsheetCommandBarButtonItem35"
            '
            'spreadsheetCommandBarButtonItem36
            '
            Me.spreadsheetCommandBarButtonItem36.CommandName = "FormatNumberAccountingEuro"
            Me.spreadsheetCommandBarButtonItem36.Id = 68
            Me.spreadsheetCommandBarButtonItem36.Name = "spreadsheetCommandBarButtonItem36"
            '
            'spreadsheetCommandBarButtonItem37
            '
            Me.spreadsheetCommandBarButtonItem37.CommandName = "FormatNumberAccountingPRC"
            Me.spreadsheetCommandBarButtonItem37.Id = 69
            Me.spreadsheetCommandBarButtonItem37.Name = "spreadsheetCommandBarButtonItem37"
            '
            'spreadsheetCommandBarButtonItem38
            '
            Me.spreadsheetCommandBarButtonItem38.CommandName = "FormatNumberAccountingSwiss"
            Me.spreadsheetCommandBarButtonItem38.Id = 70
            Me.spreadsheetCommandBarButtonItem38.Name = "spreadsheetCommandBarButtonItem38"
            '
            'SpreadsheetCommandBarButtonItem119
            '
            Me.SpreadsheetCommandBarButtonItem119.CommandName = "FormatNumberAccountingDefault"
            Me.SpreadsheetCommandBarButtonItem119.Id = 236
            Me.SpreadsheetCommandBarButtonItem119.Name = "SpreadsheetCommandBarButtonItem119"
            '
            'spreadsheetCommandBarButtonItem39
            '
            Me.spreadsheetCommandBarButtonItem39.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
            Me.spreadsheetCommandBarButtonItem39.CommandName = "FormatNumberPercent"
            Me.spreadsheetCommandBarButtonItem39.Id = 71
            Me.spreadsheetCommandBarButtonItem39.Name = "spreadsheetCommandBarButtonItem39"
            Me.spreadsheetCommandBarButtonItem39.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarButtonItem40
            '
            Me.spreadsheetCommandBarButtonItem40.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
            Me.spreadsheetCommandBarButtonItem40.CommandName = "FormatNumberAccounting"
            Me.spreadsheetCommandBarButtonItem40.Id = 72
            Me.spreadsheetCommandBarButtonItem40.Name = "spreadsheetCommandBarButtonItem40"
            Me.spreadsheetCommandBarButtonItem40.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'barButtonGroup10
            '
            Me.barButtonGroup10.Id = 19
            Me.barButtonGroup10.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem41)
            Me.barButtonGroup10.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem42)
            Me.barButtonGroup10.Name = "barButtonGroup10"
            Me.barButtonGroup10.Tag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}"
            '
            'spreadsheetCommandBarButtonItem41
            '
            Me.spreadsheetCommandBarButtonItem41.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}"
            Me.spreadsheetCommandBarButtonItem41.CommandName = "FormatNumberIncreaseDecimal"
            Me.spreadsheetCommandBarButtonItem41.Id = 73
            Me.spreadsheetCommandBarButtonItem41.Name = "spreadsheetCommandBarButtonItem41"
            Me.spreadsheetCommandBarButtonItem41.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarButtonItem42
            '
            Me.spreadsheetCommandBarButtonItem42.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}"
            Me.spreadsheetCommandBarButtonItem42.CommandName = "FormatNumberDecreaseDecimal"
            Me.spreadsheetCommandBarButtonItem42.Id = 74
            Me.spreadsheetCommandBarButtonItem42.Name = "spreadsheetCommandBarButtonItem42"
            Me.spreadsheetCommandBarButtonItem42.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem2
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem2.CommandName = "ConditionalFormattingColorScalesCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem2.DropDownControl = Me.commandBarGalleryDropDown3
            Me.spreadsheetCommandBarButtonGalleryDropDownItem2.Id = 92
            Me.spreadsheetCommandBarButtonGalleryDropDownItem2.Name = "spreadsheetCommandBarButtonGalleryDropDownItem2"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'commandBarGalleryDropDown3
            '
            '
            '
            '
            Me.commandBarGalleryDropDown3.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup3.CommandName = "ConditionalFormattingColorScalesCommandGroup"
            SpreadsheetCommandGalleryItem24.CommandName = "ConditionalFormattingColorScaleGreenYellowRed"
            SpreadsheetCommandGalleryItem25.CommandName = "ConditionalFormattingColorScaleRedYellowGreen"
            SpreadsheetCommandGalleryItem26.CommandName = "ConditionalFormattingColorScaleGreenWhiteRed"
            SpreadsheetCommandGalleryItem27.CommandName = "ConditionalFormattingColorScaleRedWhiteGreen"
            SpreadsheetCommandGalleryItem28.CommandName = "ConditionalFormattingColorScaleBlueWhiteRed"
            SpreadsheetCommandGalleryItem29.CommandName = "ConditionalFormattingColorScaleRedWhiteBlue"
            SpreadsheetCommandGalleryItem30.CommandName = "ConditionalFormattingColorScaleWhiteRed"
            SpreadsheetCommandGalleryItem31.CommandName = "ConditionalFormattingColorScaleRedWhite"
            SpreadsheetCommandGalleryItem32.CommandName = "ConditionalFormattingColorScaleGreenWhite"
            SpreadsheetCommandGalleryItem33.CommandName = "ConditionalFormattingColorScaleWhiteGreen"
            SpreadsheetCommandGalleryItem34.CommandName = "ConditionalFormattingColorScaleGreenYellow"
            SpreadsheetCommandGalleryItem35.CommandName = "ConditionalFormattingColorScaleYellowGreen"
            SpreadsheetCommandGalleryItemGroup3.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem24, SpreadsheetCommandGalleryItem25, SpreadsheetCommandGalleryItem26, SpreadsheetCommandGalleryItem27, SpreadsheetCommandGalleryItem28, SpreadsheetCommandGalleryItem29, SpreadsheetCommandGalleryItem30, SpreadsheetCommandGalleryItem31, SpreadsheetCommandGalleryItem32, SpreadsheetCommandGalleryItem33, SpreadsheetCommandGalleryItem34, SpreadsheetCommandGalleryItem35})
            Me.commandBarGalleryDropDown3.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup3})
            Me.commandBarGalleryDropDown3.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown3.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown3.Name = "commandBarGalleryDropDown3"
            Me.commandBarGalleryDropDown3.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem3
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem3.CommandName = "ConditionalFormattingIconSetsCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem3.DropDownControl = Me.commandBarGalleryDropDown4
            Me.spreadsheetCommandBarButtonGalleryDropDownItem3.Id = 93
            Me.spreadsheetCommandBarButtonGalleryDropDownItem3.Name = "spreadsheetCommandBarButtonGalleryDropDownItem3"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'commandBarGalleryDropDown4
            '
            '
            '
            '
            Me.commandBarGalleryDropDown4.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup4.CommandName = "ConditionalFormattingIconSetsDirectionalCommandGroup"
            SpreadsheetCommandGalleryItem36.CommandName = "ConditionalFormattingIconSetArrows3Colored"
            SpreadsheetCommandGalleryItem37.CommandName = "ConditionalFormattingIconSetArrows3Grayed"
            SpreadsheetCommandGalleryItem38.CommandName = "ConditionalFormattingIconSetArrows4Colored"
            SpreadsheetCommandGalleryItem39.CommandName = "ConditionalFormattingIconSetArrows4Grayed"
            SpreadsheetCommandGalleryItem40.CommandName = "ConditionalFormattingIconSetArrows5Colored"
            SpreadsheetCommandGalleryItem41.CommandName = "ConditionalFormattingIconSetArrows5Grayed"
            SpreadsheetCommandGalleryItem42.CommandName = "ConditionalFormattingIconSetTriangles3"
            SpreadsheetCommandGalleryItemGroup4.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem36, SpreadsheetCommandGalleryItem37, SpreadsheetCommandGalleryItem38, SpreadsheetCommandGalleryItem39, SpreadsheetCommandGalleryItem40, SpreadsheetCommandGalleryItem41, SpreadsheetCommandGalleryItem42})
            SpreadsheetCommandGalleryItemGroup5.CommandName = "ConditionalFormattingIconSetsShapesCommandGroup"
            SpreadsheetCommandGalleryItem43.CommandName = "ConditionalFormattingIconSetTrafficLights3"
            SpreadsheetCommandGalleryItem44.CommandName = "ConditionalFormattingIconSetTrafficLights3Rimmed"
            SpreadsheetCommandGalleryItem45.CommandName = "ConditionalFormattingIconSetTrafficLights4"
            SpreadsheetCommandGalleryItem46.CommandName = "ConditionalFormattingIconSetSigns3"
            SpreadsheetCommandGalleryItem47.CommandName = "ConditionalFormattingIconSetRedToBlack"
            SpreadsheetCommandGalleryItemGroup5.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem43, SpreadsheetCommandGalleryItem44, SpreadsheetCommandGalleryItem45, SpreadsheetCommandGalleryItem46, SpreadsheetCommandGalleryItem47})
            SpreadsheetCommandGalleryItemGroup6.CommandName = "ConditionalFormattingIconSetsIndicatorsCommandGroup"
            SpreadsheetCommandGalleryItem48.CommandName = "ConditionalFormattingIconSetSymbols3Circled"
            SpreadsheetCommandGalleryItem49.CommandName = "ConditionalFormattingIconSetSymbols3"
            SpreadsheetCommandGalleryItem50.CommandName = "ConditionalFormattingIconSetFlags3"
            SpreadsheetCommandGalleryItemGroup6.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem48, SpreadsheetCommandGalleryItem49, SpreadsheetCommandGalleryItem50})
            SpreadsheetCommandGalleryItemGroup7.CommandName = "ConditionalFormattingIconSetsRatingsCommandGroup"
            SpreadsheetCommandGalleryItem51.CommandName = "ConditionalFormattingIconSetStars3"
            SpreadsheetCommandGalleryItem52.CommandName = "ConditionalFormattingIconSetRatings4"
            SpreadsheetCommandGalleryItem53.CommandName = "ConditionalFormattingIconSetRatings5"
            SpreadsheetCommandGalleryItem54.CommandName = "ConditionalFormattingIconSetQuarters5"
            SpreadsheetCommandGalleryItem55.CommandName = "ConditionalFormattingIconSetBoxes5"
            SpreadsheetCommandGalleryItemGroup7.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem51, SpreadsheetCommandGalleryItem52, SpreadsheetCommandGalleryItem53, SpreadsheetCommandGalleryItem54, SpreadsheetCommandGalleryItem55})
            Me.commandBarGalleryDropDown4.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup4, SpreadsheetCommandGalleryItemGroup5, SpreadsheetCommandGalleryItemGroup6, SpreadsheetCommandGalleryItemGroup7})
            Me.commandBarGalleryDropDown4.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown4.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown4.Name = "commandBarGalleryDropDown4"
            Me.commandBarGalleryDropDown4.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonItem56
            '
            Me.spreadsheetCommandBarButtonItem56.CommandName = "ConditionalFormattingRemoveFromSheet"
            Me.spreadsheetCommandBarButtonItem56.Id = 94
            Me.spreadsheetCommandBarButtonItem56.Name = "spreadsheetCommandBarButtonItem56"
            '
            'spreadsheetCommandBarButtonItem57
            '
            Me.spreadsheetCommandBarButtonItem57.CommandName = "ConditionalFormattingRemove"
            Me.spreadsheetCommandBarButtonItem57.Id = 95
            Me.spreadsheetCommandBarButtonItem57.Name = "spreadsheetCommandBarButtonItem57"
            '
            'spreadsheetCommandBarSubItem7
            '
            Me.spreadsheetCommandBarSubItem7.CommandName = "ConditionalFormattingRemoveCommandGroup"
            Me.spreadsheetCommandBarSubItem7.Id = 96
            Me.spreadsheetCommandBarSubItem7.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem56), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem57)})
            Me.spreadsheetCommandBarSubItem7.Name = "spreadsheetCommandBarSubItem7"
            '
            'galleryFormatAsTableItem1
            '
            Me.galleryFormatAsTableItem1.DropDownControl = Me.commandBarGalleryDropDown5
            Me.galleryFormatAsTableItem1.Id = 97
            Me.galleryFormatAsTableItem1.Name = "galleryFormatAsTableItem1"
            '
            'commandBarGalleryDropDown5
            '
            '
            '
            '
            Me.commandBarGalleryDropDown5.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown5.Gallery.ColumnCount = 7
            Me.commandBarGalleryDropDown5.Gallery.DrawImageBackground = False
            Me.commandBarGalleryDropDown5.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
            Me.commandBarGalleryDropDown5.Gallery.ItemSize = New System.Drawing.Size(401, 339)
            Me.commandBarGalleryDropDown5.Gallery.RowCount = 10
            Me.commandBarGalleryDropDown5.Name = "commandBarGalleryDropDown5"
            Me.commandBarGalleryDropDown5.Ribbon = Me.ribbonControl1
            '
            'galleryChangeStyleItem1
            '
            '
            '
            '
            Me.galleryChangeStyleItem1.Gallery.DrawImageBackground = False
            Me.galleryChangeStyleItem1.Gallery.ImageSize = New System.Drawing.Size(362, 271)
            Me.galleryChangeStyleItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
            Me.galleryChangeStyleItem1.Gallery.ItemSize = New System.Drawing.Size(586, 157)
            Me.galleryChangeStyleItem1.Gallery.RowCount = 9
            Me.galleryChangeStyleItem1.Gallery.ShowItemText = True
            Me.galleryChangeStyleItem1.Id = 98
            Me.galleryChangeStyleItem1.Name = "galleryChangeStyleItem1"
            '
            'spreadsheetCommandBarSubItem8
            '
            Me.spreadsheetCommandBarSubItem8.CommandName = "InsertCellsCommandGroup"
            Me.spreadsheetCommandBarSubItem8.Id = 99
            Me.spreadsheetCommandBarSubItem8.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem58), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem59), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem60), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem122), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem123), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem124), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem125), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem126)})
            Me.spreadsheetCommandBarSubItem8.Name = "spreadsheetCommandBarSubItem8"
            '
            'spreadsheetCommandBarButtonItem58
            '
            Me.spreadsheetCommandBarButtonItem58.CommandName = "InsertSheetRows"
            Me.spreadsheetCommandBarButtonItem58.Id = 100
            Me.spreadsheetCommandBarButtonItem58.Name = "spreadsheetCommandBarButtonItem58"
            '
            'spreadsheetCommandBarButtonItem59
            '
            Me.spreadsheetCommandBarButtonItem59.CommandName = "InsertSheetColumns"
            Me.spreadsheetCommandBarButtonItem59.Id = 101
            Me.spreadsheetCommandBarButtonItem59.Name = "spreadsheetCommandBarButtonItem59"
            '
            'spreadsheetCommandBarButtonItem60
            '
            Me.spreadsheetCommandBarButtonItem60.CommandName = "InsertSheet"
            Me.spreadsheetCommandBarButtonItem60.Id = 102
            Me.spreadsheetCommandBarButtonItem60.Name = "spreadsheetCommandBarButtonItem60"
            '
            'SpreadsheetCommandBarButtonItem122
            '
            Me.SpreadsheetCommandBarButtonItem122.CommandName = "InsertCells"
            Me.SpreadsheetCommandBarButtonItem122.Id = 239
            Me.SpreadsheetCommandBarButtonItem122.Name = "SpreadsheetCommandBarButtonItem122"
            '
            'SpreadsheetCommandBarButtonItem123
            '
            Me.SpreadsheetCommandBarButtonItem123.CommandName = "InsertTableRowsAbove"
            Me.SpreadsheetCommandBarButtonItem123.Id = 240
            Me.SpreadsheetCommandBarButtonItem123.Name = "SpreadsheetCommandBarButtonItem123"
            '
            'SpreadsheetCommandBarButtonItem124
            '
            Me.SpreadsheetCommandBarButtonItem124.CommandName = "InsertTableRowBelow"
            Me.SpreadsheetCommandBarButtonItem124.Id = 241
            Me.SpreadsheetCommandBarButtonItem124.Name = "SpreadsheetCommandBarButtonItem124"
            '
            'SpreadsheetCommandBarButtonItem125
            '
            Me.SpreadsheetCommandBarButtonItem125.CommandName = "InsertTableColumnsToTheLeft"
            Me.SpreadsheetCommandBarButtonItem125.Id = 242
            Me.SpreadsheetCommandBarButtonItem125.Name = "SpreadsheetCommandBarButtonItem125"
            '
            'SpreadsheetCommandBarButtonItem126
            '
            Me.SpreadsheetCommandBarButtonItem126.CommandName = "InsertTableColumnToTheRight"
            Me.SpreadsheetCommandBarButtonItem126.Id = 243
            Me.SpreadsheetCommandBarButtonItem126.Name = "SpreadsheetCommandBarButtonItem126"
            '
            'spreadsheetCommandBarSubItem9
            '
            Me.spreadsheetCommandBarSubItem9.CommandName = "RemoveCellsCommandGroup"
            Me.spreadsheetCommandBarSubItem9.Id = 103
            Me.spreadsheetCommandBarSubItem9.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem61), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem62), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem63), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem127), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem128), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem129)})
            Me.spreadsheetCommandBarSubItem9.Name = "spreadsheetCommandBarSubItem9"
            '
            'spreadsheetCommandBarButtonItem61
            '
            Me.spreadsheetCommandBarButtonItem61.CommandName = "RemoveSheetRows"
            Me.spreadsheetCommandBarButtonItem61.Id = 104
            Me.spreadsheetCommandBarButtonItem61.Name = "spreadsheetCommandBarButtonItem61"
            '
            'spreadsheetCommandBarButtonItem62
            '
            Me.spreadsheetCommandBarButtonItem62.CommandName = "RemoveSheetColumns"
            Me.spreadsheetCommandBarButtonItem62.Id = 105
            Me.spreadsheetCommandBarButtonItem62.Name = "spreadsheetCommandBarButtonItem62"
            '
            'spreadsheetCommandBarButtonItem63
            '
            Me.spreadsheetCommandBarButtonItem63.CommandName = "RemoveSheet"
            Me.spreadsheetCommandBarButtonItem63.Id = 106
            Me.spreadsheetCommandBarButtonItem63.Name = "spreadsheetCommandBarButtonItem63"
            '
            'SpreadsheetCommandBarButtonItem127
            '
            Me.SpreadsheetCommandBarButtonItem127.CommandName = "RemoveCells"
            Me.SpreadsheetCommandBarButtonItem127.Id = 244
            Me.SpreadsheetCommandBarButtonItem127.Name = "SpreadsheetCommandBarButtonItem127"
            '
            'SpreadsheetCommandBarButtonItem128
            '
            Me.SpreadsheetCommandBarButtonItem128.CommandName = "RemoveTableRows"
            Me.SpreadsheetCommandBarButtonItem128.Id = 245
            Me.SpreadsheetCommandBarButtonItem128.Name = "SpreadsheetCommandBarButtonItem128"
            '
            'SpreadsheetCommandBarButtonItem129
            '
            Me.SpreadsheetCommandBarButtonItem129.CommandName = "RemoveTableColumns"
            Me.SpreadsheetCommandBarButtonItem129.Id = 246
            Me.SpreadsheetCommandBarButtonItem129.Name = "SpreadsheetCommandBarButtonItem129"
            '
            'spreadsheetCommandBarSubItem10
            '
            Me.spreadsheetCommandBarSubItem10.CommandName = "FormatCommandGroup"
            Me.spreadsheetCommandBarSubItem10.Id = 107
            Me.spreadsheetCommandBarSubItem10.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem64), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem65), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarSubItem11), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem72), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem130), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem131), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem132), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem133), New DevExpress.XtraBars.LinkPersistInfo(Me.ChangeSheetTabColorItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem134), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem32), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem135)})
            Me.spreadsheetCommandBarSubItem10.Name = "spreadsheetCommandBarSubItem10"
            '
            'spreadsheetCommandBarButtonItem64
            '
            Me.spreadsheetCommandBarButtonItem64.CommandName = "FormatAutoFitRowHeight"
            Me.spreadsheetCommandBarButtonItem64.Id = 108
            Me.spreadsheetCommandBarButtonItem64.Name = "spreadsheetCommandBarButtonItem64"
            '
            'spreadsheetCommandBarButtonItem65
            '
            Me.spreadsheetCommandBarButtonItem65.CommandName = "FormatAutoFitColumnWidth"
            Me.spreadsheetCommandBarButtonItem65.Id = 109
            Me.spreadsheetCommandBarButtonItem65.Name = "spreadsheetCommandBarButtonItem65"
            '
            'spreadsheetCommandBarSubItem11
            '
            Me.spreadsheetCommandBarSubItem11.CommandName = "HideAndUnhideCommandGroup"
            Me.spreadsheetCommandBarSubItem11.Id = 116
            Me.spreadsheetCommandBarSubItem11.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem66), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem67), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem68), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem69), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem70), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem71)})
            Me.spreadsheetCommandBarSubItem11.Name = "spreadsheetCommandBarSubItem11"
            '
            'spreadsheetCommandBarButtonItem66
            '
            Me.spreadsheetCommandBarButtonItem66.CommandName = "HideRows"
            Me.spreadsheetCommandBarButtonItem66.Id = 110
            Me.spreadsheetCommandBarButtonItem66.Name = "spreadsheetCommandBarButtonItem66"
            '
            'spreadsheetCommandBarButtonItem67
            '
            Me.spreadsheetCommandBarButtonItem67.CommandName = "HideColumns"
            Me.spreadsheetCommandBarButtonItem67.Id = 111
            Me.spreadsheetCommandBarButtonItem67.Name = "spreadsheetCommandBarButtonItem67"
            '
            'spreadsheetCommandBarButtonItem68
            '
            Me.spreadsheetCommandBarButtonItem68.CommandName = "HideSheet"
            Me.spreadsheetCommandBarButtonItem68.Id = 112
            Me.spreadsheetCommandBarButtonItem68.Name = "spreadsheetCommandBarButtonItem68"
            '
            'spreadsheetCommandBarButtonItem69
            '
            Me.spreadsheetCommandBarButtonItem69.CommandName = "UnhideRows"
            Me.spreadsheetCommandBarButtonItem69.Id = 113
            Me.spreadsheetCommandBarButtonItem69.Name = "spreadsheetCommandBarButtonItem69"
            '
            'spreadsheetCommandBarButtonItem70
            '
            Me.spreadsheetCommandBarButtonItem70.CommandName = "UnhideColumns"
            Me.spreadsheetCommandBarButtonItem70.Id = 114
            Me.spreadsheetCommandBarButtonItem70.Name = "spreadsheetCommandBarButtonItem70"
            '
            'spreadsheetCommandBarButtonItem71
            '
            Me.spreadsheetCommandBarButtonItem71.CommandName = "UnhideSheet"
            Me.spreadsheetCommandBarButtonItem71.Id = 115
            Me.spreadsheetCommandBarButtonItem71.Name = "spreadsheetCommandBarButtonItem71"
            '
            'spreadsheetCommandBarButtonItem72
            '
            Me.spreadsheetCommandBarButtonItem72.CommandName = "RenameSheet"
            Me.spreadsheetCommandBarButtonItem72.Id = 117
            Me.spreadsheetCommandBarButtonItem72.Name = "spreadsheetCommandBarButtonItem72"
            '
            'SpreadsheetCommandBarButtonItem130
            '
            Me.SpreadsheetCommandBarButtonItem130.CommandName = "FormatRowHeight"
            Me.SpreadsheetCommandBarButtonItem130.Id = 247
            Me.SpreadsheetCommandBarButtonItem130.Name = "SpreadsheetCommandBarButtonItem130"
            '
            'SpreadsheetCommandBarButtonItem131
            '
            Me.SpreadsheetCommandBarButtonItem131.CommandName = "FormatColumnWidth"
            Me.SpreadsheetCommandBarButtonItem131.Id = 248
            Me.SpreadsheetCommandBarButtonItem131.Name = "SpreadsheetCommandBarButtonItem131"
            '
            'SpreadsheetCommandBarButtonItem132
            '
            Me.SpreadsheetCommandBarButtonItem132.CommandName = "FormatDefaultColumnWidth"
            Me.SpreadsheetCommandBarButtonItem132.Id = 249
            Me.SpreadsheetCommandBarButtonItem132.Name = "SpreadsheetCommandBarButtonItem132"
            '
            'SpreadsheetCommandBarButtonItem133
            '
            Me.SpreadsheetCommandBarButtonItem133.CommandName = "MoveOrCopySheet"
            Me.SpreadsheetCommandBarButtonItem133.Id = 250
            Me.SpreadsheetCommandBarButtonItem133.Name = "SpreadsheetCommandBarButtonItem133"
            '
            'ChangeSheetTabColorItem1
            '
            Me.ChangeSheetTabColorItem1.ActAsDropDown = True
            Me.ChangeSheetTabColorItem1.Id = 251
            Me.ChangeSheetTabColorItem1.Name = "ChangeSheetTabColorItem1"
            '
            'SpreadsheetCommandBarButtonItem134
            '
            Me.SpreadsheetCommandBarButtonItem134.CommandName = "ReviewProtectSheet"
            Me.SpreadsheetCommandBarButtonItem134.Id = 252
            Me.SpreadsheetCommandBarButtonItem134.Name = "SpreadsheetCommandBarButtonItem134"
            '
            'SpreadsheetCommandBarCheckItem32
            '
            Me.SpreadsheetCommandBarCheckItem32.CommandName = "FormatCellLocked"
            Me.SpreadsheetCommandBarCheckItem32.Id = 253
            Me.SpreadsheetCommandBarCheckItem32.Name = "SpreadsheetCommandBarCheckItem32"
            '
            'SpreadsheetCommandBarButtonItem135
            '
            Me.SpreadsheetCommandBarButtonItem135.CommandName = "FormatCellsContextMenuItem"
            Me.SpreadsheetCommandBarButtonItem135.Id = 254
            Me.SpreadsheetCommandBarButtonItem135.Name = "SpreadsheetCommandBarButtonItem135"
            '
            'spreadsheetCommandBarSubItem12
            '
            Me.spreadsheetCommandBarSubItem12.CommandName = "EditingAutoSumCommandGroup"
            Me.spreadsheetCommandBarSubItem12.Id = 118
            Me.spreadsheetCommandBarSubItem12.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem73), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem74), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem75), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem76), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem77)})
            Me.spreadsheetCommandBarSubItem12.Name = "spreadsheetCommandBarSubItem12"
            Me.spreadsheetCommandBarSubItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarButtonItem73
            '
            Me.spreadsheetCommandBarButtonItem73.CommandName = "FunctionsInsertSum"
            Me.spreadsheetCommandBarButtonItem73.Id = 119
            Me.spreadsheetCommandBarButtonItem73.Name = "spreadsheetCommandBarButtonItem73"
            '
            'spreadsheetCommandBarButtonItem74
            '
            Me.spreadsheetCommandBarButtonItem74.CommandName = "FunctionsInsertAverage"
            Me.spreadsheetCommandBarButtonItem74.Id = 120
            Me.spreadsheetCommandBarButtonItem74.Name = "spreadsheetCommandBarButtonItem74"
            '
            'spreadsheetCommandBarButtonItem75
            '
            Me.spreadsheetCommandBarButtonItem75.CommandName = "FunctionsInsertCountNumbers"
            Me.spreadsheetCommandBarButtonItem75.Id = 121
            Me.spreadsheetCommandBarButtonItem75.Name = "spreadsheetCommandBarButtonItem75"
            '
            'spreadsheetCommandBarButtonItem76
            '
            Me.spreadsheetCommandBarButtonItem76.CommandName = "FunctionsInsertMax"
            Me.spreadsheetCommandBarButtonItem76.Id = 122
            Me.spreadsheetCommandBarButtonItem76.Name = "spreadsheetCommandBarButtonItem76"
            '
            'spreadsheetCommandBarButtonItem77
            '
            Me.spreadsheetCommandBarButtonItem77.CommandName = "FunctionsInsertMin"
            Me.spreadsheetCommandBarButtonItem77.Id = 123
            Me.spreadsheetCommandBarButtonItem77.Name = "spreadsheetCommandBarButtonItem77"
            '
            'spreadsheetCommandBarSubItem13
            '
            Me.spreadsheetCommandBarSubItem13.CommandName = "EditingFillCommandGroup"
            Me.spreadsheetCommandBarSubItem13.Id = 124
            Me.spreadsheetCommandBarSubItem13.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem78), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem79), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem80), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem81)})
            Me.spreadsheetCommandBarSubItem13.Name = "spreadsheetCommandBarSubItem13"
            Me.spreadsheetCommandBarSubItem13.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarButtonItem78
            '
            Me.spreadsheetCommandBarButtonItem78.CommandName = "EditingFillDown"
            Me.spreadsheetCommandBarButtonItem78.Id = 125
            Me.spreadsheetCommandBarButtonItem78.Name = "spreadsheetCommandBarButtonItem78"
            '
            'spreadsheetCommandBarButtonItem79
            '
            Me.spreadsheetCommandBarButtonItem79.CommandName = "EditingFillRight"
            Me.spreadsheetCommandBarButtonItem79.Id = 126
            Me.spreadsheetCommandBarButtonItem79.Name = "spreadsheetCommandBarButtonItem79"
            '
            'spreadsheetCommandBarButtonItem80
            '
            Me.spreadsheetCommandBarButtonItem80.CommandName = "EditingFillUp"
            Me.spreadsheetCommandBarButtonItem80.Id = 127
            Me.spreadsheetCommandBarButtonItem80.Name = "spreadsheetCommandBarButtonItem80"
            '
            'spreadsheetCommandBarButtonItem81
            '
            Me.spreadsheetCommandBarButtonItem81.CommandName = "EditingFillLeft"
            Me.spreadsheetCommandBarButtonItem81.Id = 128
            Me.spreadsheetCommandBarButtonItem81.Name = "spreadsheetCommandBarButtonItem81"
            '
            'spreadsheetCommandBarSubItem14
            '
            Me.spreadsheetCommandBarSubItem14.CommandName = "FormatClearCommandGroup"
            Me.spreadsheetCommandBarSubItem14.Id = 129
            Me.spreadsheetCommandBarSubItem14.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem82), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem83), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem84), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem85), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem86), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem87)})
            Me.spreadsheetCommandBarSubItem14.Name = "spreadsheetCommandBarSubItem14"
            Me.spreadsheetCommandBarSubItem14.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarButtonItem82
            '
            Me.spreadsheetCommandBarButtonItem82.CommandName = "FormatClearAll"
            Me.spreadsheetCommandBarButtonItem82.Id = 130
            Me.spreadsheetCommandBarButtonItem82.Name = "spreadsheetCommandBarButtonItem82"
            '
            'spreadsheetCommandBarButtonItem83
            '
            Me.spreadsheetCommandBarButtonItem83.CommandName = "FormatClearFormats"
            Me.spreadsheetCommandBarButtonItem83.Id = 131
            Me.spreadsheetCommandBarButtonItem83.Name = "spreadsheetCommandBarButtonItem83"
            '
            'spreadsheetCommandBarButtonItem84
            '
            Me.spreadsheetCommandBarButtonItem84.CommandName = "FormatClearContents"
            Me.spreadsheetCommandBarButtonItem84.Id = 132
            Me.spreadsheetCommandBarButtonItem84.Name = "spreadsheetCommandBarButtonItem84"
            '
            'spreadsheetCommandBarButtonItem85
            '
            Me.spreadsheetCommandBarButtonItem85.CommandName = "FormatClearComments"
            Me.spreadsheetCommandBarButtonItem85.Id = 133
            Me.spreadsheetCommandBarButtonItem85.Name = "spreadsheetCommandBarButtonItem85"
            '
            'spreadsheetCommandBarButtonItem86
            '
            Me.spreadsheetCommandBarButtonItem86.CommandName = "FormatClearHyperlinks"
            Me.spreadsheetCommandBarButtonItem86.Id = 134
            Me.spreadsheetCommandBarButtonItem86.Name = "spreadsheetCommandBarButtonItem86"
            '
            'spreadsheetCommandBarButtonItem87
            '
            Me.spreadsheetCommandBarButtonItem87.CommandName = "FormatRemoveHyperlinks"
            Me.spreadsheetCommandBarButtonItem87.Id = 135
            Me.spreadsheetCommandBarButtonItem87.Name = "spreadsheetCommandBarButtonItem87"
            '
            'spreadsheetCommandBarButtonItem88
            '
            Me.spreadsheetCommandBarButtonItem88.CommandName = "InsertTable"
            Me.spreadsheetCommandBarButtonItem88.Id = 136
            Me.spreadsheetCommandBarButtonItem88.Name = "spreadsheetCommandBarButtonItem88"
            '
            'spreadsheetCommandBarButtonItem89
            '
            Me.spreadsheetCommandBarButtonItem89.CommandName = "InsertPicture"
            Me.spreadsheetCommandBarButtonItem89.Id = 137
            Me.spreadsheetCommandBarButtonItem89.Name = "spreadsheetCommandBarButtonItem89"
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem4
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem4.CommandName = "InsertChartColumnCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem4.DropDownControl = Me.commandBarGalleryDropDown6
            Me.spreadsheetCommandBarButtonGalleryDropDownItem4.Id = 138
            Me.spreadsheetCommandBarButtonGalleryDropDownItem4.Name = "spreadsheetCommandBarButtonGalleryDropDownItem4"
            '
            'commandBarGalleryDropDown6
            '
            '
            '
            '
            Me.commandBarGalleryDropDown6.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup8.CommandName = "InsertChartColumn2DCommandGroup"
            SpreadsheetCommandGalleryItem56.CommandName = "InsertChartColumnClustered2D"
            SpreadsheetCommandGalleryItem57.CommandName = "InsertChartColumnStacked2D"
            SpreadsheetCommandGalleryItem58.CommandName = "InsertChartColumnPercentStacked2D"
            SpreadsheetCommandGalleryItemGroup8.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem56, SpreadsheetCommandGalleryItem57, SpreadsheetCommandGalleryItem58})
            SpreadsheetCommandGalleryItemGroup9.CommandName = "InsertChartColumn3DCommandGroup"
            SpreadsheetCommandGalleryItem59.CommandName = "InsertChartColumnClustered3D"
            SpreadsheetCommandGalleryItem60.CommandName = "InsertChartColumnStacked3D"
            SpreadsheetCommandGalleryItem61.CommandName = "InsertChartColumnPercentStacked3D"
            SpreadsheetCommandGalleryItem62.CommandName = "InsertChartColumn3D"
            SpreadsheetCommandGalleryItemGroup9.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem59, SpreadsheetCommandGalleryItem60, SpreadsheetCommandGalleryItem61, SpreadsheetCommandGalleryItem62})
            SpreadsheetCommandGalleryItemGroup10.CommandName = "InsertChartCylinderCommandGroup"
            SpreadsheetCommandGalleryItem63.CommandName = "InsertChartCylinderClustered"
            SpreadsheetCommandGalleryItem64.CommandName = "InsertChartCylinderStacked"
            SpreadsheetCommandGalleryItem65.CommandName = "InsertChartCylinderPercentStacked"
            SpreadsheetCommandGalleryItem66.CommandName = "InsertChartCylinder"
            SpreadsheetCommandGalleryItemGroup10.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem63, SpreadsheetCommandGalleryItem64, SpreadsheetCommandGalleryItem65, SpreadsheetCommandGalleryItem66})
            SpreadsheetCommandGalleryItemGroup11.CommandName = "InsertChartConeCommandGroup"
            SpreadsheetCommandGalleryItem67.CommandName = "InsertChartConeClustered"
            SpreadsheetCommandGalleryItem68.CommandName = "InsertChartConeStacked"
            SpreadsheetCommandGalleryItem69.CommandName = "InsertChartConePercentStacked"
            SpreadsheetCommandGalleryItem70.CommandName = "InsertChartCone"
            SpreadsheetCommandGalleryItemGroup11.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem67, SpreadsheetCommandGalleryItem68, SpreadsheetCommandGalleryItem69, SpreadsheetCommandGalleryItem70})
            SpreadsheetCommandGalleryItemGroup12.CommandName = "InsertChartPyramidCommandGroup"
            SpreadsheetCommandGalleryItem71.CommandName = "InsertChartPyramidClustered"
            SpreadsheetCommandGalleryItem72.CommandName = "InsertChartPyramidStacked"
            SpreadsheetCommandGalleryItem73.CommandName = "InsertChartPyramidPercentStacked"
            SpreadsheetCommandGalleryItem74.CommandName = "InsertChartPyramid"
            SpreadsheetCommandGalleryItemGroup12.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem71, SpreadsheetCommandGalleryItem72, SpreadsheetCommandGalleryItem73, SpreadsheetCommandGalleryItem74})
            Me.commandBarGalleryDropDown6.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup8, SpreadsheetCommandGalleryItemGroup9, SpreadsheetCommandGalleryItemGroup10, SpreadsheetCommandGalleryItemGroup11, SpreadsheetCommandGalleryItemGroup12})
            Me.commandBarGalleryDropDown6.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown6.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown6.Name = "commandBarGalleryDropDown6"
            Me.commandBarGalleryDropDown6.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem5
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem5.CommandName = "InsertChartLineCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem5.DropDownControl = Me.commandBarGalleryDropDown7
            Me.spreadsheetCommandBarButtonGalleryDropDownItem5.Id = 139
            Me.spreadsheetCommandBarButtonGalleryDropDownItem5.Name = "spreadsheetCommandBarButtonGalleryDropDownItem5"
            '
            'commandBarGalleryDropDown7
            '
            '
            '
            '
            Me.commandBarGalleryDropDown7.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup13.CommandName = "InsertChartLine2DCommandGroup"
            SpreadsheetCommandGalleryItem75.CommandName = "InsertChartLine"
            SpreadsheetCommandGalleryItem76.CommandName = "InsertChartStackedLine"
            SpreadsheetCommandGalleryItem77.CommandName = "InsertChartPercentStackedLine"
            SpreadsheetCommandGalleryItem78.CommandName = "InsertChartLineWithMarkers"
            SpreadsheetCommandGalleryItem79.CommandName = "InsertChartStackedLineWithMarkers"
            SpreadsheetCommandGalleryItem80.CommandName = "InsertChartPercentStackedLineWithMarkers"
            SpreadsheetCommandGalleryItemGroup13.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem75, SpreadsheetCommandGalleryItem76, SpreadsheetCommandGalleryItem77, SpreadsheetCommandGalleryItem78, SpreadsheetCommandGalleryItem79, SpreadsheetCommandGalleryItem80})
            SpreadsheetCommandGalleryItemGroup14.CommandName = "InsertChartLine3DCommandGroup"
            SpreadsheetCommandGalleryItem81.CommandName = "InsertChartLine3D"
            SpreadsheetCommandGalleryItemGroup14.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem81})
            Me.commandBarGalleryDropDown7.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup13, SpreadsheetCommandGalleryItemGroup14})
            Me.commandBarGalleryDropDown7.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown7.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown7.Name = "commandBarGalleryDropDown7"
            Me.commandBarGalleryDropDown7.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem6
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem6.CommandName = "InsertChartPieCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem6.DropDownControl = Me.commandBarGalleryDropDown8
            Me.spreadsheetCommandBarButtonGalleryDropDownItem6.Id = 140
            Me.spreadsheetCommandBarButtonGalleryDropDownItem6.Name = "spreadsheetCommandBarButtonGalleryDropDownItem6"
            '
            'commandBarGalleryDropDown8
            '
            '
            '
            '
            Me.commandBarGalleryDropDown8.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup15.CommandName = "InsertChartPie2DCommandGroup"
            SpreadsheetCommandGalleryItem82.CommandName = "InsertChartPie2D"
            SpreadsheetCommandGalleryItem83.CommandName = "InsertChartPieExploded2D"
            SpreadsheetCommandGalleryItemGroup15.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem82, SpreadsheetCommandGalleryItem83})
            SpreadsheetCommandGalleryItemGroup16.CommandName = "InsertChartPie3DCommandGroup"
            SpreadsheetCommandGalleryItem84.CommandName = "InsertChartPie3D"
            SpreadsheetCommandGalleryItem85.CommandName = "InsertChartPieExploded3D"
            SpreadsheetCommandGalleryItemGroup16.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem84, SpreadsheetCommandGalleryItem85})
            SpreadsheetCommandGalleryItemGroup17.CommandName = "InsertChartDoughnut2DCommandGroup"
            SpreadsheetCommandGalleryItem86.CommandName = "InsertChartDoughnut2D"
            SpreadsheetCommandGalleryItem87.CommandName = "InsertChartDoughnutExploded2D"
            SpreadsheetCommandGalleryItemGroup17.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem86, SpreadsheetCommandGalleryItem87})
            Me.commandBarGalleryDropDown8.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup15, SpreadsheetCommandGalleryItemGroup16, SpreadsheetCommandGalleryItemGroup17})
            Me.commandBarGalleryDropDown8.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown8.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown8.Name = "commandBarGalleryDropDown8"
            Me.commandBarGalleryDropDown8.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem7
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem7.CommandName = "InsertChartBarCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem7.DropDownControl = Me.commandBarGalleryDropDown9
            Me.spreadsheetCommandBarButtonGalleryDropDownItem7.Id = 141
            Me.spreadsheetCommandBarButtonGalleryDropDownItem7.Name = "spreadsheetCommandBarButtonGalleryDropDownItem7"
            '
            'commandBarGalleryDropDown9
            '
            '
            '
            '
            Me.commandBarGalleryDropDown9.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup18.CommandName = "InsertChartBar2DCommandGroup"
            SpreadsheetCommandGalleryItem88.CommandName = "InsertChartBarClustered2D"
            SpreadsheetCommandGalleryItem89.CommandName = "InsertChartBarStacked2D"
            SpreadsheetCommandGalleryItem90.CommandName = "InsertChartBarPercentStacked2D"
            SpreadsheetCommandGalleryItemGroup18.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem88, SpreadsheetCommandGalleryItem89, SpreadsheetCommandGalleryItem90})
            SpreadsheetCommandGalleryItemGroup19.CommandName = "InsertChartBar3DCommandGroup"
            SpreadsheetCommandGalleryItem91.CommandName = "InsertChartBarClustered3D"
            SpreadsheetCommandGalleryItem92.CommandName = "InsertChartBarStacked3D"
            SpreadsheetCommandGalleryItem93.CommandName = "InsertChartBarPercentStacked3D"
            SpreadsheetCommandGalleryItemGroup19.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem91, SpreadsheetCommandGalleryItem92, SpreadsheetCommandGalleryItem93})
            SpreadsheetCommandGalleryItemGroup20.CommandName = "InsertChartHorizontalCylinderCommandGroup"
            SpreadsheetCommandGalleryItem94.CommandName = "InsertChartHorizontalCylinderClustered"
            SpreadsheetCommandGalleryItem95.CommandName = "InsertChartHorizontalCylinderStacked"
            SpreadsheetCommandGalleryItem96.CommandName = "InsertChartHorizontalCylinderPercentStacked"
            SpreadsheetCommandGalleryItemGroup20.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem94, SpreadsheetCommandGalleryItem95, SpreadsheetCommandGalleryItem96})
            SpreadsheetCommandGalleryItemGroup21.CommandName = "InsertChartHorizontalConeCommandGroup"
            SpreadsheetCommandGalleryItem97.CommandName = "InsertChartHorizontalConeClustered"
            SpreadsheetCommandGalleryItem98.CommandName = "InsertChartHorizontalConeStacked"
            SpreadsheetCommandGalleryItem99.CommandName = "InsertChartHorizontalConePercentStacked"
            SpreadsheetCommandGalleryItemGroup21.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem97, SpreadsheetCommandGalleryItem98, SpreadsheetCommandGalleryItem99})
            SpreadsheetCommandGalleryItemGroup22.CommandName = "InsertChartHorizontalPyramidCommandGroup"
            SpreadsheetCommandGalleryItem100.CommandName = "InsertChartHorizontalPyramidClustered"
            SpreadsheetCommandGalleryItem101.CommandName = "InsertChartHorizontalPyramidStacked"
            SpreadsheetCommandGalleryItem102.CommandName = "InsertChartHorizontalPyramidPercentStacked"
            SpreadsheetCommandGalleryItemGroup22.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem100, SpreadsheetCommandGalleryItem101, SpreadsheetCommandGalleryItem102})
            Me.commandBarGalleryDropDown9.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup18, SpreadsheetCommandGalleryItemGroup19, SpreadsheetCommandGalleryItemGroup20, SpreadsheetCommandGalleryItemGroup21, SpreadsheetCommandGalleryItemGroup22})
            Me.commandBarGalleryDropDown9.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown9.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown9.Name = "commandBarGalleryDropDown9"
            Me.commandBarGalleryDropDown9.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem8
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem8.CommandName = "InsertChartAreaCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem8.DropDownControl = Me.commandBarGalleryDropDown10
            Me.spreadsheetCommandBarButtonGalleryDropDownItem8.Id = 142
            Me.spreadsheetCommandBarButtonGalleryDropDownItem8.Name = "spreadsheetCommandBarButtonGalleryDropDownItem8"
            '
            'commandBarGalleryDropDown10
            '
            '
            '
            '
            Me.commandBarGalleryDropDown10.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup23.CommandName = "InsertChartArea2DCommandGroup"
            SpreadsheetCommandGalleryItem103.CommandName = "InsertChartArea"
            SpreadsheetCommandGalleryItem104.CommandName = "InsertChartStackedArea"
            SpreadsheetCommandGalleryItem105.CommandName = "InsertChartPercentStackedArea"
            SpreadsheetCommandGalleryItemGroup23.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem103, SpreadsheetCommandGalleryItem104, SpreadsheetCommandGalleryItem105})
            SpreadsheetCommandGalleryItemGroup24.CommandName = "InsertChartArea3DCommandGroup"
            SpreadsheetCommandGalleryItem106.CommandName = "InsertChartArea3D"
            SpreadsheetCommandGalleryItem107.CommandName = "InsertChartStackedArea3D"
            SpreadsheetCommandGalleryItem108.CommandName = "InsertChartPercentStackedArea3D"
            SpreadsheetCommandGalleryItemGroup24.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem106, SpreadsheetCommandGalleryItem107, SpreadsheetCommandGalleryItem108})
            Me.commandBarGalleryDropDown10.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup23, SpreadsheetCommandGalleryItemGroup24})
            Me.commandBarGalleryDropDown10.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown10.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown10.Name = "commandBarGalleryDropDown10"
            Me.commandBarGalleryDropDown10.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem9
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem9.CommandName = "InsertChartScatterCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem9.DropDownControl = Me.commandBarGalleryDropDown11
            Me.spreadsheetCommandBarButtonGalleryDropDownItem9.Id = 143
            Me.spreadsheetCommandBarButtonGalleryDropDownItem9.Name = "spreadsheetCommandBarButtonGalleryDropDownItem9"
            '
            'commandBarGalleryDropDown11
            '
            '
            '
            '
            Me.commandBarGalleryDropDown11.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup25.CommandName = "InsertChartScatterCommandGroup"
            SpreadsheetCommandGalleryItem109.CommandName = "InsertChartScatterMarkers"
            SpreadsheetCommandGalleryItem110.CommandName = "InsertChartScatterSmoothLinesAndMarkers"
            SpreadsheetCommandGalleryItem111.CommandName = "InsertChartScatterSmoothLines"
            SpreadsheetCommandGalleryItem112.CommandName = "InsertChartScatterLinesAndMarkers"
            SpreadsheetCommandGalleryItem113.CommandName = "InsertChartScatterLines"
            SpreadsheetCommandGalleryItemGroup25.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem109, SpreadsheetCommandGalleryItem110, SpreadsheetCommandGalleryItem111, SpreadsheetCommandGalleryItem112, SpreadsheetCommandGalleryItem113})
            SpreadsheetCommandGalleryItemGroup26.CommandName = "InsertChartBubbleCommandGroup"
            SpreadsheetCommandGalleryItem114.CommandName = "InsertChartBubble"
            SpreadsheetCommandGalleryItem115.CommandName = "InsertChartBubble3D"
            SpreadsheetCommandGalleryItemGroup26.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem114, SpreadsheetCommandGalleryItem115})
            Me.commandBarGalleryDropDown11.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup25, SpreadsheetCommandGalleryItemGroup26})
            Me.commandBarGalleryDropDown11.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown11.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown11.Name = "commandBarGalleryDropDown11"
            Me.commandBarGalleryDropDown11.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem10
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem10.CommandName = "InsertChartOtherCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem10.DropDownControl = Me.commandBarGalleryDropDown12
            Me.spreadsheetCommandBarButtonGalleryDropDownItem10.Id = 144
            Me.spreadsheetCommandBarButtonGalleryDropDownItem10.Name = "spreadsheetCommandBarButtonGalleryDropDownItem10"
            '
            'commandBarGalleryDropDown12
            '
            '
            '
            '
            Me.commandBarGalleryDropDown12.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup27.CommandName = "InsertChartStockCommandGroup"
            SpreadsheetCommandGalleryItem116.CommandName = "InsertChartStockHighLowClose"
            SpreadsheetCommandGalleryItem117.CommandName = "InsertChartStockOpenHighLowClose"
            SpreadsheetCommandGalleryItemGroup27.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem116, SpreadsheetCommandGalleryItem117})
            SpreadsheetCommandGalleryItemGroup28.CommandName = "InsertChartRadarCommandGroup"
            SpreadsheetCommandGalleryItem118.CommandName = "InsertChartRadar"
            SpreadsheetCommandGalleryItem119.CommandName = "InsertChartRadarWithMarkers"
            SpreadsheetCommandGalleryItem120.CommandName = "InsertChartRadarFilled"
            SpreadsheetCommandGalleryItemGroup28.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem118, SpreadsheetCommandGalleryItem119, SpreadsheetCommandGalleryItem120})
            Me.commandBarGalleryDropDown12.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup27, SpreadsheetCommandGalleryItemGroup28})
            Me.commandBarGalleryDropDown12.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown12.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown12.Name = "commandBarGalleryDropDown12"
            Me.commandBarGalleryDropDown12.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonItem90
            '
            Me.spreadsheetCommandBarButtonItem90.CommandName = "InsertHyperlink"
            Me.spreadsheetCommandBarButtonItem90.Id = 145
            Me.spreadsheetCommandBarButtonItem90.Name = "spreadsheetCommandBarButtonItem90"
            '
            'spreadsheetCommandBarSubItem15
            '
            Me.spreadsheetCommandBarSubItem15.CommandName = "PageSetupMarginsCommandGroup"
            Me.spreadsheetCommandBarSubItem15.Id = 146
            Me.spreadsheetCommandBarSubItem15.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem13), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem14), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem15), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem147)})
            Me.spreadsheetCommandBarSubItem15.Name = "spreadsheetCommandBarSubItem15"
            '
            'spreadsheetCommandBarCheckItem13
            '
            Me.spreadsheetCommandBarCheckItem13.CaptionDependOnUnits = True
            Me.spreadsheetCommandBarCheckItem13.CommandName = "PageSetupMarginsNormal"
            Me.spreadsheetCommandBarCheckItem13.Id = 147
            Me.spreadsheetCommandBarCheckItem13.Name = "spreadsheetCommandBarCheckItem13"
            '
            'spreadsheetCommandBarCheckItem14
            '
            Me.spreadsheetCommandBarCheckItem14.CaptionDependOnUnits = True
            Me.spreadsheetCommandBarCheckItem14.CommandName = "PageSetupMarginsWide"
            Me.spreadsheetCommandBarCheckItem14.Id = 148
            Me.spreadsheetCommandBarCheckItem14.Name = "spreadsheetCommandBarCheckItem14"
            '
            'spreadsheetCommandBarCheckItem15
            '
            Me.spreadsheetCommandBarCheckItem15.CaptionDependOnUnits = True
            Me.spreadsheetCommandBarCheckItem15.CommandName = "PageSetupMarginsNarrow"
            Me.spreadsheetCommandBarCheckItem15.Id = 149
            Me.spreadsheetCommandBarCheckItem15.Name = "spreadsheetCommandBarCheckItem15"
            '
            'SpreadsheetCommandBarButtonItem147
            '
            Me.SpreadsheetCommandBarButtonItem147.CommandName = "PageSetupCustomMargins"
            Me.SpreadsheetCommandBarButtonItem147.Id = 271
            Me.SpreadsheetCommandBarButtonItem147.Name = "SpreadsheetCommandBarButtonItem147"
            '
            'spreadsheetCommandBarSubItem16
            '
            Me.spreadsheetCommandBarSubItem16.CommandName = "PageSetupOrientationCommandGroup"
            Me.spreadsheetCommandBarSubItem16.Id = 150
            Me.spreadsheetCommandBarSubItem16.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem16), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem17)})
            Me.spreadsheetCommandBarSubItem16.Name = "spreadsheetCommandBarSubItem16"
            '
            'spreadsheetCommandBarCheckItem16
            '
            Me.spreadsheetCommandBarCheckItem16.CommandName = "PageSetupOrientationPortrait"
            Me.spreadsheetCommandBarCheckItem16.Id = 151
            Me.spreadsheetCommandBarCheckItem16.Name = "spreadsheetCommandBarCheckItem16"
            '
            'spreadsheetCommandBarCheckItem17
            '
            Me.spreadsheetCommandBarCheckItem17.CommandName = "PageSetupOrientationLandscape"
            Me.spreadsheetCommandBarCheckItem17.Id = 152
            Me.spreadsheetCommandBarCheckItem17.Name = "spreadsheetCommandBarCheckItem17"
            '
            'pageSetupPaperKindItem1
            '
            Me.pageSetupPaperKindItem1.Id = 153
            Me.pageSetupPaperKindItem1.Name = "pageSetupPaperKindItem1"
            '
            'spreadsheetCommandBarSubItem17
            '
            Me.spreadsheetCommandBarSubItem17.CommandName = "ArrangeBringForwardCommandGroup"
            Me.spreadsheetCommandBarSubItem17.Id = 154
            Me.spreadsheetCommandBarSubItem17.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem91), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem92)})
            Me.spreadsheetCommandBarSubItem17.Name = "spreadsheetCommandBarSubItem17"
            '
            'spreadsheetCommandBarButtonItem91
            '
            Me.spreadsheetCommandBarButtonItem91.CommandName = "ArrangeBringForward"
            Me.spreadsheetCommandBarButtonItem91.Id = 155
            Me.spreadsheetCommandBarButtonItem91.Name = "spreadsheetCommandBarButtonItem91"
            '
            'spreadsheetCommandBarButtonItem92
            '
            Me.spreadsheetCommandBarButtonItem92.CommandName = "ArrangeBringToFront"
            Me.spreadsheetCommandBarButtonItem92.Id = 156
            Me.spreadsheetCommandBarButtonItem92.Name = "spreadsheetCommandBarButtonItem92"
            '
            'spreadsheetCommandBarSubItem18
            '
            Me.spreadsheetCommandBarSubItem18.CommandName = "ArrangeSendBackwardCommandGroup"
            Me.spreadsheetCommandBarSubItem18.Id = 157
            Me.spreadsheetCommandBarSubItem18.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem93), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem94)})
            Me.spreadsheetCommandBarSubItem18.Name = "spreadsheetCommandBarSubItem18"
            '
            'spreadsheetCommandBarButtonItem93
            '
            Me.spreadsheetCommandBarButtonItem93.CommandName = "ArrangeSendBackward"
            Me.spreadsheetCommandBarButtonItem93.Id = 158
            Me.spreadsheetCommandBarButtonItem93.Name = "spreadsheetCommandBarButtonItem93"
            '
            'spreadsheetCommandBarButtonItem94
            '
            Me.spreadsheetCommandBarButtonItem94.CommandName = "ArrangeSendToBack"
            Me.spreadsheetCommandBarButtonItem94.Id = 159
            Me.spreadsheetCommandBarButtonItem94.Name = "spreadsheetCommandBarButtonItem94"
            '
            'spreadsheetCommandBarSubItem19
            '
            Me.spreadsheetCommandBarSubItem19.CommandName = "FunctionsAutoSumCommandGroup"
            Me.spreadsheetCommandBarSubItem19.Id = 160
            Me.spreadsheetCommandBarSubItem19.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem73), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem74), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem75), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem76), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem77)})
            Me.spreadsheetCommandBarSubItem19.Name = "spreadsheetCommandBarSubItem19"
            '
            'functionsFinancialItem1
            '
            Me.functionsFinancialItem1.Id = 161
            Me.functionsFinancialItem1.Name = "functionsFinancialItem1"
            '
            'functionsLogicalItem1
            '
            Me.functionsLogicalItem1.Id = 162
            Me.functionsLogicalItem1.Name = "functionsLogicalItem1"
            '
            'functionsTextItem1
            '
            Me.functionsTextItem1.Id = 163
            Me.functionsTextItem1.Name = "functionsTextItem1"
            '
            'functionsDateAndTimeItem1
            '
            Me.functionsDateAndTimeItem1.Id = 164
            Me.functionsDateAndTimeItem1.Name = "functionsDateAndTimeItem1"
            '
            'functionsLookupAndReferenceItem1
            '
            Me.functionsLookupAndReferenceItem1.Id = 165
            Me.functionsLookupAndReferenceItem1.Name = "functionsLookupAndReferenceItem1"
            '
            'functionsMathAndTrigonometryItem1
            '
            Me.functionsMathAndTrigonometryItem1.Id = 166
            Me.functionsMathAndTrigonometryItem1.Name = "functionsMathAndTrigonometryItem1"
            '
            'spreadsheetCommandBarSubItem20
            '
            Me.spreadsheetCommandBarSubItem20.CommandName = "FunctionsMoreCommandGroup"
            Me.spreadsheetCommandBarSubItem20.Id = 167
            Me.spreadsheetCommandBarSubItem20.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.functionsStatisticalItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.functionsEngineeringItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.functionsInformationItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.functionsCompatibilityItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.functionsWebItem1)})
            Me.spreadsheetCommandBarSubItem20.Name = "spreadsheetCommandBarSubItem20"
            '
            'functionsStatisticalItem1
            '
            Me.functionsStatisticalItem1.Id = 168
            Me.functionsStatisticalItem1.Name = "functionsStatisticalItem1"
            '
            'functionsEngineeringItem1
            '
            Me.functionsEngineeringItem1.Id = 169
            Me.functionsEngineeringItem1.Name = "functionsEngineeringItem1"
            '
            'functionsInformationItem1
            '
            Me.functionsInformationItem1.Id = 170
            Me.functionsInformationItem1.Name = "functionsInformationItem1"
            '
            'functionsCompatibilityItem1
            '
            Me.functionsCompatibilityItem1.Id = 171
            Me.functionsCompatibilityItem1.Name = "functionsCompatibilityItem1"
            '
            'functionsWebItem1
            '
            Me.functionsWebItem1.Id = 172
            Me.functionsWebItem1.Name = "functionsWebItem1"
            '
            'spreadsheetCommandBarCheckItem18
            '
            Me.spreadsheetCommandBarCheckItem18.CommandName = "ViewShowFormulas"
            Me.spreadsheetCommandBarCheckItem18.Id = 173
            Me.spreadsheetCommandBarCheckItem18.Name = "spreadsheetCommandBarCheckItem18"
            '
            'spreadsheetCommandBarButtonItem100
            '
            Me.spreadsheetCommandBarButtonItem100.CommandName = "DataSortAscending"
            Me.spreadsheetCommandBarButtonItem100.Id = 174
            Me.spreadsheetCommandBarButtonItem100.Name = "spreadsheetCommandBarButtonItem100"
            '
            'spreadsheetCommandBarButtonItem101
            '
            Me.spreadsheetCommandBarButtonItem101.CommandName = "DataSortDescending"
            Me.spreadsheetCommandBarButtonItem101.Id = 175
            Me.spreadsheetCommandBarButtonItem101.Name = "spreadsheetCommandBarButtonItem101"
            '
            'spreadsheetCommandBarCheckItem19
            '
            Me.spreadsheetCommandBarCheckItem19.CommandName = "MailMergeDocumentsMode"
            Me.spreadsheetCommandBarCheckItem19.Id = 176
            Me.spreadsheetCommandBarCheckItem19.Name = "spreadsheetCommandBarCheckItem19"
            Me.spreadsheetCommandBarCheckItem19.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarCheckItem20
            '
            Me.spreadsheetCommandBarCheckItem20.CommandName = "MailMergeOneDocumentMode"
            Me.spreadsheetCommandBarCheckItem20.Id = 177
            Me.spreadsheetCommandBarCheckItem20.Name = "spreadsheetCommandBarCheckItem20"
            Me.spreadsheetCommandBarCheckItem20.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarCheckItem21
            '
            Me.spreadsheetCommandBarCheckItem21.CommandName = "MailMergeOneSheetMode"
            Me.spreadsheetCommandBarCheckItem21.Id = 178
            Me.spreadsheetCommandBarCheckItem21.Name = "spreadsheetCommandBarCheckItem21"
            Me.spreadsheetCommandBarCheckItem21.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarButtonItem102
            '
            Me.spreadsheetCommandBarButtonItem102.CommandName = "MailMergeSetHeaderRange"
            Me.spreadsheetCommandBarButtonItem102.Id = 179
            Me.spreadsheetCommandBarButtonItem102.Name = "spreadsheetCommandBarButtonItem102"
            Me.spreadsheetCommandBarButtonItem102.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarButtonItem103
            '
            Me.spreadsheetCommandBarButtonItem103.CommandName = "MailMergeSetFooterRange"
            Me.spreadsheetCommandBarButtonItem103.Id = 180
            Me.spreadsheetCommandBarButtonItem103.Name = "spreadsheetCommandBarButtonItem103"
            Me.spreadsheetCommandBarButtonItem103.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarButtonItem104
            '
            Me.spreadsheetCommandBarButtonItem104.CommandName = "MailMergeSetDetailRange"
            Me.spreadsheetCommandBarButtonItem104.Id = 181
            Me.spreadsheetCommandBarButtonItem104.Name = "spreadsheetCommandBarButtonItem104"
            Me.spreadsheetCommandBarButtonItem104.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarSubItem21
            '
            Me.spreadsheetCommandBarSubItem21.CommandName = "EditingMailMergeMasterDetailCommandGroup"
            Me.spreadsheetCommandBarSubItem21.Id = 182
            Me.spreadsheetCommandBarSubItem21.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem105), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem106)})
            Me.spreadsheetCommandBarSubItem21.Name = "spreadsheetCommandBarSubItem21"
            Me.spreadsheetCommandBarSubItem21.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarButtonItem105
            '
            Me.spreadsheetCommandBarButtonItem105.CommandName = "MailMergeSetDetailLevel"
            Me.spreadsheetCommandBarButtonItem105.Id = 183
            Me.spreadsheetCommandBarButtonItem105.Name = "spreadsheetCommandBarButtonItem105"
            '
            'spreadsheetCommandBarButtonItem106
            '
            Me.spreadsheetCommandBarButtonItem106.CommandName = "MailMergeSetDetailDataMember"
            Me.spreadsheetCommandBarButtonItem106.Id = 184
            Me.spreadsheetCommandBarButtonItem106.Name = "spreadsheetCommandBarButtonItem106"
            '
            'spreadsheetCommandBarButtonItem107
            '
            Me.spreadsheetCommandBarButtonItem107.CommandName = "MailMergeResetRange"
            Me.spreadsheetCommandBarButtonItem107.Id = 185
            Me.spreadsheetCommandBarButtonItem107.Name = "spreadsheetCommandBarButtonItem107"
            Me.spreadsheetCommandBarButtonItem107.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarCheckItem22
            '
            Me.spreadsheetCommandBarCheckItem22.CommandName = "MailMergeShowRanges"
            Me.spreadsheetCommandBarCheckItem22.Id = 186
            Me.spreadsheetCommandBarCheckItem22.Name = "spreadsheetCommandBarCheckItem22"
            Me.spreadsheetCommandBarCheckItem22.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'spreadsheetCommandBarCheckItem23
            '
            Me.spreadsheetCommandBarCheckItem23.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.spreadsheetCommandBarCheckItem23.CommandName = "ViewShowGridlines"
            Me.spreadsheetCommandBarCheckItem23.Id = 187
            Me.spreadsheetCommandBarCheckItem23.Name = "spreadsheetCommandBarCheckItem23"
            '
            'spreadsheetCommandBarCheckItem24
            '
            Me.spreadsheetCommandBarCheckItem24.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.spreadsheetCommandBarCheckItem24.CommandName = "ViewShowHeadings"
            Me.spreadsheetCommandBarCheckItem24.Id = 188
            Me.spreadsheetCommandBarCheckItem24.Name = "spreadsheetCommandBarCheckItem24"
            '
            'spreadsheetCommandBarButtonItem108
            '
            Me.spreadsheetCommandBarButtonItem108.CommandName = "ViewZoomOut"
            Me.spreadsheetCommandBarButtonItem108.Id = 189
            Me.spreadsheetCommandBarButtonItem108.Name = "spreadsheetCommandBarButtonItem108"
            '
            'spreadsheetCommandBarButtonItem109
            '
            Me.spreadsheetCommandBarButtonItem109.CommandName = "ViewZoomIn"
            Me.spreadsheetCommandBarButtonItem109.Id = 190
            Me.spreadsheetCommandBarButtonItem109.Name = "spreadsheetCommandBarButtonItem109"
            '
            'spreadsheetCommandBarButtonItem110
            '
            Me.spreadsheetCommandBarButtonItem110.CommandName = "ViewZoom100Percent"
            Me.spreadsheetCommandBarButtonItem110.Id = 191
            Me.spreadsheetCommandBarButtonItem110.Name = "spreadsheetCommandBarButtonItem110"
            '
            'spreadsheetCommandBarSubItem22
            '
            Me.spreadsheetCommandBarSubItem22.CommandName = "ViewFreezePanesCommandGroup"
            Me.spreadsheetCommandBarSubItem22.Id = 192
            Me.spreadsheetCommandBarSubItem22.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem111), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem112), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem113), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem114)})
            Me.spreadsheetCommandBarSubItem22.Name = "spreadsheetCommandBarSubItem22"
            '
            'spreadsheetCommandBarButtonItem111
            '
            Me.spreadsheetCommandBarButtonItem111.CommandName = "ViewFreezePanes"
            Me.spreadsheetCommandBarButtonItem111.Id = 193
            Me.spreadsheetCommandBarButtonItem111.Name = "spreadsheetCommandBarButtonItem111"
            '
            'spreadsheetCommandBarButtonItem112
            '
            Me.spreadsheetCommandBarButtonItem112.CommandName = "ViewUnfreezePanes"
            Me.spreadsheetCommandBarButtonItem112.Id = 194
            Me.spreadsheetCommandBarButtonItem112.Name = "spreadsheetCommandBarButtonItem112"
            '
            'spreadsheetCommandBarButtonItem113
            '
            Me.spreadsheetCommandBarButtonItem113.CommandName = "ViewFreezeTopRow"
            Me.spreadsheetCommandBarButtonItem113.Id = 195
            Me.spreadsheetCommandBarButtonItem113.Name = "spreadsheetCommandBarButtonItem113"
            '
            'spreadsheetCommandBarButtonItem114
            '
            Me.spreadsheetCommandBarButtonItem114.CommandName = "ViewFreezeFirstColumn"
            Me.spreadsheetCommandBarButtonItem114.Id = 196
            Me.spreadsheetCommandBarButtonItem114.Name = "spreadsheetCommandBarButtonItem114"
            '
            'spreadsheetCommandBarButtonItem115
            '
            Me.spreadsheetCommandBarButtonItem115.CommandName = "ChartChangeType"
            Me.spreadsheetCommandBarButtonItem115.Id = 197
            Me.spreadsheetCommandBarButtonItem115.Name = "spreadsheetCommandBarButtonItem115"
            '
            'spreadsheetCommandBarButtonItem116
            '
            Me.spreadsheetCommandBarButtonItem116.CommandName = "ChartSwitchRowColumn"
            Me.spreadsheetCommandBarButtonItem116.Id = 198
            Me.spreadsheetCommandBarButtonItem116.Name = "spreadsheetCommandBarButtonItem116"
            '
            'galleryChartLayoutItem1
            '
            '
            '
            '
            Me.galleryChartLayoutItem1.Gallery.ColumnCount = 6
            Me.galleryChartLayoutItem1.Gallery.DrawImageBackground = False
            Me.galleryChartLayoutItem1.Gallery.ImageSize = New System.Drawing.Size(265, 281)
            Me.galleryChartLayoutItem1.Gallery.RowCount = 2
            Me.galleryChartLayoutItem1.Id = 199
            Me.galleryChartLayoutItem1.Name = "galleryChartLayoutItem1"
            '
            'galleryChartStyleItem1
            '
            '
            '
            '
            Me.galleryChartStyleItem1.Gallery.ColumnCount = 8
            Me.galleryChartStyleItem1.Gallery.DrawImageBackground = False
            Me.galleryChartStyleItem1.Gallery.ImageSize = New System.Drawing.Size(362, 271)
            Me.galleryChartStyleItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
            Me.galleryChartStyleItem1.Gallery.ItemSize = New System.Drawing.Size(515, 326)
            Me.galleryChartStyleItem1.Gallery.MinimumColumnCount = 4
            Me.galleryChartStyleItem1.Gallery.RowCount = 6
            Me.galleryChartStyleItem1.Id = 200
            Me.galleryChartStyleItem1.Name = "galleryChartStyleItem1"
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem11
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem11.CommandName = "ChartTitleCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem11.DropDownControl = Me.commandBarGalleryDropDown13
            Me.spreadsheetCommandBarButtonGalleryDropDownItem11.Id = 201
            Me.spreadsheetCommandBarButtonGalleryDropDownItem11.Name = "spreadsheetCommandBarButtonGalleryDropDownItem11"
            '
            'commandBarGalleryDropDown13
            '
            '
            '
            '
            Me.commandBarGalleryDropDown13.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown13.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup29.CommandName = "ChartTitleCommandGroup"
            SpreadsheetCommandGalleryItem121.CommandName = "ChartTitleNone"
            SpreadsheetCommandGalleryItem122.CommandName = "ChartTitleCenteredOverlay"
            SpreadsheetCommandGalleryItem123.CommandName = "ChartTitleAbove"
            SpreadsheetCommandGalleryItemGroup29.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem121, SpreadsheetCommandGalleryItem122, SpreadsheetCommandGalleryItem123})
            Me.commandBarGalleryDropDown13.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup29})
            Me.commandBarGalleryDropDown13.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown13.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown13.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown13.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown13.Name = "commandBarGalleryDropDown13"
            Me.commandBarGalleryDropDown13.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarSubItem23
            '
            Me.spreadsheetCommandBarSubItem23.CommandName = "ChartAxisTitlesCommandGroup"
            Me.spreadsheetCommandBarSubItem23.Id = 202
            Me.spreadsheetCommandBarSubItem23.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem12), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem13)})
            Me.spreadsheetCommandBarSubItem23.Name = "spreadsheetCommandBarSubItem23"
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem12
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem12.CommandName = "ChartPrimaryHorizontalAxisTitleCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem12.DropDownControl = Me.commandBarGalleryDropDown14
            Me.spreadsheetCommandBarButtonGalleryDropDownItem12.Id = 203
            Me.spreadsheetCommandBarButtonGalleryDropDownItem12.Name = "spreadsheetCommandBarButtonGalleryDropDownItem12"
            '
            'commandBarGalleryDropDown14
            '
            '
            '
            '
            Me.commandBarGalleryDropDown14.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown14.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup30.CommandName = "ChartPrimaryHorizontalAxisTitleCommandGroup"
            SpreadsheetCommandGalleryItem124.CommandName = "ChartPrimaryHorizontalAxisTitleNone"
            SpreadsheetCommandGalleryItem125.CommandName = "ChartPrimaryHorizontalAxisTitleBelow"
            SpreadsheetCommandGalleryItemGroup30.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem124, SpreadsheetCommandGalleryItem125})
            Me.commandBarGalleryDropDown14.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup30})
            Me.commandBarGalleryDropDown14.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown14.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown14.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown14.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown14.Name = "commandBarGalleryDropDown14"
            Me.commandBarGalleryDropDown14.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem13
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem13.CommandName = "ChartPrimaryVerticalAxisTitleCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem13.DropDownControl = Me.commandBarGalleryDropDown15
            Me.spreadsheetCommandBarButtonGalleryDropDownItem13.Id = 204
            Me.spreadsheetCommandBarButtonGalleryDropDownItem13.Name = "spreadsheetCommandBarButtonGalleryDropDownItem13"
            '
            'commandBarGalleryDropDown15
            '
            '
            '
            '
            Me.commandBarGalleryDropDown15.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown15.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup31.CommandName = "ChartPrimaryVerticalAxisTitleCommandGroup"
            SpreadsheetCommandGalleryItem126.CommandName = "ChartPrimaryVerticalAxisTitleNone"
            SpreadsheetCommandGalleryItem127.CommandName = "ChartPrimaryVerticalAxisTitleRotated"
            SpreadsheetCommandGalleryItem128.CommandName = "ChartPrimaryVerticalAxisTitleVertical"
            SpreadsheetCommandGalleryItem129.CommandName = "ChartPrimaryVerticalAxisTitleHorizontal"
            SpreadsheetCommandGalleryItemGroup31.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem126, SpreadsheetCommandGalleryItem127, SpreadsheetCommandGalleryItem128, SpreadsheetCommandGalleryItem129})
            Me.commandBarGalleryDropDown15.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup31})
            Me.commandBarGalleryDropDown15.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown15.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown15.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown15.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown15.Name = "commandBarGalleryDropDown15"
            Me.commandBarGalleryDropDown15.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem14
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem14.CommandName = "ChartLegendCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem14.DropDownControl = Me.commandBarGalleryDropDown16
            Me.spreadsheetCommandBarButtonGalleryDropDownItem14.Id = 205
            Me.spreadsheetCommandBarButtonGalleryDropDownItem14.Name = "spreadsheetCommandBarButtonGalleryDropDownItem14"
            '
            'commandBarGalleryDropDown16
            '
            '
            '
            '
            Me.commandBarGalleryDropDown16.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown16.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup32.CommandName = "ChartLegendCommandGroup"
            SpreadsheetCommandGalleryItem130.CommandName = "ChartLegendNone"
            SpreadsheetCommandGalleryItem131.CommandName = "ChartLegendAtRight"
            SpreadsheetCommandGalleryItem132.CommandName = "ChartLegendAtTop"
            SpreadsheetCommandGalleryItem133.CommandName = "ChartLegendAtLeft"
            SpreadsheetCommandGalleryItem134.CommandName = "ChartLegendAtBottom"
            SpreadsheetCommandGalleryItem135.CommandName = "ChartLegendOverlayAtRight"
            SpreadsheetCommandGalleryItem136.CommandName = "ChartLegendOverlayAtLeft"
            SpreadsheetCommandGalleryItemGroup32.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem130, SpreadsheetCommandGalleryItem131, SpreadsheetCommandGalleryItem132, SpreadsheetCommandGalleryItem133, SpreadsheetCommandGalleryItem134, SpreadsheetCommandGalleryItem135, SpreadsheetCommandGalleryItem136})
            Me.commandBarGalleryDropDown16.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup32})
            Me.commandBarGalleryDropDown16.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown16.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown16.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown16.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown16.Name = "commandBarGalleryDropDown16"
            Me.commandBarGalleryDropDown16.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem15
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem15.CommandName = "ChartDataLabelsCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem15.DropDownControl = Me.commandBarGalleryDropDown17
            Me.spreadsheetCommandBarButtonGalleryDropDownItem15.Id = 206
            Me.spreadsheetCommandBarButtonGalleryDropDownItem15.Name = "spreadsheetCommandBarButtonGalleryDropDownItem15"
            '
            'commandBarGalleryDropDown17
            '
            '
            '
            '
            Me.commandBarGalleryDropDown17.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown17.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup33.CommandName = "ChartDataLabelsCommandGroup"
            SpreadsheetCommandGalleryItem137.CommandName = "ChartDataLabelsNone"
            SpreadsheetCommandGalleryItem138.CommandName = "ChartDataLabelsDefault"
            SpreadsheetCommandGalleryItem139.CommandName = "ChartDataLabelsCenter"
            SpreadsheetCommandGalleryItem140.CommandName = "ChartDataLabelsInsideEnd"
            SpreadsheetCommandGalleryItem141.CommandName = "ChartDataLabelsInsideBase"
            SpreadsheetCommandGalleryItem142.CommandName = "ChartDataLabelsOutsideEnd"
            SpreadsheetCommandGalleryItem143.CommandName = "ChartDataLabelsBestFit"
            SpreadsheetCommandGalleryItem144.CommandName = "ChartDataLabelsLeft"
            SpreadsheetCommandGalleryItem145.CommandName = "ChartDataLabelsRight"
            SpreadsheetCommandGalleryItem146.CommandName = "ChartDataLabelsAbove"
            SpreadsheetCommandGalleryItem147.CommandName = "ChartDataLabelsBelow"
            SpreadsheetCommandGalleryItemGroup33.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem137, SpreadsheetCommandGalleryItem138, SpreadsheetCommandGalleryItem139, SpreadsheetCommandGalleryItem140, SpreadsheetCommandGalleryItem141, SpreadsheetCommandGalleryItem142, SpreadsheetCommandGalleryItem143, SpreadsheetCommandGalleryItem144, SpreadsheetCommandGalleryItem145, SpreadsheetCommandGalleryItem146, SpreadsheetCommandGalleryItem147})
            Me.commandBarGalleryDropDown17.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup33})
            Me.commandBarGalleryDropDown17.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown17.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown17.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown17.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown17.Name = "commandBarGalleryDropDown17"
            Me.commandBarGalleryDropDown17.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarSubItem24
            '
            Me.spreadsheetCommandBarSubItem24.CommandName = "ChartAxesCommandGroup"
            Me.spreadsheetCommandBarSubItem24.Id = 207
            Me.spreadsheetCommandBarSubItem24.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem16), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem17)})
            Me.spreadsheetCommandBarSubItem24.Name = "spreadsheetCommandBarSubItem24"
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem16
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem16.CommandName = "ChartPrimaryHorizontalAxisCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem16.DropDownControl = Me.commandBarGalleryDropDown18
            Me.spreadsheetCommandBarButtonGalleryDropDownItem16.Id = 208
            Me.spreadsheetCommandBarButtonGalleryDropDownItem16.Name = "spreadsheetCommandBarButtonGalleryDropDownItem16"
            '
            'commandBarGalleryDropDown18
            '
            '
            '
            '
            Me.commandBarGalleryDropDown18.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown18.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup34.CommandName = "ChartPrimaryHorizontalAxisCommandGroup"
            SpreadsheetCommandGalleryItem148.CommandName = "ChartHidePrimaryHorizontalAxis"
            SpreadsheetCommandGalleryItem149.CommandName = "ChartPrimaryHorizontalAxisLeftToRight"
            SpreadsheetCommandGalleryItem150.CommandName = "ChartPrimaryHorizontalAxisHideLabels"
            SpreadsheetCommandGalleryItem151.CommandName = "ChartPrimaryHorizontalAxisRightToLeft"
            SpreadsheetCommandGalleryItem152.CommandName = "ChartPrimaryHorizontalAxisDefault"
            SpreadsheetCommandGalleryItem153.CommandName = "ChartPrimaryHorizontalAxisScaleThousands"
            SpreadsheetCommandGalleryItem154.CommandName = "ChartPrimaryHorizontalAxisScaleMillions"
            SpreadsheetCommandGalleryItem155.CommandName = "ChartPrimaryHorizontalAxisScaleBillions"
            SpreadsheetCommandGalleryItem156.CommandName = "ChartPrimaryHorizontalAxisScaleLogarithm"
            SpreadsheetCommandGalleryItemGroup34.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem148, SpreadsheetCommandGalleryItem149, SpreadsheetCommandGalleryItem150, SpreadsheetCommandGalleryItem151, SpreadsheetCommandGalleryItem152, SpreadsheetCommandGalleryItem153, SpreadsheetCommandGalleryItem154, SpreadsheetCommandGalleryItem155, SpreadsheetCommandGalleryItem156})
            Me.commandBarGalleryDropDown18.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup34})
            Me.commandBarGalleryDropDown18.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown18.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown18.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown18.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown18.Name = "commandBarGalleryDropDown18"
            Me.commandBarGalleryDropDown18.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem17
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem17.CommandName = "ChartPrimaryVerticalAxisCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem17.DropDownControl = Me.commandBarGalleryDropDown19
            Me.spreadsheetCommandBarButtonGalleryDropDownItem17.Id = 209
            Me.spreadsheetCommandBarButtonGalleryDropDownItem17.Name = "spreadsheetCommandBarButtonGalleryDropDownItem17"
            '
            'commandBarGalleryDropDown19
            '
            '
            '
            '
            Me.commandBarGalleryDropDown19.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown19.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup35.CommandName = "ChartPrimaryVerticalAxisCommandGroup"
            SpreadsheetCommandGalleryItem157.CommandName = "ChartHidePrimaryVerticalAxis"
            SpreadsheetCommandGalleryItem158.CommandName = "ChartPrimaryVerticalAxisLeftToRight"
            SpreadsheetCommandGalleryItem159.CommandName = "ChartPrimaryVerticalAxisHideLabels"
            SpreadsheetCommandGalleryItem160.CommandName = "ChartPrimaryVerticalAxisRightToLeft"
            SpreadsheetCommandGalleryItem161.CommandName = "ChartPrimaryVerticalAxisDefault"
            SpreadsheetCommandGalleryItem162.CommandName = "ChartPrimaryVerticalAxisScaleThousands"
            SpreadsheetCommandGalleryItem163.CommandName = "ChartPrimaryVerticalAxisScaleMillions"
            SpreadsheetCommandGalleryItem164.CommandName = "ChartPrimaryVerticalAxisScaleBillions"
            SpreadsheetCommandGalleryItem165.CommandName = "ChartPrimaryVerticalAxisScaleLogarithm"
            SpreadsheetCommandGalleryItemGroup35.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem157, SpreadsheetCommandGalleryItem158, SpreadsheetCommandGalleryItem159, SpreadsheetCommandGalleryItem160, SpreadsheetCommandGalleryItem161, SpreadsheetCommandGalleryItem162, SpreadsheetCommandGalleryItem163, SpreadsheetCommandGalleryItem164, SpreadsheetCommandGalleryItem165})
            Me.commandBarGalleryDropDown19.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup35})
            Me.commandBarGalleryDropDown19.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown19.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown19.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown19.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown19.Name = "commandBarGalleryDropDown19"
            Me.commandBarGalleryDropDown19.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarSubItem25
            '
            Me.spreadsheetCommandBarSubItem25.CommandName = "ChartGridlinesCommandGroup"
            Me.spreadsheetCommandBarSubItem25.Id = 210
            Me.spreadsheetCommandBarSubItem25.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem18), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem19)})
            Me.spreadsheetCommandBarSubItem25.Name = "spreadsheetCommandBarSubItem25"
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem18
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem18.CommandName = "ChartPrimaryHorizontalGridlinesCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem18.DropDownControl = Me.commandBarGalleryDropDown20
            Me.spreadsheetCommandBarButtonGalleryDropDownItem18.Id = 211
            Me.spreadsheetCommandBarButtonGalleryDropDownItem18.Name = "spreadsheetCommandBarButtonGalleryDropDownItem18"
            '
            'commandBarGalleryDropDown20
            '
            '
            '
            '
            Me.commandBarGalleryDropDown20.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown20.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup36.CommandName = "ChartPrimaryHorizontalGridlinesCommandGroup"
            SpreadsheetCommandGalleryItem166.CommandName = "ChartPrimaryHorizontalGridlinesNone"
            SpreadsheetCommandGalleryItem167.CommandName = "ChartPrimaryHorizontalGridlinesMajor"
            SpreadsheetCommandGalleryItem168.CommandName = "ChartPrimaryHorizontalGridlinesMinor"
            SpreadsheetCommandGalleryItem169.CommandName = "ChartPrimaryHorizontalGridlinesMajorAndMinor"
            SpreadsheetCommandGalleryItemGroup36.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem166, SpreadsheetCommandGalleryItem167, SpreadsheetCommandGalleryItem168, SpreadsheetCommandGalleryItem169})
            Me.commandBarGalleryDropDown20.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup36})
            Me.commandBarGalleryDropDown20.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown20.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown20.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown20.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown20.Name = "commandBarGalleryDropDown20"
            Me.commandBarGalleryDropDown20.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem19
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem19.CommandName = "ChartPrimaryVerticalGridlinesCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem19.DropDownControl = Me.commandBarGalleryDropDown21
            Me.spreadsheetCommandBarButtonGalleryDropDownItem19.Id = 212
            Me.spreadsheetCommandBarButtonGalleryDropDownItem19.Name = "spreadsheetCommandBarButtonGalleryDropDownItem19"
            '
            'commandBarGalleryDropDown21
            '
            '
            '
            '
            Me.commandBarGalleryDropDown21.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown21.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup37.CommandName = "ChartPrimaryVerticalGridlinesCommandGroup"
            SpreadsheetCommandGalleryItem170.CommandName = "ChartPrimaryVerticalGridlinesNone"
            SpreadsheetCommandGalleryItem171.CommandName = "ChartPrimaryVerticalGridlinesMajor"
            SpreadsheetCommandGalleryItem172.CommandName = "ChartPrimaryVerticalGridlinesMinor"
            SpreadsheetCommandGalleryItem173.CommandName = "ChartPrimaryVerticalGridlinesMajorAndMinor"
            SpreadsheetCommandGalleryItemGroup37.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem170, SpreadsheetCommandGalleryItem171, SpreadsheetCommandGalleryItem172, SpreadsheetCommandGalleryItem173})
            Me.commandBarGalleryDropDown21.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup37})
            Me.commandBarGalleryDropDown21.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown21.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown21.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown21.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown21.Name = "commandBarGalleryDropDown21"
            Me.commandBarGalleryDropDown21.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem20
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem20.CommandName = "ChartLinesCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem20.DropDownControl = Me.commandBarGalleryDropDown22
            Me.spreadsheetCommandBarButtonGalleryDropDownItem20.Id = 213
            Me.spreadsheetCommandBarButtonGalleryDropDownItem20.Name = "spreadsheetCommandBarButtonGalleryDropDownItem20"
            '
            'commandBarGalleryDropDown22
            '
            '
            '
            '
            Me.commandBarGalleryDropDown22.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown22.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup38.CommandName = "ChartLinesCommandGroup"
            SpreadsheetCommandGalleryItem174.CommandName = "ChartLinesNone"
            SpreadsheetCommandGalleryItem175.CommandName = "ChartShowDropLines"
            SpreadsheetCommandGalleryItem176.CommandName = "ChartShowHighLowLines"
            SpreadsheetCommandGalleryItem177.CommandName = "ChartShowDropLinesAndHighLowLines"
            SpreadsheetCommandGalleryItem178.CommandName = "ChartShowSeriesLines"
            SpreadsheetCommandGalleryItemGroup38.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem174, SpreadsheetCommandGalleryItem175, SpreadsheetCommandGalleryItem176, SpreadsheetCommandGalleryItem177, SpreadsheetCommandGalleryItem178})
            Me.commandBarGalleryDropDown22.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup38})
            Me.commandBarGalleryDropDown22.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown22.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown22.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown22.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown22.Name = "commandBarGalleryDropDown22"
            Me.commandBarGalleryDropDown22.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem21
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem21.CommandName = "ChartUpDownBarsCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem21.DropDownControl = Me.commandBarGalleryDropDown23
            Me.spreadsheetCommandBarButtonGalleryDropDownItem21.Id = 214
            Me.spreadsheetCommandBarButtonGalleryDropDownItem21.Name = "spreadsheetCommandBarButtonGalleryDropDownItem21"
            '
            'commandBarGalleryDropDown23
            '
            '
            '
            '
            Me.commandBarGalleryDropDown23.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown23.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup39.CommandName = "ChartUpDownBarsCommandGroup"
            SpreadsheetCommandGalleryItem179.CommandName = "ChartHideUpDownBars"
            SpreadsheetCommandGalleryItem180.CommandName = "ChartShowUpDownBars"
            SpreadsheetCommandGalleryItemGroup39.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem179, SpreadsheetCommandGalleryItem180})
            Me.commandBarGalleryDropDown23.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup39})
            Me.commandBarGalleryDropDown23.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown23.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown23.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown23.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown23.Name = "commandBarGalleryDropDown23"
            Me.commandBarGalleryDropDown23.Ribbon = Me.ribbonControl1
            '
            'spreadsheetCommandBarButtonGalleryDropDownItem22
            '
            Me.spreadsheetCommandBarButtonGalleryDropDownItem22.CommandName = "ChartErrorBarsCommandGroup"
            Me.spreadsheetCommandBarButtonGalleryDropDownItem22.DropDownControl = Me.commandBarGalleryDropDown24
            Me.spreadsheetCommandBarButtonGalleryDropDownItem22.Id = 215
            Me.spreadsheetCommandBarButtonGalleryDropDownItem22.Name = "spreadsheetCommandBarButtonGalleryDropDownItem22"
            '
            'commandBarGalleryDropDown24
            '
            '
            '
            '
            Me.commandBarGalleryDropDown24.Gallery.AllowFilter = False
            Me.commandBarGalleryDropDown24.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both
            SpreadsheetCommandGalleryItemGroup40.CommandName = "ChartErrorBarsCommandGroup"
            SpreadsheetCommandGalleryItem181.CommandName = "ChartErrorBarsNone"
            SpreadsheetCommandGalleryItem182.CommandName = "ChartErrorBarsStandardError"
            SpreadsheetCommandGalleryItem183.CommandName = "ChartErrorBarsPercentage"
            SpreadsheetCommandGalleryItem184.CommandName = "ChartErrorBarsStandardDeviation"
            SpreadsheetCommandGalleryItemGroup40.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem181, SpreadsheetCommandGalleryItem182, SpreadsheetCommandGalleryItem183, SpreadsheetCommandGalleryItem184})
            Me.commandBarGalleryDropDown24.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup40})
            Me.commandBarGalleryDropDown24.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.commandBarGalleryDropDown24.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
            Me.commandBarGalleryDropDown24.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
            Me.commandBarGalleryDropDown24.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.commandBarGalleryDropDown24.Name = "commandBarGalleryDropDown24"
            Me.commandBarGalleryDropDown24.Ribbon = Me.ribbonControl1
            '
            'barStaticItem1
            '
            Me.barStaticItem1.Caption = "Table Name:"
            Me.barStaticItem1.Id = 216
            Me.barStaticItem1.Name = "barStaticItem1"
            '
            'renameTableItem1
            '
            Me.renameTableItem1.Edit = Me.repositoryItemTextEdit1
            Me.renameTableItem1.Id = 217
            Me.renameTableItem1.Name = "renameTableItem1"
            '
            'repositoryItemTextEdit1
            '
            Me.repositoryItemTextEdit1.AutoHeight = False
            Me.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1"
            '
            'spreadsheetCommandBarCheckItem25
            '
            Me.spreadsheetCommandBarCheckItem25.CommandName = "TableToolsConvertToRange"
            Me.spreadsheetCommandBarCheckItem25.Id = 218
            Me.spreadsheetCommandBarCheckItem25.Name = "spreadsheetCommandBarCheckItem25"
            Me.spreadsheetCommandBarCheckItem25.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'spreadsheetCommandBarCheckItem26
            '
            Me.spreadsheetCommandBarCheckItem26.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.spreadsheetCommandBarCheckItem26.CommandName = "TableToolsToggleHeaderRow"
            Me.spreadsheetCommandBarCheckItem26.Id = 219
            Me.spreadsheetCommandBarCheckItem26.Name = "spreadsheetCommandBarCheckItem26"
            '
            'spreadsheetCommandBarCheckItem27
            '
            Me.spreadsheetCommandBarCheckItem27.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.spreadsheetCommandBarCheckItem27.CommandName = "TableToolsToggleTotalRow"
            Me.spreadsheetCommandBarCheckItem27.Id = 220
            Me.spreadsheetCommandBarCheckItem27.Name = "spreadsheetCommandBarCheckItem27"
            '
            'spreadsheetCommandBarCheckItem28
            '
            Me.spreadsheetCommandBarCheckItem28.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.spreadsheetCommandBarCheckItem28.CommandName = "TableToolsToggleBandedColumns"
            Me.spreadsheetCommandBarCheckItem28.Id = 221
            Me.spreadsheetCommandBarCheckItem28.Name = "spreadsheetCommandBarCheckItem28"
            '
            'spreadsheetCommandBarCheckItem29
            '
            Me.spreadsheetCommandBarCheckItem29.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.spreadsheetCommandBarCheckItem29.CommandName = "TableToolsToggleFirstColumn"
            Me.spreadsheetCommandBarCheckItem29.Id = 222
            Me.spreadsheetCommandBarCheckItem29.Name = "spreadsheetCommandBarCheckItem29"
            '
            'spreadsheetCommandBarCheckItem30
            '
            Me.spreadsheetCommandBarCheckItem30.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.spreadsheetCommandBarCheckItem30.CommandName = "TableToolsToggleLastColumn"
            Me.spreadsheetCommandBarCheckItem30.Id = 223
            Me.spreadsheetCommandBarCheckItem30.Name = "spreadsheetCommandBarCheckItem30"
            '
            'spreadsheetCommandBarCheckItem31
            '
            Me.spreadsheetCommandBarCheckItem31.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.spreadsheetCommandBarCheckItem31.CommandName = "TableToolsToggleBandedRows"
            Me.spreadsheetCommandBarCheckItem31.Id = 224
            Me.spreadsheetCommandBarCheckItem31.Name = "spreadsheetCommandBarCheckItem31"
            '
            'galleryTableStylesItem1
            '
            '
            '
            '
            Me.galleryTableStylesItem1.Gallery.ColumnCount = 7
            Me.galleryTableStylesItem1.Gallery.DrawImageBackground = False
            Me.galleryTableStylesItem1.Gallery.ImageSize = New System.Drawing.Size(362, 271)
            Me.galleryTableStylesItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
            Me.galleryTableStylesItem1.Gallery.ItemSize = New System.Drawing.Size(401, 339)
            Me.galleryTableStylesItem1.Gallery.RowCount = 10
            Me.galleryTableStylesItem1.Id = 225
            Me.galleryTableStylesItem1.Name = "galleryTableStylesItem1"
            '
            'SpreadsheetCommandBarButtonItem117
            '
            Me.SpreadsheetCommandBarButtonItem117.CommandName = "FileEncrypt"
            Me.SpreadsheetCommandBarButtonItem117.Id = 234
            Me.SpreadsheetCommandBarButtonItem117.Name = "SpreadsheetCommandBarButtonItem117"
            '
            'SpreadsheetCommandBarButtonItem118
            '
            Me.SpreadsheetCommandBarButtonItem118.CommandName = "FileShowDocumentProperties"
            Me.SpreadsheetCommandBarButtonItem118.Id = 235
            Me.SpreadsheetCommandBarButtonItem118.Name = "SpreadsheetCommandBarButtonItem118"
            '
            'SpreadsheetCommandBarButtonItem120
            '
            Me.SpreadsheetCommandBarButtonItem120.CommandName = "NewConditionalFormattingRule"
            Me.SpreadsheetCommandBarButtonItem120.Id = 237
            Me.SpreadsheetCommandBarButtonItem120.Name = "SpreadsheetCommandBarButtonItem120"
            '
            'SpreadsheetCommandBarButtonItem121
            '
            Me.SpreadsheetCommandBarButtonItem121.CommandName = "ConditionalFormattingRulesManager"
            Me.SpreadsheetCommandBarButtonItem121.Id = 238
            Me.SpreadsheetCommandBarButtonItem121.Name = "SpreadsheetCommandBarButtonItem121"
            '
            'SpreadsheetCommandBarSubItem26
            '
            Me.SpreadsheetCommandBarSubItem26.CommandName = "EditingSortAndFilterCommandGroup"
            Me.SpreadsheetCommandBarSubItem26.Id = 255
            Me.SpreadsheetCommandBarSubItem26.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem100), New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem101), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem33), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem136), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem137)})
            Me.SpreadsheetCommandBarSubItem26.Name = "SpreadsheetCommandBarSubItem26"
            '
            'SpreadsheetCommandBarCheckItem33
            '
            Me.SpreadsheetCommandBarCheckItem33.CommandName = "DataFilterToggle"
            Me.SpreadsheetCommandBarCheckItem33.Id = 256
            Me.SpreadsheetCommandBarCheckItem33.Name = "SpreadsheetCommandBarCheckItem33"
            '
            'SpreadsheetCommandBarButtonItem136
            '
            Me.SpreadsheetCommandBarButtonItem136.CommandName = "DataFilterClear"
            Me.SpreadsheetCommandBarButtonItem136.Id = 257
            Me.SpreadsheetCommandBarButtonItem136.Name = "SpreadsheetCommandBarButtonItem136"
            '
            'SpreadsheetCommandBarButtonItem137
            '
            Me.SpreadsheetCommandBarButtonItem137.CommandName = "DataFilterReApply"
            Me.SpreadsheetCommandBarButtonItem137.Id = 258
            Me.SpreadsheetCommandBarButtonItem137.Name = "SpreadsheetCommandBarButtonItem137"
            '
            'SpreadsheetCommandBarSubItem27
            '
            Me.SpreadsheetCommandBarSubItem27.CommandName = "EditingFindAndSelectCommandGroup"
            Me.SpreadsheetCommandBarSubItem27.Id = 259
            Me.SpreadsheetCommandBarSubItem27.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem138), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem139), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem140), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem141), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem142), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem143), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem144)})
            Me.SpreadsheetCommandBarSubItem27.Name = "SpreadsheetCommandBarSubItem27"
            '
            'SpreadsheetCommandBarButtonItem138
            '
            Me.SpreadsheetCommandBarButtonItem138.CommandName = "EditingFind"
            Me.SpreadsheetCommandBarButtonItem138.Id = 260
            Me.SpreadsheetCommandBarButtonItem138.Name = "SpreadsheetCommandBarButtonItem138"
            '
            'SpreadsheetCommandBarButtonItem139
            '
            Me.SpreadsheetCommandBarButtonItem139.CommandName = "EditingReplace"
            Me.SpreadsheetCommandBarButtonItem139.Id = 261
            Me.SpreadsheetCommandBarButtonItem139.Name = "SpreadsheetCommandBarButtonItem139"
            '
            'SpreadsheetCommandBarButtonItem140
            '
            Me.SpreadsheetCommandBarButtonItem140.CommandName = "EditingSelectFormulas"
            Me.SpreadsheetCommandBarButtonItem140.Id = 262
            Me.SpreadsheetCommandBarButtonItem140.Name = "SpreadsheetCommandBarButtonItem140"
            '
            'SpreadsheetCommandBarButtonItem141
            '
            Me.SpreadsheetCommandBarButtonItem141.CommandName = "EditingSelectComments"
            Me.SpreadsheetCommandBarButtonItem141.Id = 263
            Me.SpreadsheetCommandBarButtonItem141.Name = "SpreadsheetCommandBarButtonItem141"
            '
            'SpreadsheetCommandBarButtonItem142
            '
            Me.SpreadsheetCommandBarButtonItem142.CommandName = "EditingSelectConditionalFormatting"
            Me.SpreadsheetCommandBarButtonItem142.Id = 264
            Me.SpreadsheetCommandBarButtonItem142.Name = "SpreadsheetCommandBarButtonItem142"
            '
            'SpreadsheetCommandBarButtonItem143
            '
            Me.SpreadsheetCommandBarButtonItem143.CommandName = "EditingSelectConstants"
            Me.SpreadsheetCommandBarButtonItem143.Id = 265
            Me.SpreadsheetCommandBarButtonItem143.Name = "SpreadsheetCommandBarButtonItem143"
            '
            'SpreadsheetCommandBarButtonItem144
            '
            Me.SpreadsheetCommandBarButtonItem144.CommandName = "EditingSelectDataValidation"
            Me.SpreadsheetCommandBarButtonItem144.Id = 266
            Me.SpreadsheetCommandBarButtonItem144.Name = "SpreadsheetCommandBarButtonItem144"
            '
            'SpreadsheetCommandBarButtonItem145
            '
            Me.SpreadsheetCommandBarButtonItem145.CommandName = "InsertPivotTable"
            Me.SpreadsheetCommandBarButtonItem145.Id = 267
            Me.SpreadsheetCommandBarButtonItem145.Name = "SpreadsheetCommandBarButtonItem145"
            '
            'SpreadsheetCommandBarButtonGalleryDropDownItem23
            '
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem23.CommandName = "InsertChartStatisticCommandGroup"
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem23.DropDownControl = Me.CommandBarGalleryDropDown25
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem23.Id = 268
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem23.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem23"
            '
            'CommandBarGalleryDropDown25
            '
            '
            '
            '
            Me.CommandBarGalleryDropDown25.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup41.CommandName = "InsertChartHistogramCommandGroup"
            SpreadsheetCommandGalleryItem185.CommandName = "InsertChartHistogram"
            SpreadsheetCommandGalleryItem186.CommandName = "InsertChartPareto"
            SpreadsheetCommandGalleryItemGroup41.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem185, SpreadsheetCommandGalleryItem186})
            SpreadsheetCommandGalleryItemGroup42.CommandName = "InsertChartBoxAndWhiskerCommandGroup"
            SpreadsheetCommandGalleryItem187.CommandName = "InsertChartBoxAndWhisker"
            SpreadsheetCommandGalleryItemGroup42.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem187})
            Me.CommandBarGalleryDropDown25.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup41, SpreadsheetCommandGalleryItemGroup42})
            Me.CommandBarGalleryDropDown25.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.CommandBarGalleryDropDown25.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.CommandBarGalleryDropDown25.Name = "CommandBarGalleryDropDown25"
            Me.CommandBarGalleryDropDown25.Ribbon = Me.ribbonControl1
            '
            'SpreadsheetCommandBarButtonGalleryDropDownItem24
            '
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem24.CommandName = "InsertChartHierarchyCommandGroup"
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem24.DropDownControl = Me.CommandBarGalleryDropDown26
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem24.Id = 269
            Me.SpreadsheetCommandBarButtonGalleryDropDownItem24.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem24"
            '
            'CommandBarGalleryDropDown26
            '
            '
            '
            '
            Me.CommandBarGalleryDropDown26.Gallery.AllowFilter = False
            SpreadsheetCommandGalleryItemGroup43.CommandName = "InsertChartTreemapCommandGroup"
            SpreadsheetCommandGalleryItem188.CommandName = "InsertChartTreemap"
            SpreadsheetCommandGalleryItemGroup43.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem188})
            SpreadsheetCommandGalleryItemGroup44.CommandName = "InsertChartSunburstCommandGroup"
            SpreadsheetCommandGalleryItem189.CommandName = "InsertChartSunburst"
            SpreadsheetCommandGalleryItemGroup44.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem189})
            Me.CommandBarGalleryDropDown26.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup43, SpreadsheetCommandGalleryItemGroup44})
            Me.CommandBarGalleryDropDown26.Gallery.ImageSize = New System.Drawing.Size(32, 32)
            Me.CommandBarGalleryDropDown26.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
            Me.CommandBarGalleryDropDown26.Name = "CommandBarGalleryDropDown26"
            Me.CommandBarGalleryDropDown26.Ribbon = Me.ribbonControl1
            '
            'SpreadsheetCommandBarButtonItem146
            '
            Me.SpreadsheetCommandBarButtonItem146.CommandName = "InsertSymbol"
            Me.SpreadsheetCommandBarButtonItem146.Id = 270
            Me.SpreadsheetCommandBarButtonItem146.Name = "SpreadsheetCommandBarButtonItem146"
            '
            'SpreadsheetCommandBarSubItem28
            '
            Me.SpreadsheetCommandBarSubItem28.CommandName = "PageSetupPrintAreaCommandGroup"
            Me.SpreadsheetCommandBarSubItem28.Id = 272
            Me.SpreadsheetCommandBarSubItem28.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem148), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem149), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem150)})
            Me.SpreadsheetCommandBarSubItem28.Name = "SpreadsheetCommandBarSubItem28"
            '
            'SpreadsheetCommandBarButtonItem148
            '
            Me.SpreadsheetCommandBarButtonItem148.CommandName = "PageSetupSetPrintArea"
            Me.SpreadsheetCommandBarButtonItem148.Id = 273
            Me.SpreadsheetCommandBarButtonItem148.Name = "SpreadsheetCommandBarButtonItem148"
            '
            'SpreadsheetCommandBarButtonItem149
            '
            Me.SpreadsheetCommandBarButtonItem149.CommandName = "PageSetupClearPrintArea"
            Me.SpreadsheetCommandBarButtonItem149.Id = 274
            Me.SpreadsheetCommandBarButtonItem149.Name = "SpreadsheetCommandBarButtonItem149"
            '
            'SpreadsheetCommandBarButtonItem150
            '
            Me.SpreadsheetCommandBarButtonItem150.CommandName = "PageSetupAddPrintArea"
            Me.SpreadsheetCommandBarButtonItem150.Id = 275
            Me.SpreadsheetCommandBarButtonItem150.Name = "SpreadsheetCommandBarButtonItem150"
            '
            'SpreadsheetCommandBarButtonItem151
            '
            Me.SpreadsheetCommandBarButtonItem151.CommandName = "PageSetupPrintTitles"
            Me.SpreadsheetCommandBarButtonItem151.Id = 276
            Me.SpreadsheetCommandBarButtonItem151.Name = "SpreadsheetCommandBarButtonItem151"
            '
            'SpreadsheetCommandBarCheckItem34
            '
            Me.SpreadsheetCommandBarCheckItem34.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.SpreadsheetCommandBarCheckItem34.CommandName = "PageSetupPrintGridlines"
            Me.SpreadsheetCommandBarCheckItem34.Id = 277
            Me.SpreadsheetCommandBarCheckItem34.Name = "SpreadsheetCommandBarCheckItem34"
            '
            'SpreadsheetCommandBarCheckItem35
            '
            Me.SpreadsheetCommandBarCheckItem35.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.SpreadsheetCommandBarCheckItem35.CommandName = "PageSetupPrintHeadings"
            Me.SpreadsheetCommandBarCheckItem35.Id = 278
            Me.SpreadsheetCommandBarCheckItem35.Name = "SpreadsheetCommandBarCheckItem35"
            '
            'SpreadsheetCommandBarButtonItem152
            '
            Me.SpreadsheetCommandBarButtonItem152.CommandName = "FormulasShowNameManager"
            Me.SpreadsheetCommandBarButtonItem152.Id = 279
            Me.SpreadsheetCommandBarButtonItem152.Name = "SpreadsheetCommandBarButtonItem152"
            '
            'SpreadsheetCommandBarButtonItem153
            '
            Me.SpreadsheetCommandBarButtonItem153.CommandName = "FormulasDefineNameCommand"
            Me.SpreadsheetCommandBarButtonItem153.Id = 280
            Me.SpreadsheetCommandBarButtonItem153.Name = "SpreadsheetCommandBarButtonItem153"
            Me.SpreadsheetCommandBarButtonItem153.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'DefinedNameListItem1
            '
            Me.DefinedNameListItem1.Id = 281
            Me.DefinedNameListItem1.Name = "DefinedNameListItem1"
            Me.DefinedNameListItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarButtonItem154
            '
            Me.SpreadsheetCommandBarButtonItem154.CommandName = "FormulasCreateDefinedNamesFromSelection"
            Me.SpreadsheetCommandBarButtonItem154.Id = 282
            Me.SpreadsheetCommandBarButtonItem154.Name = "SpreadsheetCommandBarButtonItem154"
            Me.SpreadsheetCommandBarButtonItem154.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarSubItem29
            '
            Me.SpreadsheetCommandBarSubItem29.CommandName = "FormulasCalculationOptionsCommandGroup"
            Me.SpreadsheetCommandBarSubItem29.Id = 283
            Me.SpreadsheetCommandBarSubItem29.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem36), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem37)})
            Me.SpreadsheetCommandBarSubItem29.Name = "SpreadsheetCommandBarSubItem29"
            '
            'SpreadsheetCommandBarCheckItem36
            '
            Me.SpreadsheetCommandBarCheckItem36.CommandName = "FormulasCalculationModeAutomatic"
            Me.SpreadsheetCommandBarCheckItem36.Id = 284
            Me.SpreadsheetCommandBarCheckItem36.Name = "SpreadsheetCommandBarCheckItem36"
            '
            'SpreadsheetCommandBarCheckItem37
            '
            Me.SpreadsheetCommandBarCheckItem37.CommandName = "FormulasCalculationModeManual"
            Me.SpreadsheetCommandBarCheckItem37.Id = 285
            Me.SpreadsheetCommandBarCheckItem37.Name = "SpreadsheetCommandBarCheckItem37"
            '
            'SpreadsheetCommandBarButtonItem155
            '
            Me.SpreadsheetCommandBarButtonItem155.CommandName = "FormulasCalculateNow"
            Me.SpreadsheetCommandBarButtonItem155.Id = 286
            Me.SpreadsheetCommandBarButtonItem155.Name = "SpreadsheetCommandBarButtonItem155"
            Me.SpreadsheetCommandBarButtonItem155.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarButtonItem156
            '
            Me.SpreadsheetCommandBarButtonItem156.CommandName = "FormulasCalculateSheet"
            Me.SpreadsheetCommandBarButtonItem156.Id = 287
            Me.SpreadsheetCommandBarButtonItem156.Name = "SpreadsheetCommandBarButtonItem156"
            Me.SpreadsheetCommandBarButtonItem156.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarSubItem30
            '
            Me.SpreadsheetCommandBarSubItem30.CommandName = "DataToolsDataValidationCommandGroup"
            Me.SpreadsheetCommandBarSubItem30.Id = 288
            Me.SpreadsheetCommandBarSubItem30.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem157), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem158), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem159)})
            Me.SpreadsheetCommandBarSubItem30.Name = "SpreadsheetCommandBarSubItem30"
            '
            'SpreadsheetCommandBarButtonItem157
            '
            Me.SpreadsheetCommandBarButtonItem157.CommandName = "DataToolsDataValidation"
            Me.SpreadsheetCommandBarButtonItem157.Id = 289
            Me.SpreadsheetCommandBarButtonItem157.Name = "SpreadsheetCommandBarButtonItem157"
            '
            'SpreadsheetCommandBarButtonItem158
            '
            Me.SpreadsheetCommandBarButtonItem158.CommandName = "DataToolsCircleInvalidData"
            Me.SpreadsheetCommandBarButtonItem158.Id = 290
            Me.SpreadsheetCommandBarButtonItem158.Name = "SpreadsheetCommandBarButtonItem158"
            '
            'SpreadsheetCommandBarButtonItem159
            '
            Me.SpreadsheetCommandBarButtonItem159.CommandName = "DataToolsClearValidationCircles"
            Me.SpreadsheetCommandBarButtonItem159.Id = 291
            Me.SpreadsheetCommandBarButtonItem159.Name = "SpreadsheetCommandBarButtonItem159"
            '
            'SpreadsheetCommandBarSubItem31
            '
            Me.SpreadsheetCommandBarSubItem31.CommandName = "OutlineGroupCommandGroup"
            Me.SpreadsheetCommandBarSubItem31.Id = 292
            Me.SpreadsheetCommandBarSubItem31.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem160), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem161)})
            Me.SpreadsheetCommandBarSubItem31.Name = "SpreadsheetCommandBarSubItem31"
            Me.SpreadsheetCommandBarSubItem31.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem160
            '
            Me.SpreadsheetCommandBarButtonItem160.CommandName = "GroupOutline"
            Me.SpreadsheetCommandBarButtonItem160.Id = 293
            Me.SpreadsheetCommandBarButtonItem160.Name = "SpreadsheetCommandBarButtonItem160"
            '
            'SpreadsheetCommandBarButtonItem161
            '
            Me.SpreadsheetCommandBarButtonItem161.CommandName = "AutoOutline"
            Me.SpreadsheetCommandBarButtonItem161.Id = 294
            Me.SpreadsheetCommandBarButtonItem161.Name = "SpreadsheetCommandBarButtonItem161"
            '
            'SpreadsheetCommandBarSubItem32
            '
            Me.SpreadsheetCommandBarSubItem32.CommandName = "OutlineUngroupCommandGroup"
            Me.SpreadsheetCommandBarSubItem32.Id = 295
            Me.SpreadsheetCommandBarSubItem32.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem162), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem163)})
            Me.SpreadsheetCommandBarSubItem32.Name = "SpreadsheetCommandBarSubItem32"
            Me.SpreadsheetCommandBarSubItem32.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem162
            '
            Me.SpreadsheetCommandBarButtonItem162.CommandName = "UngroupOutline"
            Me.SpreadsheetCommandBarButtonItem162.Id = 296
            Me.SpreadsheetCommandBarButtonItem162.Name = "SpreadsheetCommandBarButtonItem162"
            '
            'SpreadsheetCommandBarButtonItem163
            '
            Me.SpreadsheetCommandBarButtonItem163.CommandName = "ClearOutline"
            Me.SpreadsheetCommandBarButtonItem163.Id = 297
            Me.SpreadsheetCommandBarButtonItem163.Name = "SpreadsheetCommandBarButtonItem163"
            '
            'SpreadsheetCommandBarButtonItem164
            '
            Me.SpreadsheetCommandBarButtonItem164.CommandName = "Subtotal"
            Me.SpreadsheetCommandBarButtonItem164.Id = 298
            Me.SpreadsheetCommandBarButtonItem164.Name = "SpreadsheetCommandBarButtonItem164"
            Me.SpreadsheetCommandBarButtonItem164.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem165
            '
            Me.SpreadsheetCommandBarButtonItem165.CommandName = "ShowDetail"
            Me.SpreadsheetCommandBarButtonItem165.Id = 299
            Me.SpreadsheetCommandBarButtonItem165.Name = "SpreadsheetCommandBarButtonItem165"
            Me.SpreadsheetCommandBarButtonItem165.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarButtonItem166
            '
            Me.SpreadsheetCommandBarButtonItem166.CommandName = "HideDetail"
            Me.SpreadsheetCommandBarButtonItem166.Id = 300
            Me.SpreadsheetCommandBarButtonItem166.Name = "SpreadsheetCommandBarButtonItem166"
            Me.SpreadsheetCommandBarButtonItem166.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarButtonItem167
            '
            Me.SpreadsheetCommandBarButtonItem167.CommandName = "ReviewInsertComment"
            Me.SpreadsheetCommandBarButtonItem167.Id = 301
            Me.SpreadsheetCommandBarButtonItem167.Name = "SpreadsheetCommandBarButtonItem167"
            '
            'SpreadsheetCommandBarButtonItem168
            '
            Me.SpreadsheetCommandBarButtonItem168.CommandName = "ReviewEditComment"
            Me.SpreadsheetCommandBarButtonItem168.Id = 302
            Me.SpreadsheetCommandBarButtonItem168.Name = "SpreadsheetCommandBarButtonItem168"
            '
            'SpreadsheetCommandBarButtonItem169
            '
            Me.SpreadsheetCommandBarButtonItem169.CommandName = "ReviewDeleteComment"
            Me.SpreadsheetCommandBarButtonItem169.Id = 303
            Me.SpreadsheetCommandBarButtonItem169.Name = "SpreadsheetCommandBarButtonItem169"
            '
            'SpreadsheetCommandBarButtonItem170
            '
            Me.SpreadsheetCommandBarButtonItem170.CommandName = "ReviewShowHideComment"
            Me.SpreadsheetCommandBarButtonItem170.Id = 304
            Me.SpreadsheetCommandBarButtonItem170.Name = "SpreadsheetCommandBarButtonItem170"
            '
            'SpreadsheetCommandBarButtonItem171
            '
            Me.SpreadsheetCommandBarButtonItem171.CommandName = "ReviewUnprotectSheet"
            Me.SpreadsheetCommandBarButtonItem171.Id = 305
            Me.SpreadsheetCommandBarButtonItem171.Name = "SpreadsheetCommandBarButtonItem171"
            '
            'SpreadsheetCommandBarButtonItem172
            '
            Me.SpreadsheetCommandBarButtonItem172.CommandName = "ReviewProtectWorkbook"
            Me.SpreadsheetCommandBarButtonItem172.Id = 306
            Me.SpreadsheetCommandBarButtonItem172.Name = "SpreadsheetCommandBarButtonItem172"
            '
            'SpreadsheetCommandBarButtonItem173
            '
            Me.SpreadsheetCommandBarButtonItem173.CommandName = "ReviewUnprotectWorkbook"
            Me.SpreadsheetCommandBarButtonItem173.Id = 307
            Me.SpreadsheetCommandBarButtonItem173.Name = "SpreadsheetCommandBarButtonItem173"
            '
            'SpreadsheetCommandBarButtonItem174
            '
            Me.SpreadsheetCommandBarButtonItem174.CommandName = "ReviewShowProtectedRangeManager"
            Me.SpreadsheetCommandBarButtonItem174.Id = 308
            Me.SpreadsheetCommandBarButtonItem174.Name = "SpreadsheetCommandBarButtonItem174"
            '
            'SpreadsheetCommandBarButtonItem175
            '
            Me.SpreadsheetCommandBarButtonItem175.CommandName = "ViewZoom"
            Me.SpreadsheetCommandBarButtonItem175.Id = 309
            Me.SpreadsheetCommandBarButtonItem175.Name = "SpreadsheetCommandBarButtonItem175"
            '
            'SpreadsheetCommandBarButtonItem176
            '
            Me.SpreadsheetCommandBarButtonItem176.CommandName = "ChartSelectData"
            Me.SpreadsheetCommandBarButtonItem176.Id = 310
            Me.SpreadsheetCommandBarButtonItem176.Name = "SpreadsheetCommandBarButtonItem176"
            '
            'SpreadsheetCommandBarButtonItem177
            '
            Me.SpreadsheetCommandBarButtonItem177.CommandName = "MoveChart"
            Me.SpreadsheetCommandBarButtonItem177.Id = 311
            Me.SpreadsheetCommandBarButtonItem177.Name = "SpreadsheetCommandBarButtonItem177"
            '
            'RenameTableItemCaption1
            '
            Me.RenameTableItemCaption1.Id = 312
            Me.RenameTableItemCaption1.Name = "RenameTableItemCaption1"
            '
            'SpreadsheetCommandBarButtonItem178
            '
            Me.SpreadsheetCommandBarButtonItem178.CommandName = "OptionsPivotTable"
            Me.SpreadsheetCommandBarButtonItem178.Id = 313
            Me.SpreadsheetCommandBarButtonItem178.Name = "SpreadsheetCommandBarButtonItem178"
            '
            'SpreadsheetCommandBarButtonItem179
            '
            Me.SpreadsheetCommandBarButtonItem179.CommandName = "SelectFieldTypePivotTable"
            Me.SpreadsheetCommandBarButtonItem179.Id = 314
            Me.SpreadsheetCommandBarButtonItem179.Name = "SpreadsheetCommandBarButtonItem179"
            '
            'SpreadsheetCommandBarButtonItem180
            '
            Me.SpreadsheetCommandBarButtonItem180.CommandName = "PivotTableExpandField"
            Me.SpreadsheetCommandBarButtonItem180.Id = 315
            Me.SpreadsheetCommandBarButtonItem180.Name = "SpreadsheetCommandBarButtonItem180"
            Me.SpreadsheetCommandBarButtonItem180.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarButtonItem181
            '
            Me.SpreadsheetCommandBarButtonItem181.CommandName = "PivotTableCollapseField"
            Me.SpreadsheetCommandBarButtonItem181.Id = 316
            Me.SpreadsheetCommandBarButtonItem181.Name = "SpreadsheetCommandBarButtonItem181"
            Me.SpreadsheetCommandBarButtonItem181.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarButtonItem182
            '
            Me.SpreadsheetCommandBarButtonItem182.CommandName = "PivotTableGroupSelection"
            Me.SpreadsheetCommandBarButtonItem182.Id = 317
            Me.SpreadsheetCommandBarButtonItem182.Name = "SpreadsheetCommandBarButtonItem182"
            Me.SpreadsheetCommandBarButtonItem182.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarButtonItem183
            '
            Me.SpreadsheetCommandBarButtonItem183.CommandName = "PivotTableUngroup"
            Me.SpreadsheetCommandBarButtonItem183.Id = 318
            Me.SpreadsheetCommandBarButtonItem183.Name = "SpreadsheetCommandBarButtonItem183"
            Me.SpreadsheetCommandBarButtonItem183.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarButtonItem184
            '
            Me.SpreadsheetCommandBarButtonItem184.CommandName = "PivotTableGroupField"
            Me.SpreadsheetCommandBarButtonItem184.Id = 319
            Me.SpreadsheetCommandBarButtonItem184.Name = "SpreadsheetCommandBarButtonItem184"
            Me.SpreadsheetCommandBarButtonItem184.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
            '
            'SpreadsheetCommandBarSubItem33
            '
            Me.SpreadsheetCommandBarSubItem33.CommandName = "PivotTableDataRefreshGroup"
            Me.SpreadsheetCommandBarSubItem33.Id = 320
            Me.SpreadsheetCommandBarSubItem33.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem185), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem186)})
            Me.SpreadsheetCommandBarSubItem33.Name = "SpreadsheetCommandBarSubItem33"
            '
            'SpreadsheetCommandBarButtonItem185
            '
            Me.SpreadsheetCommandBarButtonItem185.CommandName = "RefreshPivotTable"
            Me.SpreadsheetCommandBarButtonItem185.Id = 321
            Me.SpreadsheetCommandBarButtonItem185.Name = "SpreadsheetCommandBarButtonItem185"
            '
            'SpreadsheetCommandBarButtonItem186
            '
            Me.SpreadsheetCommandBarButtonItem186.CommandName = "RefreshAllPivotTable"
            Me.SpreadsheetCommandBarButtonItem186.Id = 322
            Me.SpreadsheetCommandBarButtonItem186.Name = "SpreadsheetCommandBarButtonItem186"
            '
            'SpreadsheetCommandBarButtonItem187
            '
            Me.SpreadsheetCommandBarButtonItem187.CommandName = "ChangeDataSourcePivotTable"
            Me.SpreadsheetCommandBarButtonItem187.Id = 323
            Me.SpreadsheetCommandBarButtonItem187.Name = "SpreadsheetCommandBarButtonItem187"
            '
            'SpreadsheetCommandBarSubItem34
            '
            Me.SpreadsheetCommandBarSubItem34.CommandName = "PivotTableActionsClearGroup"
            Me.SpreadsheetCommandBarSubItem34.Id = 324
            Me.SpreadsheetCommandBarSubItem34.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem188), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem189)})
            Me.SpreadsheetCommandBarSubItem34.Name = "SpreadsheetCommandBarSubItem34"
            '
            'SpreadsheetCommandBarButtonItem188
            '
            Me.SpreadsheetCommandBarButtonItem188.CommandName = "ClearAllPivotTable"
            Me.SpreadsheetCommandBarButtonItem188.Id = 325
            Me.SpreadsheetCommandBarButtonItem188.Name = "SpreadsheetCommandBarButtonItem188"
            '
            'SpreadsheetCommandBarButtonItem189
            '
            Me.SpreadsheetCommandBarButtonItem189.CommandName = "ClearFiltersPivotTable"
            Me.SpreadsheetCommandBarButtonItem189.Id = 326
            Me.SpreadsheetCommandBarButtonItem189.Name = "SpreadsheetCommandBarButtonItem189"
            '
            'SpreadsheetCommandBarSubItem35
            '
            Me.SpreadsheetCommandBarSubItem35.CommandName = "PivotTableActionsSelectGroup"
            Me.SpreadsheetCommandBarSubItem35.Id = 327
            Me.SpreadsheetCommandBarSubItem35.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem190), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem191), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem192)})
            Me.SpreadsheetCommandBarSubItem35.Name = "SpreadsheetCommandBarSubItem35"
            '
            'SpreadsheetCommandBarButtonItem190
            '
            Me.SpreadsheetCommandBarButtonItem190.CommandName = "SelectValuesPivotTable"
            Me.SpreadsheetCommandBarButtonItem190.Id = 328
            Me.SpreadsheetCommandBarButtonItem190.Name = "SpreadsheetCommandBarButtonItem190"
            '
            'SpreadsheetCommandBarButtonItem191
            '
            Me.SpreadsheetCommandBarButtonItem191.CommandName = "SelectLabelsPivotTable"
            Me.SpreadsheetCommandBarButtonItem191.Id = 329
            Me.SpreadsheetCommandBarButtonItem191.Name = "SpreadsheetCommandBarButtonItem191"
            '
            'SpreadsheetCommandBarButtonItem192
            '
            Me.SpreadsheetCommandBarButtonItem192.CommandName = "SelectEntirePivotTable"
            Me.SpreadsheetCommandBarButtonItem192.Id = 330
            Me.SpreadsheetCommandBarButtonItem192.Name = "SpreadsheetCommandBarButtonItem192"
            '
            'SpreadsheetCommandBarButtonItem193
            '
            Me.SpreadsheetCommandBarButtonItem193.CommandName = "MovePivotTable"
            Me.SpreadsheetCommandBarButtonItem193.Id = 331
            Me.SpreadsheetCommandBarButtonItem193.Name = "SpreadsheetCommandBarButtonItem193"
            '
            'SpreadsheetCommandBarSubItem36
            '
            Me.SpreadsheetCommandBarSubItem36.CommandName = "PivotTableCalculationFieldsItemsSetsGroup"
            Me.SpreadsheetCommandBarSubItem36.Id = 332
            Me.SpreadsheetCommandBarSubItem36.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem194), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem195), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem196), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem197)})
            Me.SpreadsheetCommandBarSubItem36.Name = "SpreadsheetCommandBarSubItem36"
            '
            'SpreadsheetCommandBarButtonItem194
            '
            Me.SpreadsheetCommandBarButtonItem194.CommandName = "PivotTableCalculatedField"
            Me.SpreadsheetCommandBarButtonItem194.Id = 333
            Me.SpreadsheetCommandBarButtonItem194.Name = "SpreadsheetCommandBarButtonItem194"
            '
            'SpreadsheetCommandBarButtonItem195
            '
            Me.SpreadsheetCommandBarButtonItem195.CommandName = "PivotTableCalculatedItem"
            Me.SpreadsheetCommandBarButtonItem195.Id = 334
            Me.SpreadsheetCommandBarButtonItem195.Name = "SpreadsheetCommandBarButtonItem195"
            '
            'SpreadsheetCommandBarButtonItem196
            '
            Me.SpreadsheetCommandBarButtonItem196.CommandName = "PivotTableCalculatedItemSolveOrder"
            Me.SpreadsheetCommandBarButtonItem196.Id = 335
            Me.SpreadsheetCommandBarButtonItem196.Name = "SpreadsheetCommandBarButtonItem196"
            '
            'SpreadsheetCommandBarButtonItem197
            '
            Me.SpreadsheetCommandBarButtonItem197.CommandName = "PivotTableListFormulas"
            Me.SpreadsheetCommandBarButtonItem197.Id = 336
            Me.SpreadsheetCommandBarButtonItem197.Name = "SpreadsheetCommandBarButtonItem197"
            '
            'SpreadsheetCommandBarCheckItem38
            '
            Me.SpreadsheetCommandBarCheckItem38.CommandName = "FieldListPanelPivotTable"
            Me.SpreadsheetCommandBarCheckItem38.Id = 337
            Me.SpreadsheetCommandBarCheckItem38.Name = "SpreadsheetCommandBarCheckItem38"
            '
            'SpreadsheetCommandBarCheckItem39
            '
            Me.SpreadsheetCommandBarCheckItem39.CommandName = "ShowPivotTableExpandCollapseButtons"
            Me.SpreadsheetCommandBarCheckItem39.Id = 338
            Me.SpreadsheetCommandBarCheckItem39.Name = "SpreadsheetCommandBarCheckItem39"
            '
            'SpreadsheetCommandBarCheckItem40
            '
            Me.SpreadsheetCommandBarCheckItem40.CommandName = "ShowPivotTableFieldHeaders"
            Me.SpreadsheetCommandBarCheckItem40.Id = 339
            Me.SpreadsheetCommandBarCheckItem40.Name = "SpreadsheetCommandBarCheckItem40"
            '
            'SpreadsheetCommandBarSubItem37
            '
            Me.SpreadsheetCommandBarSubItem37.CommandName = "PivotTableLayoutSubtotalsGroup"
            Me.SpreadsheetCommandBarSubItem37.Id = 340
            Me.SpreadsheetCommandBarSubItem37.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem198), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem199), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem200)})
            Me.SpreadsheetCommandBarSubItem37.Name = "SpreadsheetCommandBarSubItem37"
            '
            'SpreadsheetCommandBarButtonItem198
            '
            Me.SpreadsheetCommandBarButtonItem198.CommandName = "PivotTableDoNotShowSubtotals"
            Me.SpreadsheetCommandBarButtonItem198.Id = 341
            Me.SpreadsheetCommandBarButtonItem198.Name = "SpreadsheetCommandBarButtonItem198"
            Me.SpreadsheetCommandBarButtonItem198.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem199
            '
            Me.SpreadsheetCommandBarButtonItem199.CommandName = "PivotTableShowAllSubtotalsAtBottom"
            Me.SpreadsheetCommandBarButtonItem199.Id = 342
            Me.SpreadsheetCommandBarButtonItem199.Name = "SpreadsheetCommandBarButtonItem199"
            Me.SpreadsheetCommandBarButtonItem199.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem200
            '
            Me.SpreadsheetCommandBarButtonItem200.CommandName = "PivotTableShowAllSubtotalsAtTop"
            Me.SpreadsheetCommandBarButtonItem200.Id = 343
            Me.SpreadsheetCommandBarButtonItem200.Name = "SpreadsheetCommandBarButtonItem200"
            Me.SpreadsheetCommandBarButtonItem200.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarSubItem38
            '
            Me.SpreadsheetCommandBarSubItem38.CommandName = "PivotTableLayoutGrandTotalsGroup"
            Me.SpreadsheetCommandBarSubItem38.Id = 344
            Me.SpreadsheetCommandBarSubItem38.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem201), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem202), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem203), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem204)})
            Me.SpreadsheetCommandBarSubItem38.Name = "SpreadsheetCommandBarSubItem38"
            '
            'SpreadsheetCommandBarButtonItem201
            '
            Me.SpreadsheetCommandBarButtonItem201.CommandName = "PivotTableGrandTotalsOffRowsColumns"
            Me.SpreadsheetCommandBarButtonItem201.Id = 345
            Me.SpreadsheetCommandBarButtonItem201.Name = "SpreadsheetCommandBarButtonItem201"
            Me.SpreadsheetCommandBarButtonItem201.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem202
            '
            Me.SpreadsheetCommandBarButtonItem202.CommandName = "PivotTableGrandTotalsOnRowsColumns"
            Me.SpreadsheetCommandBarButtonItem202.Id = 346
            Me.SpreadsheetCommandBarButtonItem202.Name = "SpreadsheetCommandBarButtonItem202"
            Me.SpreadsheetCommandBarButtonItem202.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem203
            '
            Me.SpreadsheetCommandBarButtonItem203.CommandName = "PivotTableGrandTotalsOnRowsOnly"
            Me.SpreadsheetCommandBarButtonItem203.Id = 347
            Me.SpreadsheetCommandBarButtonItem203.Name = "SpreadsheetCommandBarButtonItem203"
            Me.SpreadsheetCommandBarButtonItem203.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem204
            '
            Me.SpreadsheetCommandBarButtonItem204.CommandName = "PivotTableGrandTotalsOnColumnsOnly"
            Me.SpreadsheetCommandBarButtonItem204.Id = 348
            Me.SpreadsheetCommandBarButtonItem204.Name = "SpreadsheetCommandBarButtonItem204"
            Me.SpreadsheetCommandBarButtonItem204.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarSubItem39
            '
            Me.SpreadsheetCommandBarSubItem39.CommandName = "PivotTableLayoutReportLayoutGroup"
            Me.SpreadsheetCommandBarSubItem39.Id = 349
            Me.SpreadsheetCommandBarSubItem39.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem205), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem206), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem207), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem208), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem209)})
            Me.SpreadsheetCommandBarSubItem39.Name = "SpreadsheetCommandBarSubItem39"
            '
            'SpreadsheetCommandBarButtonItem205
            '
            Me.SpreadsheetCommandBarButtonItem205.CommandName = "PivotTableShowCompactForm"
            Me.SpreadsheetCommandBarButtonItem205.Id = 350
            Me.SpreadsheetCommandBarButtonItem205.Name = "SpreadsheetCommandBarButtonItem205"
            Me.SpreadsheetCommandBarButtonItem205.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem206
            '
            Me.SpreadsheetCommandBarButtonItem206.CommandName = "PivotTableShowOutlineForm"
            Me.SpreadsheetCommandBarButtonItem206.Id = 351
            Me.SpreadsheetCommandBarButtonItem206.Name = "SpreadsheetCommandBarButtonItem206"
            Me.SpreadsheetCommandBarButtonItem206.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem207
            '
            Me.SpreadsheetCommandBarButtonItem207.CommandName = "PivotTableShowTabularForm"
            Me.SpreadsheetCommandBarButtonItem207.Id = 352
            Me.SpreadsheetCommandBarButtonItem207.Name = "SpreadsheetCommandBarButtonItem207"
            Me.SpreadsheetCommandBarButtonItem207.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem208
            '
            Me.SpreadsheetCommandBarButtonItem208.CommandName = "PivotTableRepeatAllItemLabels"
            Me.SpreadsheetCommandBarButtonItem208.Id = 353
            Me.SpreadsheetCommandBarButtonItem208.Name = "SpreadsheetCommandBarButtonItem208"
            Me.SpreadsheetCommandBarButtonItem208.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem209
            '
            Me.SpreadsheetCommandBarButtonItem209.CommandName = "PivotTableDoNotRepeatItemLabels"
            Me.SpreadsheetCommandBarButtonItem209.Id = 354
            Me.SpreadsheetCommandBarButtonItem209.Name = "SpreadsheetCommandBarButtonItem209"
            Me.SpreadsheetCommandBarButtonItem209.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarSubItem40
            '
            Me.SpreadsheetCommandBarSubItem40.CommandName = "PivotTableLayoutBlankRowsGroup"
            Me.SpreadsheetCommandBarSubItem40.Id = 355
            Me.SpreadsheetCommandBarSubItem40.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem210), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem211)})
            Me.SpreadsheetCommandBarSubItem40.Name = "SpreadsheetCommandBarSubItem40"
            '
            'SpreadsheetCommandBarButtonItem210
            '
            Me.SpreadsheetCommandBarButtonItem210.CommandName = "PivotTableInsertBlankLineEachItem"
            Me.SpreadsheetCommandBarButtonItem210.Id = 356
            Me.SpreadsheetCommandBarButtonItem210.Name = "SpreadsheetCommandBarButtonItem210"
            Me.SpreadsheetCommandBarButtonItem210.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarButtonItem211
            '
            Me.SpreadsheetCommandBarButtonItem211.CommandName = "PivotTableRemoveBlankLineEachItem"
            Me.SpreadsheetCommandBarButtonItem211.Id = 357
            Me.SpreadsheetCommandBarButtonItem211.Name = "SpreadsheetCommandBarButtonItem211"
            Me.SpreadsheetCommandBarButtonItem211.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
            '
            'SpreadsheetCommandBarCheckItem41
            '
            Me.SpreadsheetCommandBarCheckItem41.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.SpreadsheetCommandBarCheckItem41.CommandName = "PivotTableToggleRowHeaders"
            Me.SpreadsheetCommandBarCheckItem41.Id = 358
            Me.SpreadsheetCommandBarCheckItem41.Name = "SpreadsheetCommandBarCheckItem41"
            '
            'SpreadsheetCommandBarCheckItem42
            '
            Me.SpreadsheetCommandBarCheckItem42.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.SpreadsheetCommandBarCheckItem42.CommandName = "PivotTableToggleColumnHeaders"
            Me.SpreadsheetCommandBarCheckItem42.Id = 359
            Me.SpreadsheetCommandBarCheckItem42.Name = "SpreadsheetCommandBarCheckItem42"
            '
            'SpreadsheetCommandBarCheckItem43
            '
            Me.SpreadsheetCommandBarCheckItem43.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.SpreadsheetCommandBarCheckItem43.CommandName = "PivotTableToggleBandedRows"
            Me.SpreadsheetCommandBarCheckItem43.Id = 360
            Me.SpreadsheetCommandBarCheckItem43.Name = "SpreadsheetCommandBarCheckItem43"
            '
            'SpreadsheetCommandBarCheckItem44
            '
            Me.SpreadsheetCommandBarCheckItem44.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
            Me.SpreadsheetCommandBarCheckItem44.CommandName = "PivotTableToggleBandedColumns"
            Me.SpreadsheetCommandBarCheckItem44.Id = 361
            Me.SpreadsheetCommandBarCheckItem44.Name = "SpreadsheetCommandBarCheckItem44"
            '
            'GalleryPivotStylesItem1
            '
            '
            '
            '
            Me.GalleryPivotStylesItem1.Gallery.ColumnCount = 7
            Me.GalleryPivotStylesItem1.Gallery.DrawImageBackground = False
            Me.GalleryPivotStylesItem1.Gallery.ImageSize = New System.Drawing.Size(126, 90)
            Me.GalleryPivotStylesItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
            Me.GalleryPivotStylesItem1.Gallery.ItemSize = New System.Drawing.Size(114, 95)
            Me.GalleryPivotStylesItem1.Gallery.RowCount = 10
            Me.GalleryPivotStylesItem1.Id = 362
            Me.GalleryPivotStylesItem1.Name = "GalleryPivotStylesItem1"
            '
            'fileRibbonPage1
            '
            Me.fileRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.commonRibbonPageGroup1, Me.InfoRibbonPageGroup1})
            Me.fileRibbonPage1.Name = "fileRibbonPage1"
            '
            'commonRibbonPageGroup1
            '
            Me.commonRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.[False]
            Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem1)
            Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem2)
            Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem3)
            Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem4)
            Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem5)
            Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem6)
            Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem7)
            Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem8)
            Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem9)
            Me.commonRibbonPageGroup1.Name = "commonRibbonPageGroup1"
            '
            'InfoRibbonPageGroup1
            '
            Me.InfoRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.[False]
            Me.InfoRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem117)
            Me.InfoRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem118)
            Me.InfoRibbonPageGroup1.Name = "InfoRibbonPageGroup1"
            '
            'spreadsheetBarController1
            '
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem2)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem3)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem4)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem5)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem6)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem7)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem8)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem9)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem10)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem11)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem12)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem13)
            Me.spreadsheetBarController1.BarItems.Add(Me.changeFontNameItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.changeFontSizeItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem14)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem15)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem2)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem3)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem4)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem16)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem17)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem18)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem19)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem20)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem21)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem22)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem23)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem24)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem25)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem26)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem27)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem28)
            Me.spreadsheetBarController1.BarItems.Add(Me.changeBorderLineColorItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.changeBorderLineStyleItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.changeCellFillColorItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.changeFontColorItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem5)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem6)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem7)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem8)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem9)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem10)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem29)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem30)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem11)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem2)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem12)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem31)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem32)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem33)
            Me.spreadsheetBarController1.BarItems.Add(Me.changeNumberFormatItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem3)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem34)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem35)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem36)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem37)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem38)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem39)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem40)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem41)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem42)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem4)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem5)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem43)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem44)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem45)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem46)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem47)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem48)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem49)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem6)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem50)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem51)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem52)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem53)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem54)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem55)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem2)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem3)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem7)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem56)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem57)
            Me.spreadsheetBarController1.BarItems.Add(Me.galleryFormatAsTableItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.galleryChangeStyleItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem8)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem58)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem59)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem60)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem9)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem61)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem62)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem63)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem10)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem64)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem65)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem11)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem66)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem67)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem68)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem69)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem70)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem71)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem72)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem12)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem73)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem74)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem75)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem76)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem77)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem13)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem78)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem79)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem80)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem81)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem14)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem82)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem83)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem84)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem85)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem86)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem87)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem88)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem89)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem4)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem5)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem6)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem7)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem8)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem9)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem10)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem90)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem15)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem13)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem14)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem15)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem16)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem16)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem17)
            Me.spreadsheetBarController1.BarItems.Add(Me.pageSetupPaperKindItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem17)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem91)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem92)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem18)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem93)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem94)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem19)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem95)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem96)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem97)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem98)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem99)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsFinancialItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsLogicalItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsTextItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsDateAndTimeItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsLookupAndReferenceItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsMathAndTrigonometryItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem20)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsStatisticalItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsEngineeringItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsInformationItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsCompatibilityItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.functionsWebItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem18)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem100)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem101)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem19)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem20)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem21)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem102)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem103)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem104)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem21)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem105)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem106)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem107)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem22)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem23)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem24)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem108)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem109)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem110)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem22)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem111)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem112)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem113)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem114)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem115)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem116)
            Me.spreadsheetBarController1.BarItems.Add(Me.galleryChartLayoutItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.galleryChartStyleItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem11)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem23)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem12)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem13)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem14)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem15)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem24)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem16)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem17)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem25)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem18)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem19)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem20)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem21)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem22)
            Me.spreadsheetBarController1.BarItems.Add(Me.barStaticItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.renameTableItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem25)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem26)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem27)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem28)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem29)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem30)
            Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem31)
            Me.spreadsheetBarController1.BarItems.Add(Me.galleryTableStylesItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem117)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem118)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem119)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem120)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem121)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem122)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem123)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem124)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem125)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem126)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem127)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem128)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem129)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem130)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem131)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem132)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem133)
            Me.spreadsheetBarController1.BarItems.Add(Me.ChangeSheetTabColorItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem134)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem32)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem135)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem33)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem136)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem137)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem26)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem138)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem139)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem140)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem141)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem142)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem143)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem144)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem27)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem145)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem23)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem24)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem146)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem147)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem148)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem149)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem150)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem28)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem151)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem34)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem35)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem152)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem153)
            Me.spreadsheetBarController1.BarItems.Add(Me.DefinedNameListItem1)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem154)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem36)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem37)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem29)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem155)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem156)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem157)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem158)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem159)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem30)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem160)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem161)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem31)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem162)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem163)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem32)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem164)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem165)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem166)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem167)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem168)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem169)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem170)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem171)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem172)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem173)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem174)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem175)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem176)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem177)
            Me.spreadsheetBarController1.BarItems.Add(Me.RenameTableItemCaption1)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem178)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem179)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem180)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem181)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem182)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem183)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem184)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem185)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem186)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem33)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem187)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem188)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem189)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem34)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem190)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem191)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem192)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem35)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem193)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem194)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem195)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem196)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem197)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem36)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem38)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem39)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem40)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem198)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem199)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem200)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem37)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem201)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem202)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem203)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem204)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem38)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem205)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem206)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem207)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem208)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem209)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem39)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem210)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem211)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem40)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem41)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem42)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem43)
            Me.spreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem44)
            Me.spreadsheetBarController1.BarItems.Add(Me.GalleryPivotStylesItem1)
            Me.spreadsheetBarController1.Control = Me.spreadsheetControl1
            '
            'spreadsheetCommandBarButtonItem95
            '
            Me.spreadsheetCommandBarButtonItem95.CommandName = "FunctionsInsertSum"
            Me.spreadsheetCommandBarButtonItem95.Name = "spreadsheetCommandBarButtonItem95"
            '
            'spreadsheetCommandBarButtonItem96
            '
            Me.spreadsheetCommandBarButtonItem96.CommandName = "FunctionsInsertAverage"
            Me.spreadsheetCommandBarButtonItem96.Name = "spreadsheetCommandBarButtonItem96"
            '
            'spreadsheetCommandBarButtonItem97
            '
            Me.spreadsheetCommandBarButtonItem97.CommandName = "FunctionsInsertCountNumbers"
            Me.spreadsheetCommandBarButtonItem97.Name = "spreadsheetCommandBarButtonItem97"
            '
            'spreadsheetCommandBarButtonItem98
            '
            Me.spreadsheetCommandBarButtonItem98.CommandName = "FunctionsInsertMax"
            Me.spreadsheetCommandBarButtonItem98.Name = "spreadsheetCommandBarButtonItem98"
            '
            'spreadsheetCommandBarButtonItem99
            '
            Me.spreadsheetCommandBarButtonItem99.CommandName = "FunctionsInsertMin"
            Me.spreadsheetCommandBarButtonItem99.Name = "spreadsheetCommandBarButtonItem99"
            '
            'SpreadsheetFormulaBar1
            '
            Me.SpreadsheetFormulaBar1.Dock = System.Windows.Forms.DockStyle.Top
            Me.SpreadsheetFormulaBar1.Location = New System.Drawing.Point(0, 193)
            Me.SpreadsheetFormulaBar1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
            Me.SpreadsheetFormulaBar1.MinimumSize = New System.Drawing.Size(0, 24)
            Me.SpreadsheetFormulaBar1.Name = "SpreadsheetFormulaBar1"
            Me.SpreadsheetFormulaBar1.Size = New System.Drawing.Size(1148, 30)
            Me.SpreadsheetFormulaBar1.SpreadsheetControl = Me.spreadsheetControl1
            Me.SpreadsheetFormulaBar1.TabIndex = 5
            '
            'SplitterControl2
            '
            Me.SplitterControl2.Dock = System.Windows.Forms.DockStyle.Top
            Me.SplitterControl2.Location = New System.Drawing.Point(0, 223)
            Me.SplitterControl2.MinSize = 20
            Me.SplitterControl2.Name = "SplitterControl2"
            Me.SplitterControl2.Size = New System.Drawing.Size(1148, 12)
            Me.SplitterControl2.TabIndex = 4
            Me.SplitterControl2.TabStop = False
            '
            'Form1
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(1148, 690)
            Me.Controls.Add(Me.spreadsheetControl1)
            Me.Controls.Add(Me.SplitterControl2)
            Me.Controls.Add(Me.SpreadsheetFormulaBar1)
            Me.Controls.Add(Me.ribbonControl1)
            Me.Margin = New System.Windows.Forms.Padding(4)
            Me.Name = "Form1"
            Me.Ribbon = Me.ribbonControl1
            Me.Text = "Form1"
            CType(Me.commandBarGalleryDropDown2, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.ribbonControl1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.repositoryItemFontEdit1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.repositoryItemSpreadsheetFontSizeEdit1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.repositoryItemPopupGalleryEdit1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown3, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown4, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown5, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown6, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown7, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown8, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown9, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown10, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown11, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown12, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown13, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown14, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown15, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown16, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown17, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown18, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown19, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown20, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown21, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown22, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown23, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.commandBarGalleryDropDown24, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.repositoryItemTextEdit1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.CommandBarGalleryDropDown25, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.CommandBarGalleryDropDown26, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.spreadsheetBarController1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

#End Region

        Private spreadsheetControl1 As DevExpress.XtraSpreadsheet.SpreadsheetControl
        Private ribbonControl1 As DevExpress.XtraBars.Ribbon.RibbonControl
        Private spreadsheetCommandBarButtonItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private barButtonGroup1 As DevExpress.XtraBars.BarButtonGroup
        Private changeFontNameItem1 As DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem
        Private repositoryItemFontEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemFontEdit
        Private changeFontSizeItem1 As DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem
        Private repositoryItemSpreadsheetFontSizeEdit1 As DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit
        Private spreadsheetCommandBarButtonItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private barButtonGroup2 As DevExpress.XtraBars.BarButtonGroup
        Private spreadsheetCommandBarCheckItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private barButtonGroup3 As DevExpress.XtraBars.BarButtonGroup
        Private spreadsheetCommandBarSubItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private changeBorderLineColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem
        Private changeBorderLineStyleItem1 As DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem
        Private commandBarGalleryDropDown1 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private barButtonGroup4 As DevExpress.XtraBars.BarButtonGroup
        Private changeCellFillColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem
        Private changeFontColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem
        Private barButtonGroup5 As DevExpress.XtraBars.BarButtonGroup
        Private spreadsheetCommandBarCheckItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private barButtonGroup6 As DevExpress.XtraBars.BarButtonGroup
        Private spreadsheetCommandBarCheckItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private barButtonGroup7 As DevExpress.XtraBars.BarButtonGroup
        Private spreadsheetCommandBarButtonItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarCheckItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarSubItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarCheckItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarButtonItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private barButtonGroup8 As DevExpress.XtraBars.BarButtonGroup
        Private changeNumberFormatItem1 As DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem
        Private repositoryItemPopupGalleryEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit
        Private barButtonGroup9 As DevExpress.XtraBars.BarButtonGroup
        Private spreadsheetCommandBarSubItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private barButtonGroup10 As DevExpress.XtraBars.BarButtonGroup
        Private spreadsheetCommandBarButtonItem41 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem42 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarSubItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem43 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem44 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem45 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem46 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem47 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem48 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem49 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem50 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem51 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem52 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem53 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem54 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem55 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonGalleryDropDownItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown2 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown3 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown4 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarSubItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem56 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem57 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private galleryFormatAsTableItem1 As DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem
        Private commandBarGalleryDropDown5 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private galleryChangeStyleItem1 As DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem
        Private spreadsheetCommandBarSubItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem58 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem59 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem60 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem61 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem62 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem63 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem64 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem65 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem66 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem67 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem68 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem69 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem70 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem71 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem72 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem73 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem74 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem75 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem76 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem77 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem78 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem79 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem80 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem81 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem82 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem83 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem84 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem85 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem86 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem87 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem88 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem89 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonGalleryDropDownItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown6 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown7 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown8 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown9 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown10 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown11 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown12 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonItem90 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarCheckItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarSubItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarCheckItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private pageSetupPaperKindItem1 As DevExpress.XtraSpreadsheet.UI.PageSetupPaperKindItem
        Private spreadsheetCommandBarSubItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem91 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem92 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem93 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem94 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private functionsFinancialItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsFinancialItem
        Private functionsLogicalItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsLogicalItem
        Private functionsTextItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsTextItem
        Private functionsDateAndTimeItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsDateAndTimeItem
        Private functionsLookupAndReferenceItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsLookupAndReferenceItem
        Private functionsMathAndTrigonometryItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsMathAndTrigonometryItem
        Private spreadsheetCommandBarSubItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private functionsStatisticalItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsStatisticalItem
        Private functionsEngineeringItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsEngineeringItem
        Private functionsInformationItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsInformationItem
        Private functionsCompatibilityItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsCompatibilityItem
        Private functionsWebItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsWebItem
        Private spreadsheetCommandBarCheckItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarButtonItem100 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem101 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarCheckItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarButtonItem102 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem103 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem104 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem105 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem106 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem107 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarCheckItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarButtonItem108 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem109 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem110 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarSubItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonItem111 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem112 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem113 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem114 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem115 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem116 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private galleryChartLayoutItem1 As DevExpress.XtraSpreadsheet.UI.GalleryChartLayoutItem
        Private galleryChartStyleItem1 As DevExpress.XtraSpreadsheet.UI.GalleryChartStyleItem
        Private spreadsheetCommandBarButtonGalleryDropDownItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown13 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarSubItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonGalleryDropDownItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown14 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown15 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown16 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown17 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarSubItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonGalleryDropDownItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown18 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown19 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarSubItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Private spreadsheetCommandBarButtonGalleryDropDownItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown20 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown21 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown22 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown23 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private spreadsheetCommandBarButtonGalleryDropDownItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Private commandBarGalleryDropDown24 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Private barStaticItem1 As DevExpress.XtraBars.BarStaticItem
        Private renameTableItem1 As DevExpress.XtraSpreadsheet.UI.RenameTableItem
        Private repositoryItemTextEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemTextEdit
        Private spreadsheetCommandBarCheckItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private spreadsheetCommandBarCheckItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Private galleryTableStylesItem1 As DevExpress.XtraSpreadsheet.UI.GalleryTableStylesItem
        Private fileRibbonPage1 As DevExpress.XtraSpreadsheet.UI.FileRibbonPage
        Private commonRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.CommonRibbonPageGroup
        Private spreadsheetBarController1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController
        Private spreadsheetCommandBarButtonItem95 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem96 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem97 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem98 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Private spreadsheetCommandBarButtonItem99 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem119 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem122 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem123 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem124 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem125 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem126 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem127 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem128 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem129 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem130 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem131 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem132 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem133 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents ChangeSheetTabColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem
        Friend WithEvents SpreadsheetCommandBarButtonItem134 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarCheckItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarButtonItem135 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem147 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem117 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem118 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem120 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem121 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarCheckItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarButtonItem136 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem137 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem138 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem139 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem140 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem141 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem142 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem143 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem144 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem145 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Friend WithEvents CommandBarGalleryDropDown25 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
        Friend WithEvents CommandBarGalleryDropDown26 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
        Friend WithEvents SpreadsheetCommandBarButtonItem146 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem148 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem149 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem150 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem151 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarCheckItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarCheckItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarButtonItem152 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem153 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents DefinedNameListItem1 As DevExpress.XtraSpreadsheet.UI.DefinedNameListItem
        Friend WithEvents SpreadsheetCommandBarButtonItem154 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarCheckItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarCheckItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarButtonItem155 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem156 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem157 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem158 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem159 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem160 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem161 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem162 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem163 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem164 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem165 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem166 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem167 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem168 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem169 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem170 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem171 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem172 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem173 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem174 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem175 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem176 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem177 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents RenameTableItemCaption1 As DevExpress.XtraSpreadsheet.UI.RenameTableItemCaption
        Friend WithEvents SpreadsheetCommandBarButtonItem178 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem179 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem180 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem181 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem182 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem183 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem184 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem185 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem186 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem187 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem188 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem189 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem190 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem191 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem192 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem193 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem194 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem195 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem196 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem197 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarCheckItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarCheckItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarCheckItem40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarSubItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem198 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem199 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem200 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem201 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem202 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem203 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem204 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem205 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem206 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem207 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem208 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem209 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarSubItem40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
        Friend WithEvents SpreadsheetCommandBarButtonItem210 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarButtonItem211 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
        Friend WithEvents SpreadsheetCommandBarCheckItem41 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarCheckItem42 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarCheckItem43 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents SpreadsheetCommandBarCheckItem44 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
        Friend WithEvents GalleryPivotStylesItem1 As DevExpress.XtraSpreadsheet.UI.GalleryPivotStylesItem
        Friend WithEvents InfoRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.InfoRibbonPageGroup
        Friend WithEvents SpreadsheetFormulaBar1 As DevExpress.XtraSpreadsheet.SpreadsheetFormulaBar
        Friend WithEvents SplitterControl2 As DevExpress.XtraEditors.SplitterControl
    End Class
End Namespace


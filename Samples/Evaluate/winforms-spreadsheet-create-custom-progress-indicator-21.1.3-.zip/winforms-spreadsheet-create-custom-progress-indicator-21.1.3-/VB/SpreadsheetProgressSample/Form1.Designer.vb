﻿Namespace SpreadsheetProgressSample
	Partial Public Class Form1
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.components = New System.ComponentModel.Container()
			Dim galleryItemGroup1 As New DevExpress.XtraBars.Ribbon.GalleryItemGroup()
			Dim spreadsheetCommandGalleryItem1 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem2 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem3 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem4 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem5 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem6 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem7 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem8 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem9 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem10 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem11 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup1 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem12 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem13 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem14 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem15 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem16 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem17 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup2 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem18 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem19 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem20 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem21 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem22 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem23 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup3 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem24 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem25 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem26 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem27 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem28 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem29 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem30 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem31 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem32 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem33 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem34 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem35 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup4 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem36 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem37 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem38 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem39 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem40 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem41 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem42 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup5 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem43 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem44 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem45 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem46 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem47 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup6 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem48 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem49 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem50 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup7 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem51 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem52 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem53 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem54 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem55 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup8 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem56 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem57 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem58 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup9 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem59 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem60 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem61 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem62 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup10 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem63 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem64 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem65 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem66 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup11 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem67 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem68 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem69 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem70 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup12 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem71 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem72 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem73 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem74 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup13 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem75 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem76 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem77 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem78 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem79 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem80 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup14 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem81 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup15 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem82 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem83 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup16 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem84 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem85 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup17 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem86 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem87 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup18 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem88 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem89 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem90 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup19 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem91 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem92 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem93 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup20 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem94 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem95 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem96 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup21 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem97 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem98 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem99 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup22 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem100 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem101 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem102 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup23 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem103 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem104 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem105 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup24 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem106 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem107 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem108 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup25 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem109 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem110 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem111 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem112 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem113 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup26 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem114 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem115 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup27 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem116 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem117 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem118 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem119 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup28 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem120 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem121 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem122 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup29 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem123 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem124 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem125 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem126 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem127 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem128 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem129 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem130 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem131 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup30 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem132 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem133 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem134 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem135 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem136 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem137 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem138 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem139 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem140 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup31 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem141 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem142 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem143 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem144 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup32 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem145 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem146 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem147 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem148 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup33 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem149 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem150 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem151 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup34 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem152 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem153 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup35 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem154 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem155 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem156 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem157 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup36 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem158 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem159 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem160 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem161 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem162 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem163 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem164 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup37 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem165 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem166 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem167 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem168 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem169 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem170 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem171 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem172 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem173 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem174 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem175 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup38 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem176 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem177 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem178 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem179 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem180 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup39 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem181 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem182 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItemGroup40 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
			Dim spreadsheetCommandGalleryItem183 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem184 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem185 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim spreadsheetCommandGalleryItem186 As New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
			Dim superToolTip1 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipItem1 As New DevExpress.Utils.ToolTipItem()
			Dim superToolTip2 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipItem2 As New DevExpress.Utils.ToolTipItem()
			Dim superToolTip3 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipItem3 As New DevExpress.Utils.ToolTipItem()
			Dim superToolTip4 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipItem4 As New DevExpress.Utils.ToolTipItem()
			Dim superToolTip5 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipItem5 As New DevExpress.Utils.ToolTipItem()
			Dim superToolTip6 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipItem6 As New DevExpress.Utils.ToolTipItem()
			Dim superToolTip7 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipItem7 As New DevExpress.Utils.ToolTipItem()
			Dim superToolTip8 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipItem8 As New DevExpress.Utils.ToolTipItem()
			Dim reduceOperation1 As New DevExpress.XtraBars.Ribbon.ReduceOperation()
			Me.splashScreenManager1 = New DevExpress.XtraSplashScreen.SplashScreenManager(Me, GetType(Global.SpreadsheetProgressSample.WaitForm1), False, False)
			Me.spreadsheetControl1 = New DevExpress.XtraSpreadsheet.SpreadsheetControl()
			Me.ribbonControl1 = New DevExpress.XtraBars.Ribbon.RibbonControl()
			Me.spreadsheetCommandBarButtonItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.barButtonGroup1 = New DevExpress.XtraBars.BarButtonGroup()
			Me.changeFontNameItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem()
			Me.repositoryItemFontEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemFontEdit()
			Me.changeFontSizeItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem()
			Me.repositoryItemSpreadsheetFontSizeEdit1 = New DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit()
			Me.spreadsheetCommandBarButtonItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.barButtonGroup2 = New DevExpress.XtraBars.BarButtonGroup()
			Me.spreadsheetCommandBarCheckItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.barButtonGroup3 = New DevExpress.XtraBars.BarButtonGroup()
			Me.spreadsheetCommandBarSubItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem25 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem26 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem27 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem28 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem29 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem30 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.changeBorderLineColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem()
			Me.changeBorderLineStyleItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem()
			Me.commandBarGalleryDropDown1 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.barButtonGroup4 = New DevExpress.XtraBars.BarButtonGroup()
			Me.changeCellFillColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem()
			Me.changeFontColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem()
			Me.barButtonGroup5 = New DevExpress.XtraBars.BarButtonGroup()
			Me.spreadsheetCommandBarCheckItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.barButtonGroup6 = New DevExpress.XtraBars.BarButtonGroup()
			Me.spreadsheetCommandBarCheckItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.barButtonGroup7 = New DevExpress.XtraBars.BarButtonGroup()
			Me.spreadsheetCommandBarButtonItem31 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem32 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarCheckItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarSubItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarCheckItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarButtonItem33 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem34 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem35 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.barButtonGroup8 = New DevExpress.XtraBars.BarButtonGroup()
			Me.changeNumberFormatItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem()
			Me.repositoryItemPopupGalleryEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit()
			Me.barButtonGroup9 = New DevExpress.XtraBars.BarButtonGroup()
			Me.spreadsheetCommandBarSubItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem36 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem37 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem38 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem39 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem40 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem41 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem42 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem43 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.barButtonGroup10 = New DevExpress.XtraBars.BarButtonGroup()
			Me.spreadsheetCommandBarButtonItem44 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem45 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarSubItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem46 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem47 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem48 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem49 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem50 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem51 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem52 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem53 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem54 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem55 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem56 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem57 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem58 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonGalleryDropDownItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown2 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown3 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown4 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonItem59 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem60 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem61 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem62 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.galleryFormatAsTableItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem()
			Me.commandBarGalleryDropDown5 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.galleryChangeStyleItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem()
			Me.spreadsheetCommandBarSubItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem63 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem64 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem65 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem66 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem67 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem68 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem69 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem70 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem71 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem72 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem73 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem74 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem75 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem76 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem77 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem78 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem79 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem80 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem81 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem82 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem83 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem84 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem85 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem86 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem87 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem88 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem89 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.changeSheetTabColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem()
			Me.spreadsheetCommandBarButtonItem90 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarCheckItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarButtonItem91 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem92 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem93 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem94 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem95 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem96 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem97 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem98 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem99 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem100 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem101 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem102 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem103 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem104 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem105 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem106 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem107 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem108 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarCheckItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarButtonItem109 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem110 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem111 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem112 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem113 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem114 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem115 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem116 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem117 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem118 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem119 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem120 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonGalleryDropDownItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown6 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown7 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown8 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown9 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown10 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown11 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown12 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonItem121 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem122 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarCheckItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarButtonItem123 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarCheckItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.pageSetupPaperKindItem1 = New DevExpress.XtraSpreadsheet.UI.PageSetupPaperKindItem()
			Me.spreadsheetCommandBarSubItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem124 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem125 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem126 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem127 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarCheckItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarSubItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem128 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem129 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem130 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem131 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.functionsFinancialItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsFinancialItem()
			Me.functionsLogicalItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsLogicalItem()
			Me.functionsTextItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsTextItem()
			Me.functionsDateAndTimeItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsDateAndTimeItem()
			Me.functionsLookupAndReferenceItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsLookupAndReferenceItem()
			Me.functionsMathAndTrigonometryItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsMathAndTrigonometryItem()
			Me.spreadsheetCommandBarSubItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.functionsStatisticalItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsStatisticalItem()
			Me.functionsEngineeringItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsEngineeringItem()
			Me.functionsInformationItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsInformationItem()
			Me.functionsCompatibilityItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsCompatibilityItem()
			Me.functionsWebItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsWebItem()
			Me.spreadsheetCommandBarButtonItem132 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem133 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.definedNameListItem1 = New DevExpress.XtraSpreadsheet.UI.DefinedNameListItem()
			Me.spreadsheetCommandBarButtonItem134 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarCheckItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarSubItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarCheckItem25 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem26 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarButtonItem135 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem136 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem25 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem137 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem138 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem139 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem26 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem140 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem141 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem27 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem142 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem143 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem144 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem145 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem146 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem147 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem148 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem149 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem150 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem151 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem152 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem153 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem154 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem155 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem156 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem157 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem158 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem28 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem159 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem160 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem161 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem162 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem163 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem164 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem165 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.galleryChartLayoutItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryChartLayoutItem()
			Me.galleryChartStyleItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryChartStyleItem()
			Me.spreadsheetCommandBarButtonItem166 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem29 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonGalleryDropDownItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown13 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown14 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarSubItem30 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonGalleryDropDownItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown15 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown16 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown17 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarSubItem31 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonGalleryDropDownItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown18 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown19 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown20 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown21 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown22 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown23 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.spreadsheetCommandBarButtonGalleryDropDownItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
			Me.commandBarGalleryDropDown24 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.renameTableItemCaption1 = New DevExpress.XtraSpreadsheet.UI.RenameTableItemCaption()
			Me.renameTableItem1 = New DevExpress.XtraSpreadsheet.UI.RenameTableItem()
			Me.repositoryItemTextEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemTextEdit()
			Me.spreadsheetCommandBarCheckItem27 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem28 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem29 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem30 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem31 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem32 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem33 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.galleryTableStylesItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryTableStylesItem()
			Me.spreadsheetCommandBarButtonItem167 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem168 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem169 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem170 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem171 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem172 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem173 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem32 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem174 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem175 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem176 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem33 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem177 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem178 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem34 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem179 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem180 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem181 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem182 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem35 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem183 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem184 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem185 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem186 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarCheckItem34 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem35 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem36 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarSubItem36 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem187 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem188 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem189 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem37 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem190 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem191 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem192 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem193 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem38 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem194 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem195 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem196 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem197 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem198 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarSubItem39 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
			Me.spreadsheetCommandBarButtonItem199 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarButtonItem200 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
			Me.spreadsheetCommandBarCheckItem37 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem38 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem39 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.spreadsheetCommandBarCheckItem40 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
			Me.galleryPivotStylesItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryPivotStylesItem()
			Me.endModeInfoStaticItem1 = New DevExpress.XtraSpreadsheet.UI.EndModeInfoStaticItem()
			Me.averageInfoStaticItem1 = New DevExpress.XtraSpreadsheet.UI.AverageInfoStaticItem()
			Me.countInfoStaticItem1 = New DevExpress.XtraSpreadsheet.UI.CountInfoStaticItem()
			Me.numericalCountInfoStaticItem1 = New DevExpress.XtraSpreadsheet.UI.NumericalCountInfoStaticItem()
			Me.minInfoStaticItem1 = New DevExpress.XtraSpreadsheet.UI.MinInfoStaticItem()
			Me.maxInfoStaticItem1 = New DevExpress.XtraSpreadsheet.UI.MaxInfoStaticItem()
			Me.sumInfoStaticItem1 = New DevExpress.XtraSpreadsheet.UI.SumInfoStaticItem()
			Me.zoomEditItem1 = New DevExpress.XtraSpreadsheet.UI.ZoomEditItem()
			Me.repositoryItemZoomTrackBar1 = New DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar()
			Me.showZoomButtonItem1 = New DevExpress.XtraSpreadsheet.UI.ShowZoomButtonItem()
			Me.chartToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.ChartToolsRibbonPageCategory()
			Me.chartsDesignRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignRibbonPage()
			Me.chartsDesignTypeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignTypeRibbonPageGroup()
			Me.chartsDesignDataRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignDataRibbonPageGroup()
			Me.chartsDesignLayoutsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignLayoutsRibbonPageGroup()
			Me.chartsDesignStylesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignStylesRibbonPageGroup()
			Me.chartsDesignLocationRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignLocationRibbonPageGroup()
			Me.chartsLayoutRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ChartsLayoutRibbonPage()
			Me.chartsLayoutAxesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsLayoutAxesRibbonPageGroup()
			Me.chartsLayoutLabelsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsLayoutLabelsRibbonPageGroup()
			Me.chartsLayoutAnalysisRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsLayoutAnalysisRibbonPageGroup()
			Me.chartsFormatRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ChartsFormatRibbonPage()
			Me.chartsFormatArrangeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsFormatArrangeRibbonPageGroup()
			Me.tableToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageCategory()
			Me.tableToolsDesignRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.TableToolsDesignRibbonPage()
			Me.tablePropertiesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TablePropertiesRibbonPageGroup()
			Me.tableToolsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageGroup()
			Me.tableStyleOptionsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TableStyleOptionsRibbonPageGroup()
			Me.tableStylesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TableStylesRibbonPageGroup()
			Me.drawingToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.DrawingToolsRibbonPageCategory()
			Me.drawingFormatRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.DrawingFormatRibbonPage()
			Me.drawingFormatArrangeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.DrawingFormatArrangeRibbonPageGroup()
			Me.pictureToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.PictureToolsRibbonPageCategory()
			Me.pictureFormatRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.PictureFormatRibbonPage()
			Me.pictureFormatArrangeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PictureFormatArrangeRibbonPageGroup()
			Me.pivotTableToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.PivotTableToolsRibbonPageCategory()
			Me.pivotTableAnalyzeRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeRibbonPage()
			Me.pivotTableAnalyzePivotTableRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzePivotTableRibbonPageGroup()
			Me.pivotTableAnalyzeActiveFieldRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActiveFieldRibbonPageGroup()
			Me.pivotTableAnalyzeGroupRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeGroupRibbonPageGroup()
			Me.pivotTableAnalyzeDataRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeDataRibbonPageGroup()
			Me.pivotTableAnalyzeActionsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActionsRibbonPageGroup()
			Me.pivotTableAnalyzeCalculationsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeCalculationsRibbonPageGroup()
			Me.pivotTableAnalyzeShowRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeShowRibbonPageGroup()
			Me.pivotTableDesignRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.PivotTableDesignRibbonPage()
			Me.pivotTableDesignLayoutRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableDesignLayoutRibbonPageGroup()
			Me.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup()
			Me.pivotTableDesignPivotTableStylesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStylesRibbonPageGroup()
			Me.fileRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.FileRibbonPage()
			Me.commonRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.CommonRibbonPageGroup()
			Me.infoRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.InfoRibbonPageGroup()
			Me.homeRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.HomeRibbonPage()
			Me.clipboardRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ClipboardRibbonPageGroup()
			Me.fontRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FontRibbonPageGroup()
			Me.alignmentRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.AlignmentRibbonPageGroup()
			Me.numberRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.NumberRibbonPageGroup()
			Me.stylesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.StylesRibbonPageGroup()
			Me.cellsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.CellsRibbonPageGroup()
			Me.editingRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.EditingRibbonPageGroup()
			Me.insertRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.InsertRibbonPage()
			Me.tablesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TablesRibbonPageGroup()
			Me.illustrationsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.IllustrationsRibbonPageGroup()
			Me.chartsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsRibbonPageGroup()
			Me.linksRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.LinksRibbonPageGroup()
			Me.symbolsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.SymbolsRibbonPageGroup()
			Me.pageLayoutRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.PageLayoutRibbonPage()
			Me.pageSetupRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PageSetupRibbonPageGroup()
			Me.pageSetupShowRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PageSetupShowRibbonPageGroup()
			Me.pageSetupPrintRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PageSetupPrintRibbonPageGroup()
			Me.arrangeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ArrangeRibbonPageGroup()
			Me.formulasRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.FormulasRibbonPage()
			Me.functionLibraryRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FunctionLibraryRibbonPageGroup()
			Me.formulaDefinedNamesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FormulaDefinedNamesRibbonPageGroup()
			Me.formulaAuditingRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FormulaAuditingRibbonPageGroup()
			Me.formulaCalculationRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FormulaCalculationRibbonPageGroup()
			Me.dataRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.DataRibbonPage()
			Me.sortAndFilterRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.SortAndFilterRibbonPageGroup()
			Me.dataToolsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.DataToolsRibbonPageGroup()
			Me.outlineRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.OutlineRibbonPageGroup()
			Me.reviewRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ReviewRibbonPage()
			Me.commentsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.CommentsRibbonPageGroup()
			Me.changesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChangesRibbonPageGroup()
			Me.viewRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ViewRibbonPage()
			Me.showRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ShowRibbonPageGroup()
			Me.zoomRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ZoomRibbonPageGroup()
			Me.windowRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.WindowRibbonPageGroup()
			Me.repositoryItemProgressBar1 = New DevExpress.XtraEditors.Repository.RepositoryItemProgressBar()
			Me.ribbonStatusBar1 = New DevExpress.XtraBars.Ribbon.RibbonStatusBar()
			Me.spreadsheetFormulaBar1 = New DevExpress.XtraSpreadsheet.SpreadsheetFormulaBar()
			Me.splitterControl1 = New DevExpress.XtraEditors.SplitterControl()
			Me.spreadsheetBarController1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController(Me.components)
			CType(Me.ribbonControl1, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.repositoryItemFontEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.repositoryItemSpreadsheetFontSizeEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown1, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.repositoryItemPopupGalleryEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown2, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown3, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown4, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown5, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown6, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown7, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown8, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown9, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown10, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown11, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown12, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown13, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown14, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown15, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown16, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown17, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown18, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown19, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown20, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown21, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown22, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown23, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.commandBarGalleryDropDown24, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.repositoryItemTextEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.repositoryItemZoomTrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.repositoryItemProgressBar1, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.spreadsheetBarController1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' splashScreenManager1
			' 
			Me.splashScreenManager1.ClosingDelay = 500
			' 
			' spreadsheetControl1
			' 
			Me.spreadsheetControl1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.spreadsheetControl1.Location = New System.Drawing.Point(0, 192)
			Me.spreadsheetControl1.Margin = New System.Windows.Forms.Padding(2)
			Me.spreadsheetControl1.MenuManager = Me.ribbonControl1
			Me.spreadsheetControl1.Name = "spreadsheetControl1"
			Me.spreadsheetControl1.Size = New System.Drawing.Size(892, 225)
			Me.spreadsheetControl1.TabIndex = 0
			Me.spreadsheetControl1.Text = "spreadsheetControl1"
'INSTANT VB NOTE: The following InitializeComponent event wireup was converted to a 'Handles' clause:
'ORIGINAL LINE: this.spreadsheetControl1.UnhandledException += new DevExpress.XtraSpreadsheet.UnhandledExceptionEventHandler(this.spreadsheetControl1_UnhandledException);
			' 
			' ribbonControl1
			' 
			Me.ribbonControl1.EmptyAreaImageOptions.ImagePadding = New System.Windows.Forms.Padding(22, 24, 22, 24)
			Me.ribbonControl1.ExpandCollapseItem.Id = 0
			Me.ribbonControl1.Items.AddRange(New DevExpress.XtraBars.BarItem() { Me.ribbonControl1.ExpandCollapseItem, Me.ribbonControl1.SearchEditItem, Me.spreadsheetCommandBarButtonItem1, Me.spreadsheetCommandBarButtonItem2, Me.spreadsheetCommandBarButtonItem3, Me.spreadsheetCommandBarButtonItem4, Me.spreadsheetCommandBarButtonItem5, Me.spreadsheetCommandBarButtonItem6, Me.spreadsheetCommandBarButtonItem7, Me.spreadsheetCommandBarButtonItem8, Me.spreadsheetCommandBarButtonItem9, Me.spreadsheetCommandBarButtonItem10, Me.spreadsheetCommandBarButtonItem11, Me.spreadsheetCommandBarButtonItem12, Me.spreadsheetCommandBarButtonItem13, Me.spreadsheetCommandBarButtonItem14, Me.spreadsheetCommandBarButtonItem15, Me.barButtonGroup1, Me.changeFontNameItem1, Me.changeFontSizeItem1, Me.spreadsheetCommandBarButtonItem16, Me.spreadsheetCommandBarButtonItem17, Me.barButtonGroup2, Me.spreadsheetCommandBarCheckItem1, Me.spreadsheetCommandBarCheckItem2, Me.spreadsheetCommandBarCheckItem3, Me.spreadsheetCommandBarCheckItem4, Me.barButtonGroup3, Me.spreadsheetCommandBarSubItem1, Me.spreadsheetCommandBarButtonItem18, Me.spreadsheetCommandBarButtonItem19, Me.spreadsheetCommandBarButtonItem20, Me.spreadsheetCommandBarButtonItem21, Me.spreadsheetCommandBarButtonItem22, Me.spreadsheetCommandBarButtonItem23, Me.spreadsheetCommandBarButtonItem24, Me.spreadsheetCommandBarButtonItem25, Me.spreadsheetCommandBarButtonItem26, Me.spreadsheetCommandBarButtonItem27, Me.spreadsheetCommandBarButtonItem28, Me.spreadsheetCommandBarButtonItem29, Me.spreadsheetCommandBarButtonItem30, Me.changeBorderLineColorItem1, Me.changeBorderLineStyleItem1, Me.barButtonGroup4, Me.changeCellFillColorItem1, Me.changeFontColorItem1, Me.barButtonGroup5, Me.spreadsheetCommandBarCheckItem5, Me.spreadsheetCommandBarCheckItem6, Me.spreadsheetCommandBarCheckItem7, Me.barButtonGroup6, Me.spreadsheetCommandBarCheckItem8, Me.spreadsheetCommandBarCheckItem9, Me.spreadsheetCommandBarCheckItem10, Me.barButtonGroup7, Me.spreadsheetCommandBarButtonItem31, Me.spreadsheetCommandBarButtonItem32, Me.spreadsheetCommandBarCheckItem11, Me.spreadsheetCommandBarSubItem2, Me.spreadsheetCommandBarCheckItem12, Me.spreadsheetCommandBarButtonItem33, Me.spreadsheetCommandBarButtonItem34, Me.spreadsheetCommandBarButtonItem35, Me.barButtonGroup8, Me.changeNumberFormatItem1, Me.barButtonGroup9, Me.spreadsheetCommandBarSubItem3, Me.spreadsheetCommandBarButtonItem36, Me.spreadsheetCommandBarButtonItem37, Me.spreadsheetCommandBarButtonItem38, Me.spreadsheetCommandBarButtonItem39, Me.spreadsheetCommandBarButtonItem40, Me.spreadsheetCommandBarButtonItem41, Me.spreadsheetCommandBarButtonItem42, Me.spreadsheetCommandBarButtonItem43, Me.barButtonGroup10, Me.spreadsheetCommandBarButtonItem44, Me.spreadsheetCommandBarButtonItem45, Me.spreadsheetCommandBarSubItem7, Me.spreadsheetCommandBarButtonItem46, Me.spreadsheetCommandBarButtonItem47, Me.spreadsheetCommandBarButtonItem48, Me.spreadsheetCommandBarButtonItem49, Me.spreadsheetCommandBarButtonItem50, Me.spreadsheetCommandBarButtonItem51, Me.spreadsheetCommandBarButtonItem52, Me.spreadsheetCommandBarSubItem4, Me.spreadsheetCommandBarButtonItem53, Me.spreadsheetCommandBarButtonItem54, Me.spreadsheetCommandBarButtonItem55, Me.spreadsheetCommandBarButtonItem56, Me.spreadsheetCommandBarButtonItem57, Me.spreadsheetCommandBarButtonItem58, Me.spreadsheetCommandBarSubItem5, Me.spreadsheetCommandBarButtonGalleryDropDownItem1, Me.spreadsheetCommandBarButtonGalleryDropDownItem2, Me.spreadsheetCommandBarButtonGalleryDropDownItem3, Me.spreadsheetCommandBarButtonItem59, Me.spreadsheetCommandBarButtonItem60, Me.spreadsheetCommandBarButtonItem61, Me.spreadsheetCommandBarSubItem6, Me.spreadsheetCommandBarButtonItem62, Me.galleryFormatAsTableItem1, Me.galleryChangeStyleItem1, Me.spreadsheetCommandBarSubItem8, Me.spreadsheetCommandBarButtonItem63, Me.spreadsheetCommandBarButtonItem64, Me.spreadsheetCommandBarButtonItem65, Me.spreadsheetCommandBarButtonItem66, Me.spreadsheetCommandBarButtonItem67, Me.spreadsheetCommandBarButtonItem68, Me.spreadsheetCommandBarButtonItem69, Me.spreadsheetCommandBarButtonItem70, Me.spreadsheetCommandBarSubItem9, Me.spreadsheetCommandBarButtonItem71, Me.spreadsheetCommandBarButtonItem72, Me.spreadsheetCommandBarButtonItem73, Me.spreadsheetCommandBarButtonItem74, Me.spreadsheetCommandBarButtonItem75, Me.spreadsheetCommandBarButtonItem76, Me.spreadsheetCommandBarSubItem11, Me.spreadsheetCommandBarButtonItem77, Me.spreadsheetCommandBarButtonItem78, Me.spreadsheetCommandBarButtonItem79, Me.spreadsheetCommandBarButtonItem80, Me.spreadsheetCommandBarButtonItem81, Me.spreadsheetCommandBarButtonItem82, Me.spreadsheetCommandBarButtonItem83, Me.spreadsheetCommandBarButtonItem84, Me.spreadsheetCommandBarButtonItem85, Me.spreadsheetCommandBarButtonItem86, Me.spreadsheetCommandBarButtonItem87, Me.spreadsheetCommandBarSubItem10, Me.spreadsheetCommandBarButtonItem88, Me.spreadsheetCommandBarButtonItem89, Me.changeSheetTabColorItem1, Me.spreadsheetCommandBarButtonItem90, Me.spreadsheetCommandBarCheckItem13, Me.spreadsheetCommandBarButtonItem91, Me.spreadsheetCommandBarSubItem12, Me.spreadsheetCommandBarButtonItem92, Me.spreadsheetCommandBarButtonItem93, Me.spreadsheetCommandBarButtonItem94, Me.spreadsheetCommandBarButtonItem95, Me.spreadsheetCommandBarButtonItem96, Me.spreadsheetCommandBarSubItem13, Me.spreadsheetCommandBarButtonItem97, Me.spreadsheetCommandBarButtonItem98, Me.spreadsheetCommandBarButtonItem99, Me.spreadsheetCommandBarButtonItem100, Me.spreadsheetCommandBarSubItem14, Me.spreadsheetCommandBarButtonItem101, Me.spreadsheetCommandBarButtonItem102, Me.spreadsheetCommandBarButtonItem103, Me.spreadsheetCommandBarButtonItem104, Me.spreadsheetCommandBarButtonItem105, Me.spreadsheetCommandBarButtonItem106, Me.spreadsheetCommandBarSubItem15, Me.spreadsheetCommandBarButtonItem107, Me.spreadsheetCommandBarButtonItem108, Me.spreadsheetCommandBarCheckItem14, Me.spreadsheetCommandBarButtonItem109, Me.spreadsheetCommandBarButtonItem110, Me.spreadsheetCommandBarSubItem16, Me.spreadsheetCommandBarButtonItem111, Me.spreadsheetCommandBarButtonItem112, Me.spreadsheetCommandBarButtonItem113, Me.spreadsheetCommandBarButtonItem114, Me.spreadsheetCommandBarButtonItem115, Me.spreadsheetCommandBarButtonItem116, Me.spreadsheetCommandBarButtonItem117, Me.spreadsheetCommandBarButtonItem118, Me.spreadsheetCommandBarButtonItem119, Me.spreadsheetCommandBarButtonItem120, Me.spreadsheetCommandBarButtonGalleryDropDownItem4, Me.spreadsheetCommandBarButtonGalleryDropDownItem5, Me.spreadsheetCommandBarButtonGalleryDropDownItem6, Me.spreadsheetCommandBarButtonGalleryDropDownItem7, Me.spreadsheetCommandBarButtonGalleryDropDownItem8, Me.spreadsheetCommandBarButtonGalleryDropDownItem9, Me.spreadsheetCommandBarButtonGalleryDropDownItem10, Me.spreadsheetCommandBarButtonItem121, Me.spreadsheetCommandBarButtonItem122, Me.spreadsheetCommandBarSubItem17, Me.spreadsheetCommandBarCheckItem15, Me.spreadsheetCommandBarCheckItem16, Me.spreadsheetCommandBarCheckItem17, Me.spreadsheetCommandBarButtonItem123, Me.spreadsheetCommandBarSubItem18, Me.spreadsheetCommandBarCheckItem18, Me.spreadsheetCommandBarCheckItem19, Me.pageSetupPaperKindItem1, Me.spreadsheetCommandBarSubItem19, Me.spreadsheetCommandBarButtonItem124, Me.spreadsheetCommandBarButtonItem125, Me.spreadsheetCommandBarButtonItem126, Me.spreadsheetCommandBarButtonItem127, Me.spreadsheetCommandBarCheckItem20, Me.spreadsheetCommandBarCheckItem21, Me.spreadsheetCommandBarCheckItem22, Me.spreadsheetCommandBarCheckItem23, Me.spreadsheetCommandBarSubItem20, Me.spreadsheetCommandBarButtonItem128, Me.spreadsheetCommandBarButtonItem129, Me.spreadsheetCommandBarSubItem21, Me.spreadsheetCommandBarButtonItem130, Me.spreadsheetCommandBarButtonItem131, Me.spreadsheetCommandBarSubItem22, Me.functionsFinancialItem1, Me.functionsLogicalItem1, Me.functionsTextItem1, Me.functionsDateAndTimeItem1, Me.functionsLookupAndReferenceItem1, Me.functionsMathAndTrigonometryItem1, Me.spreadsheetCommandBarSubItem23, Me.functionsStatisticalItem1, Me.functionsEngineeringItem1, Me.functionsInformationItem1, Me.functionsCompatibilityItem1, Me.functionsWebItem1, Me.spreadsheetCommandBarButtonItem132, Me.spreadsheetCommandBarButtonItem133, Me.definedNameListItem1, Me.spreadsheetCommandBarButtonItem134, Me.spreadsheetCommandBarCheckItem24, Me.spreadsheetCommandBarSubItem24, Me.spreadsheetCommandBarCheckItem25, Me.spreadsheetCommandBarCheckItem26, Me.spreadsheetCommandBarButtonItem135, Me.spreadsheetCommandBarButtonItem136, Me.spreadsheetCommandBarSubItem25, Me.spreadsheetCommandBarButtonItem137, Me.spreadsheetCommandBarButtonItem138, Me.spreadsheetCommandBarButtonItem139, Me.spreadsheetCommandBarSubItem26, Me.spreadsheetCommandBarButtonItem140, Me.spreadsheetCommandBarButtonItem141, Me.spreadsheetCommandBarSubItem27, Me.spreadsheetCommandBarButtonItem142, Me.spreadsheetCommandBarButtonItem143, Me.spreadsheetCommandBarButtonItem144, Me.spreadsheetCommandBarButtonItem145, Me.spreadsheetCommandBarButtonItem146, Me.spreadsheetCommandBarButtonItem147, Me.spreadsheetCommandBarButtonItem148, Me.spreadsheetCommandBarButtonItem149, Me.spreadsheetCommandBarButtonItem150, Me.spreadsheetCommandBarButtonItem151, Me.spreadsheetCommandBarButtonItem152, Me.spreadsheetCommandBarButtonItem153, Me.spreadsheetCommandBarButtonItem154, Me.spreadsheetCommandBarButtonItem155, Me.spreadsheetCommandBarButtonItem156, Me.spreadsheetCommandBarButtonItem157, Me.spreadsheetCommandBarButtonItem158, Me.spreadsheetCommandBarSubItem28, Me.spreadsheetCommandBarButtonItem159, Me.spreadsheetCommandBarButtonItem160, Me.spreadsheetCommandBarButtonItem161, Me.spreadsheetCommandBarButtonItem162, Me.spreadsheetCommandBarButtonItem163, Me.spreadsheetCommandBarButtonItem164, Me.spreadsheetCommandBarButtonItem165, Me.galleryChartLayoutItem1, Me.galleryChartStyleItem1, Me.spreadsheetCommandBarButtonItem166, Me.spreadsheetCommandBarSubItem29, Me.spreadsheetCommandBarButtonGalleryDropDownItem11, Me.spreadsheetCommandBarButtonGalleryDropDownItem12, Me.spreadsheetCommandBarSubItem30, Me.spreadsheetCommandBarButtonGalleryDropDownItem13, Me.spreadsheetCommandBarButtonGalleryDropDownItem14, Me.spreadsheetCommandBarButtonGalleryDropDownItem15, Me.spreadsheetCommandBarSubItem31, Me.spreadsheetCommandBarButtonGalleryDropDownItem16, Me.spreadsheetCommandBarButtonGalleryDropDownItem17, Me.spreadsheetCommandBarButtonGalleryDropDownItem18, Me.spreadsheetCommandBarButtonGalleryDropDownItem19, Me.spreadsheetCommandBarButtonGalleryDropDownItem20, Me.spreadsheetCommandBarButtonGalleryDropDownItem21, Me.spreadsheetCommandBarButtonGalleryDropDownItem22, Me.renameTableItemCaption1, Me.renameTableItem1, Me.spreadsheetCommandBarCheckItem27, Me.spreadsheetCommandBarCheckItem28, Me.spreadsheetCommandBarCheckItem29, Me.spreadsheetCommandBarCheckItem30, Me.spreadsheetCommandBarCheckItem31, Me.spreadsheetCommandBarCheckItem32, Me.spreadsheetCommandBarCheckItem33, Me.galleryTableStylesItem1, Me.spreadsheetCommandBarButtonItem167, Me.spreadsheetCommandBarButtonItem168, Me.spreadsheetCommandBarButtonItem169, Me.spreadsheetCommandBarButtonItem170, Me.spreadsheetCommandBarButtonItem171, Me.spreadsheetCommandBarButtonItem172, Me.spreadsheetCommandBarButtonItem173, Me.spreadsheetCommandBarSubItem32, Me.spreadsheetCommandBarButtonItem174, Me.spreadsheetCommandBarButtonItem175, Me.spreadsheetCommandBarButtonItem176, Me.spreadsheetCommandBarSubItem33, Me.spreadsheetCommandBarButtonItem177, Me.spreadsheetCommandBarButtonItem178, Me.spreadsheetCommandBarSubItem34, Me.spreadsheetCommandBarButtonItem179, Me.spreadsheetCommandBarButtonItem180, Me.spreadsheetCommandBarButtonItem181, Me.spreadsheetCommandBarButtonItem182, Me.spreadsheetCommandBarSubItem35, Me.spreadsheetCommandBarButtonItem183, Me.spreadsheetCommandBarButtonItem184, Me.spreadsheetCommandBarButtonItem185, Me.spreadsheetCommandBarButtonItem186, Me.spreadsheetCommandBarCheckItem34, Me.spreadsheetCommandBarCheckItem35, Me.spreadsheetCommandBarCheckItem36, Me.spreadsheetCommandBarSubItem36, Me.spreadsheetCommandBarButtonItem187, Me.spreadsheetCommandBarButtonItem188, Me.spreadsheetCommandBarButtonItem189, Me.spreadsheetCommandBarSubItem37, Me.spreadsheetCommandBarButtonItem190, Me.spreadsheetCommandBarButtonItem191, Me.spreadsheetCommandBarButtonItem192, Me.spreadsheetCommandBarButtonItem193, Me.spreadsheetCommandBarSubItem38, Me.spreadsheetCommandBarButtonItem194, Me.spreadsheetCommandBarButtonItem195, Me.spreadsheetCommandBarButtonItem196, Me.spreadsheetCommandBarButtonItem197, Me.spreadsheetCommandBarButtonItem198, Me.spreadsheetCommandBarSubItem39, Me.spreadsheetCommandBarButtonItem199, Me.spreadsheetCommandBarButtonItem200, Me.spreadsheetCommandBarCheckItem37, Me.spreadsheetCommandBarCheckItem38, Me.spreadsheetCommandBarCheckItem39, Me.spreadsheetCommandBarCheckItem40, Me.galleryPivotStylesItem1, Me.endModeInfoStaticItem1, Me.averageInfoStaticItem1, Me.countInfoStaticItem1, Me.numericalCountInfoStaticItem1, Me.minInfoStaticItem1, Me.maxInfoStaticItem1, Me.sumInfoStaticItem1, Me.zoomEditItem1, Me.showZoomButtonItem1})
			Me.ribbonControl1.Location = New System.Drawing.Point(0, 0)
			Me.ribbonControl1.Margin = New System.Windows.Forms.Padding(2)
			Me.ribbonControl1.MaxItemId = 355
			Me.ribbonControl1.Name = "ribbonControl1"
			Me.ribbonControl1.OptionsMenuMinWidth = 247
			Me.ribbonControl1.PageCategories.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageCategory() { Me.chartToolsRibbonPageCategory1, Me.tableToolsRibbonPageCategory1, Me.drawingToolsRibbonPageCategory1, Me.pictureToolsRibbonPageCategory1, Me.pivotTableToolsRibbonPageCategory1})
			Me.ribbonControl1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() { Me.fileRibbonPage1, Me.homeRibbonPage1, Me.insertRibbonPage1, Me.pageLayoutRibbonPage1, Me.formulasRibbonPage1, Me.dataRibbonPage1, Me.reviewRibbonPage1, Me.viewRibbonPage1})
			Me.ribbonControl1.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() { Me.repositoryItemFontEdit1, Me.repositoryItemSpreadsheetFontSizeEdit1, Me.repositoryItemPopupGalleryEdit1, Me.repositoryItemTextEdit1, Me.repositoryItemZoomTrackBar1, Me.repositoryItemProgressBar1})
			Me.ribbonControl1.Size = New System.Drawing.Size(892, 158)
			Me.ribbonControl1.StatusBar = Me.ribbonStatusBar1
			' 
			' spreadsheetCommandBarButtonItem1
			' 
			Me.spreadsheetCommandBarButtonItem1.CommandName = "FileNew"
			Me.spreadsheetCommandBarButtonItem1.Id = 1
			Me.spreadsheetCommandBarButtonItem1.Name = "spreadsheetCommandBarButtonItem1"
			' 
			' spreadsheetCommandBarButtonItem2
			' 
			Me.spreadsheetCommandBarButtonItem2.CommandName = "FileOpen"
			Me.spreadsheetCommandBarButtonItem2.Id = 2
			Me.spreadsheetCommandBarButtonItem2.Name = "spreadsheetCommandBarButtonItem2"
			' 
			' spreadsheetCommandBarButtonItem3
			' 
			Me.spreadsheetCommandBarButtonItem3.CommandName = "FileSave"
			Me.spreadsheetCommandBarButtonItem3.Id = 3
			Me.spreadsheetCommandBarButtonItem3.Name = "spreadsheetCommandBarButtonItem3"
			' 
			' spreadsheetCommandBarButtonItem4
			' 
			Me.spreadsheetCommandBarButtonItem4.CommandName = "FileSaveAs"
			Me.spreadsheetCommandBarButtonItem4.Id = 4
			Me.spreadsheetCommandBarButtonItem4.Name = "spreadsheetCommandBarButtonItem4"
			' 
			' spreadsheetCommandBarButtonItem5
			' 
			Me.spreadsheetCommandBarButtonItem5.CommandName = "FileQuickPrint"
			Me.spreadsheetCommandBarButtonItem5.Id = 5
			Me.spreadsheetCommandBarButtonItem5.Name = "spreadsheetCommandBarButtonItem5"
			' 
			' spreadsheetCommandBarButtonItem6
			' 
			Me.spreadsheetCommandBarButtonItem6.CommandName = "FilePrint"
			Me.spreadsheetCommandBarButtonItem6.Id = 6
			Me.spreadsheetCommandBarButtonItem6.Name = "spreadsheetCommandBarButtonItem6"
			' 
			' spreadsheetCommandBarButtonItem7
			' 
			Me.spreadsheetCommandBarButtonItem7.CommandName = "FilePrintPreview"
			Me.spreadsheetCommandBarButtonItem7.Id = 7
			Me.spreadsheetCommandBarButtonItem7.Name = "spreadsheetCommandBarButtonItem7"
			' 
			' spreadsheetCommandBarButtonItem8
			' 
			Me.spreadsheetCommandBarButtonItem8.CommandName = "FileUndo"
			Me.spreadsheetCommandBarButtonItem8.Id = 8
			Me.spreadsheetCommandBarButtonItem8.Name = "spreadsheetCommandBarButtonItem8"
			' 
			' spreadsheetCommandBarButtonItem9
			' 
			Me.spreadsheetCommandBarButtonItem9.CommandName = "FileRedo"
			Me.spreadsheetCommandBarButtonItem9.Id = 9
			Me.spreadsheetCommandBarButtonItem9.Name = "spreadsheetCommandBarButtonItem9"
			' 
			' spreadsheetCommandBarButtonItem10
			' 
			Me.spreadsheetCommandBarButtonItem10.CommandName = "FileEncrypt"
			Me.spreadsheetCommandBarButtonItem10.Id = 10
			Me.spreadsheetCommandBarButtonItem10.Name = "spreadsheetCommandBarButtonItem10"
			' 
			' spreadsheetCommandBarButtonItem11
			' 
			Me.spreadsheetCommandBarButtonItem11.CommandName = "FileShowDocumentProperties"
			Me.spreadsheetCommandBarButtonItem11.Id = 11
			Me.spreadsheetCommandBarButtonItem11.Name = "spreadsheetCommandBarButtonItem11"
			' 
			' spreadsheetCommandBarButtonItem12
			' 
			Me.spreadsheetCommandBarButtonItem12.CommandName = "PasteSelection"
			Me.spreadsheetCommandBarButtonItem12.Id = 22
			Me.spreadsheetCommandBarButtonItem12.Name = "spreadsheetCommandBarButtonItem12"
			Me.spreadsheetCommandBarButtonItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem13
			' 
			Me.spreadsheetCommandBarButtonItem13.CommandName = "CutSelection"
			Me.spreadsheetCommandBarButtonItem13.Id = 23
			Me.spreadsheetCommandBarButtonItem13.Name = "spreadsheetCommandBarButtonItem13"
			Me.spreadsheetCommandBarButtonItem13.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem14
			' 
			Me.spreadsheetCommandBarButtonItem14.CommandName = "CopySelection"
			Me.spreadsheetCommandBarButtonItem14.Id = 24
			Me.spreadsheetCommandBarButtonItem14.Name = "spreadsheetCommandBarButtonItem14"
			Me.spreadsheetCommandBarButtonItem14.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem15
			' 
			Me.spreadsheetCommandBarButtonItem15.CommandName = "ShowPasteSpecialForm"
			Me.spreadsheetCommandBarButtonItem15.Id = 25
			Me.spreadsheetCommandBarButtonItem15.Name = "spreadsheetCommandBarButtonItem15"
			Me.spreadsheetCommandBarButtonItem15.RibbonStyle = (CType((DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText Or DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText), DevExpress.XtraBars.Ribbon.RibbonItemStyles))
			' 
			' barButtonGroup1
			' 
			Me.barButtonGroup1.Id = 12
			Me.barButtonGroup1.ItemLinks.Add(Me.changeFontNameItem1)
			Me.barButtonGroup1.ItemLinks.Add(Me.changeFontSizeItem1)
			Me.barButtonGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem16)
			Me.barButtonGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem17)
			Me.barButtonGroup1.Name = "barButtonGroup1"
			Me.barButtonGroup1.Tag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}"
			' 
			' changeFontNameItem1
			' 
			Me.changeFontNameItem1.Edit = Me.repositoryItemFontEdit1
			Me.changeFontNameItem1.Id = 26
			Me.changeFontNameItem1.Name = "changeFontNameItem1"
			' 
			' repositoryItemFontEdit1
			' 
			Me.repositoryItemFontEdit1.AutoHeight = False
			Me.repositoryItemFontEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() { New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
			Me.repositoryItemFontEdit1.Name = "repositoryItemFontEdit1"
			' 
			' changeFontSizeItem1
			' 
			Me.changeFontSizeItem1.Edit = Me.repositoryItemSpreadsheetFontSizeEdit1
			Me.changeFontSizeItem1.Id = 27
			Me.changeFontSizeItem1.Name = "changeFontSizeItem1"
			' 
			' repositoryItemSpreadsheetFontSizeEdit1
			' 
			Me.repositoryItemSpreadsheetFontSizeEdit1.AutoHeight = False
			Me.repositoryItemSpreadsheetFontSizeEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() { New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
			Me.repositoryItemSpreadsheetFontSizeEdit1.Control = Me.spreadsheetControl1
			Me.repositoryItemSpreadsheetFontSizeEdit1.Name = "repositoryItemSpreadsheetFontSizeEdit1"
			' 
			' spreadsheetCommandBarButtonItem16
			' 
			Me.spreadsheetCommandBarButtonItem16.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}"
			Me.spreadsheetCommandBarButtonItem16.CommandName = "FormatIncreaseFontSize"
			Me.spreadsheetCommandBarButtonItem16.Id = 28
			Me.spreadsheetCommandBarButtonItem16.Name = "spreadsheetCommandBarButtonItem16"
			Me.spreadsheetCommandBarButtonItem16.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarButtonItem17
			' 
			Me.spreadsheetCommandBarButtonItem17.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}"
			Me.spreadsheetCommandBarButtonItem17.CommandName = "FormatDecreaseFontSize"
			Me.spreadsheetCommandBarButtonItem17.Id = 29
			Me.spreadsheetCommandBarButtonItem17.Name = "spreadsheetCommandBarButtonItem17"
			Me.spreadsheetCommandBarButtonItem17.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' barButtonGroup2
			' 
			Me.barButtonGroup2.Id = 13
			Me.barButtonGroup2.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem1)
			Me.barButtonGroup2.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem2)
			Me.barButtonGroup2.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem3)
			Me.barButtonGroup2.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem4)
			Me.barButtonGroup2.Name = "barButtonGroup2"
			Me.barButtonGroup2.Tag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
			' 
			' spreadsheetCommandBarCheckItem1
			' 
			Me.spreadsheetCommandBarCheckItem1.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
			Me.spreadsheetCommandBarCheckItem1.CommandName = "FormatFontBold"
			Me.spreadsheetCommandBarCheckItem1.Id = 30
			Me.spreadsheetCommandBarCheckItem1.Name = "spreadsheetCommandBarCheckItem1"
			Me.spreadsheetCommandBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarCheckItem2
			' 
			Me.spreadsheetCommandBarCheckItem2.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
			Me.spreadsheetCommandBarCheckItem2.CommandName = "FormatFontItalic"
			Me.spreadsheetCommandBarCheckItem2.Id = 31
			Me.spreadsheetCommandBarCheckItem2.Name = "spreadsheetCommandBarCheckItem2"
			Me.spreadsheetCommandBarCheckItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarCheckItem3
			' 
			Me.spreadsheetCommandBarCheckItem3.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
			Me.spreadsheetCommandBarCheckItem3.CommandName = "FormatFontUnderline"
			Me.spreadsheetCommandBarCheckItem3.Id = 32
			Me.spreadsheetCommandBarCheckItem3.Name = "spreadsheetCommandBarCheckItem3"
			Me.spreadsheetCommandBarCheckItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarCheckItem4
			' 
			Me.spreadsheetCommandBarCheckItem4.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
			Me.spreadsheetCommandBarCheckItem4.CommandName = "FormatFontStrikeout"
			Me.spreadsheetCommandBarCheckItem4.Id = 33
			Me.spreadsheetCommandBarCheckItem4.Name = "spreadsheetCommandBarCheckItem4"
			Me.spreadsheetCommandBarCheckItem4.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' barButtonGroup3
			' 
			Me.barButtonGroup3.Id = 14
			Me.barButtonGroup3.ItemLinks.Add(Me.spreadsheetCommandBarSubItem1)
			Me.barButtonGroup3.Name = "barButtonGroup3"
			Me.barButtonGroup3.Tag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}"
			' 
			' spreadsheetCommandBarSubItem1
			' 
			Me.spreadsheetCommandBarSubItem1.ButtonGroupTag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}"
			Me.spreadsheetCommandBarSubItem1.CommandName = "FormatBordersCommandGroup"
			Me.spreadsheetCommandBarSubItem1.Id = 34
			Me.spreadsheetCommandBarSubItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem18),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem19),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem20),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem21),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem22),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem23),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem24),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem25),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem26),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem27),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem28),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem29),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem30),
				New DevExpress.XtraBars.LinkPersistInfo(Me.changeBorderLineColorItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.changeBorderLineStyleItem1)
			})
			Me.spreadsheetCommandBarSubItem1.Name = "spreadsheetCommandBarSubItem1"
			Me.spreadsheetCommandBarSubItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarButtonItem18
			' 
			Me.spreadsheetCommandBarButtonItem18.CommandName = "FormatBottomBorder"
			Me.spreadsheetCommandBarButtonItem18.Id = 35
			Me.spreadsheetCommandBarButtonItem18.Name = "spreadsheetCommandBarButtonItem18"
			' 
			' spreadsheetCommandBarButtonItem19
			' 
			Me.spreadsheetCommandBarButtonItem19.CommandName = "FormatTopBorder"
			Me.spreadsheetCommandBarButtonItem19.Id = 36
			Me.spreadsheetCommandBarButtonItem19.Name = "spreadsheetCommandBarButtonItem19"
			' 
			' spreadsheetCommandBarButtonItem20
			' 
			Me.spreadsheetCommandBarButtonItem20.CommandName = "FormatLeftBorder"
			Me.spreadsheetCommandBarButtonItem20.Id = 37
			Me.spreadsheetCommandBarButtonItem20.Name = "spreadsheetCommandBarButtonItem20"
			' 
			' spreadsheetCommandBarButtonItem21
			' 
			Me.spreadsheetCommandBarButtonItem21.CommandName = "FormatRightBorder"
			Me.spreadsheetCommandBarButtonItem21.Id = 38
			Me.spreadsheetCommandBarButtonItem21.Name = "spreadsheetCommandBarButtonItem21"
			' 
			' spreadsheetCommandBarButtonItem22
			' 
			Me.spreadsheetCommandBarButtonItem22.CommandName = "FormatNoBorders"
			Me.spreadsheetCommandBarButtonItem22.Id = 39
			Me.spreadsheetCommandBarButtonItem22.Name = "spreadsheetCommandBarButtonItem22"
			' 
			' spreadsheetCommandBarButtonItem23
			' 
			Me.spreadsheetCommandBarButtonItem23.CommandName = "FormatAllBorders"
			Me.spreadsheetCommandBarButtonItem23.Id = 40
			Me.spreadsheetCommandBarButtonItem23.Name = "spreadsheetCommandBarButtonItem23"
			' 
			' spreadsheetCommandBarButtonItem24
			' 
			Me.spreadsheetCommandBarButtonItem24.CommandName = "FormatOutsideBorders"
			Me.spreadsheetCommandBarButtonItem24.Id = 41
			Me.spreadsheetCommandBarButtonItem24.Name = "spreadsheetCommandBarButtonItem24"
			' 
			' spreadsheetCommandBarButtonItem25
			' 
			Me.spreadsheetCommandBarButtonItem25.CommandName = "FormatThickBorder"
			Me.spreadsheetCommandBarButtonItem25.Id = 42
			Me.spreadsheetCommandBarButtonItem25.Name = "spreadsheetCommandBarButtonItem25"
			' 
			' spreadsheetCommandBarButtonItem26
			' 
			Me.spreadsheetCommandBarButtonItem26.CommandName = "FormatBottomDoubleBorder"
			Me.spreadsheetCommandBarButtonItem26.Id = 43
			Me.spreadsheetCommandBarButtonItem26.Name = "spreadsheetCommandBarButtonItem26"
			' 
			' spreadsheetCommandBarButtonItem27
			' 
			Me.spreadsheetCommandBarButtonItem27.CommandName = "FormatBottomThickBorder"
			Me.spreadsheetCommandBarButtonItem27.Id = 44
			Me.spreadsheetCommandBarButtonItem27.Name = "spreadsheetCommandBarButtonItem27"
			' 
			' spreadsheetCommandBarButtonItem28
			' 
			Me.spreadsheetCommandBarButtonItem28.CommandName = "FormatTopAndBottomBorder"
			Me.spreadsheetCommandBarButtonItem28.Id = 45
			Me.spreadsheetCommandBarButtonItem28.Name = "spreadsheetCommandBarButtonItem28"
			' 
			' spreadsheetCommandBarButtonItem29
			' 
			Me.spreadsheetCommandBarButtonItem29.CommandName = "FormatTopAndThickBottomBorder"
			Me.spreadsheetCommandBarButtonItem29.Id = 46
			Me.spreadsheetCommandBarButtonItem29.Name = "spreadsheetCommandBarButtonItem29"
			' 
			' spreadsheetCommandBarButtonItem30
			' 
			Me.spreadsheetCommandBarButtonItem30.CommandName = "FormatTopAndDoubleBottomBorder"
			Me.spreadsheetCommandBarButtonItem30.Id = 47
			Me.spreadsheetCommandBarButtonItem30.Name = "spreadsheetCommandBarButtonItem30"
			' 
			' changeBorderLineColorItem1
			' 
			Me.changeBorderLineColorItem1.ActAsDropDown = True
			Me.changeBorderLineColorItem1.Id = 48
			Me.changeBorderLineColorItem1.Name = "changeBorderLineColorItem1"
			' 
			' changeBorderLineStyleItem1
			' 
			Me.changeBorderLineStyleItem1.DropDownControl = Me.commandBarGalleryDropDown1
			Me.changeBorderLineStyleItem1.Id = 49
			Me.changeBorderLineStyleItem1.Name = "changeBorderLineStyleItem1"
			' 
			' commandBarGalleryDropDown1
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown1.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown1.Gallery.ColumnCount = 1
			Me.commandBarGalleryDropDown1.Gallery.DrawImageBackground = False
			Me.commandBarGalleryDropDown1.Gallery.ImageSize = New System.Drawing.Size(65, 46)
			Me.commandBarGalleryDropDown1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
			Me.commandBarGalleryDropDown1.Gallery.ItemSize = New System.Drawing.Size(136, 26)
			Me.commandBarGalleryDropDown1.Gallery.RowCount = 14
			Me.commandBarGalleryDropDown1.Gallery.ShowGroupCaption = False
			Me.commandBarGalleryDropDown1.Gallery.ShowItemText = True
			Me.commandBarGalleryDropDown1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown1.Name = "commandBarGalleryDropDown1"
			Me.commandBarGalleryDropDown1.Ribbon = Me.ribbonControl1
			' 
			' barButtonGroup4
			' 
			Me.barButtonGroup4.Id = 15
			Me.barButtonGroup4.ItemLinks.Add(Me.changeCellFillColorItem1)
			Me.barButtonGroup4.ItemLinks.Add(Me.changeFontColorItem1)
			Me.barButtonGroup4.Name = "barButtonGroup4"
			Me.barButtonGroup4.Tag = "{C2275623-04A3-41E8-8D6A-EB5C7F8541D1}"
			' 
			' changeCellFillColorItem1
			' 
			Me.changeCellFillColorItem1.Id = 50
			Me.changeCellFillColorItem1.Name = "changeCellFillColorItem1"
			' 
			' changeFontColorItem1
			' 
			Me.changeFontColorItem1.Id = 51
			Me.changeFontColorItem1.Name = "changeFontColorItem1"
			' 
			' barButtonGroup5
			' 
			Me.barButtonGroup5.Id = 16
			Me.barButtonGroup5.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem5)
			Me.barButtonGroup5.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem6)
			Me.barButtonGroup5.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem7)
			Me.barButtonGroup5.Name = "barButtonGroup5"
			Me.barButtonGroup5.Tag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
			' 
			' spreadsheetCommandBarCheckItem5
			' 
			Me.spreadsheetCommandBarCheckItem5.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
			Me.spreadsheetCommandBarCheckItem5.CommandName = "FormatAlignmentTop"
			Me.spreadsheetCommandBarCheckItem5.Id = 52
			Me.spreadsheetCommandBarCheckItem5.Name = "spreadsheetCommandBarCheckItem5"
			Me.spreadsheetCommandBarCheckItem5.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarCheckItem6
			' 
			Me.spreadsheetCommandBarCheckItem6.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
			Me.spreadsheetCommandBarCheckItem6.CommandName = "FormatAlignmentMiddle"
			Me.spreadsheetCommandBarCheckItem6.Id = 53
			Me.spreadsheetCommandBarCheckItem6.Name = "spreadsheetCommandBarCheckItem6"
			Me.spreadsheetCommandBarCheckItem6.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarCheckItem7
			' 
			Me.spreadsheetCommandBarCheckItem7.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
			Me.spreadsheetCommandBarCheckItem7.CommandName = "FormatAlignmentBottom"
			Me.spreadsheetCommandBarCheckItem7.Id = 54
			Me.spreadsheetCommandBarCheckItem7.Name = "spreadsheetCommandBarCheckItem7"
			Me.spreadsheetCommandBarCheckItem7.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' barButtonGroup6
			' 
			Me.barButtonGroup6.Id = 17
			Me.barButtonGroup6.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem8)
			Me.barButtonGroup6.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem9)
			Me.barButtonGroup6.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem10)
			Me.barButtonGroup6.Name = "barButtonGroup6"
			Me.barButtonGroup6.Tag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
			' 
			' spreadsheetCommandBarCheckItem8
			' 
			Me.spreadsheetCommandBarCheckItem8.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
			Me.spreadsheetCommandBarCheckItem8.CommandName = "FormatAlignmentLeft"
			Me.spreadsheetCommandBarCheckItem8.Id = 55
			Me.spreadsheetCommandBarCheckItem8.Name = "spreadsheetCommandBarCheckItem8"
			Me.spreadsheetCommandBarCheckItem8.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarCheckItem9
			' 
			Me.spreadsheetCommandBarCheckItem9.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
			Me.spreadsheetCommandBarCheckItem9.CommandName = "FormatAlignmentCenter"
			Me.spreadsheetCommandBarCheckItem9.Id = 56
			Me.spreadsheetCommandBarCheckItem9.Name = "spreadsheetCommandBarCheckItem9"
			Me.spreadsheetCommandBarCheckItem9.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarCheckItem10
			' 
			Me.spreadsheetCommandBarCheckItem10.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
			Me.spreadsheetCommandBarCheckItem10.CommandName = "FormatAlignmentRight"
			Me.spreadsheetCommandBarCheckItem10.Id = 57
			Me.spreadsheetCommandBarCheckItem10.Name = "spreadsheetCommandBarCheckItem10"
			Me.spreadsheetCommandBarCheckItem10.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' barButtonGroup7
			' 
			Me.barButtonGroup7.Id = 18
			Me.barButtonGroup7.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem31)
			Me.barButtonGroup7.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem32)
			Me.barButtonGroup7.Name = "barButtonGroup7"
			Me.barButtonGroup7.Tag = "{A5E37DED-106E-44FC-8044-CE3824C08225}"
			' 
			' spreadsheetCommandBarButtonItem31
			' 
			Me.spreadsheetCommandBarButtonItem31.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}"
			Me.spreadsheetCommandBarButtonItem31.CommandName = "FormatDecreaseIndent"
			Me.spreadsheetCommandBarButtonItem31.Id = 58
			Me.spreadsheetCommandBarButtonItem31.Name = "spreadsheetCommandBarButtonItem31"
			Me.spreadsheetCommandBarButtonItem31.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarButtonItem32
			' 
			Me.spreadsheetCommandBarButtonItem32.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}"
			Me.spreadsheetCommandBarButtonItem32.CommandName = "FormatIncreaseIndent"
			Me.spreadsheetCommandBarButtonItem32.Id = 59
			Me.spreadsheetCommandBarButtonItem32.Name = "spreadsheetCommandBarButtonItem32"
			Me.spreadsheetCommandBarButtonItem32.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarCheckItem11
			' 
			Me.spreadsheetCommandBarCheckItem11.CommandName = "FormatWrapText"
			Me.spreadsheetCommandBarCheckItem11.Id = 60
			Me.spreadsheetCommandBarCheckItem11.Name = "spreadsheetCommandBarCheckItem11"
			Me.spreadsheetCommandBarCheckItem11.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarSubItem2
			' 
			Me.spreadsheetCommandBarSubItem2.CommandName = "EditingMergeCellsCommandGroup"
			Me.spreadsheetCommandBarSubItem2.Id = 61
			Me.spreadsheetCommandBarSubItem2.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem12),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem33),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem34),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem35)
			})
			Me.spreadsheetCommandBarSubItem2.Name = "spreadsheetCommandBarSubItem2"
			Me.spreadsheetCommandBarSubItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarCheckItem12
			' 
			Me.spreadsheetCommandBarCheckItem12.CommandName = "EditingMergeAndCenterCells"
			Me.spreadsheetCommandBarCheckItem12.Id = 62
			Me.spreadsheetCommandBarCheckItem12.Name = "spreadsheetCommandBarCheckItem12"
			' 
			' spreadsheetCommandBarButtonItem33
			' 
			Me.spreadsheetCommandBarButtonItem33.CommandName = "EditingMergeCellsAcross"
			Me.spreadsheetCommandBarButtonItem33.Id = 63
			Me.spreadsheetCommandBarButtonItem33.Name = "spreadsheetCommandBarButtonItem33"
			' 
			' spreadsheetCommandBarButtonItem34
			' 
			Me.spreadsheetCommandBarButtonItem34.CommandName = "EditingMergeCells"
			Me.spreadsheetCommandBarButtonItem34.Id = 64
			Me.spreadsheetCommandBarButtonItem34.Name = "spreadsheetCommandBarButtonItem34"
			' 
			' spreadsheetCommandBarButtonItem35
			' 
			Me.spreadsheetCommandBarButtonItem35.CommandName = "EditingUnmergeCells"
			Me.spreadsheetCommandBarButtonItem35.Id = 65
			Me.spreadsheetCommandBarButtonItem35.Name = "spreadsheetCommandBarButtonItem35"
			' 
			' barButtonGroup8
			' 
			Me.barButtonGroup8.Id = 19
			Me.barButtonGroup8.ItemLinks.Add(Me.changeNumberFormatItem1)
			Me.barButtonGroup8.Name = "barButtonGroup8"
			Me.barButtonGroup8.Tag = "{0B3A7A43-3079-4ce0-83A8-3789F5F6DC9F}"
			' 
			' changeNumberFormatItem1
			' 
			Me.changeNumberFormatItem1.Edit = Me.repositoryItemPopupGalleryEdit1
			Me.changeNumberFormatItem1.Id = 66
			Me.changeNumberFormatItem1.Name = "changeNumberFormatItem1"
			' 
			' repositoryItemPopupGalleryEdit1
			' 
			Me.repositoryItemPopupGalleryEdit1.AutoHeight = False
			Me.repositoryItemPopupGalleryEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() { New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
			' 
			' 
			' 
			Me.repositoryItemPopupGalleryEdit1.Gallery.AllowFilter = False
			Me.repositoryItemPopupGalleryEdit1.Gallery.AutoFitColumns = False
			Me.repositoryItemPopupGalleryEdit1.Gallery.ColumnCount = 1
			Me.repositoryItemPopupGalleryEdit1.Gallery.FixedImageSize = False
			spreadsheetCommandGalleryItem1.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem1.CaptionAsValue = True
			spreadsheetCommandGalleryItem1.Checked = True
			spreadsheetCommandGalleryItem1.CommandName = "FormatNumberGeneral"
			spreadsheetCommandGalleryItem1.IsEmptyHint = True
			spreadsheetCommandGalleryItem2.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem2.CaptionAsValue = True
			spreadsheetCommandGalleryItem2.CommandName = "FormatNumberDecimal"
			spreadsheetCommandGalleryItem2.IsEmptyHint = True
			spreadsheetCommandGalleryItem3.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem3.CaptionAsValue = True
			spreadsheetCommandGalleryItem3.CommandName = "FormatNumberAccountingCurrency"
			spreadsheetCommandGalleryItem3.IsEmptyHint = True
			spreadsheetCommandGalleryItem4.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem4.CaptionAsValue = True
			spreadsheetCommandGalleryItem4.CommandName = "FormatNumberAccountingRegular"
			spreadsheetCommandGalleryItem4.IsEmptyHint = True
			spreadsheetCommandGalleryItem5.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem5.CaptionAsValue = True
			spreadsheetCommandGalleryItem5.CommandName = "FormatNumberShortDate"
			spreadsheetCommandGalleryItem5.IsEmptyHint = True
			spreadsheetCommandGalleryItem6.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem6.CaptionAsValue = True
			spreadsheetCommandGalleryItem6.CommandName = "FormatNumberLongDate"
			spreadsheetCommandGalleryItem6.IsEmptyHint = True
			spreadsheetCommandGalleryItem7.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem7.CaptionAsValue = True
			spreadsheetCommandGalleryItem7.CommandName = "FormatNumberTime"
			spreadsheetCommandGalleryItem7.IsEmptyHint = True
			spreadsheetCommandGalleryItem8.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem8.CaptionAsValue = True
			spreadsheetCommandGalleryItem8.CommandName = "FormatNumberPercentage"
			spreadsheetCommandGalleryItem8.IsEmptyHint = True
			spreadsheetCommandGalleryItem9.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem9.CaptionAsValue = True
			spreadsheetCommandGalleryItem9.CommandName = "FormatNumberFraction"
			spreadsheetCommandGalleryItem9.IsEmptyHint = True
			spreadsheetCommandGalleryItem10.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem10.CaptionAsValue = True
			spreadsheetCommandGalleryItem10.CommandName = "FormatNumberScientific"
			spreadsheetCommandGalleryItem10.IsEmptyHint = True
			spreadsheetCommandGalleryItem11.AlwaysUpdateDescription = True
			spreadsheetCommandGalleryItem11.CaptionAsValue = True
			spreadsheetCommandGalleryItem11.CommandName = "FormatNumberText"
			spreadsheetCommandGalleryItem11.IsEmptyHint = True
			galleryItemGroup1.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem1, spreadsheetCommandGalleryItem2, spreadsheetCommandGalleryItem3, spreadsheetCommandGalleryItem4, spreadsheetCommandGalleryItem5, spreadsheetCommandGalleryItem6, spreadsheetCommandGalleryItem7, spreadsheetCommandGalleryItem8, spreadsheetCommandGalleryItem9, spreadsheetCommandGalleryItem10, spreadsheetCommandGalleryItem11})
			Me.repositoryItemPopupGalleryEdit1.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { galleryItemGroup1})
			Me.repositoryItemPopupGalleryEdit1.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.repositoryItemPopupGalleryEdit1.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.repositoryItemPopupGalleryEdit1.Gallery.RowCount = 11
			Me.repositoryItemPopupGalleryEdit1.Gallery.ShowGroupCaption = False
			Me.repositoryItemPopupGalleryEdit1.Gallery.ShowItemText = True
			Me.repositoryItemPopupGalleryEdit1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Hide
			Me.repositoryItemPopupGalleryEdit1.Gallery.StretchItems = True
			Me.repositoryItemPopupGalleryEdit1.Name = "repositoryItemPopupGalleryEdit1"
			Me.repositoryItemPopupGalleryEdit1.ShowButtons = False
			Me.repositoryItemPopupGalleryEdit1.ShowPopupCloseButton = False
			Me.repositoryItemPopupGalleryEdit1.ShowSizeGrip = False
			' 
			' barButtonGroup9
			' 
			Me.barButtonGroup9.Id = 20
			Me.barButtonGroup9.ItemLinks.Add(Me.spreadsheetCommandBarSubItem3)
			Me.barButtonGroup9.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem42)
			Me.barButtonGroup9.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem43)
			Me.barButtonGroup9.Name = "barButtonGroup9"
			Me.barButtonGroup9.Tag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
			' 
			' spreadsheetCommandBarSubItem3
			' 
			Me.spreadsheetCommandBarSubItem3.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
			Me.spreadsheetCommandBarSubItem3.CommandName = "FormatNumberAccountingCommandGroup"
			Me.spreadsheetCommandBarSubItem3.Id = 67
			Me.spreadsheetCommandBarSubItem3.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem36),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem37),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem38),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem39),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem40),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem41)
			})
			Me.spreadsheetCommandBarSubItem3.Name = "spreadsheetCommandBarSubItem3"
			Me.spreadsheetCommandBarSubItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarButtonItem36
			' 
			Me.spreadsheetCommandBarButtonItem36.CommandName = "FormatNumberAccountingDefault"
			Me.spreadsheetCommandBarButtonItem36.Id = 68
			Me.spreadsheetCommandBarButtonItem36.Name = "spreadsheetCommandBarButtonItem36"
			' 
			' spreadsheetCommandBarButtonItem37
			' 
			Me.spreadsheetCommandBarButtonItem37.CommandName = "FormatNumberAccountingUS"
			Me.spreadsheetCommandBarButtonItem37.Id = 69
			Me.spreadsheetCommandBarButtonItem37.Name = "spreadsheetCommandBarButtonItem37"
			' 
			' spreadsheetCommandBarButtonItem38
			' 
			Me.spreadsheetCommandBarButtonItem38.CommandName = "FormatNumberAccountingUK"
			Me.spreadsheetCommandBarButtonItem38.Id = 70
			Me.spreadsheetCommandBarButtonItem38.Name = "spreadsheetCommandBarButtonItem38"
			' 
			' spreadsheetCommandBarButtonItem39
			' 
			Me.spreadsheetCommandBarButtonItem39.CommandName = "FormatNumberAccountingEuro"
			Me.spreadsheetCommandBarButtonItem39.Id = 71
			Me.spreadsheetCommandBarButtonItem39.Name = "spreadsheetCommandBarButtonItem39"
			' 
			' spreadsheetCommandBarButtonItem40
			' 
			Me.spreadsheetCommandBarButtonItem40.CommandName = "FormatNumberAccountingPRC"
			Me.spreadsheetCommandBarButtonItem40.Id = 72
			Me.spreadsheetCommandBarButtonItem40.Name = "spreadsheetCommandBarButtonItem40"
			' 
			' spreadsheetCommandBarButtonItem41
			' 
			Me.spreadsheetCommandBarButtonItem41.CommandName = "FormatNumberAccountingSwiss"
			Me.spreadsheetCommandBarButtonItem41.Id = 73
			Me.spreadsheetCommandBarButtonItem41.Name = "spreadsheetCommandBarButtonItem41"
			' 
			' spreadsheetCommandBarButtonItem42
			' 
			Me.spreadsheetCommandBarButtonItem42.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
			Me.spreadsheetCommandBarButtonItem42.CommandName = "FormatNumberPercent"
			Me.spreadsheetCommandBarButtonItem42.Id = 74
			Me.spreadsheetCommandBarButtonItem42.Name = "spreadsheetCommandBarButtonItem42"
			Me.spreadsheetCommandBarButtonItem42.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarButtonItem43
			' 
			Me.spreadsheetCommandBarButtonItem43.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
			Me.spreadsheetCommandBarButtonItem43.CommandName = "FormatNumberAccounting"
			Me.spreadsheetCommandBarButtonItem43.Id = 75
			Me.spreadsheetCommandBarButtonItem43.Name = "spreadsheetCommandBarButtonItem43"
			Me.spreadsheetCommandBarButtonItem43.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' barButtonGroup10
			' 
			Me.barButtonGroup10.Id = 21
			Me.barButtonGroup10.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem44)
			Me.barButtonGroup10.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem45)
			Me.barButtonGroup10.Name = "barButtonGroup10"
			Me.barButtonGroup10.Tag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}"
			' 
			' spreadsheetCommandBarButtonItem44
			' 
			Me.spreadsheetCommandBarButtonItem44.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}"
			Me.spreadsheetCommandBarButtonItem44.CommandName = "FormatNumberIncreaseDecimal"
			Me.spreadsheetCommandBarButtonItem44.Id = 76
			Me.spreadsheetCommandBarButtonItem44.Name = "spreadsheetCommandBarButtonItem44"
			Me.spreadsheetCommandBarButtonItem44.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarButtonItem45
			' 
			Me.spreadsheetCommandBarButtonItem45.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}"
			Me.spreadsheetCommandBarButtonItem45.CommandName = "FormatNumberDecreaseDecimal"
			Me.spreadsheetCommandBarButtonItem45.Id = 77
			Me.spreadsheetCommandBarButtonItem45.Name = "spreadsheetCommandBarButtonItem45"
			Me.spreadsheetCommandBarButtonItem45.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' spreadsheetCommandBarSubItem7
			' 
			Me.spreadsheetCommandBarSubItem7.CommandName = "ConditionalFormattingCommandGroup"
			Me.spreadsheetCommandBarSubItem7.Id = 78
			Me.spreadsheetCommandBarSubItem7.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarSubItem4),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarSubItem5),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem2),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem3),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem59),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarSubItem6),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem62)
			})
			Me.spreadsheetCommandBarSubItem7.Name = "spreadsheetCommandBarSubItem7"
			' 
			' spreadsheetCommandBarSubItem4
			' 
			Me.spreadsheetCommandBarSubItem4.CommandName = "ConditionalFormattingHighlightCellsRuleCommandGroup"
			Me.spreadsheetCommandBarSubItem4.Id = 86
			Me.spreadsheetCommandBarSubItem4.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem46),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem47),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem48),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem49),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem50),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem51),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem52)
			})
			Me.spreadsheetCommandBarSubItem4.Name = "spreadsheetCommandBarSubItem4"
			' 
			' spreadsheetCommandBarButtonItem46
			' 
			Me.spreadsheetCommandBarButtonItem46.CommandName = "ConditionalFormattingGreaterThanRuleCommand"
			Me.spreadsheetCommandBarButtonItem46.Id = 79
			Me.spreadsheetCommandBarButtonItem46.Name = "spreadsheetCommandBarButtonItem46"
			Me.spreadsheetCommandBarButtonItem46.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem47
			' 
			Me.spreadsheetCommandBarButtonItem47.CommandName = "ConditionalFormattingLessThanRuleCommand"
			Me.spreadsheetCommandBarButtonItem47.Id = 80
			Me.spreadsheetCommandBarButtonItem47.Name = "spreadsheetCommandBarButtonItem47"
			Me.spreadsheetCommandBarButtonItem47.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem48
			' 
			Me.spreadsheetCommandBarButtonItem48.CommandName = "ConditionalFormattingBetweenRuleCommand"
			Me.spreadsheetCommandBarButtonItem48.Id = 81
			Me.spreadsheetCommandBarButtonItem48.Name = "spreadsheetCommandBarButtonItem48"
			Me.spreadsheetCommandBarButtonItem48.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem49
			' 
			Me.spreadsheetCommandBarButtonItem49.CommandName = "ConditionalFormattingEqualToRuleCommand"
			Me.spreadsheetCommandBarButtonItem49.Id = 82
			Me.spreadsheetCommandBarButtonItem49.Name = "spreadsheetCommandBarButtonItem49"
			Me.spreadsheetCommandBarButtonItem49.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem50
			' 
			Me.spreadsheetCommandBarButtonItem50.CommandName = "ConditionalFormattingTextContainsRuleCommand"
			Me.spreadsheetCommandBarButtonItem50.Id = 83
			Me.spreadsheetCommandBarButtonItem50.Name = "spreadsheetCommandBarButtonItem50"
			Me.spreadsheetCommandBarButtonItem50.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem51
			' 
			Me.spreadsheetCommandBarButtonItem51.CommandName = "ConditionalFormattingDateOccurringRuleCommand"
			Me.spreadsheetCommandBarButtonItem51.Id = 84
			Me.spreadsheetCommandBarButtonItem51.Name = "spreadsheetCommandBarButtonItem51"
			Me.spreadsheetCommandBarButtonItem51.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem52
			' 
			Me.spreadsheetCommandBarButtonItem52.CommandName = "ConditionalFormattingDuplicateValuesRuleCommand"
			Me.spreadsheetCommandBarButtonItem52.Id = 85
			Me.spreadsheetCommandBarButtonItem52.Name = "spreadsheetCommandBarButtonItem52"
			Me.spreadsheetCommandBarButtonItem52.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarSubItem5
			' 
			Me.spreadsheetCommandBarSubItem5.CommandName = "ConditionalFormattingTopBottomRuleCommandGroup"
			Me.spreadsheetCommandBarSubItem5.Id = 93
			Me.spreadsheetCommandBarSubItem5.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem53),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem54),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem55),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem56),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem57),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem58)
			})
			Me.spreadsheetCommandBarSubItem5.Name = "spreadsheetCommandBarSubItem5"
			' 
			' spreadsheetCommandBarButtonItem53
			' 
			Me.spreadsheetCommandBarButtonItem53.CommandName = "ConditionalFormattingTop10RuleCommand"
			Me.spreadsheetCommandBarButtonItem53.Id = 87
			Me.spreadsheetCommandBarButtonItem53.Name = "spreadsheetCommandBarButtonItem53"
			Me.spreadsheetCommandBarButtonItem53.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem54
			' 
			Me.spreadsheetCommandBarButtonItem54.CommandName = "ConditionalFormattingTop10PercentRuleCommand"
			Me.spreadsheetCommandBarButtonItem54.Id = 88
			Me.spreadsheetCommandBarButtonItem54.Name = "spreadsheetCommandBarButtonItem54"
			Me.spreadsheetCommandBarButtonItem54.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem55
			' 
			Me.spreadsheetCommandBarButtonItem55.CommandName = "ConditionalFormattingBottom10RuleCommand"
			Me.spreadsheetCommandBarButtonItem55.Id = 89
			Me.spreadsheetCommandBarButtonItem55.Name = "spreadsheetCommandBarButtonItem55"
			Me.spreadsheetCommandBarButtonItem55.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem56
			' 
			Me.spreadsheetCommandBarButtonItem56.CommandName = "ConditionalFormattingBottom10PercentRuleCommand"
			Me.spreadsheetCommandBarButtonItem56.Id = 90
			Me.spreadsheetCommandBarButtonItem56.Name = "spreadsheetCommandBarButtonItem56"
			Me.spreadsheetCommandBarButtonItem56.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem57
			' 
			Me.spreadsheetCommandBarButtonItem57.CommandName = "ConditionalFormattingAboveAverageRuleCommand"
			Me.spreadsheetCommandBarButtonItem57.Id = 91
			Me.spreadsheetCommandBarButtonItem57.Name = "spreadsheetCommandBarButtonItem57"
			Me.spreadsheetCommandBarButtonItem57.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem58
			' 
			Me.spreadsheetCommandBarButtonItem58.CommandName = "ConditionalFormattingBelowAverageRuleCommand"
			Me.spreadsheetCommandBarButtonItem58.Id = 92
			Me.spreadsheetCommandBarButtonItem58.Name = "spreadsheetCommandBarButtonItem58"
			Me.spreadsheetCommandBarButtonItem58.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem1
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem1.CommandName = "ConditionalFormattingDataBarsCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem1.DropDownControl = Me.commandBarGalleryDropDown2
			Me.spreadsheetCommandBarButtonGalleryDropDownItem1.Id = 94
			Me.spreadsheetCommandBarButtonGalleryDropDownItem1.Name = "spreadsheetCommandBarButtonGalleryDropDownItem1"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' commandBarGalleryDropDown2
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown2.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup1.CommandName = "ConditionalFormattingDataBarsGradientFillCommandGroup"
			spreadsheetCommandGalleryItem12.CommandName = "ConditionalFormattingDataBarGradientBlue"
			spreadsheetCommandGalleryItem13.CommandName = "ConditionalFormattingDataBarGradientGreen"
			spreadsheetCommandGalleryItem14.CommandName = "ConditionalFormattingDataBarGradientRed"
			spreadsheetCommandGalleryItem15.CommandName = "ConditionalFormattingDataBarGradientOrange"
			spreadsheetCommandGalleryItem16.CommandName = "ConditionalFormattingDataBarGradientLightBlue"
			spreadsheetCommandGalleryItem17.CommandName = "ConditionalFormattingDataBarGradientPurple"
			spreadsheetCommandGalleryItemGroup1.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem12, spreadsheetCommandGalleryItem13, spreadsheetCommandGalleryItem14, spreadsheetCommandGalleryItem15, spreadsheetCommandGalleryItem16, spreadsheetCommandGalleryItem17})
			spreadsheetCommandGalleryItemGroup2.CommandName = "ConditionalFormattingDataBarsSolidFillCommandGroup"
			spreadsheetCommandGalleryItem18.CommandName = "ConditionalFormattingDataBarSolidBlue"
			spreadsheetCommandGalleryItem19.CommandName = "ConditionalFormattingDataBarSolidGreen"
			spreadsheetCommandGalleryItem20.CommandName = "ConditionalFormattingDataBarSolidRed"
			spreadsheetCommandGalleryItem21.CommandName = "ConditionalFormattingDataBarSolidOrange"
			spreadsheetCommandGalleryItem22.CommandName = "ConditionalFormattingDataBarSolidLightBlue"
			spreadsheetCommandGalleryItem23.CommandName = "ConditionalFormattingDataBarSolidPurple"
			spreadsheetCommandGalleryItemGroup2.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem18, spreadsheetCommandGalleryItem19, spreadsheetCommandGalleryItem20, spreadsheetCommandGalleryItem21, spreadsheetCommandGalleryItem22, spreadsheetCommandGalleryItem23})
			Me.commandBarGalleryDropDown2.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup1, spreadsheetCommandGalleryItemGroup2})
			Me.commandBarGalleryDropDown2.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown2.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown2.Name = "commandBarGalleryDropDown2"
			Me.commandBarGalleryDropDown2.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem2
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem2.CommandName = "ConditionalFormattingColorScalesCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem2.DropDownControl = Me.commandBarGalleryDropDown3
			Me.spreadsheetCommandBarButtonGalleryDropDownItem2.Id = 95
			Me.spreadsheetCommandBarButtonGalleryDropDownItem2.Name = "spreadsheetCommandBarButtonGalleryDropDownItem2"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' commandBarGalleryDropDown3
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown3.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup3.CommandName = "ConditionalFormattingColorScalesCommandGroup"
			spreadsheetCommandGalleryItem24.CommandName = "ConditionalFormattingColorScaleGreenYellowRed"
			spreadsheetCommandGalleryItem25.CommandName = "ConditionalFormattingColorScaleRedYellowGreen"
			spreadsheetCommandGalleryItem26.CommandName = "ConditionalFormattingColorScaleGreenWhiteRed"
			spreadsheetCommandGalleryItem27.CommandName = "ConditionalFormattingColorScaleRedWhiteGreen"
			spreadsheetCommandGalleryItem28.CommandName = "ConditionalFormattingColorScaleBlueWhiteRed"
			spreadsheetCommandGalleryItem29.CommandName = "ConditionalFormattingColorScaleRedWhiteBlue"
			spreadsheetCommandGalleryItem30.CommandName = "ConditionalFormattingColorScaleWhiteRed"
			spreadsheetCommandGalleryItem31.CommandName = "ConditionalFormattingColorScaleRedWhite"
			spreadsheetCommandGalleryItem32.CommandName = "ConditionalFormattingColorScaleGreenWhite"
			spreadsheetCommandGalleryItem33.CommandName = "ConditionalFormattingColorScaleWhiteGreen"
			spreadsheetCommandGalleryItem34.CommandName = "ConditionalFormattingColorScaleGreenYellow"
			spreadsheetCommandGalleryItem35.CommandName = "ConditionalFormattingColorScaleYellowGreen"
			spreadsheetCommandGalleryItemGroup3.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem24, spreadsheetCommandGalleryItem25, spreadsheetCommandGalleryItem26, spreadsheetCommandGalleryItem27, spreadsheetCommandGalleryItem28, spreadsheetCommandGalleryItem29, spreadsheetCommandGalleryItem30, spreadsheetCommandGalleryItem31, spreadsheetCommandGalleryItem32, spreadsheetCommandGalleryItem33, spreadsheetCommandGalleryItem34, spreadsheetCommandGalleryItem35})
			Me.commandBarGalleryDropDown3.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup3})
			Me.commandBarGalleryDropDown3.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown3.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown3.Name = "commandBarGalleryDropDown3"
			Me.commandBarGalleryDropDown3.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem3
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem3.CommandName = "ConditionalFormattingIconSetsCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem3.DropDownControl = Me.commandBarGalleryDropDown4
			Me.spreadsheetCommandBarButtonGalleryDropDownItem3.Id = 96
			Me.spreadsheetCommandBarButtonGalleryDropDownItem3.Name = "spreadsheetCommandBarButtonGalleryDropDownItem3"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' commandBarGalleryDropDown4
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown4.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup4.CommandName = "ConditionalFormattingIconSetsDirectionalCommandGroup"
			spreadsheetCommandGalleryItem36.CommandName = "ConditionalFormattingIconSetArrows3Colored"
			spreadsheetCommandGalleryItem37.CommandName = "ConditionalFormattingIconSetArrows3Grayed"
			spreadsheetCommandGalleryItem38.CommandName = "ConditionalFormattingIconSetArrows4Colored"
			spreadsheetCommandGalleryItem39.CommandName = "ConditionalFormattingIconSetArrows4Grayed"
			spreadsheetCommandGalleryItem40.CommandName = "ConditionalFormattingIconSetArrows5Colored"
			spreadsheetCommandGalleryItem41.CommandName = "ConditionalFormattingIconSetArrows5Grayed"
			spreadsheetCommandGalleryItem42.CommandName = "ConditionalFormattingIconSetTriangles3"
			spreadsheetCommandGalleryItemGroup4.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem36, spreadsheetCommandGalleryItem37, spreadsheetCommandGalleryItem38, spreadsheetCommandGalleryItem39, spreadsheetCommandGalleryItem40, spreadsheetCommandGalleryItem41, spreadsheetCommandGalleryItem42})
			spreadsheetCommandGalleryItemGroup5.CommandName = "ConditionalFormattingIconSetsShapesCommandGroup"
			spreadsheetCommandGalleryItem43.CommandName = "ConditionalFormattingIconSetTrafficLights3"
			spreadsheetCommandGalleryItem44.CommandName = "ConditionalFormattingIconSetTrafficLights3Rimmed"
			spreadsheetCommandGalleryItem45.CommandName = "ConditionalFormattingIconSetTrafficLights4"
			spreadsheetCommandGalleryItem46.CommandName = "ConditionalFormattingIconSetSigns3"
			spreadsheetCommandGalleryItem47.CommandName = "ConditionalFormattingIconSetRedToBlack"
			spreadsheetCommandGalleryItemGroup5.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem43, spreadsheetCommandGalleryItem44, spreadsheetCommandGalleryItem45, spreadsheetCommandGalleryItem46, spreadsheetCommandGalleryItem47})
			spreadsheetCommandGalleryItemGroup6.CommandName = "ConditionalFormattingIconSetsIndicatorsCommandGroup"
			spreadsheetCommandGalleryItem48.CommandName = "ConditionalFormattingIconSetSymbols3Circled"
			spreadsheetCommandGalleryItem49.CommandName = "ConditionalFormattingIconSetSymbols3"
			spreadsheetCommandGalleryItem50.CommandName = "ConditionalFormattingIconSetFlags3"
			spreadsheetCommandGalleryItemGroup6.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem48, spreadsheetCommandGalleryItem49, spreadsheetCommandGalleryItem50})
			spreadsheetCommandGalleryItemGroup7.CommandName = "ConditionalFormattingIconSetsRatingsCommandGroup"
			spreadsheetCommandGalleryItem51.CommandName = "ConditionalFormattingIconSetStars3"
			spreadsheetCommandGalleryItem52.CommandName = "ConditionalFormattingIconSetRatings4"
			spreadsheetCommandGalleryItem53.CommandName = "ConditionalFormattingIconSetRatings5"
			spreadsheetCommandGalleryItem54.CommandName = "ConditionalFormattingIconSetQuarters5"
			spreadsheetCommandGalleryItem55.CommandName = "ConditionalFormattingIconSetBoxes5"
			spreadsheetCommandGalleryItemGroup7.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem51, spreadsheetCommandGalleryItem52, spreadsheetCommandGalleryItem53, spreadsheetCommandGalleryItem54, spreadsheetCommandGalleryItem55})
			Me.commandBarGalleryDropDown4.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup4, spreadsheetCommandGalleryItemGroup5, spreadsheetCommandGalleryItemGroup6, spreadsheetCommandGalleryItemGroup7})
			Me.commandBarGalleryDropDown4.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown4.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown4.Name = "commandBarGalleryDropDown4"
			Me.commandBarGalleryDropDown4.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonItem59
			' 
			Me.spreadsheetCommandBarButtonItem59.CommandName = "NewConditionalFormattingRule"
			Me.spreadsheetCommandBarButtonItem59.Id = 97
			Me.spreadsheetCommandBarButtonItem59.Name = "spreadsheetCommandBarButtonItem59"
			' 
			' spreadsheetCommandBarSubItem6
			' 
			Me.spreadsheetCommandBarSubItem6.CommandName = "ConditionalFormattingRemoveCommandGroup"
			Me.spreadsheetCommandBarSubItem6.Id = 100
			Me.spreadsheetCommandBarSubItem6.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem60),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem61)
			})
			Me.spreadsheetCommandBarSubItem6.Name = "spreadsheetCommandBarSubItem6"
			' 
			' spreadsheetCommandBarButtonItem60
			' 
			Me.spreadsheetCommandBarButtonItem60.CommandName = "ConditionalFormattingRemoveFromSheet"
			Me.spreadsheetCommandBarButtonItem60.Id = 98
			Me.spreadsheetCommandBarButtonItem60.Name = "spreadsheetCommandBarButtonItem60"
			' 
			' spreadsheetCommandBarButtonItem61
			' 
			Me.spreadsheetCommandBarButtonItem61.CommandName = "ConditionalFormattingRemove"
			Me.spreadsheetCommandBarButtonItem61.Id = 99
			Me.spreadsheetCommandBarButtonItem61.Name = "spreadsheetCommandBarButtonItem61"
			' 
			' spreadsheetCommandBarButtonItem62
			' 
			Me.spreadsheetCommandBarButtonItem62.CommandName = "ConditionalFormattingRulesManager"
			Me.spreadsheetCommandBarButtonItem62.Id = 101
			Me.spreadsheetCommandBarButtonItem62.Name = "spreadsheetCommandBarButtonItem62"
			' 
			' galleryFormatAsTableItem1
			' 
			Me.galleryFormatAsTableItem1.DropDownControl = Me.commandBarGalleryDropDown5
			Me.galleryFormatAsTableItem1.Id = 102
			Me.galleryFormatAsTableItem1.Name = "galleryFormatAsTableItem1"
			' 
			' commandBarGalleryDropDown5
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown5.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown5.Gallery.ColumnCount = 7
			Me.commandBarGalleryDropDown5.Gallery.DrawImageBackground = False
			Me.commandBarGalleryDropDown5.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
			Me.commandBarGalleryDropDown5.Gallery.ItemSize = New System.Drawing.Size(55, 47)
			Me.commandBarGalleryDropDown5.Gallery.RowCount = 10
			Me.commandBarGalleryDropDown5.Name = "commandBarGalleryDropDown5"
			Me.commandBarGalleryDropDown5.Ribbon = Me.ribbonControl1
			' 
			' galleryChangeStyleItem1
			' 
			' 
			' 
			' 
			Me.galleryChangeStyleItem1.Gallery.DrawImageBackground = False
			Me.galleryChangeStyleItem1.Gallery.ImageSize = New System.Drawing.Size(61, 47)
			Me.galleryChangeStyleItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
			Me.galleryChangeStyleItem1.Gallery.ItemSize = New System.Drawing.Size(79, 23)
			Me.galleryChangeStyleItem1.Gallery.RowCount = 9
			Me.galleryChangeStyleItem1.Gallery.ShowItemText = True
			Me.galleryChangeStyleItem1.Id = 103
			Me.galleryChangeStyleItem1.Name = "galleryChangeStyleItem1"
			' 
			' spreadsheetCommandBarSubItem8
			' 
			Me.spreadsheetCommandBarSubItem8.CommandName = "InsertCellsCommandGroup"
			Me.spreadsheetCommandBarSubItem8.Id = 104
			Me.spreadsheetCommandBarSubItem8.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem63),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem64),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem65),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem66),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem67),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem68),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem69),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem70)
			})
			Me.spreadsheetCommandBarSubItem8.Name = "spreadsheetCommandBarSubItem8"
			' 
			' spreadsheetCommandBarButtonItem63
			' 
			Me.spreadsheetCommandBarButtonItem63.CommandName = "InsertCells"
			Me.spreadsheetCommandBarButtonItem63.Id = 105
			Me.spreadsheetCommandBarButtonItem63.Name = "spreadsheetCommandBarButtonItem63"
			' 
			' spreadsheetCommandBarButtonItem64
			' 
			Me.spreadsheetCommandBarButtonItem64.CommandName = "InsertSheetRows"
			Me.spreadsheetCommandBarButtonItem64.Id = 106
			Me.spreadsheetCommandBarButtonItem64.Name = "spreadsheetCommandBarButtonItem64"
			' 
			' spreadsheetCommandBarButtonItem65
			' 
			Me.spreadsheetCommandBarButtonItem65.CommandName = "InsertSheetColumns"
			Me.spreadsheetCommandBarButtonItem65.Id = 107
			Me.spreadsheetCommandBarButtonItem65.Name = "spreadsheetCommandBarButtonItem65"
			' 
			' spreadsheetCommandBarButtonItem66
			' 
			Me.spreadsheetCommandBarButtonItem66.CommandName = "InsertTableRowsAbove"
			Me.spreadsheetCommandBarButtonItem66.Id = 108
			Me.spreadsheetCommandBarButtonItem66.Name = "spreadsheetCommandBarButtonItem66"
			' 
			' spreadsheetCommandBarButtonItem67
			' 
			Me.spreadsheetCommandBarButtonItem67.CommandName = "InsertTableRowBelow"
			Me.spreadsheetCommandBarButtonItem67.Id = 109
			Me.spreadsheetCommandBarButtonItem67.Name = "spreadsheetCommandBarButtonItem67"
			' 
			' spreadsheetCommandBarButtonItem68
			' 
			Me.spreadsheetCommandBarButtonItem68.CommandName = "InsertTableColumnsToTheLeft"
			Me.spreadsheetCommandBarButtonItem68.Id = 110
			Me.spreadsheetCommandBarButtonItem68.Name = "spreadsheetCommandBarButtonItem68"
			' 
			' spreadsheetCommandBarButtonItem69
			' 
			Me.spreadsheetCommandBarButtonItem69.CommandName = "InsertTableColumnToTheRight"
			Me.spreadsheetCommandBarButtonItem69.Id = 111
			Me.spreadsheetCommandBarButtonItem69.Name = "spreadsheetCommandBarButtonItem69"
			' 
			' spreadsheetCommandBarButtonItem70
			' 
			Me.spreadsheetCommandBarButtonItem70.CommandName = "InsertSheet"
			Me.spreadsheetCommandBarButtonItem70.Id = 112
			Me.spreadsheetCommandBarButtonItem70.Name = "spreadsheetCommandBarButtonItem70"
			' 
			' spreadsheetCommandBarSubItem9
			' 
			Me.spreadsheetCommandBarSubItem9.CommandName = "RemoveCellsCommandGroup"
			Me.spreadsheetCommandBarSubItem9.Id = 113
			Me.spreadsheetCommandBarSubItem9.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem71),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem72),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem73),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem74),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem75),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem76)
			})
			Me.spreadsheetCommandBarSubItem9.Name = "spreadsheetCommandBarSubItem9"
			' 
			' spreadsheetCommandBarButtonItem71
			' 
			Me.spreadsheetCommandBarButtonItem71.CommandName = "RemoveCells"
			Me.spreadsheetCommandBarButtonItem71.Id = 114
			Me.spreadsheetCommandBarButtonItem71.Name = "spreadsheetCommandBarButtonItem71"
			' 
			' spreadsheetCommandBarButtonItem72
			' 
			Me.spreadsheetCommandBarButtonItem72.CommandName = "RemoveSheetRows"
			Me.spreadsheetCommandBarButtonItem72.Id = 115
			Me.spreadsheetCommandBarButtonItem72.Name = "spreadsheetCommandBarButtonItem72"
			' 
			' spreadsheetCommandBarButtonItem73
			' 
			Me.spreadsheetCommandBarButtonItem73.CommandName = "RemoveSheetColumns"
			Me.spreadsheetCommandBarButtonItem73.Id = 116
			Me.spreadsheetCommandBarButtonItem73.Name = "spreadsheetCommandBarButtonItem73"
			' 
			' spreadsheetCommandBarButtonItem74
			' 
			Me.spreadsheetCommandBarButtonItem74.CommandName = "RemoveTableRows"
			Me.spreadsheetCommandBarButtonItem74.Id = 117
			Me.spreadsheetCommandBarButtonItem74.Name = "spreadsheetCommandBarButtonItem74"
			' 
			' spreadsheetCommandBarButtonItem75
			' 
			Me.spreadsheetCommandBarButtonItem75.CommandName = "RemoveTableColumns"
			Me.spreadsheetCommandBarButtonItem75.Id = 118
			Me.spreadsheetCommandBarButtonItem75.Name = "spreadsheetCommandBarButtonItem75"
			' 
			' spreadsheetCommandBarButtonItem76
			' 
			Me.spreadsheetCommandBarButtonItem76.CommandName = "RemoveSheet"
			Me.spreadsheetCommandBarButtonItem76.Id = 119
			Me.spreadsheetCommandBarButtonItem76.Name = "spreadsheetCommandBarButtonItem76"
			' 
			' spreadsheetCommandBarSubItem11
			' 
			Me.spreadsheetCommandBarSubItem11.CommandName = "FormatCommandGroup"
			Me.spreadsheetCommandBarSubItem11.Id = 120
			Me.spreadsheetCommandBarSubItem11.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem77),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem78),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem79),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem80),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem81),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarSubItem10),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem88),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem89),
				New DevExpress.XtraBars.LinkPersistInfo(Me.changeSheetTabColorItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem90),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem13),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem91)
			})
			Me.spreadsheetCommandBarSubItem11.Name = "spreadsheetCommandBarSubItem11"
			' 
			' spreadsheetCommandBarButtonItem77
			' 
			Me.spreadsheetCommandBarButtonItem77.CommandName = "FormatRowHeight"
			Me.spreadsheetCommandBarButtonItem77.Id = 121
			Me.spreadsheetCommandBarButtonItem77.Name = "spreadsheetCommandBarButtonItem77"
			' 
			' spreadsheetCommandBarButtonItem78
			' 
			Me.spreadsheetCommandBarButtonItem78.CommandName = "FormatAutoFitRowHeight"
			Me.spreadsheetCommandBarButtonItem78.Id = 122
			Me.spreadsheetCommandBarButtonItem78.Name = "spreadsheetCommandBarButtonItem78"
			' 
			' spreadsheetCommandBarButtonItem79
			' 
			Me.spreadsheetCommandBarButtonItem79.CommandName = "FormatColumnWidth"
			Me.spreadsheetCommandBarButtonItem79.Id = 123
			Me.spreadsheetCommandBarButtonItem79.Name = "spreadsheetCommandBarButtonItem79"
			' 
			' spreadsheetCommandBarButtonItem80
			' 
			Me.spreadsheetCommandBarButtonItem80.CommandName = "FormatAutoFitColumnWidth"
			Me.spreadsheetCommandBarButtonItem80.Id = 124
			Me.spreadsheetCommandBarButtonItem80.Name = "spreadsheetCommandBarButtonItem80"
			' 
			' spreadsheetCommandBarButtonItem81
			' 
			Me.spreadsheetCommandBarButtonItem81.CommandName = "FormatDefaultColumnWidth"
			Me.spreadsheetCommandBarButtonItem81.Id = 125
			Me.spreadsheetCommandBarButtonItem81.Name = "spreadsheetCommandBarButtonItem81"
			' 
			' spreadsheetCommandBarSubItem10
			' 
			Me.spreadsheetCommandBarSubItem10.CommandName = "HideAndUnhideCommandGroup"
			Me.spreadsheetCommandBarSubItem10.Id = 132
			Me.spreadsheetCommandBarSubItem10.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem82),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem83),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem84),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem85),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem86),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem87)
			})
			Me.spreadsheetCommandBarSubItem10.Name = "spreadsheetCommandBarSubItem10"
			' 
			' spreadsheetCommandBarButtonItem82
			' 
			Me.spreadsheetCommandBarButtonItem82.CommandName = "HideRows"
			Me.spreadsheetCommandBarButtonItem82.Id = 126
			Me.spreadsheetCommandBarButtonItem82.Name = "spreadsheetCommandBarButtonItem82"
			' 
			' spreadsheetCommandBarButtonItem83
			' 
			Me.spreadsheetCommandBarButtonItem83.CommandName = "HideColumns"
			Me.spreadsheetCommandBarButtonItem83.Id = 127
			Me.spreadsheetCommandBarButtonItem83.Name = "spreadsheetCommandBarButtonItem83"
			' 
			' spreadsheetCommandBarButtonItem84
			' 
			Me.spreadsheetCommandBarButtonItem84.CommandName = "HideSheet"
			Me.spreadsheetCommandBarButtonItem84.Id = 128
			Me.spreadsheetCommandBarButtonItem84.Name = "spreadsheetCommandBarButtonItem84"
			' 
			' spreadsheetCommandBarButtonItem85
			' 
			Me.spreadsheetCommandBarButtonItem85.CommandName = "UnhideRows"
			Me.spreadsheetCommandBarButtonItem85.Id = 129
			Me.spreadsheetCommandBarButtonItem85.Name = "spreadsheetCommandBarButtonItem85"
			' 
			' spreadsheetCommandBarButtonItem86
			' 
			Me.spreadsheetCommandBarButtonItem86.CommandName = "UnhideColumns"
			Me.spreadsheetCommandBarButtonItem86.Id = 130
			Me.spreadsheetCommandBarButtonItem86.Name = "spreadsheetCommandBarButtonItem86"
			' 
			' spreadsheetCommandBarButtonItem87
			' 
			Me.spreadsheetCommandBarButtonItem87.CommandName = "UnhideSheet"
			Me.spreadsheetCommandBarButtonItem87.Id = 131
			Me.spreadsheetCommandBarButtonItem87.Name = "spreadsheetCommandBarButtonItem87"
			' 
			' spreadsheetCommandBarButtonItem88
			' 
			Me.spreadsheetCommandBarButtonItem88.CommandName = "RenameSheet"
			Me.spreadsheetCommandBarButtonItem88.Id = 133
			Me.spreadsheetCommandBarButtonItem88.Name = "spreadsheetCommandBarButtonItem88"
			' 
			' spreadsheetCommandBarButtonItem89
			' 
			Me.spreadsheetCommandBarButtonItem89.CommandName = "MoveOrCopySheet"
			Me.spreadsheetCommandBarButtonItem89.Id = 134
			Me.spreadsheetCommandBarButtonItem89.Name = "spreadsheetCommandBarButtonItem89"
			' 
			' changeSheetTabColorItem1
			' 
			Me.changeSheetTabColorItem1.ActAsDropDown = True
			Me.changeSheetTabColorItem1.Id = 135
			Me.changeSheetTabColorItem1.Name = "changeSheetTabColorItem1"
			' 
			' spreadsheetCommandBarButtonItem90
			' 
			Me.spreadsheetCommandBarButtonItem90.CommandName = "ReviewProtectSheet"
			Me.spreadsheetCommandBarButtonItem90.Id = 136
			Me.spreadsheetCommandBarButtonItem90.Name = "spreadsheetCommandBarButtonItem90"
			' 
			' spreadsheetCommandBarCheckItem13
			' 
			Me.spreadsheetCommandBarCheckItem13.CommandName = "FormatCellLocked"
			Me.spreadsheetCommandBarCheckItem13.Id = 137
			Me.spreadsheetCommandBarCheckItem13.Name = "spreadsheetCommandBarCheckItem13"
			' 
			' spreadsheetCommandBarButtonItem91
			' 
			Me.spreadsheetCommandBarButtonItem91.CommandName = "FormatCellsContextMenuItem"
			Me.spreadsheetCommandBarButtonItem91.Id = 138
			Me.spreadsheetCommandBarButtonItem91.Name = "spreadsheetCommandBarButtonItem91"
			' 
			' spreadsheetCommandBarSubItem12
			' 
			Me.spreadsheetCommandBarSubItem12.CommandName = "EditingAutoSumCommandGroup"
			Me.spreadsheetCommandBarSubItem12.Id = 139
			Me.spreadsheetCommandBarSubItem12.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem92),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem93),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem94),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem95),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem96)
			})
			Me.spreadsheetCommandBarSubItem12.Name = "spreadsheetCommandBarSubItem12"
			Me.spreadsheetCommandBarSubItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem92
			' 
			Me.spreadsheetCommandBarButtonItem92.CommandName = "FunctionsInsertSum"
			Me.spreadsheetCommandBarButtonItem92.Id = 140
			Me.spreadsheetCommandBarButtonItem92.Name = "spreadsheetCommandBarButtonItem92"
			' 
			' spreadsheetCommandBarButtonItem93
			' 
			Me.spreadsheetCommandBarButtonItem93.CommandName = "FunctionsInsertAverage"
			Me.spreadsheetCommandBarButtonItem93.Id = 141
			Me.spreadsheetCommandBarButtonItem93.Name = "spreadsheetCommandBarButtonItem93"
			' 
			' spreadsheetCommandBarButtonItem94
			' 
			Me.spreadsheetCommandBarButtonItem94.CommandName = "FunctionsInsertCountNumbers"
			Me.spreadsheetCommandBarButtonItem94.Id = 142
			Me.spreadsheetCommandBarButtonItem94.Name = "spreadsheetCommandBarButtonItem94"
			' 
			' spreadsheetCommandBarButtonItem95
			' 
			Me.spreadsheetCommandBarButtonItem95.CommandName = "FunctionsInsertMax"
			Me.spreadsheetCommandBarButtonItem95.Id = 143
			Me.spreadsheetCommandBarButtonItem95.Name = "spreadsheetCommandBarButtonItem95"
			' 
			' spreadsheetCommandBarButtonItem96
			' 
			Me.spreadsheetCommandBarButtonItem96.CommandName = "FunctionsInsertMin"
			Me.spreadsheetCommandBarButtonItem96.Id = 144
			Me.spreadsheetCommandBarButtonItem96.Name = "spreadsheetCommandBarButtonItem96"
			' 
			' spreadsheetCommandBarSubItem13
			' 
			Me.spreadsheetCommandBarSubItem13.CommandName = "EditingFillCommandGroup"
			Me.spreadsheetCommandBarSubItem13.Id = 145
			Me.spreadsheetCommandBarSubItem13.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem97),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem98),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem99),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem100)
			})
			Me.spreadsheetCommandBarSubItem13.Name = "spreadsheetCommandBarSubItem13"
			Me.spreadsheetCommandBarSubItem13.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem97
			' 
			Me.spreadsheetCommandBarButtonItem97.CommandName = "EditingFillDown"
			Me.spreadsheetCommandBarButtonItem97.Id = 146
			Me.spreadsheetCommandBarButtonItem97.Name = "spreadsheetCommandBarButtonItem97"
			' 
			' spreadsheetCommandBarButtonItem98
			' 
			Me.spreadsheetCommandBarButtonItem98.CommandName = "EditingFillRight"
			Me.spreadsheetCommandBarButtonItem98.Id = 147
			Me.spreadsheetCommandBarButtonItem98.Name = "spreadsheetCommandBarButtonItem98"
			' 
			' spreadsheetCommandBarButtonItem99
			' 
			Me.spreadsheetCommandBarButtonItem99.CommandName = "EditingFillUp"
			Me.spreadsheetCommandBarButtonItem99.Id = 148
			Me.spreadsheetCommandBarButtonItem99.Name = "spreadsheetCommandBarButtonItem99"
			' 
			' spreadsheetCommandBarButtonItem100
			' 
			Me.spreadsheetCommandBarButtonItem100.CommandName = "EditingFillLeft"
			Me.spreadsheetCommandBarButtonItem100.Id = 149
			Me.spreadsheetCommandBarButtonItem100.Name = "spreadsheetCommandBarButtonItem100"
			' 
			' spreadsheetCommandBarSubItem14
			' 
			Me.spreadsheetCommandBarSubItem14.CommandName = "FormatClearCommandGroup"
			Me.spreadsheetCommandBarSubItem14.Id = 150
			Me.spreadsheetCommandBarSubItem14.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem101),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem102),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem103),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem104),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem105),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem106)
			})
			Me.spreadsheetCommandBarSubItem14.Name = "spreadsheetCommandBarSubItem14"
			Me.spreadsheetCommandBarSubItem14.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem101
			' 
			Me.spreadsheetCommandBarButtonItem101.CommandName = "FormatClearAll"
			Me.spreadsheetCommandBarButtonItem101.Id = 151
			Me.spreadsheetCommandBarButtonItem101.Name = "spreadsheetCommandBarButtonItem101"
			' 
			' spreadsheetCommandBarButtonItem102
			' 
			Me.spreadsheetCommandBarButtonItem102.CommandName = "FormatClearFormats"
			Me.spreadsheetCommandBarButtonItem102.Id = 152
			Me.spreadsheetCommandBarButtonItem102.Name = "spreadsheetCommandBarButtonItem102"
			' 
			' spreadsheetCommandBarButtonItem103
			' 
			Me.spreadsheetCommandBarButtonItem103.CommandName = "FormatClearContents"
			Me.spreadsheetCommandBarButtonItem103.Id = 153
			Me.spreadsheetCommandBarButtonItem103.Name = "spreadsheetCommandBarButtonItem103"
			' 
			' spreadsheetCommandBarButtonItem104
			' 
			Me.spreadsheetCommandBarButtonItem104.CommandName = "FormatClearComments"
			Me.spreadsheetCommandBarButtonItem104.Id = 154
			Me.spreadsheetCommandBarButtonItem104.Name = "spreadsheetCommandBarButtonItem104"
			' 
			' spreadsheetCommandBarButtonItem105
			' 
			Me.spreadsheetCommandBarButtonItem105.CommandName = "FormatClearHyperlinks"
			Me.spreadsheetCommandBarButtonItem105.Id = 155
			Me.spreadsheetCommandBarButtonItem105.Name = "spreadsheetCommandBarButtonItem105"
			' 
			' spreadsheetCommandBarButtonItem106
			' 
			Me.spreadsheetCommandBarButtonItem106.CommandName = "FormatRemoveHyperlinks"
			Me.spreadsheetCommandBarButtonItem106.Id = 156
			Me.spreadsheetCommandBarButtonItem106.Name = "spreadsheetCommandBarButtonItem106"
			' 
			' spreadsheetCommandBarSubItem15
			' 
			Me.spreadsheetCommandBarSubItem15.CommandName = "EditingSortAndFilterCommandGroup"
			Me.spreadsheetCommandBarSubItem15.Id = 157
			Me.spreadsheetCommandBarSubItem15.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem107),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem108),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem14),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem109),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem110)
			})
			Me.spreadsheetCommandBarSubItem15.Name = "spreadsheetCommandBarSubItem15"
			' 
			' spreadsheetCommandBarButtonItem107
			' 
			Me.spreadsheetCommandBarButtonItem107.CommandName = "DataSortAscending"
			Me.spreadsheetCommandBarButtonItem107.Id = 158
			Me.spreadsheetCommandBarButtonItem107.Name = "spreadsheetCommandBarButtonItem107"
			' 
			' spreadsheetCommandBarButtonItem108
			' 
			Me.spreadsheetCommandBarButtonItem108.CommandName = "DataSortDescending"
			Me.spreadsheetCommandBarButtonItem108.Id = 159
			Me.spreadsheetCommandBarButtonItem108.Name = "spreadsheetCommandBarButtonItem108"
			' 
			' spreadsheetCommandBarCheckItem14
			' 
			Me.spreadsheetCommandBarCheckItem14.CommandName = "DataFilterToggle"
			Me.spreadsheetCommandBarCheckItem14.Id = 160
			Me.spreadsheetCommandBarCheckItem14.Name = "spreadsheetCommandBarCheckItem14"
			' 
			' spreadsheetCommandBarButtonItem109
			' 
			Me.spreadsheetCommandBarButtonItem109.CommandName = "DataFilterClear"
			Me.spreadsheetCommandBarButtonItem109.Id = 161
			Me.spreadsheetCommandBarButtonItem109.Name = "spreadsheetCommandBarButtonItem109"
			' 
			' spreadsheetCommandBarButtonItem110
			' 
			Me.spreadsheetCommandBarButtonItem110.CommandName = "DataFilterReApply"
			Me.spreadsheetCommandBarButtonItem110.Id = 162
			Me.spreadsheetCommandBarButtonItem110.Name = "spreadsheetCommandBarButtonItem110"
			' 
			' spreadsheetCommandBarSubItem16
			' 
			Me.spreadsheetCommandBarSubItem16.CommandName = "EditingFindAndSelectCommandGroup"
			Me.spreadsheetCommandBarSubItem16.Id = 163
			Me.spreadsheetCommandBarSubItem16.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem111),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem112),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem113),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem114),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem115),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem116),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem117)
			})
			Me.spreadsheetCommandBarSubItem16.Name = "spreadsheetCommandBarSubItem16"
			' 
			' spreadsheetCommandBarButtonItem111
			' 
			Me.spreadsheetCommandBarButtonItem111.CommandName = "EditingFind"
			Me.spreadsheetCommandBarButtonItem111.Id = 164
			Me.spreadsheetCommandBarButtonItem111.Name = "spreadsheetCommandBarButtonItem111"
			' 
			' spreadsheetCommandBarButtonItem112
			' 
			Me.spreadsheetCommandBarButtonItem112.CommandName = "EditingReplace"
			Me.spreadsheetCommandBarButtonItem112.Id = 165
			Me.spreadsheetCommandBarButtonItem112.Name = "spreadsheetCommandBarButtonItem112"
			' 
			' spreadsheetCommandBarButtonItem113
			' 
			Me.spreadsheetCommandBarButtonItem113.CommandName = "EditingSelectFormulas"
			Me.spreadsheetCommandBarButtonItem113.Id = 166
			Me.spreadsheetCommandBarButtonItem113.Name = "spreadsheetCommandBarButtonItem113"
			' 
			' spreadsheetCommandBarButtonItem114
			' 
			Me.spreadsheetCommandBarButtonItem114.CommandName = "EditingSelectComments"
			Me.spreadsheetCommandBarButtonItem114.Id = 167
			Me.spreadsheetCommandBarButtonItem114.Name = "spreadsheetCommandBarButtonItem114"
			' 
			' spreadsheetCommandBarButtonItem115
			' 
			Me.spreadsheetCommandBarButtonItem115.CommandName = "EditingSelectConditionalFormatting"
			Me.spreadsheetCommandBarButtonItem115.Id = 168
			Me.spreadsheetCommandBarButtonItem115.Name = "spreadsheetCommandBarButtonItem115"
			' 
			' spreadsheetCommandBarButtonItem116
			' 
			Me.spreadsheetCommandBarButtonItem116.CommandName = "EditingSelectConstants"
			Me.spreadsheetCommandBarButtonItem116.Id = 169
			Me.spreadsheetCommandBarButtonItem116.Name = "spreadsheetCommandBarButtonItem116"
			' 
			' spreadsheetCommandBarButtonItem117
			' 
			Me.spreadsheetCommandBarButtonItem117.CommandName = "EditingSelectDataValidation"
			Me.spreadsheetCommandBarButtonItem117.Id = 170
			Me.spreadsheetCommandBarButtonItem117.Name = "spreadsheetCommandBarButtonItem117"
			' 
			' spreadsheetCommandBarButtonItem118
			' 
			Me.spreadsheetCommandBarButtonItem118.CommandName = "InsertPivotTable"
			Me.spreadsheetCommandBarButtonItem118.Id = 171
			Me.spreadsheetCommandBarButtonItem118.Name = "spreadsheetCommandBarButtonItem118"
			' 
			' spreadsheetCommandBarButtonItem119
			' 
			Me.spreadsheetCommandBarButtonItem119.CommandName = "InsertTable"
			Me.spreadsheetCommandBarButtonItem119.Id = 172
			Me.spreadsheetCommandBarButtonItem119.Name = "spreadsheetCommandBarButtonItem119"
			' 
			' spreadsheetCommandBarButtonItem120
			' 
			Me.spreadsheetCommandBarButtonItem120.CommandName = "InsertPicture"
			Me.spreadsheetCommandBarButtonItem120.Id = 173
			Me.spreadsheetCommandBarButtonItem120.Name = "spreadsheetCommandBarButtonItem120"
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem4
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem4.CommandName = "InsertChartColumnCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem4.DropDownControl = Me.commandBarGalleryDropDown6
			Me.spreadsheetCommandBarButtonGalleryDropDownItem4.Id = 174
			Me.spreadsheetCommandBarButtonGalleryDropDownItem4.Name = "spreadsheetCommandBarButtonGalleryDropDownItem4"
			' 
			' commandBarGalleryDropDown6
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown6.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup8.CommandName = "InsertChartColumn2DCommandGroup"
			spreadsheetCommandGalleryItem56.CommandName = "InsertChartColumnClustered2D"
			spreadsheetCommandGalleryItem57.CommandName = "InsertChartColumnStacked2D"
			spreadsheetCommandGalleryItem58.CommandName = "InsertChartColumnPercentStacked2D"
			spreadsheetCommandGalleryItemGroup8.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem56, spreadsheetCommandGalleryItem57, spreadsheetCommandGalleryItem58})
			spreadsheetCommandGalleryItemGroup9.CommandName = "InsertChartColumn3DCommandGroup"
			spreadsheetCommandGalleryItem59.CommandName = "InsertChartColumnClustered3D"
			spreadsheetCommandGalleryItem60.CommandName = "InsertChartColumnStacked3D"
			spreadsheetCommandGalleryItem61.CommandName = "InsertChartColumnPercentStacked3D"
			spreadsheetCommandGalleryItem62.CommandName = "InsertChartColumn3D"
			spreadsheetCommandGalleryItemGroup9.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem59, spreadsheetCommandGalleryItem60, spreadsheetCommandGalleryItem61, spreadsheetCommandGalleryItem62})
			spreadsheetCommandGalleryItemGroup10.CommandName = "InsertChartCylinderCommandGroup"
			spreadsheetCommandGalleryItem63.CommandName = "InsertChartCylinderClustered"
			spreadsheetCommandGalleryItem64.CommandName = "InsertChartCylinderStacked"
			spreadsheetCommandGalleryItem65.CommandName = "InsertChartCylinderPercentStacked"
			spreadsheetCommandGalleryItem66.CommandName = "InsertChartCylinder"
			spreadsheetCommandGalleryItemGroup10.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem63, spreadsheetCommandGalleryItem64, spreadsheetCommandGalleryItem65, spreadsheetCommandGalleryItem66})
			spreadsheetCommandGalleryItemGroup11.CommandName = "InsertChartConeCommandGroup"
			spreadsheetCommandGalleryItem67.CommandName = "InsertChartConeClustered"
			spreadsheetCommandGalleryItem68.CommandName = "InsertChartConeStacked"
			spreadsheetCommandGalleryItem69.CommandName = "InsertChartConePercentStacked"
			spreadsheetCommandGalleryItem70.CommandName = "InsertChartCone"
			spreadsheetCommandGalleryItemGroup11.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem67, spreadsheetCommandGalleryItem68, spreadsheetCommandGalleryItem69, spreadsheetCommandGalleryItem70})
			spreadsheetCommandGalleryItemGroup12.CommandName = "InsertChartPyramidCommandGroup"
			spreadsheetCommandGalleryItem71.CommandName = "InsertChartPyramidClustered"
			spreadsheetCommandGalleryItem72.CommandName = "InsertChartPyramidStacked"
			spreadsheetCommandGalleryItem73.CommandName = "InsertChartPyramidPercentStacked"
			spreadsheetCommandGalleryItem74.CommandName = "InsertChartPyramid"
			spreadsheetCommandGalleryItemGroup12.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem71, spreadsheetCommandGalleryItem72, spreadsheetCommandGalleryItem73, spreadsheetCommandGalleryItem74})
			Me.commandBarGalleryDropDown6.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup8, spreadsheetCommandGalleryItemGroup9, spreadsheetCommandGalleryItemGroup10, spreadsheetCommandGalleryItemGroup11, spreadsheetCommandGalleryItemGroup12})
			Me.commandBarGalleryDropDown6.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown6.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown6.Name = "commandBarGalleryDropDown6"
			Me.commandBarGalleryDropDown6.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem5
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem5.CommandName = "InsertChartLineCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem5.DropDownControl = Me.commandBarGalleryDropDown7
			Me.spreadsheetCommandBarButtonGalleryDropDownItem5.Id = 175
			Me.spreadsheetCommandBarButtonGalleryDropDownItem5.Name = "spreadsheetCommandBarButtonGalleryDropDownItem5"
			' 
			' commandBarGalleryDropDown7
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown7.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup13.CommandName = "InsertChartLine2DCommandGroup"
			spreadsheetCommandGalleryItem75.CommandName = "InsertChartLine"
			spreadsheetCommandGalleryItem76.CommandName = "InsertChartStackedLine"
			spreadsheetCommandGalleryItem77.CommandName = "InsertChartPercentStackedLine"
			spreadsheetCommandGalleryItem78.CommandName = "InsertChartLineWithMarkers"
			spreadsheetCommandGalleryItem79.CommandName = "InsertChartStackedLineWithMarkers"
			spreadsheetCommandGalleryItem80.CommandName = "InsertChartPercentStackedLineWithMarkers"
			spreadsheetCommandGalleryItemGroup13.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem75, spreadsheetCommandGalleryItem76, spreadsheetCommandGalleryItem77, spreadsheetCommandGalleryItem78, spreadsheetCommandGalleryItem79, spreadsheetCommandGalleryItem80})
			spreadsheetCommandGalleryItemGroup14.CommandName = "InsertChartLine3DCommandGroup"
			spreadsheetCommandGalleryItem81.CommandName = "InsertChartLine3D"
			spreadsheetCommandGalleryItemGroup14.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem81})
			Me.commandBarGalleryDropDown7.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup13, spreadsheetCommandGalleryItemGroup14})
			Me.commandBarGalleryDropDown7.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown7.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown7.Name = "commandBarGalleryDropDown7"
			Me.commandBarGalleryDropDown7.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem6
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem6.CommandName = "InsertChartPieCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem6.DropDownControl = Me.commandBarGalleryDropDown8
			Me.spreadsheetCommandBarButtonGalleryDropDownItem6.Id = 176
			Me.spreadsheetCommandBarButtonGalleryDropDownItem6.Name = "spreadsheetCommandBarButtonGalleryDropDownItem6"
			' 
			' commandBarGalleryDropDown8
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown8.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup15.CommandName = "InsertChartPie2DCommandGroup"
			spreadsheetCommandGalleryItem82.CommandName = "InsertChartPie2D"
			spreadsheetCommandGalleryItem83.CommandName = "InsertChartPieExploded2D"
			spreadsheetCommandGalleryItemGroup15.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem82, spreadsheetCommandGalleryItem83})
			spreadsheetCommandGalleryItemGroup16.CommandName = "InsertChartPie3DCommandGroup"
			spreadsheetCommandGalleryItem84.CommandName = "InsertChartPie3D"
			spreadsheetCommandGalleryItem85.CommandName = "InsertChartPieExploded3D"
			spreadsheetCommandGalleryItemGroup16.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem84, spreadsheetCommandGalleryItem85})
			spreadsheetCommandGalleryItemGroup17.CommandName = "InsertChartDoughnut2DCommandGroup"
			spreadsheetCommandGalleryItem86.CommandName = "InsertChartDoughnut2D"
			spreadsheetCommandGalleryItem87.CommandName = "InsertChartDoughnutExploded2D"
			spreadsheetCommandGalleryItemGroup17.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem86, spreadsheetCommandGalleryItem87})
			Me.commandBarGalleryDropDown8.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup15, spreadsheetCommandGalleryItemGroup16, spreadsheetCommandGalleryItemGroup17})
			Me.commandBarGalleryDropDown8.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown8.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown8.Name = "commandBarGalleryDropDown8"
			Me.commandBarGalleryDropDown8.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem7
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem7.CommandName = "InsertChartBarCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem7.DropDownControl = Me.commandBarGalleryDropDown9
			Me.spreadsheetCommandBarButtonGalleryDropDownItem7.Id = 177
			Me.spreadsheetCommandBarButtonGalleryDropDownItem7.Name = "spreadsheetCommandBarButtonGalleryDropDownItem7"
			' 
			' commandBarGalleryDropDown9
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown9.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup18.CommandName = "InsertChartBar2DCommandGroup"
			spreadsheetCommandGalleryItem88.CommandName = "InsertChartBarClustered2D"
			spreadsheetCommandGalleryItem89.CommandName = "InsertChartBarStacked2D"
			spreadsheetCommandGalleryItem90.CommandName = "InsertChartBarPercentStacked2D"
			spreadsheetCommandGalleryItemGroup18.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem88, spreadsheetCommandGalleryItem89, spreadsheetCommandGalleryItem90})
			spreadsheetCommandGalleryItemGroup19.CommandName = "InsertChartBar3DCommandGroup"
			spreadsheetCommandGalleryItem91.CommandName = "InsertChartBarClustered3D"
			spreadsheetCommandGalleryItem92.CommandName = "InsertChartBarStacked3D"
			spreadsheetCommandGalleryItem93.CommandName = "InsertChartBarPercentStacked3D"
			spreadsheetCommandGalleryItemGroup19.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem91, spreadsheetCommandGalleryItem92, spreadsheetCommandGalleryItem93})
			spreadsheetCommandGalleryItemGroup20.CommandName = "InsertChartHorizontalCylinderCommandGroup"
			spreadsheetCommandGalleryItem94.CommandName = "InsertChartHorizontalCylinderClustered"
			spreadsheetCommandGalleryItem95.CommandName = "InsertChartHorizontalCylinderStacked"
			spreadsheetCommandGalleryItem96.CommandName = "InsertChartHorizontalCylinderPercentStacked"
			spreadsheetCommandGalleryItemGroup20.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem94, spreadsheetCommandGalleryItem95, spreadsheetCommandGalleryItem96})
			spreadsheetCommandGalleryItemGroup21.CommandName = "InsertChartHorizontalConeCommandGroup"
			spreadsheetCommandGalleryItem97.CommandName = "InsertChartHorizontalConeClustered"
			spreadsheetCommandGalleryItem98.CommandName = "InsertChartHorizontalConeStacked"
			spreadsheetCommandGalleryItem99.CommandName = "InsertChartHorizontalConePercentStacked"
			spreadsheetCommandGalleryItemGroup21.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem97, spreadsheetCommandGalleryItem98, spreadsheetCommandGalleryItem99})
			spreadsheetCommandGalleryItemGroup22.CommandName = "InsertChartHorizontalPyramidCommandGroup"
			spreadsheetCommandGalleryItem100.CommandName = "InsertChartHorizontalPyramidClustered"
			spreadsheetCommandGalleryItem101.CommandName = "InsertChartHorizontalPyramidStacked"
			spreadsheetCommandGalleryItem102.CommandName = "InsertChartHorizontalPyramidPercentStacked"
			spreadsheetCommandGalleryItemGroup22.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem100, spreadsheetCommandGalleryItem101, spreadsheetCommandGalleryItem102})
			Me.commandBarGalleryDropDown9.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup18, spreadsheetCommandGalleryItemGroup19, spreadsheetCommandGalleryItemGroup20, spreadsheetCommandGalleryItemGroup21, spreadsheetCommandGalleryItemGroup22})
			Me.commandBarGalleryDropDown9.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown9.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown9.Name = "commandBarGalleryDropDown9"
			Me.commandBarGalleryDropDown9.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem8
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem8.CommandName = "InsertChartAreaCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem8.DropDownControl = Me.commandBarGalleryDropDown10
			Me.spreadsheetCommandBarButtonGalleryDropDownItem8.Id = 178
			Me.spreadsheetCommandBarButtonGalleryDropDownItem8.Name = "spreadsheetCommandBarButtonGalleryDropDownItem8"
			' 
			' commandBarGalleryDropDown10
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown10.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup23.CommandName = "InsertChartArea2DCommandGroup"
			spreadsheetCommandGalleryItem103.CommandName = "InsertChartArea"
			spreadsheetCommandGalleryItem104.CommandName = "InsertChartStackedArea"
			spreadsheetCommandGalleryItem105.CommandName = "InsertChartPercentStackedArea"
			spreadsheetCommandGalleryItemGroup23.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem103, spreadsheetCommandGalleryItem104, spreadsheetCommandGalleryItem105})
			spreadsheetCommandGalleryItemGroup24.CommandName = "InsertChartArea3DCommandGroup"
			spreadsheetCommandGalleryItem106.CommandName = "InsertChartArea3D"
			spreadsheetCommandGalleryItem107.CommandName = "InsertChartStackedArea3D"
			spreadsheetCommandGalleryItem108.CommandName = "InsertChartPercentStackedArea3D"
			spreadsheetCommandGalleryItemGroup24.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem106, spreadsheetCommandGalleryItem107, spreadsheetCommandGalleryItem108})
			Me.commandBarGalleryDropDown10.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup23, spreadsheetCommandGalleryItemGroup24})
			Me.commandBarGalleryDropDown10.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown10.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown10.Name = "commandBarGalleryDropDown10"
			Me.commandBarGalleryDropDown10.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem9
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem9.CommandName = "InsertChartScatterCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem9.DropDownControl = Me.commandBarGalleryDropDown11
			Me.spreadsheetCommandBarButtonGalleryDropDownItem9.Id = 179
			Me.spreadsheetCommandBarButtonGalleryDropDownItem9.Name = "spreadsheetCommandBarButtonGalleryDropDownItem9"
			' 
			' commandBarGalleryDropDown11
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown11.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup25.CommandName = "InsertChartScatterCommandGroup"
			spreadsheetCommandGalleryItem109.CommandName = "InsertChartScatterMarkers"
			spreadsheetCommandGalleryItem110.CommandName = "InsertChartScatterSmoothLinesAndMarkers"
			spreadsheetCommandGalleryItem111.CommandName = "InsertChartScatterSmoothLines"
			spreadsheetCommandGalleryItem112.CommandName = "InsertChartScatterLinesAndMarkers"
			spreadsheetCommandGalleryItem113.CommandName = "InsertChartScatterLines"
			spreadsheetCommandGalleryItemGroup25.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem109, spreadsheetCommandGalleryItem110, spreadsheetCommandGalleryItem111, spreadsheetCommandGalleryItem112, spreadsheetCommandGalleryItem113})
			spreadsheetCommandGalleryItemGroup26.CommandName = "InsertChartBubbleCommandGroup"
			spreadsheetCommandGalleryItem114.CommandName = "InsertChartBubble"
			spreadsheetCommandGalleryItem115.CommandName = "InsertChartBubble3D"
			spreadsheetCommandGalleryItemGroup26.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem114, spreadsheetCommandGalleryItem115})
			Me.commandBarGalleryDropDown11.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup25, spreadsheetCommandGalleryItemGroup26})
			Me.commandBarGalleryDropDown11.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown11.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown11.Name = "commandBarGalleryDropDown11"
			Me.commandBarGalleryDropDown11.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem10
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem10.CommandName = "InsertChartOtherCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem10.DropDownControl = Me.commandBarGalleryDropDown12
			Me.spreadsheetCommandBarButtonGalleryDropDownItem10.Id = 180
			Me.spreadsheetCommandBarButtonGalleryDropDownItem10.Name = "spreadsheetCommandBarButtonGalleryDropDownItem10"
			' 
			' commandBarGalleryDropDown12
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown12.Gallery.AllowFilter = False
			spreadsheetCommandGalleryItemGroup27.CommandName = "InsertChartStockCommandGroup"
			spreadsheetCommandGalleryItem116.CommandName = "InsertChartStockHighLowClose"
			spreadsheetCommandGalleryItem117.CommandName = "InsertChartStockOpenHighLowClose"
			spreadsheetCommandGalleryItem118.CommandName = "InsertChartStockVolumeHighLowClose"
			spreadsheetCommandGalleryItem119.CommandName = "InsertChartStockVolumeOpenHighLowClose"
			spreadsheetCommandGalleryItemGroup27.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem116, spreadsheetCommandGalleryItem117, spreadsheetCommandGalleryItem118, spreadsheetCommandGalleryItem119})
			spreadsheetCommandGalleryItemGroup28.CommandName = "InsertChartRadarCommandGroup"
			spreadsheetCommandGalleryItem120.CommandName = "InsertChartRadar"
			spreadsheetCommandGalleryItem121.CommandName = "InsertChartRadarWithMarkers"
			spreadsheetCommandGalleryItem122.CommandName = "InsertChartRadarFilled"
			spreadsheetCommandGalleryItemGroup28.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem120, spreadsheetCommandGalleryItem121, spreadsheetCommandGalleryItem122})
			Me.commandBarGalleryDropDown12.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup27, spreadsheetCommandGalleryItemGroup28})
			Me.commandBarGalleryDropDown12.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown12.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown12.Name = "commandBarGalleryDropDown12"
			Me.commandBarGalleryDropDown12.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonItem121
			' 
			Me.spreadsheetCommandBarButtonItem121.CommandName = "InsertHyperlink"
			Me.spreadsheetCommandBarButtonItem121.Id = 181
			Me.spreadsheetCommandBarButtonItem121.Name = "spreadsheetCommandBarButtonItem121"
			' 
			' spreadsheetCommandBarButtonItem122
			' 
			Me.spreadsheetCommandBarButtonItem122.CommandName = "InsertSymbol"
			Me.spreadsheetCommandBarButtonItem122.Id = 182
			Me.spreadsheetCommandBarButtonItem122.Name = "spreadsheetCommandBarButtonItem122"
			' 
			' spreadsheetCommandBarSubItem17
			' 
			Me.spreadsheetCommandBarSubItem17.CommandName = "PageSetupMarginsCommandGroup"
			Me.spreadsheetCommandBarSubItem17.Id = 183
			Me.spreadsheetCommandBarSubItem17.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem15),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem16),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem17),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem123)
			})
			Me.spreadsheetCommandBarSubItem17.Name = "spreadsheetCommandBarSubItem17"
			' 
			' spreadsheetCommandBarCheckItem15
			' 
			Me.spreadsheetCommandBarCheckItem15.CaptionDependOnUnits = True
			Me.spreadsheetCommandBarCheckItem15.CommandName = "PageSetupMarginsNormal"
			Me.spreadsheetCommandBarCheckItem15.Id = 184
			Me.spreadsheetCommandBarCheckItem15.Name = "spreadsheetCommandBarCheckItem15"
			' 
			' spreadsheetCommandBarCheckItem16
			' 
			Me.spreadsheetCommandBarCheckItem16.CaptionDependOnUnits = True
			Me.spreadsheetCommandBarCheckItem16.CommandName = "PageSetupMarginsWide"
			Me.spreadsheetCommandBarCheckItem16.Id = 185
			Me.spreadsheetCommandBarCheckItem16.Name = "spreadsheetCommandBarCheckItem16"
			' 
			' spreadsheetCommandBarCheckItem17
			' 
			Me.spreadsheetCommandBarCheckItem17.CaptionDependOnUnits = True
			Me.spreadsheetCommandBarCheckItem17.CommandName = "PageSetupMarginsNarrow"
			Me.spreadsheetCommandBarCheckItem17.Id = 186
			Me.spreadsheetCommandBarCheckItem17.Name = "spreadsheetCommandBarCheckItem17"
			' 
			' spreadsheetCommandBarButtonItem123
			' 
			Me.spreadsheetCommandBarButtonItem123.CommandName = "PageSetupCustomMargins"
			Me.spreadsheetCommandBarButtonItem123.Id = 187
			Me.spreadsheetCommandBarButtonItem123.Name = "spreadsheetCommandBarButtonItem123"
			' 
			' spreadsheetCommandBarSubItem18
			' 
			Me.spreadsheetCommandBarSubItem18.CommandName = "PageSetupOrientationCommandGroup"
			Me.spreadsheetCommandBarSubItem18.Id = 188
			Me.spreadsheetCommandBarSubItem18.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem18),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem19)
			})
			Me.spreadsheetCommandBarSubItem18.Name = "spreadsheetCommandBarSubItem18"
			' 
			' spreadsheetCommandBarCheckItem18
			' 
			Me.spreadsheetCommandBarCheckItem18.CommandName = "PageSetupOrientationPortrait"
			Me.spreadsheetCommandBarCheckItem18.Id = 189
			Me.spreadsheetCommandBarCheckItem18.Name = "spreadsheetCommandBarCheckItem18"
			' 
			' spreadsheetCommandBarCheckItem19
			' 
			Me.spreadsheetCommandBarCheckItem19.CommandName = "PageSetupOrientationLandscape"
			Me.spreadsheetCommandBarCheckItem19.Id = 190
			Me.spreadsheetCommandBarCheckItem19.Name = "spreadsheetCommandBarCheckItem19"
			' 
			' pageSetupPaperKindItem1
			' 
			Me.pageSetupPaperKindItem1.Id = 191
			Me.pageSetupPaperKindItem1.Name = "pageSetupPaperKindItem1"
			' 
			' spreadsheetCommandBarSubItem19
			' 
			Me.spreadsheetCommandBarSubItem19.CommandName = "PageSetupPrintAreaCommandGroup"
			Me.spreadsheetCommandBarSubItem19.Id = 192
			Me.spreadsheetCommandBarSubItem19.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem124),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem125),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem126)
			})
			Me.spreadsheetCommandBarSubItem19.Name = "spreadsheetCommandBarSubItem19"
			' 
			' spreadsheetCommandBarButtonItem124
			' 
			Me.spreadsheetCommandBarButtonItem124.CommandName = "PageSetupSetPrintArea"
			Me.spreadsheetCommandBarButtonItem124.Id = 193
			Me.spreadsheetCommandBarButtonItem124.Name = "spreadsheetCommandBarButtonItem124"
			' 
			' spreadsheetCommandBarButtonItem125
			' 
			Me.spreadsheetCommandBarButtonItem125.CommandName = "PageSetupClearPrintArea"
			Me.spreadsheetCommandBarButtonItem125.Id = 194
			Me.spreadsheetCommandBarButtonItem125.Name = "spreadsheetCommandBarButtonItem125"
			' 
			' spreadsheetCommandBarButtonItem126
			' 
			Me.spreadsheetCommandBarButtonItem126.CommandName = "PageSetupAddPrintArea"
			Me.spreadsheetCommandBarButtonItem126.Id = 195
			Me.spreadsheetCommandBarButtonItem126.Name = "spreadsheetCommandBarButtonItem126"
			' 
			' spreadsheetCommandBarButtonItem127
			' 
			Me.spreadsheetCommandBarButtonItem127.CommandName = "PageSetupPrintTitles"
			Me.spreadsheetCommandBarButtonItem127.Id = 196
			Me.spreadsheetCommandBarButtonItem127.Name = "spreadsheetCommandBarButtonItem127"
			' 
			' spreadsheetCommandBarCheckItem20
			' 
			Me.spreadsheetCommandBarCheckItem20.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem20.CommandName = "ViewShowGridlines"
			Me.spreadsheetCommandBarCheckItem20.Id = 197
			Me.spreadsheetCommandBarCheckItem20.Name = "spreadsheetCommandBarCheckItem20"
			' 
			' spreadsheetCommandBarCheckItem21
			' 
			Me.spreadsheetCommandBarCheckItem21.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem21.CommandName = "ViewShowHeadings"
			Me.spreadsheetCommandBarCheckItem21.Id = 198
			Me.spreadsheetCommandBarCheckItem21.Name = "spreadsheetCommandBarCheckItem21"
			' 
			' spreadsheetCommandBarCheckItem22
			' 
			Me.spreadsheetCommandBarCheckItem22.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem22.CommandName = "PageSetupPrintGridlines"
			Me.spreadsheetCommandBarCheckItem22.Id = 199
			Me.spreadsheetCommandBarCheckItem22.Name = "spreadsheetCommandBarCheckItem22"
			' 
			' spreadsheetCommandBarCheckItem23
			' 
			Me.spreadsheetCommandBarCheckItem23.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem23.CommandName = "PageSetupPrintHeadings"
			Me.spreadsheetCommandBarCheckItem23.Id = 200
			Me.spreadsheetCommandBarCheckItem23.Name = "spreadsheetCommandBarCheckItem23"
			' 
			' spreadsheetCommandBarSubItem20
			' 
			Me.spreadsheetCommandBarSubItem20.CommandName = "ArrangeBringForwardCommandGroup"
			Me.spreadsheetCommandBarSubItem20.Id = 201
			Me.spreadsheetCommandBarSubItem20.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem128),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem129)
			})
			Me.spreadsheetCommandBarSubItem20.Name = "spreadsheetCommandBarSubItem20"
			' 
			' spreadsheetCommandBarButtonItem128
			' 
			Me.spreadsheetCommandBarButtonItem128.CommandName = "ArrangeBringForward"
			Me.spreadsheetCommandBarButtonItem128.Id = 202
			Me.spreadsheetCommandBarButtonItem128.Name = "spreadsheetCommandBarButtonItem128"
			' 
			' spreadsheetCommandBarButtonItem129
			' 
			Me.spreadsheetCommandBarButtonItem129.CommandName = "ArrangeBringToFront"
			Me.spreadsheetCommandBarButtonItem129.Id = 203
			Me.spreadsheetCommandBarButtonItem129.Name = "spreadsheetCommandBarButtonItem129"
			' 
			' spreadsheetCommandBarSubItem21
			' 
			Me.spreadsheetCommandBarSubItem21.CommandName = "ArrangeSendBackwardCommandGroup"
			Me.spreadsheetCommandBarSubItem21.Id = 204
			Me.spreadsheetCommandBarSubItem21.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem130),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem131)
			})
			Me.spreadsheetCommandBarSubItem21.Name = "spreadsheetCommandBarSubItem21"
			' 
			' spreadsheetCommandBarButtonItem130
			' 
			Me.spreadsheetCommandBarButtonItem130.CommandName = "ArrangeSendBackward"
			Me.spreadsheetCommandBarButtonItem130.Id = 205
			Me.spreadsheetCommandBarButtonItem130.Name = "spreadsheetCommandBarButtonItem130"
			' 
			' spreadsheetCommandBarButtonItem131
			' 
			Me.spreadsheetCommandBarButtonItem131.CommandName = "ArrangeSendToBack"
			Me.spreadsheetCommandBarButtonItem131.Id = 206
			Me.spreadsheetCommandBarButtonItem131.Name = "spreadsheetCommandBarButtonItem131"
			' 
			' spreadsheetCommandBarSubItem22
			' 
			Me.spreadsheetCommandBarSubItem22.CommandName = "FunctionsAutoSumCommandGroup"
			Me.spreadsheetCommandBarSubItem22.Id = 207
			Me.spreadsheetCommandBarSubItem22.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem92),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem93),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem94),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem95),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem96)
			})
			Me.spreadsheetCommandBarSubItem22.Name = "spreadsheetCommandBarSubItem22"
			' 
			' functionsFinancialItem1
			' 
			Me.functionsFinancialItem1.Id = 208
			Me.functionsFinancialItem1.Name = "functionsFinancialItem1"
			' 
			' functionsLogicalItem1
			' 
			Me.functionsLogicalItem1.Id = 209
			Me.functionsLogicalItem1.Name = "functionsLogicalItem1"
			' 
			' functionsTextItem1
			' 
			Me.functionsTextItem1.Id = 210
			Me.functionsTextItem1.Name = "functionsTextItem1"
			' 
			' functionsDateAndTimeItem1
			' 
			Me.functionsDateAndTimeItem1.Id = 211
			Me.functionsDateAndTimeItem1.Name = "functionsDateAndTimeItem1"
			' 
			' functionsLookupAndReferenceItem1
			' 
			Me.functionsLookupAndReferenceItem1.Id = 212
			Me.functionsLookupAndReferenceItem1.Name = "functionsLookupAndReferenceItem1"
			' 
			' functionsMathAndTrigonometryItem1
			' 
			Me.functionsMathAndTrigonometryItem1.Id = 213
			Me.functionsMathAndTrigonometryItem1.Name = "functionsMathAndTrigonometryItem1"
			' 
			' spreadsheetCommandBarSubItem23
			' 
			Me.spreadsheetCommandBarSubItem23.CommandName = "FunctionsMoreCommandGroup"
			Me.spreadsheetCommandBarSubItem23.Id = 214
			Me.spreadsheetCommandBarSubItem23.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.functionsStatisticalItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.functionsEngineeringItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.functionsInformationItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.functionsCompatibilityItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.functionsWebItem1)
			})
			Me.spreadsheetCommandBarSubItem23.Name = "spreadsheetCommandBarSubItem23"
			' 
			' functionsStatisticalItem1
			' 
			Me.functionsStatisticalItem1.Id = 215
			Me.functionsStatisticalItem1.Name = "functionsStatisticalItem1"
			' 
			' functionsEngineeringItem1
			' 
			Me.functionsEngineeringItem1.Id = 216
			Me.functionsEngineeringItem1.Name = "functionsEngineeringItem1"
			' 
			' functionsInformationItem1
			' 
			Me.functionsInformationItem1.Id = 217
			Me.functionsInformationItem1.Name = "functionsInformationItem1"
			' 
			' functionsCompatibilityItem1
			' 
			Me.functionsCompatibilityItem1.Id = 218
			Me.functionsCompatibilityItem1.Name = "functionsCompatibilityItem1"
			' 
			' functionsWebItem1
			' 
			Me.functionsWebItem1.Id = 219
			Me.functionsWebItem1.Name = "functionsWebItem1"
			' 
			' spreadsheetCommandBarButtonItem132
			' 
			Me.spreadsheetCommandBarButtonItem132.CommandName = "FormulasShowNameManager"
			Me.spreadsheetCommandBarButtonItem132.Id = 220
			Me.spreadsheetCommandBarButtonItem132.Name = "spreadsheetCommandBarButtonItem132"
			' 
			' spreadsheetCommandBarButtonItem133
			' 
			Me.spreadsheetCommandBarButtonItem133.CommandName = "FormulasDefineNameCommand"
			Me.spreadsheetCommandBarButtonItem133.Id = 221
			Me.spreadsheetCommandBarButtonItem133.Name = "spreadsheetCommandBarButtonItem133"
			Me.spreadsheetCommandBarButtonItem133.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' definedNameListItem1
			' 
			Me.definedNameListItem1.Id = 222
			Me.definedNameListItem1.Name = "definedNameListItem1"
			Me.definedNameListItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem134
			' 
			Me.spreadsheetCommandBarButtonItem134.CommandName = "FormulasCreateDefinedNamesFromSelection"
			Me.spreadsheetCommandBarButtonItem134.Id = 223
			Me.spreadsheetCommandBarButtonItem134.Name = "spreadsheetCommandBarButtonItem134"
			Me.spreadsheetCommandBarButtonItem134.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarCheckItem24
			' 
			Me.spreadsheetCommandBarCheckItem24.CommandName = "ViewShowFormulas"
			Me.spreadsheetCommandBarCheckItem24.Id = 224
			Me.spreadsheetCommandBarCheckItem24.Name = "spreadsheetCommandBarCheckItem24"
			' 
			' spreadsheetCommandBarSubItem24
			' 
			Me.spreadsheetCommandBarSubItem24.CommandName = "FormulasCalculationOptionsCommandGroup"
			Me.spreadsheetCommandBarSubItem24.Id = 225
			Me.spreadsheetCommandBarSubItem24.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem25),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarCheckItem26)
			})
			Me.spreadsheetCommandBarSubItem24.Name = "spreadsheetCommandBarSubItem24"
			' 
			' spreadsheetCommandBarCheckItem25
			' 
			Me.spreadsheetCommandBarCheckItem25.CommandName = "FormulasCalculationModeAutomatic"
			Me.spreadsheetCommandBarCheckItem25.Id = 226
			Me.spreadsheetCommandBarCheckItem25.Name = "spreadsheetCommandBarCheckItem25"
			' 
			' spreadsheetCommandBarCheckItem26
			' 
			Me.spreadsheetCommandBarCheckItem26.CommandName = "FormulasCalculationModeManual"
			Me.spreadsheetCommandBarCheckItem26.Id = 227
			Me.spreadsheetCommandBarCheckItem26.Name = "spreadsheetCommandBarCheckItem26"
			' 
			' spreadsheetCommandBarButtonItem135
			' 
			Me.spreadsheetCommandBarButtonItem135.CommandName = "FormulasCalculateNow"
			Me.spreadsheetCommandBarButtonItem135.Id = 228
			Me.spreadsheetCommandBarButtonItem135.Name = "spreadsheetCommandBarButtonItem135"
			Me.spreadsheetCommandBarButtonItem135.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem136
			' 
			Me.spreadsheetCommandBarButtonItem136.CommandName = "FormulasCalculateSheet"
			Me.spreadsheetCommandBarButtonItem136.Id = 229
			Me.spreadsheetCommandBarButtonItem136.Name = "spreadsheetCommandBarButtonItem136"
			Me.spreadsheetCommandBarButtonItem136.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarSubItem25
			' 
			Me.spreadsheetCommandBarSubItem25.CommandName = "DataToolsDataValidationCommandGroup"
			Me.spreadsheetCommandBarSubItem25.Id = 230
			Me.spreadsheetCommandBarSubItem25.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem137),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem138),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem139)
			})
			Me.spreadsheetCommandBarSubItem25.Name = "spreadsheetCommandBarSubItem25"
			' 
			' spreadsheetCommandBarButtonItem137
			' 
			Me.spreadsheetCommandBarButtonItem137.CommandName = "DataToolsDataValidation"
			Me.spreadsheetCommandBarButtonItem137.Id = 231
			Me.spreadsheetCommandBarButtonItem137.Name = "spreadsheetCommandBarButtonItem137"
			' 
			' spreadsheetCommandBarButtonItem138
			' 
			Me.spreadsheetCommandBarButtonItem138.CommandName = "DataToolsCircleInvalidData"
			Me.spreadsheetCommandBarButtonItem138.Id = 232
			Me.spreadsheetCommandBarButtonItem138.Name = "spreadsheetCommandBarButtonItem138"
			' 
			' spreadsheetCommandBarButtonItem139
			' 
			Me.spreadsheetCommandBarButtonItem139.CommandName = "DataToolsClearValidationCircles"
			Me.spreadsheetCommandBarButtonItem139.Id = 233
			Me.spreadsheetCommandBarButtonItem139.Name = "spreadsheetCommandBarButtonItem139"
			' 
			' spreadsheetCommandBarSubItem26
			' 
			Me.spreadsheetCommandBarSubItem26.CommandName = "OutlineGroupCommandGroup"
			Me.spreadsheetCommandBarSubItem26.Id = 234
			Me.spreadsheetCommandBarSubItem26.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem140),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem141)
			})
			Me.spreadsheetCommandBarSubItem26.Name = "spreadsheetCommandBarSubItem26"
			Me.spreadsheetCommandBarSubItem26.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem140
			' 
			Me.spreadsheetCommandBarButtonItem140.CommandName = "GroupOutline"
			Me.spreadsheetCommandBarButtonItem140.Id = 235
			Me.spreadsheetCommandBarButtonItem140.Name = "spreadsheetCommandBarButtonItem140"
			' 
			' spreadsheetCommandBarButtonItem141
			' 
			Me.spreadsheetCommandBarButtonItem141.CommandName = "AutoOutline"
			Me.spreadsheetCommandBarButtonItem141.Id = 236
			Me.spreadsheetCommandBarButtonItem141.Name = "spreadsheetCommandBarButtonItem141"
			' 
			' spreadsheetCommandBarSubItem27
			' 
			Me.spreadsheetCommandBarSubItem27.CommandName = "OutlineUngroupCommandGroup"
			Me.spreadsheetCommandBarSubItem27.Id = 237
			Me.spreadsheetCommandBarSubItem27.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem142),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem143)
			})
			Me.spreadsheetCommandBarSubItem27.Name = "spreadsheetCommandBarSubItem27"
			Me.spreadsheetCommandBarSubItem27.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem142
			' 
			Me.spreadsheetCommandBarButtonItem142.CommandName = "UngroupOutline"
			Me.spreadsheetCommandBarButtonItem142.Id = 238
			Me.spreadsheetCommandBarButtonItem142.Name = "spreadsheetCommandBarButtonItem142"
			' 
			' spreadsheetCommandBarButtonItem143
			' 
			Me.spreadsheetCommandBarButtonItem143.CommandName = "ClearOutline"
			Me.spreadsheetCommandBarButtonItem143.Id = 239
			Me.spreadsheetCommandBarButtonItem143.Name = "spreadsheetCommandBarButtonItem143"
			' 
			' spreadsheetCommandBarButtonItem144
			' 
			Me.spreadsheetCommandBarButtonItem144.CommandName = "Subtotal"
			Me.spreadsheetCommandBarButtonItem144.Id = 240
			Me.spreadsheetCommandBarButtonItem144.Name = "spreadsheetCommandBarButtonItem144"
			Me.spreadsheetCommandBarButtonItem144.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem145
			' 
			Me.spreadsheetCommandBarButtonItem145.CommandName = "ShowDetail"
			Me.spreadsheetCommandBarButtonItem145.Id = 241
			Me.spreadsheetCommandBarButtonItem145.Name = "spreadsheetCommandBarButtonItem145"
			Me.spreadsheetCommandBarButtonItem145.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem146
			' 
			Me.spreadsheetCommandBarButtonItem146.CommandName = "HideDetail"
			Me.spreadsheetCommandBarButtonItem146.Id = 242
			Me.spreadsheetCommandBarButtonItem146.Name = "spreadsheetCommandBarButtonItem146"
			Me.spreadsheetCommandBarButtonItem146.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem147
			' 
			Me.spreadsheetCommandBarButtonItem147.CommandName = "ReviewInsertComment"
			Me.spreadsheetCommandBarButtonItem147.Id = 243
			Me.spreadsheetCommandBarButtonItem147.Name = "spreadsheetCommandBarButtonItem147"
			' 
			' spreadsheetCommandBarButtonItem148
			' 
			Me.spreadsheetCommandBarButtonItem148.CommandName = "ReviewEditComment"
			Me.spreadsheetCommandBarButtonItem148.Id = 244
			Me.spreadsheetCommandBarButtonItem148.Name = "spreadsheetCommandBarButtonItem148"
			' 
			' spreadsheetCommandBarButtonItem149
			' 
			Me.spreadsheetCommandBarButtonItem149.CommandName = "ReviewDeleteComment"
			Me.spreadsheetCommandBarButtonItem149.Id = 245
			Me.spreadsheetCommandBarButtonItem149.Name = "spreadsheetCommandBarButtonItem149"
			' 
			' spreadsheetCommandBarButtonItem150
			' 
			Me.spreadsheetCommandBarButtonItem150.CommandName = "ReviewShowHideComment"
			Me.spreadsheetCommandBarButtonItem150.Id = 246
			Me.spreadsheetCommandBarButtonItem150.Name = "spreadsheetCommandBarButtonItem150"
			Me.spreadsheetCommandBarButtonItem150.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem151
			' 
			Me.spreadsheetCommandBarButtonItem151.CommandName = "ReviewUnprotectSheet"
			Me.spreadsheetCommandBarButtonItem151.Id = 247
			Me.spreadsheetCommandBarButtonItem151.Name = "spreadsheetCommandBarButtonItem151"
			' 
			' spreadsheetCommandBarButtonItem152
			' 
			Me.spreadsheetCommandBarButtonItem152.CommandName = "ReviewProtectWorkbook"
			Me.spreadsheetCommandBarButtonItem152.Id = 248
			Me.spreadsheetCommandBarButtonItem152.Name = "spreadsheetCommandBarButtonItem152"
			' 
			' spreadsheetCommandBarButtonItem153
			' 
			Me.spreadsheetCommandBarButtonItem153.CommandName = "ReviewUnprotectWorkbook"
			Me.spreadsheetCommandBarButtonItem153.Id = 249
			Me.spreadsheetCommandBarButtonItem153.Name = "spreadsheetCommandBarButtonItem153"
			' 
			' spreadsheetCommandBarButtonItem154
			' 
			Me.spreadsheetCommandBarButtonItem154.CommandName = "ReviewShowProtectedRangeManager"
			Me.spreadsheetCommandBarButtonItem154.Id = 250
			Me.spreadsheetCommandBarButtonItem154.Name = "spreadsheetCommandBarButtonItem154"
			' 
			' spreadsheetCommandBarButtonItem155
			' 
			Me.spreadsheetCommandBarButtonItem155.CommandName = "ViewZoom"
			Me.spreadsheetCommandBarButtonItem155.Id = 251
			Me.spreadsheetCommandBarButtonItem155.Name = "spreadsheetCommandBarButtonItem155"
			' 
			' spreadsheetCommandBarButtonItem156
			' 
			Me.spreadsheetCommandBarButtonItem156.CommandName = "ViewZoomOut"
			Me.spreadsheetCommandBarButtonItem156.Id = 252
			Me.spreadsheetCommandBarButtonItem156.Name = "spreadsheetCommandBarButtonItem156"
			' 
			' spreadsheetCommandBarButtonItem157
			' 
			Me.spreadsheetCommandBarButtonItem157.CommandName = "ViewZoomIn"
			Me.spreadsheetCommandBarButtonItem157.Id = 253
			Me.spreadsheetCommandBarButtonItem157.Name = "spreadsheetCommandBarButtonItem157"
			' 
			' spreadsheetCommandBarButtonItem158
			' 
			Me.spreadsheetCommandBarButtonItem158.CommandName = "ViewZoom100Percent"
			Me.spreadsheetCommandBarButtonItem158.Id = 254
			Me.spreadsheetCommandBarButtonItem158.Name = "spreadsheetCommandBarButtonItem158"
			' 
			' spreadsheetCommandBarSubItem28
			' 
			Me.spreadsheetCommandBarSubItem28.CommandName = "ViewFreezePanesCommandGroup"
			Me.spreadsheetCommandBarSubItem28.Id = 255
			Me.spreadsheetCommandBarSubItem28.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem159),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem160),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem161),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem162)
			})
			Me.spreadsheetCommandBarSubItem28.Name = "spreadsheetCommandBarSubItem28"
			' 
			' spreadsheetCommandBarButtonItem159
			' 
			Me.spreadsheetCommandBarButtonItem159.CommandName = "ViewFreezePanes"
			Me.spreadsheetCommandBarButtonItem159.Id = 256
			Me.spreadsheetCommandBarButtonItem159.Name = "spreadsheetCommandBarButtonItem159"
			' 
			' spreadsheetCommandBarButtonItem160
			' 
			Me.spreadsheetCommandBarButtonItem160.CommandName = "ViewUnfreezePanes"
			Me.spreadsheetCommandBarButtonItem160.Id = 257
			Me.spreadsheetCommandBarButtonItem160.Name = "spreadsheetCommandBarButtonItem160"
			' 
			' spreadsheetCommandBarButtonItem161
			' 
			Me.spreadsheetCommandBarButtonItem161.CommandName = "ViewFreezeTopRow"
			Me.spreadsheetCommandBarButtonItem161.Id = 258
			Me.spreadsheetCommandBarButtonItem161.Name = "spreadsheetCommandBarButtonItem161"
			' 
			' spreadsheetCommandBarButtonItem162
			' 
			Me.spreadsheetCommandBarButtonItem162.CommandName = "ViewFreezeFirstColumn"
			Me.spreadsheetCommandBarButtonItem162.Id = 259
			Me.spreadsheetCommandBarButtonItem162.Name = "spreadsheetCommandBarButtonItem162"
			' 
			' spreadsheetCommandBarButtonItem163
			' 
			Me.spreadsheetCommandBarButtonItem163.CommandName = "ChartChangeType"
			Me.spreadsheetCommandBarButtonItem163.Id = 260
			Me.spreadsheetCommandBarButtonItem163.Name = "spreadsheetCommandBarButtonItem163"
			' 
			' spreadsheetCommandBarButtonItem164
			' 
			Me.spreadsheetCommandBarButtonItem164.CommandName = "ChartSwitchRowColumn"
			Me.spreadsheetCommandBarButtonItem164.Id = 261
			Me.spreadsheetCommandBarButtonItem164.Name = "spreadsheetCommandBarButtonItem164"
			' 
			' spreadsheetCommandBarButtonItem165
			' 
			Me.spreadsheetCommandBarButtonItem165.CommandName = "ChartSelectData"
			Me.spreadsheetCommandBarButtonItem165.Id = 262
			Me.spreadsheetCommandBarButtonItem165.Name = "spreadsheetCommandBarButtonItem165"
			' 
			' galleryChartLayoutItem1
			' 
			' 
			' 
			' 
			Me.galleryChartLayoutItem1.Gallery.ColumnCount = 6
			Me.galleryChartLayoutItem1.Gallery.DrawImageBackground = False
			Me.galleryChartLayoutItem1.Gallery.ImageSize = New System.Drawing.Size(36, 39)
			Me.galleryChartLayoutItem1.Gallery.RowCount = 2
			Me.galleryChartLayoutItem1.Id = 263
			Me.galleryChartLayoutItem1.Name = "galleryChartLayoutItem1"
			' 
			' galleryChartStyleItem1
			' 
			' 
			' 
			' 
			Me.galleryChartStyleItem1.Gallery.ColumnCount = 8
			Me.galleryChartStyleItem1.Gallery.DrawImageBackground = False
			Me.galleryChartStyleItem1.Gallery.ImageSize = New System.Drawing.Size(61, 47)
			Me.galleryChartStyleItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
			Me.galleryChartStyleItem1.Gallery.ItemSize = New System.Drawing.Size(70, 45)
			Me.galleryChartStyleItem1.Gallery.MinimumColumnCount = 4
			Me.galleryChartStyleItem1.Gallery.RowCount = 6
			Me.galleryChartStyleItem1.Id = 264
			Me.galleryChartStyleItem1.Name = "galleryChartStyleItem1"
			' 
			' spreadsheetCommandBarButtonItem166
			' 
			Me.spreadsheetCommandBarButtonItem166.CommandName = "MoveChart"
			Me.spreadsheetCommandBarButtonItem166.Id = 265
			Me.spreadsheetCommandBarButtonItem166.Name = "spreadsheetCommandBarButtonItem166"
			' 
			' spreadsheetCommandBarSubItem29
			' 
			Me.spreadsheetCommandBarSubItem29.CommandName = "ChartAxesCommandGroup"
			Me.spreadsheetCommandBarSubItem29.Id = 266
			Me.spreadsheetCommandBarSubItem29.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem11),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem12)
			})
			Me.spreadsheetCommandBarSubItem29.Name = "spreadsheetCommandBarSubItem29"
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem11
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem11.CommandName = "ChartPrimaryHorizontalAxisCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem11.DropDownControl = Me.commandBarGalleryDropDown13
			Me.spreadsheetCommandBarButtonGalleryDropDownItem11.Id = 267
			Me.spreadsheetCommandBarButtonGalleryDropDownItem11.Name = "spreadsheetCommandBarButtonGalleryDropDownItem11"
			' 
			' commandBarGalleryDropDown13
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown13.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown13.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup29.CommandName = "ChartPrimaryHorizontalAxisCommandGroup"
			spreadsheetCommandGalleryItem123.CommandName = "ChartHidePrimaryHorizontalAxis"
			spreadsheetCommandGalleryItem124.CommandName = "ChartPrimaryHorizontalAxisLeftToRight"
			spreadsheetCommandGalleryItem125.CommandName = "ChartPrimaryHorizontalAxisHideLabels"
			spreadsheetCommandGalleryItem126.CommandName = "ChartPrimaryHorizontalAxisRightToLeft"
			spreadsheetCommandGalleryItem127.CommandName = "ChartPrimaryHorizontalAxisDefault"
			spreadsheetCommandGalleryItem128.CommandName = "ChartPrimaryHorizontalAxisScaleThousands"
			spreadsheetCommandGalleryItem129.CommandName = "ChartPrimaryHorizontalAxisScaleMillions"
			spreadsheetCommandGalleryItem130.CommandName = "ChartPrimaryHorizontalAxisScaleBillions"
			spreadsheetCommandGalleryItem131.CommandName = "ChartPrimaryHorizontalAxisScaleLogarithm"
			spreadsheetCommandGalleryItemGroup29.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem123, spreadsheetCommandGalleryItem124, spreadsheetCommandGalleryItem125, spreadsheetCommandGalleryItem126, spreadsheetCommandGalleryItem127, spreadsheetCommandGalleryItem128, spreadsheetCommandGalleryItem129, spreadsheetCommandGalleryItem130, spreadsheetCommandGalleryItem131})
			Me.commandBarGalleryDropDown13.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup29})
			Me.commandBarGalleryDropDown13.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown13.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown13.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown13.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown13.Name = "commandBarGalleryDropDown13"
			Me.commandBarGalleryDropDown13.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem12
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem12.CommandName = "ChartPrimaryVerticalAxisCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem12.DropDownControl = Me.commandBarGalleryDropDown14
			Me.spreadsheetCommandBarButtonGalleryDropDownItem12.Id = 268
			Me.spreadsheetCommandBarButtonGalleryDropDownItem12.Name = "spreadsheetCommandBarButtonGalleryDropDownItem12"
			' 
			' commandBarGalleryDropDown14
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown14.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown14.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup30.CommandName = "ChartPrimaryVerticalAxisCommandGroup"
			spreadsheetCommandGalleryItem132.CommandName = "ChartHidePrimaryVerticalAxis"
			spreadsheetCommandGalleryItem133.CommandName = "ChartPrimaryVerticalAxisLeftToRight"
			spreadsheetCommandGalleryItem134.CommandName = "ChartPrimaryVerticalAxisHideLabels"
			spreadsheetCommandGalleryItem135.CommandName = "ChartPrimaryVerticalAxisRightToLeft"
			spreadsheetCommandGalleryItem136.CommandName = "ChartPrimaryVerticalAxisDefault"
			spreadsheetCommandGalleryItem137.CommandName = "ChartPrimaryVerticalAxisScaleThousands"
			spreadsheetCommandGalleryItem138.CommandName = "ChartPrimaryVerticalAxisScaleMillions"
			spreadsheetCommandGalleryItem139.CommandName = "ChartPrimaryVerticalAxisScaleBillions"
			spreadsheetCommandGalleryItem140.CommandName = "ChartPrimaryVerticalAxisScaleLogarithm"
			spreadsheetCommandGalleryItemGroup30.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem132, spreadsheetCommandGalleryItem133, spreadsheetCommandGalleryItem134, spreadsheetCommandGalleryItem135, spreadsheetCommandGalleryItem136, spreadsheetCommandGalleryItem137, spreadsheetCommandGalleryItem138, spreadsheetCommandGalleryItem139, spreadsheetCommandGalleryItem140})
			Me.commandBarGalleryDropDown14.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup30})
			Me.commandBarGalleryDropDown14.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown14.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown14.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown14.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown14.Name = "commandBarGalleryDropDown14"
			Me.commandBarGalleryDropDown14.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarSubItem30
			' 
			Me.spreadsheetCommandBarSubItem30.CommandName = "ChartGridlinesCommandGroup"
			Me.spreadsheetCommandBarSubItem30.Id = 269
			Me.spreadsheetCommandBarSubItem30.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem13),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem14)
			})
			Me.spreadsheetCommandBarSubItem30.Name = "spreadsheetCommandBarSubItem30"
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem13
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem13.CommandName = "ChartPrimaryHorizontalGridlinesCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem13.DropDownControl = Me.commandBarGalleryDropDown15
			Me.spreadsheetCommandBarButtonGalleryDropDownItem13.Id = 270
			Me.spreadsheetCommandBarButtonGalleryDropDownItem13.Name = "spreadsheetCommandBarButtonGalleryDropDownItem13"
			' 
			' commandBarGalleryDropDown15
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown15.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown15.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup31.CommandName = "ChartPrimaryHorizontalGridlinesCommandGroup"
			spreadsheetCommandGalleryItem141.CommandName = "ChartPrimaryHorizontalGridlinesNone"
			spreadsheetCommandGalleryItem142.CommandName = "ChartPrimaryHorizontalGridlinesMajor"
			spreadsheetCommandGalleryItem143.CommandName = "ChartPrimaryHorizontalGridlinesMinor"
			spreadsheetCommandGalleryItem144.CommandName = "ChartPrimaryHorizontalGridlinesMajorAndMinor"
			spreadsheetCommandGalleryItemGroup31.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem141, spreadsheetCommandGalleryItem142, spreadsheetCommandGalleryItem143, spreadsheetCommandGalleryItem144})
			Me.commandBarGalleryDropDown15.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup31})
			Me.commandBarGalleryDropDown15.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown15.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown15.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown15.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown15.Name = "commandBarGalleryDropDown15"
			Me.commandBarGalleryDropDown15.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem14
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem14.CommandName = "ChartPrimaryVerticalGridlinesCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem14.DropDownControl = Me.commandBarGalleryDropDown16
			Me.spreadsheetCommandBarButtonGalleryDropDownItem14.Id = 271
			Me.spreadsheetCommandBarButtonGalleryDropDownItem14.Name = "spreadsheetCommandBarButtonGalleryDropDownItem14"
			' 
			' commandBarGalleryDropDown16
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown16.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown16.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup32.CommandName = "ChartPrimaryVerticalGridlinesCommandGroup"
			spreadsheetCommandGalleryItem145.CommandName = "ChartPrimaryVerticalGridlinesNone"
			spreadsheetCommandGalleryItem146.CommandName = "ChartPrimaryVerticalGridlinesMajor"
			spreadsheetCommandGalleryItem147.CommandName = "ChartPrimaryVerticalGridlinesMinor"
			spreadsheetCommandGalleryItem148.CommandName = "ChartPrimaryVerticalGridlinesMajorAndMinor"
			spreadsheetCommandGalleryItemGroup32.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem145, spreadsheetCommandGalleryItem146, spreadsheetCommandGalleryItem147, spreadsheetCommandGalleryItem148})
			Me.commandBarGalleryDropDown16.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup32})
			Me.commandBarGalleryDropDown16.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown16.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown16.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown16.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown16.Name = "commandBarGalleryDropDown16"
			Me.commandBarGalleryDropDown16.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem15
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem15.CommandName = "ChartTitleCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem15.DropDownControl = Me.commandBarGalleryDropDown17
			Me.spreadsheetCommandBarButtonGalleryDropDownItem15.Id = 272
			Me.spreadsheetCommandBarButtonGalleryDropDownItem15.Name = "spreadsheetCommandBarButtonGalleryDropDownItem15"
			' 
			' commandBarGalleryDropDown17
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown17.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown17.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup33.CommandName = "ChartTitleCommandGroup"
			spreadsheetCommandGalleryItem149.CommandName = "ChartTitleNone"
			spreadsheetCommandGalleryItem150.CommandName = "ChartTitleCenteredOverlay"
			spreadsheetCommandGalleryItem151.CommandName = "ChartTitleAbove"
			spreadsheetCommandGalleryItemGroup33.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem149, spreadsheetCommandGalleryItem150, spreadsheetCommandGalleryItem151})
			Me.commandBarGalleryDropDown17.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup33})
			Me.commandBarGalleryDropDown17.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown17.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown17.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown17.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown17.Name = "commandBarGalleryDropDown17"
			Me.commandBarGalleryDropDown17.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarSubItem31
			' 
			Me.spreadsheetCommandBarSubItem31.CommandName = "ChartAxisTitlesCommandGroup"
			Me.spreadsheetCommandBarSubItem31.Id = 273
			Me.spreadsheetCommandBarSubItem31.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem16),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonGalleryDropDownItem17)
			})
			Me.spreadsheetCommandBarSubItem31.Name = "spreadsheetCommandBarSubItem31"
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem16
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem16.CommandName = "ChartPrimaryHorizontalAxisTitleCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem16.DropDownControl = Me.commandBarGalleryDropDown18
			Me.spreadsheetCommandBarButtonGalleryDropDownItem16.Id = 274
			Me.spreadsheetCommandBarButtonGalleryDropDownItem16.Name = "spreadsheetCommandBarButtonGalleryDropDownItem16"
			' 
			' commandBarGalleryDropDown18
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown18.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown18.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup34.CommandName = "ChartPrimaryHorizontalAxisTitleCommandGroup"
			spreadsheetCommandGalleryItem152.CommandName = "ChartPrimaryHorizontalAxisTitleNone"
			spreadsheetCommandGalleryItem153.CommandName = "ChartPrimaryHorizontalAxisTitleBelow"
			spreadsheetCommandGalleryItemGroup34.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem152, spreadsheetCommandGalleryItem153})
			Me.commandBarGalleryDropDown18.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup34})
			Me.commandBarGalleryDropDown18.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown18.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown18.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown18.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown18.Name = "commandBarGalleryDropDown18"
			Me.commandBarGalleryDropDown18.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem17
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem17.CommandName = "ChartPrimaryVerticalAxisTitleCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem17.DropDownControl = Me.commandBarGalleryDropDown19
			Me.spreadsheetCommandBarButtonGalleryDropDownItem17.Id = 275
			Me.spreadsheetCommandBarButtonGalleryDropDownItem17.Name = "spreadsheetCommandBarButtonGalleryDropDownItem17"
			' 
			' commandBarGalleryDropDown19
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown19.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown19.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup35.CommandName = "ChartPrimaryVerticalAxisTitleCommandGroup"
			spreadsheetCommandGalleryItem154.CommandName = "ChartPrimaryVerticalAxisTitleNone"
			spreadsheetCommandGalleryItem155.CommandName = "ChartPrimaryVerticalAxisTitleRotated"
			spreadsheetCommandGalleryItem156.CommandName = "ChartPrimaryVerticalAxisTitleVertical"
			spreadsheetCommandGalleryItem157.CommandName = "ChartPrimaryVerticalAxisTitleHorizontal"
			spreadsheetCommandGalleryItemGroup35.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem154, spreadsheetCommandGalleryItem155, spreadsheetCommandGalleryItem156, spreadsheetCommandGalleryItem157})
			Me.commandBarGalleryDropDown19.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup35})
			Me.commandBarGalleryDropDown19.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown19.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown19.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown19.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown19.Name = "commandBarGalleryDropDown19"
			Me.commandBarGalleryDropDown19.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem18
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem18.CommandName = "ChartLegendCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem18.DropDownControl = Me.commandBarGalleryDropDown20
			Me.spreadsheetCommandBarButtonGalleryDropDownItem18.Id = 276
			Me.spreadsheetCommandBarButtonGalleryDropDownItem18.Name = "spreadsheetCommandBarButtonGalleryDropDownItem18"
			' 
			' commandBarGalleryDropDown20
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown20.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown20.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup36.CommandName = "ChartLegendCommandGroup"
			spreadsheetCommandGalleryItem158.CommandName = "ChartLegendNone"
			spreadsheetCommandGalleryItem159.CommandName = "ChartLegendAtRight"
			spreadsheetCommandGalleryItem160.CommandName = "ChartLegendAtTop"
			spreadsheetCommandGalleryItem161.CommandName = "ChartLegendAtLeft"
			spreadsheetCommandGalleryItem162.CommandName = "ChartLegendAtBottom"
			spreadsheetCommandGalleryItem163.CommandName = "ChartLegendOverlayAtRight"
			spreadsheetCommandGalleryItem164.CommandName = "ChartLegendOverlayAtLeft"
			spreadsheetCommandGalleryItemGroup36.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem158, spreadsheetCommandGalleryItem159, spreadsheetCommandGalleryItem160, spreadsheetCommandGalleryItem161, spreadsheetCommandGalleryItem162, spreadsheetCommandGalleryItem163, spreadsheetCommandGalleryItem164})
			Me.commandBarGalleryDropDown20.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup36})
			Me.commandBarGalleryDropDown20.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown20.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown20.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown20.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown20.Name = "commandBarGalleryDropDown20"
			Me.commandBarGalleryDropDown20.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem19
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem19.CommandName = "ChartDataLabelsCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem19.DropDownControl = Me.commandBarGalleryDropDown21
			Me.spreadsheetCommandBarButtonGalleryDropDownItem19.Id = 277
			Me.spreadsheetCommandBarButtonGalleryDropDownItem19.Name = "spreadsheetCommandBarButtonGalleryDropDownItem19"
			' 
			' commandBarGalleryDropDown21
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown21.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown21.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup37.CommandName = "ChartDataLabelsCommandGroup"
			spreadsheetCommandGalleryItem165.CommandName = "ChartDataLabelsNone"
			spreadsheetCommandGalleryItem166.CommandName = "ChartDataLabelsDefault"
			spreadsheetCommandGalleryItem167.CommandName = "ChartDataLabelsCenter"
			spreadsheetCommandGalleryItem168.CommandName = "ChartDataLabelsInsideEnd"
			spreadsheetCommandGalleryItem169.CommandName = "ChartDataLabelsInsideBase"
			spreadsheetCommandGalleryItem170.CommandName = "ChartDataLabelsOutsideEnd"
			spreadsheetCommandGalleryItem171.CommandName = "ChartDataLabelsBestFit"
			spreadsheetCommandGalleryItem172.CommandName = "ChartDataLabelsLeft"
			spreadsheetCommandGalleryItem173.CommandName = "ChartDataLabelsRight"
			spreadsheetCommandGalleryItem174.CommandName = "ChartDataLabelsAbove"
			spreadsheetCommandGalleryItem175.CommandName = "ChartDataLabelsBelow"
			spreadsheetCommandGalleryItemGroup37.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem165, spreadsheetCommandGalleryItem166, spreadsheetCommandGalleryItem167, spreadsheetCommandGalleryItem168, spreadsheetCommandGalleryItem169, spreadsheetCommandGalleryItem170, spreadsheetCommandGalleryItem171, spreadsheetCommandGalleryItem172, spreadsheetCommandGalleryItem173, spreadsheetCommandGalleryItem174, spreadsheetCommandGalleryItem175})
			Me.commandBarGalleryDropDown21.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup37})
			Me.commandBarGalleryDropDown21.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown21.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown21.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown21.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown21.Name = "commandBarGalleryDropDown21"
			Me.commandBarGalleryDropDown21.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem20
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem20.CommandName = "ChartLinesCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem20.DropDownControl = Me.commandBarGalleryDropDown22
			Me.spreadsheetCommandBarButtonGalleryDropDownItem20.Id = 278
			Me.spreadsheetCommandBarButtonGalleryDropDownItem20.Name = "spreadsheetCommandBarButtonGalleryDropDownItem20"
			' 
			' commandBarGalleryDropDown22
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown22.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown22.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup38.CommandName = "ChartLinesCommandGroup"
			spreadsheetCommandGalleryItem176.CommandName = "ChartLinesNone"
			spreadsheetCommandGalleryItem177.CommandName = "ChartShowDropLines"
			spreadsheetCommandGalleryItem178.CommandName = "ChartShowHighLowLines"
			spreadsheetCommandGalleryItem179.CommandName = "ChartShowDropLinesAndHighLowLines"
			spreadsheetCommandGalleryItem180.CommandName = "ChartShowSeriesLines"
			spreadsheetCommandGalleryItemGroup38.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem176, spreadsheetCommandGalleryItem177, spreadsheetCommandGalleryItem178, spreadsheetCommandGalleryItem179, spreadsheetCommandGalleryItem180})
			Me.commandBarGalleryDropDown22.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup38})
			Me.commandBarGalleryDropDown22.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown22.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown22.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown22.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown22.Name = "commandBarGalleryDropDown22"
			Me.commandBarGalleryDropDown22.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem21
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem21.CommandName = "ChartUpDownBarsCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem21.DropDownControl = Me.commandBarGalleryDropDown23
			Me.spreadsheetCommandBarButtonGalleryDropDownItem21.Id = 279
			Me.spreadsheetCommandBarButtonGalleryDropDownItem21.Name = "spreadsheetCommandBarButtonGalleryDropDownItem21"
			' 
			' commandBarGalleryDropDown23
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown23.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown23.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup39.CommandName = "ChartUpDownBarsCommandGroup"
			spreadsheetCommandGalleryItem181.CommandName = "ChartHideUpDownBars"
			spreadsheetCommandGalleryItem182.CommandName = "ChartShowUpDownBars"
			spreadsheetCommandGalleryItemGroup39.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem181, spreadsheetCommandGalleryItem182})
			Me.commandBarGalleryDropDown23.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup39})
			Me.commandBarGalleryDropDown23.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown23.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown23.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown23.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown23.Name = "commandBarGalleryDropDown23"
			Me.commandBarGalleryDropDown23.Ribbon = Me.ribbonControl1
			' 
			' spreadsheetCommandBarButtonGalleryDropDownItem22
			' 
			Me.spreadsheetCommandBarButtonGalleryDropDownItem22.CommandName = "ChartErrorBarsCommandGroup"
			Me.spreadsheetCommandBarButtonGalleryDropDownItem22.DropDownControl = Me.commandBarGalleryDropDown24
			Me.spreadsheetCommandBarButtonGalleryDropDownItem22.Id = 280
			Me.spreadsheetCommandBarButtonGalleryDropDownItem22.Name = "spreadsheetCommandBarButtonGalleryDropDownItem22"
			' 
			' commandBarGalleryDropDown24
			' 
			' 
			' 
			' 
			Me.commandBarGalleryDropDown24.Gallery.AllowFilter = False
			Me.commandBarGalleryDropDown24.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
			spreadsheetCommandGalleryItemGroup40.CommandName = "ChartErrorBarsCommandGroup"
			spreadsheetCommandGalleryItem183.CommandName = "ChartErrorBarsNone"
			spreadsheetCommandGalleryItem184.CommandName = "ChartErrorBarsStandardError"
			spreadsheetCommandGalleryItem185.CommandName = "ChartErrorBarsPercentage"
			spreadsheetCommandGalleryItem186.CommandName = "ChartErrorBarsStandardDeviation"
			spreadsheetCommandGalleryItemGroup40.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() { spreadsheetCommandGalleryItem183, spreadsheetCommandGalleryItem184, spreadsheetCommandGalleryItem185, spreadsheetCommandGalleryItem186})
			Me.commandBarGalleryDropDown24.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { spreadsheetCommandGalleryItemGroup40})
			Me.commandBarGalleryDropDown24.Gallery.ImageSize = New System.Drawing.Size(32, 32)
			Me.commandBarGalleryDropDown24.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
			Me.commandBarGalleryDropDown24.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
			Me.commandBarGalleryDropDown24.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.commandBarGalleryDropDown24.Name = "commandBarGalleryDropDown24"
			Me.commandBarGalleryDropDown24.Ribbon = Me.ribbonControl1
			' 
			' renameTableItemCaption1
			' 
			Me.renameTableItemCaption1.Id = 281
			Me.renameTableItemCaption1.Name = "renameTableItemCaption1"
			' 
			' renameTableItem1
			' 
			Me.renameTableItem1.Edit = Me.repositoryItemTextEdit1
			Me.renameTableItem1.Id = 282
			Me.renameTableItem1.Name = "renameTableItem1"
			' 
			' repositoryItemTextEdit1
			' 
			Me.repositoryItemTextEdit1.AutoHeight = False
			Me.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1"
			' 
			' spreadsheetCommandBarCheckItem27
			' 
			Me.spreadsheetCommandBarCheckItem27.CommandName = "TableToolsConvertToRange"
			Me.spreadsheetCommandBarCheckItem27.Id = 283
			Me.spreadsheetCommandBarCheckItem27.Name = "spreadsheetCommandBarCheckItem27"
			Me.spreadsheetCommandBarCheckItem27.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarCheckItem28
			' 
			Me.spreadsheetCommandBarCheckItem28.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem28.CommandName = "TableToolsToggleHeaderRow"
			Me.spreadsheetCommandBarCheckItem28.Id = 284
			Me.spreadsheetCommandBarCheckItem28.Name = "spreadsheetCommandBarCheckItem28"
			' 
			' spreadsheetCommandBarCheckItem29
			' 
			Me.spreadsheetCommandBarCheckItem29.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem29.CommandName = "TableToolsToggleTotalRow"
			Me.spreadsheetCommandBarCheckItem29.Id = 285
			Me.spreadsheetCommandBarCheckItem29.Name = "spreadsheetCommandBarCheckItem29"
			' 
			' spreadsheetCommandBarCheckItem30
			' 
			Me.spreadsheetCommandBarCheckItem30.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem30.CommandName = "TableToolsToggleBandedColumns"
			Me.spreadsheetCommandBarCheckItem30.Id = 286
			Me.spreadsheetCommandBarCheckItem30.Name = "spreadsheetCommandBarCheckItem30"
			' 
			' spreadsheetCommandBarCheckItem31
			' 
			Me.spreadsheetCommandBarCheckItem31.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem31.CommandName = "TableToolsToggleFirstColumn"
			Me.spreadsheetCommandBarCheckItem31.Id = 287
			Me.spreadsheetCommandBarCheckItem31.Name = "spreadsheetCommandBarCheckItem31"
			' 
			' spreadsheetCommandBarCheckItem32
			' 
			Me.spreadsheetCommandBarCheckItem32.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem32.CommandName = "TableToolsToggleLastColumn"
			Me.spreadsheetCommandBarCheckItem32.Id = 288
			Me.spreadsheetCommandBarCheckItem32.Name = "spreadsheetCommandBarCheckItem32"
			' 
			' spreadsheetCommandBarCheckItem33
			' 
			Me.spreadsheetCommandBarCheckItem33.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem33.CommandName = "TableToolsToggleBandedRows"
			Me.spreadsheetCommandBarCheckItem33.Id = 289
			Me.spreadsheetCommandBarCheckItem33.Name = "spreadsheetCommandBarCheckItem33"
			' 
			' galleryTableStylesItem1
			' 
			' 
			' 
			' 
			Me.galleryTableStylesItem1.Gallery.ColumnCount = 7
			Me.galleryTableStylesItem1.Gallery.DrawImageBackground = False
			Me.galleryTableStylesItem1.Gallery.ImageSize = New System.Drawing.Size(61, 47)
			Me.galleryTableStylesItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
			Me.galleryTableStylesItem1.Gallery.ItemSize = New System.Drawing.Size(55, 47)
			Me.galleryTableStylesItem1.Gallery.RowCount = 10
			Me.galleryTableStylesItem1.Id = 290
			Me.galleryTableStylesItem1.Name = "galleryTableStylesItem1"
			' 
			' spreadsheetCommandBarButtonItem167
			' 
			Me.spreadsheetCommandBarButtonItem167.CommandName = "OptionsPivotTable"
			Me.spreadsheetCommandBarButtonItem167.Id = 291
			Me.spreadsheetCommandBarButtonItem167.Name = "spreadsheetCommandBarButtonItem167"
			' 
			' spreadsheetCommandBarButtonItem168
			' 
			Me.spreadsheetCommandBarButtonItem168.CommandName = "SelectFieldTypePivotTable"
			Me.spreadsheetCommandBarButtonItem168.Id = 292
			Me.spreadsheetCommandBarButtonItem168.Name = "spreadsheetCommandBarButtonItem168"
			' 
			' spreadsheetCommandBarButtonItem169
			' 
			Me.spreadsheetCommandBarButtonItem169.CommandName = "PivotTableExpandField"
			Me.spreadsheetCommandBarButtonItem169.Id = 293
			Me.spreadsheetCommandBarButtonItem169.Name = "spreadsheetCommandBarButtonItem169"
			Me.spreadsheetCommandBarButtonItem169.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem170
			' 
			Me.spreadsheetCommandBarButtonItem170.CommandName = "PivotTableCollapseField"
			Me.spreadsheetCommandBarButtonItem170.Id = 294
			Me.spreadsheetCommandBarButtonItem170.Name = "spreadsheetCommandBarButtonItem170"
			Me.spreadsheetCommandBarButtonItem170.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem171
			' 
			Me.spreadsheetCommandBarButtonItem171.CommandName = "PivotTableGroupSelection"
			Me.spreadsheetCommandBarButtonItem171.Id = 295
			Me.spreadsheetCommandBarButtonItem171.Name = "spreadsheetCommandBarButtonItem171"
			Me.spreadsheetCommandBarButtonItem171.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem172
			' 
			Me.spreadsheetCommandBarButtonItem172.CommandName = "PivotTableUngroup"
			Me.spreadsheetCommandBarButtonItem172.Id = 296
			Me.spreadsheetCommandBarButtonItem172.Name = "spreadsheetCommandBarButtonItem172"
			Me.spreadsheetCommandBarButtonItem172.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarButtonItem173
			' 
			Me.spreadsheetCommandBarButtonItem173.CommandName = "PivotTableGroupField"
			Me.spreadsheetCommandBarButtonItem173.Id = 297
			Me.spreadsheetCommandBarButtonItem173.Name = "spreadsheetCommandBarButtonItem173"
			Me.spreadsheetCommandBarButtonItem173.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' spreadsheetCommandBarSubItem32
			' 
			Me.spreadsheetCommandBarSubItem32.CommandName = "PivotTableDataRefreshGroup"
			Me.spreadsheetCommandBarSubItem32.Id = 298
			Me.spreadsheetCommandBarSubItem32.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem174),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem175)
			})
			Me.spreadsheetCommandBarSubItem32.Name = "spreadsheetCommandBarSubItem32"
			' 
			' spreadsheetCommandBarButtonItem174
			' 
			Me.spreadsheetCommandBarButtonItem174.CommandName = "RefreshPivotTable"
			Me.spreadsheetCommandBarButtonItem174.Id = 299
			Me.spreadsheetCommandBarButtonItem174.Name = "spreadsheetCommandBarButtonItem174"
			' 
			' spreadsheetCommandBarButtonItem175
			' 
			Me.spreadsheetCommandBarButtonItem175.CommandName = "RefreshAllPivotTable"
			Me.spreadsheetCommandBarButtonItem175.Id = 300
			Me.spreadsheetCommandBarButtonItem175.Name = "spreadsheetCommandBarButtonItem175"
			' 
			' spreadsheetCommandBarButtonItem176
			' 
			Me.spreadsheetCommandBarButtonItem176.CommandName = "ChangeDataSourcePivotTable"
			Me.spreadsheetCommandBarButtonItem176.Id = 301
			Me.spreadsheetCommandBarButtonItem176.Name = "spreadsheetCommandBarButtonItem176"
			' 
			' spreadsheetCommandBarSubItem33
			' 
			Me.spreadsheetCommandBarSubItem33.CommandName = "PivotTableActionsClearGroup"
			Me.spreadsheetCommandBarSubItem33.Id = 302
			Me.spreadsheetCommandBarSubItem33.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem177),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem178)
			})
			Me.spreadsheetCommandBarSubItem33.Name = "spreadsheetCommandBarSubItem33"
			' 
			' spreadsheetCommandBarButtonItem177
			' 
			Me.spreadsheetCommandBarButtonItem177.CommandName = "ClearAllPivotTable"
			Me.spreadsheetCommandBarButtonItem177.Id = 303
			Me.spreadsheetCommandBarButtonItem177.Name = "spreadsheetCommandBarButtonItem177"
			' 
			' spreadsheetCommandBarButtonItem178
			' 
			Me.spreadsheetCommandBarButtonItem178.CommandName = "ClearFiltersPivotTable"
			Me.spreadsheetCommandBarButtonItem178.Id = 304
			Me.spreadsheetCommandBarButtonItem178.Name = "spreadsheetCommandBarButtonItem178"
			' 
			' spreadsheetCommandBarSubItem34
			' 
			Me.spreadsheetCommandBarSubItem34.CommandName = "PivotTableActionsSelectGroup"
			Me.spreadsheetCommandBarSubItem34.Id = 305
			Me.spreadsheetCommandBarSubItem34.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem179),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem180),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem181)
			})
			Me.spreadsheetCommandBarSubItem34.Name = "spreadsheetCommandBarSubItem34"
			' 
			' spreadsheetCommandBarButtonItem179
			' 
			Me.spreadsheetCommandBarButtonItem179.CommandName = "SelectValuesPivotTable"
			Me.spreadsheetCommandBarButtonItem179.Id = 306
			Me.spreadsheetCommandBarButtonItem179.Name = "spreadsheetCommandBarButtonItem179"
			' 
			' spreadsheetCommandBarButtonItem180
			' 
			Me.spreadsheetCommandBarButtonItem180.CommandName = "SelectLabelsPivotTable"
			Me.spreadsheetCommandBarButtonItem180.Id = 307
			Me.spreadsheetCommandBarButtonItem180.Name = "spreadsheetCommandBarButtonItem180"
			' 
			' spreadsheetCommandBarButtonItem181
			' 
			Me.spreadsheetCommandBarButtonItem181.CommandName = "SelectEntirePivotTable"
			Me.spreadsheetCommandBarButtonItem181.Id = 308
			Me.spreadsheetCommandBarButtonItem181.Name = "spreadsheetCommandBarButtonItem181"
			' 
			' spreadsheetCommandBarButtonItem182
			' 
			Me.spreadsheetCommandBarButtonItem182.CommandName = "MovePivotTable"
			Me.spreadsheetCommandBarButtonItem182.Id = 309
			Me.spreadsheetCommandBarButtonItem182.Name = "spreadsheetCommandBarButtonItem182"
			' 
			' spreadsheetCommandBarSubItem35
			' 
			Me.spreadsheetCommandBarSubItem35.CommandName = "PivotTableCalculationFieldsItemsSetsGroup"
			Me.spreadsheetCommandBarSubItem35.Id = 310
			Me.spreadsheetCommandBarSubItem35.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem183),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem184),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem185),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem186)
			})
			Me.spreadsheetCommandBarSubItem35.Name = "spreadsheetCommandBarSubItem35"
			' 
			' spreadsheetCommandBarButtonItem183
			' 
			Me.spreadsheetCommandBarButtonItem183.CommandName = "PivotTableCalculatedField"
			Me.spreadsheetCommandBarButtonItem183.Id = 311
			Me.spreadsheetCommandBarButtonItem183.Name = "spreadsheetCommandBarButtonItem183"
			' 
			' spreadsheetCommandBarButtonItem184
			' 
			Me.spreadsheetCommandBarButtonItem184.CommandName = "PivotTableCalculatedItem"
			Me.spreadsheetCommandBarButtonItem184.Id = 312
			Me.spreadsheetCommandBarButtonItem184.Name = "spreadsheetCommandBarButtonItem184"
			' 
			' spreadsheetCommandBarButtonItem185
			' 
			Me.spreadsheetCommandBarButtonItem185.CommandName = "PivotTableCalculatedItemSolveOrder"
			Me.spreadsheetCommandBarButtonItem185.Id = 313
			Me.spreadsheetCommandBarButtonItem185.Name = "spreadsheetCommandBarButtonItem185"
			' 
			' spreadsheetCommandBarButtonItem186
			' 
			Me.spreadsheetCommandBarButtonItem186.CommandName = "PivotTableListFormulas"
			Me.spreadsheetCommandBarButtonItem186.Id = 314
			Me.spreadsheetCommandBarButtonItem186.Name = "spreadsheetCommandBarButtonItem186"
			' 
			' spreadsheetCommandBarCheckItem34
			' 
			Me.spreadsheetCommandBarCheckItem34.CommandName = "FieldListPanelPivotTable"
			Me.spreadsheetCommandBarCheckItem34.Id = 315
			Me.spreadsheetCommandBarCheckItem34.Name = "spreadsheetCommandBarCheckItem34"
			' 
			' spreadsheetCommandBarCheckItem35
			' 
			Me.spreadsheetCommandBarCheckItem35.CommandName = "ShowPivotTableExpandCollapseButtons"
			Me.spreadsheetCommandBarCheckItem35.Id = 316
			Me.spreadsheetCommandBarCheckItem35.Name = "spreadsheetCommandBarCheckItem35"
			' 
			' spreadsheetCommandBarCheckItem36
			' 
			Me.spreadsheetCommandBarCheckItem36.CommandName = "ShowPivotTableFieldHeaders"
			Me.spreadsheetCommandBarCheckItem36.Id = 317
			Me.spreadsheetCommandBarCheckItem36.Name = "spreadsheetCommandBarCheckItem36"
			' 
			' spreadsheetCommandBarSubItem36
			' 
			Me.spreadsheetCommandBarSubItem36.CommandName = "PivotTableLayoutSubtotalsGroup"
			Me.spreadsheetCommandBarSubItem36.Id = 318
			Me.spreadsheetCommandBarSubItem36.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem187),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem188),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem189)
			})
			Me.spreadsheetCommandBarSubItem36.Name = "spreadsheetCommandBarSubItem36"
			' 
			' spreadsheetCommandBarButtonItem187
			' 
			Me.spreadsheetCommandBarButtonItem187.CommandName = "PivotTableDoNotShowSubtotals"
			Me.spreadsheetCommandBarButtonItem187.Id = 319
			Me.spreadsheetCommandBarButtonItem187.Name = "spreadsheetCommandBarButtonItem187"
			Me.spreadsheetCommandBarButtonItem187.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem188
			' 
			Me.spreadsheetCommandBarButtonItem188.CommandName = "PivotTableShowAllSubtotalsAtBottom"
			Me.spreadsheetCommandBarButtonItem188.Id = 320
			Me.spreadsheetCommandBarButtonItem188.Name = "spreadsheetCommandBarButtonItem188"
			Me.spreadsheetCommandBarButtonItem188.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem189
			' 
			Me.spreadsheetCommandBarButtonItem189.CommandName = "PivotTableShowAllSubtotalsAtTop"
			Me.spreadsheetCommandBarButtonItem189.Id = 321
			Me.spreadsheetCommandBarButtonItem189.Name = "spreadsheetCommandBarButtonItem189"
			Me.spreadsheetCommandBarButtonItem189.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarSubItem37
			' 
			Me.spreadsheetCommandBarSubItem37.CommandName = "PivotTableLayoutGrandTotalsGroup"
			Me.spreadsheetCommandBarSubItem37.Id = 322
			Me.spreadsheetCommandBarSubItem37.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem190),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem191),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem192),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem193)
			})
			Me.spreadsheetCommandBarSubItem37.Name = "spreadsheetCommandBarSubItem37"
			' 
			' spreadsheetCommandBarButtonItem190
			' 
			Me.spreadsheetCommandBarButtonItem190.CommandName = "PivotTableGrandTotalsOffRowsColumns"
			Me.spreadsheetCommandBarButtonItem190.Id = 323
			Me.spreadsheetCommandBarButtonItem190.Name = "spreadsheetCommandBarButtonItem190"
			Me.spreadsheetCommandBarButtonItem190.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem191
			' 
			Me.spreadsheetCommandBarButtonItem191.CommandName = "PivotTableGrandTotalsOnRowsColumns"
			Me.spreadsheetCommandBarButtonItem191.Id = 324
			Me.spreadsheetCommandBarButtonItem191.Name = "spreadsheetCommandBarButtonItem191"
			Me.spreadsheetCommandBarButtonItem191.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem192
			' 
			Me.spreadsheetCommandBarButtonItem192.CommandName = "PivotTableGrandTotalsOnRowsOnly"
			Me.spreadsheetCommandBarButtonItem192.Id = 325
			Me.spreadsheetCommandBarButtonItem192.Name = "spreadsheetCommandBarButtonItem192"
			Me.spreadsheetCommandBarButtonItem192.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem193
			' 
			Me.spreadsheetCommandBarButtonItem193.CommandName = "PivotTableGrandTotalsOnColumnsOnly"
			Me.spreadsheetCommandBarButtonItem193.Id = 326
			Me.spreadsheetCommandBarButtonItem193.Name = "spreadsheetCommandBarButtonItem193"
			Me.spreadsheetCommandBarButtonItem193.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarSubItem38
			' 
			Me.spreadsheetCommandBarSubItem38.CommandName = "PivotTableLayoutReportLayoutGroup"
			Me.spreadsheetCommandBarSubItem38.Id = 327
			Me.spreadsheetCommandBarSubItem38.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem194),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem195),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem196),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem197),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem198)
			})
			Me.spreadsheetCommandBarSubItem38.Name = "spreadsheetCommandBarSubItem38"
			' 
			' spreadsheetCommandBarButtonItem194
			' 
			Me.spreadsheetCommandBarButtonItem194.CommandName = "PivotTableShowCompactForm"
			Me.spreadsheetCommandBarButtonItem194.Id = 328
			Me.spreadsheetCommandBarButtonItem194.Name = "spreadsheetCommandBarButtonItem194"
			Me.spreadsheetCommandBarButtonItem194.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem195
			' 
			Me.spreadsheetCommandBarButtonItem195.CommandName = "PivotTableShowOutlineForm"
			Me.spreadsheetCommandBarButtonItem195.Id = 329
			Me.spreadsheetCommandBarButtonItem195.Name = "spreadsheetCommandBarButtonItem195"
			Me.spreadsheetCommandBarButtonItem195.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem196
			' 
			Me.spreadsheetCommandBarButtonItem196.CommandName = "PivotTableShowTabularForm"
			Me.spreadsheetCommandBarButtonItem196.Id = 330
			Me.spreadsheetCommandBarButtonItem196.Name = "spreadsheetCommandBarButtonItem196"
			Me.spreadsheetCommandBarButtonItem196.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem197
			' 
			Me.spreadsheetCommandBarButtonItem197.CommandName = "PivotTableRepeatAllItemLabels"
			Me.spreadsheetCommandBarButtonItem197.Id = 331
			Me.spreadsheetCommandBarButtonItem197.Name = "spreadsheetCommandBarButtonItem197"
			Me.spreadsheetCommandBarButtonItem197.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem198
			' 
			Me.spreadsheetCommandBarButtonItem198.CommandName = "PivotTableDoNotRepeatItemLabels"
			Me.spreadsheetCommandBarButtonItem198.Id = 332
			Me.spreadsheetCommandBarButtonItem198.Name = "spreadsheetCommandBarButtonItem198"
			Me.spreadsheetCommandBarButtonItem198.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarSubItem39
			' 
			Me.spreadsheetCommandBarSubItem39.CommandName = "PivotTableLayoutBlankRowsGroup"
			Me.spreadsheetCommandBarSubItem39.Id = 333
			Me.spreadsheetCommandBarSubItem39.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem199),
				New DevExpress.XtraBars.LinkPersistInfo(Me.spreadsheetCommandBarButtonItem200)
			})
			Me.spreadsheetCommandBarSubItem39.Name = "spreadsheetCommandBarSubItem39"
			' 
			' spreadsheetCommandBarButtonItem199
			' 
			Me.spreadsheetCommandBarButtonItem199.CommandName = "PivotTableInsertBlankLineEachItem"
			Me.spreadsheetCommandBarButtonItem199.Id = 334
			Me.spreadsheetCommandBarButtonItem199.Name = "spreadsheetCommandBarButtonItem199"
			Me.spreadsheetCommandBarButtonItem199.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarButtonItem200
			' 
			Me.spreadsheetCommandBarButtonItem200.CommandName = "PivotTableRemoveBlankLineEachItem"
			Me.spreadsheetCommandBarButtonItem200.Id = 335
			Me.spreadsheetCommandBarButtonItem200.Name = "spreadsheetCommandBarButtonItem200"
			Me.spreadsheetCommandBarButtonItem200.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' spreadsheetCommandBarCheckItem37
			' 
			Me.spreadsheetCommandBarCheckItem37.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem37.CommandName = "PivotTableToggleRowHeaders"
			Me.spreadsheetCommandBarCheckItem37.Id = 336
			Me.spreadsheetCommandBarCheckItem37.Name = "spreadsheetCommandBarCheckItem37"
			' 
			' spreadsheetCommandBarCheckItem38
			' 
			Me.spreadsheetCommandBarCheckItem38.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem38.CommandName = "PivotTableToggleColumnHeaders"
			Me.spreadsheetCommandBarCheckItem38.Id = 337
			Me.spreadsheetCommandBarCheckItem38.Name = "spreadsheetCommandBarCheckItem38"
			' 
			' spreadsheetCommandBarCheckItem39
			' 
			Me.spreadsheetCommandBarCheckItem39.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem39.CommandName = "PivotTableToggleBandedRows"
			Me.spreadsheetCommandBarCheckItem39.Id = 338
			Me.spreadsheetCommandBarCheckItem39.Name = "spreadsheetCommandBarCheckItem39"
			' 
			' spreadsheetCommandBarCheckItem40
			' 
			Me.spreadsheetCommandBarCheckItem40.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.spreadsheetCommandBarCheckItem40.CommandName = "PivotTableToggleBandedColumns"
			Me.spreadsheetCommandBarCheckItem40.Id = 339
			Me.spreadsheetCommandBarCheckItem40.Name = "spreadsheetCommandBarCheckItem40"
			' 
			' galleryPivotStylesItem1
			' 
			' 
			' 
			' 
			Me.galleryPivotStylesItem1.Gallery.ColumnCount = 7
			Me.galleryPivotStylesItem1.Gallery.DrawImageBackground = False
			Me.galleryPivotStylesItem1.Gallery.ImageSize = New System.Drawing.Size(61, 47)
			Me.galleryPivotStylesItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
			Me.galleryPivotStylesItem1.Gallery.ItemSize = New System.Drawing.Size(55, 50)
			Me.galleryPivotStylesItem1.Gallery.RowCount = 10
			Me.galleryPivotStylesItem1.Id = 340
			Me.galleryPivotStylesItem1.Name = "galleryPivotStylesItem1"
			' 
			' endModeInfoStaticItem1
			' 
			Me.endModeInfoStaticItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
			Me.endModeInfoStaticItem1.Id = 341
			Me.endModeInfoStaticItem1.Name = "endModeInfoStaticItem1"
			' 
			' averageInfoStaticItem1
			' 
			Me.averageInfoStaticItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
			Me.averageInfoStaticItem1.Id = 342
			Me.averageInfoStaticItem1.Name = "averageInfoStaticItem1"
			toolTipItem1.Text = "Average of selected cells"
			superToolTip1.Items.Add(toolTipItem1)
			Me.averageInfoStaticItem1.SuperTip = superToolTip1
			Me.averageInfoStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
			' 
			' countInfoStaticItem1
			' 
			Me.countInfoStaticItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
			Me.countInfoStaticItem1.Id = 343
			Me.countInfoStaticItem1.Name = "countInfoStaticItem1"
			toolTipItem2.Text = "Number of selected cells that contain data"
			superToolTip2.Items.Add(toolTipItem2)
			Me.countInfoStaticItem1.SuperTip = superToolTip2
			Me.countInfoStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
			' 
			' numericalCountInfoStaticItem1
			' 
			Me.numericalCountInfoStaticItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
			Me.numericalCountInfoStaticItem1.Id = 344
			Me.numericalCountInfoStaticItem1.Name = "numericalCountInfoStaticItem1"
			toolTipItem3.Text = "Number of selected cells that contain numerical data"
			superToolTip3.Items.Add(toolTipItem3)
			Me.numericalCountInfoStaticItem1.SuperTip = superToolTip3
			Me.numericalCountInfoStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
			' 
			' minInfoStaticItem1
			' 
			Me.minInfoStaticItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
			Me.minInfoStaticItem1.Id = 345
			Me.minInfoStaticItem1.Name = "minInfoStaticItem1"
			toolTipItem4.Text = "Minimum value in selection"
			superToolTip4.Items.Add(toolTipItem4)
			Me.minInfoStaticItem1.SuperTip = superToolTip4
			Me.minInfoStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
			' 
			' maxInfoStaticItem1
			' 
			Me.maxInfoStaticItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
			Me.maxInfoStaticItem1.Id = 346
			Me.maxInfoStaticItem1.Name = "maxInfoStaticItem1"
			toolTipItem5.Text = "Maximum value in selection"
			superToolTip5.Items.Add(toolTipItem5)
			Me.maxInfoStaticItem1.SuperTip = superToolTip5
			Me.maxInfoStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
			' 
			' sumInfoStaticItem1
			' 
			Me.sumInfoStaticItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
			Me.sumInfoStaticItem1.Id = 347
			Me.sumInfoStaticItem1.Name = "sumInfoStaticItem1"
			toolTipItem6.Text = "Sum of selected cells"
			superToolTip6.Items.Add(toolTipItem6)
			Me.sumInfoStaticItem1.SuperTip = superToolTip6
			Me.sumInfoStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
			' 
			' zoomEditItem1
			' 
			Me.zoomEditItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
			Me.zoomEditItem1.Edit = Me.repositoryItemZoomTrackBar1
			Me.zoomEditItem1.Id = 348
			Me.zoomEditItem1.Name = "zoomEditItem1"
			toolTipItem7.Text = "Zoom"
			superToolTip7.Items.Add(toolTipItem7)
			Me.zoomEditItem1.SuperTip = superToolTip7
			' 
			' repositoryItemZoomTrackBar1
			' 
			Me.repositoryItemZoomTrackBar1.AllowUseMiddleValue = True
			Me.repositoryItemZoomTrackBar1.LargeChange = 10
			Me.repositoryItemZoomTrackBar1.Maximum = 400
			Me.repositoryItemZoomTrackBar1.Middle = 100
			Me.repositoryItemZoomTrackBar1.Minimum = 10
			Me.repositoryItemZoomTrackBar1.Name = "repositoryItemZoomTrackBar1"
			Me.repositoryItemZoomTrackBar1.SmallChange = 10
			Me.repositoryItemZoomTrackBar1.SnapToMiddle = 5
			' 
			' showZoomButtonItem1
			' 
			Me.showZoomButtonItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
			Me.showZoomButtonItem1.Id = 349
			Me.showZoomButtonItem1.ItemAppearance.Disabled.Options.UseTextOptions = True
			Me.showZoomButtonItem1.ItemAppearance.Hovered.Options.UseTextOptions = True
			Me.showZoomButtonItem1.ItemAppearance.Normal.Options.UseTextOptions = True
			Me.showZoomButtonItem1.ItemAppearance.Pressed.Options.UseTextOptions = True
			Me.showZoomButtonItem1.Name = "showZoomButtonItem1"
			Me.showZoomButtonItem1.SmallWithTextWidth = 45
			toolTipItem8.Text = "Zoom level. Click to open the Zoom dialog box."
			superToolTip8.Items.Add(toolTipItem8)
			Me.showZoomButtonItem1.SuperTip = superToolTip8
			' 
			' chartToolsRibbonPageCategory1
			' 
			Me.chartToolsRibbonPageCategory1.Control = Me.spreadsheetControl1
			Me.chartToolsRibbonPageCategory1.Name = "chartToolsRibbonPageCategory1"
			Me.chartToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() { Me.chartsDesignRibbonPage1, Me.chartsLayoutRibbonPage1, Me.chartsFormatRibbonPage1})
			Me.chartToolsRibbonPageCategory1.Visible = False
			' 
			' chartsDesignRibbonPage1
			' 
			Me.chartsDesignRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.chartsDesignTypeRibbonPageGroup1, Me.chartsDesignDataRibbonPageGroup1, Me.chartsDesignLayoutsRibbonPageGroup1, Me.chartsDesignStylesRibbonPageGroup1, Me.chartsDesignLocationRibbonPageGroup1})
			Me.chartsDesignRibbonPage1.Name = "chartsDesignRibbonPage1"
			Me.chartsDesignRibbonPage1.Visible = False
			' 
			' chartsDesignTypeRibbonPageGroup1
			' 
			Me.chartsDesignTypeRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsDesignTypeRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem163)
			Me.chartsDesignTypeRibbonPageGroup1.Name = "chartsDesignTypeRibbonPageGroup1"
			' 
			' chartsDesignDataRibbonPageGroup1
			' 
			Me.chartsDesignDataRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsDesignDataRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem164)
			Me.chartsDesignDataRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem165)
			Me.chartsDesignDataRibbonPageGroup1.Name = "chartsDesignDataRibbonPageGroup1"
			' 
			' chartsDesignLayoutsRibbonPageGroup1
			' 
			Me.chartsDesignLayoutsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsDesignLayoutsRibbonPageGroup1.ItemLinks.Add(Me.galleryChartLayoutItem1)
			Me.chartsDesignLayoutsRibbonPageGroup1.Name = "chartsDesignLayoutsRibbonPageGroup1"
			' 
			' chartsDesignStylesRibbonPageGroup1
			' 
			Me.chartsDesignStylesRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsDesignStylesRibbonPageGroup1.ItemLinks.Add(Me.galleryChartStyleItem1)
			Me.chartsDesignStylesRibbonPageGroup1.Name = "chartsDesignStylesRibbonPageGroup1"
			' 
			' chartsDesignLocationRibbonPageGroup1
			' 
			Me.chartsDesignLocationRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsDesignLocationRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem166)
			Me.chartsDesignLocationRibbonPageGroup1.Name = "chartsDesignLocationRibbonPageGroup1"
			' 
			' chartsLayoutRibbonPage1
			' 
			Me.chartsLayoutRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.chartsLayoutAxesRibbonPageGroup1, Me.chartsLayoutLabelsRibbonPageGroup1, Me.chartsLayoutAnalysisRibbonPageGroup1})
			Me.chartsLayoutRibbonPage1.Name = "chartsLayoutRibbonPage1"
			Me.chartsLayoutRibbonPage1.Visible = False
			' 
			' chartsLayoutAxesRibbonPageGroup1
			' 
			Me.chartsLayoutAxesRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsLayoutAxesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem29)
			Me.chartsLayoutAxesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem30)
			Me.chartsLayoutAxesRibbonPageGroup1.Name = "chartsLayoutAxesRibbonPageGroup1"
			' 
			' chartsLayoutLabelsRibbonPageGroup1
			' 
			Me.chartsLayoutLabelsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem15)
			Me.chartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem31)
			Me.chartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem18)
			Me.chartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem19)
			Me.chartsLayoutLabelsRibbonPageGroup1.Name = "chartsLayoutLabelsRibbonPageGroup1"
			' 
			' chartsLayoutAnalysisRibbonPageGroup1
			' 
			Me.chartsLayoutAnalysisRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsLayoutAnalysisRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem20)
			Me.chartsLayoutAnalysisRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem21)
			Me.chartsLayoutAnalysisRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem22)
			Me.chartsLayoutAnalysisRibbonPageGroup1.Name = "chartsLayoutAnalysisRibbonPageGroup1"
			' 
			' chartsFormatRibbonPage1
			' 
			Me.chartsFormatRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.chartsFormatArrangeRibbonPageGroup1})
			Me.chartsFormatRibbonPage1.Name = "chartsFormatRibbonPage1"
			Me.chartsFormatRibbonPage1.Visible = False
			' 
			' chartsFormatArrangeRibbonPageGroup1
			' 
			Me.chartsFormatArrangeRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem20)
			Me.chartsFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem21)
			Me.chartsFormatArrangeRibbonPageGroup1.Name = "chartsFormatArrangeRibbonPageGroup1"
			' 
			' tableToolsRibbonPageCategory1
			' 
			Me.tableToolsRibbonPageCategory1.Control = Me.spreadsheetControl1
			Me.tableToolsRibbonPageCategory1.Name = "tableToolsRibbonPageCategory1"
			Me.tableToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() { Me.tableToolsDesignRibbonPage1})
			Me.tableToolsRibbonPageCategory1.Visible = False
			' 
			' tableToolsDesignRibbonPage1
			' 
			Me.tableToolsDesignRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.tablePropertiesRibbonPageGroup1, Me.tableToolsRibbonPageGroup1, Me.tableStyleOptionsRibbonPageGroup1, Me.tableStylesRibbonPageGroup1})
			Me.tableToolsDesignRibbonPage1.Name = "tableToolsDesignRibbonPage1"
			Me.tableToolsDesignRibbonPage1.Visible = False
			' 
			' tablePropertiesRibbonPageGroup1
			' 
			Me.tablePropertiesRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.tablePropertiesRibbonPageGroup1.ItemLinks.Add(Me.renameTableItemCaption1)
			Me.tablePropertiesRibbonPageGroup1.ItemLinks.Add(Me.renameTableItem1)
			Me.tablePropertiesRibbonPageGroup1.Name = "tablePropertiesRibbonPageGroup1"
			' 
			' tableToolsRibbonPageGroup1
			' 
			Me.tableToolsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.tableToolsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem27)
			Me.tableToolsRibbonPageGroup1.Name = "tableToolsRibbonPageGroup1"
			' 
			' tableStyleOptionsRibbonPageGroup1
			' 
			Me.tableStyleOptionsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem28)
			Me.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem29)
			Me.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem30)
			Me.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem31)
			Me.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem32)
			Me.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem33)
			Me.tableStyleOptionsRibbonPageGroup1.Name = "tableStyleOptionsRibbonPageGroup1"
			' 
			' tableStylesRibbonPageGroup1
			' 
			Me.tableStylesRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.tableStylesRibbonPageGroup1.ItemLinks.Add(Me.galleryTableStylesItem1)
			Me.tableStylesRibbonPageGroup1.Name = "tableStylesRibbonPageGroup1"
			' 
			' drawingToolsRibbonPageCategory1
			' 
			Me.drawingToolsRibbonPageCategory1.Control = Me.spreadsheetControl1
			Me.drawingToolsRibbonPageCategory1.Name = "drawingToolsRibbonPageCategory1"
			Me.drawingToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() { Me.drawingFormatRibbonPage1})
			Me.drawingToolsRibbonPageCategory1.Visible = False
			' 
			' drawingFormatRibbonPage1
			' 
			Me.drawingFormatRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.drawingFormatArrangeRibbonPageGroup1})
			Me.drawingFormatRibbonPage1.Name = "drawingFormatRibbonPage1"
			Me.drawingFormatRibbonPage1.Visible = False
			' 
			' drawingFormatArrangeRibbonPageGroup1
			' 
			Me.drawingFormatArrangeRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.drawingFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem20)
			Me.drawingFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem21)
			Me.drawingFormatArrangeRibbonPageGroup1.Name = "drawingFormatArrangeRibbonPageGroup1"
			' 
			' pictureToolsRibbonPageCategory1
			' 
			Me.pictureToolsRibbonPageCategory1.Control = Me.spreadsheetControl1
			Me.pictureToolsRibbonPageCategory1.Name = "pictureToolsRibbonPageCategory1"
			Me.pictureToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() { Me.pictureFormatRibbonPage1})
			Me.pictureToolsRibbonPageCategory1.Visible = False
			' 
			' pictureFormatRibbonPage1
			' 
			Me.pictureFormatRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.pictureFormatArrangeRibbonPageGroup1})
			Me.pictureFormatRibbonPage1.Name = "pictureFormatRibbonPage1"
			Me.pictureFormatRibbonPage1.Visible = False
			' 
			' pictureFormatArrangeRibbonPageGroup1
			' 
			Me.pictureFormatArrangeRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pictureFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem20)
			Me.pictureFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem21)
			Me.pictureFormatArrangeRibbonPageGroup1.Name = "pictureFormatArrangeRibbonPageGroup1"
			' 
			' pivotTableToolsRibbonPageCategory1
			' 
			Me.pivotTableToolsRibbonPageCategory1.Control = Me.spreadsheetControl1
			Me.pivotTableToolsRibbonPageCategory1.Name = "pivotTableToolsRibbonPageCategory1"
			Me.pivotTableToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() { Me.pivotTableAnalyzeRibbonPage1, Me.pivotTableDesignRibbonPage1})
			Me.pivotTableToolsRibbonPageCategory1.Visible = False
			' 
			' pivotTableAnalyzeRibbonPage1
			' 
			Me.pivotTableAnalyzeRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.pivotTableAnalyzePivotTableRibbonPageGroup1, Me.pivotTableAnalyzeActiveFieldRibbonPageGroup1, Me.pivotTableAnalyzeGroupRibbonPageGroup1, Me.pivotTableAnalyzeDataRibbonPageGroup1, Me.pivotTableAnalyzeActionsRibbonPageGroup1, Me.pivotTableAnalyzeCalculationsRibbonPageGroup1, Me.pivotTableAnalyzeShowRibbonPageGroup1})
			Me.pivotTableAnalyzeRibbonPage1.Name = "pivotTableAnalyzeRibbonPage1"
			Me.pivotTableAnalyzeRibbonPage1.Visible = False
			' 
			' pivotTableAnalyzePivotTableRibbonPageGroup1
			' 
			Me.pivotTableAnalyzePivotTableRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableAnalyzePivotTableRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem167)
			Me.pivotTableAnalyzePivotTableRibbonPageGroup1.Name = "pivotTableAnalyzePivotTableRibbonPageGroup1"
			' 
			' pivotTableAnalyzeActiveFieldRibbonPageGroup1
			' 
			Me.pivotTableAnalyzeActiveFieldRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableAnalyzeActiveFieldRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem168)
			Me.pivotTableAnalyzeActiveFieldRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem169)
			Me.pivotTableAnalyzeActiveFieldRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem170)
			Me.pivotTableAnalyzeActiveFieldRibbonPageGroup1.Name = "pivotTableAnalyzeActiveFieldRibbonPageGroup1"
			' 
			' pivotTableAnalyzeGroupRibbonPageGroup1
			' 
			Me.pivotTableAnalyzeGroupRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableAnalyzeGroupRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem171)
			Me.pivotTableAnalyzeGroupRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem172)
			Me.pivotTableAnalyzeGroupRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem173)
			Me.pivotTableAnalyzeGroupRibbonPageGroup1.Name = "pivotTableAnalyzeGroupRibbonPageGroup1"
			' 
			' pivotTableAnalyzeDataRibbonPageGroup1
			' 
			Me.pivotTableAnalyzeDataRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableAnalyzeDataRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem32)
			Me.pivotTableAnalyzeDataRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem176)
			Me.pivotTableAnalyzeDataRibbonPageGroup1.Name = "pivotTableAnalyzeDataRibbonPageGroup1"
			' 
			' pivotTableAnalyzeActionsRibbonPageGroup1
			' 
			Me.pivotTableAnalyzeActionsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableAnalyzeActionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem33)
			Me.pivotTableAnalyzeActionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem34)
			Me.pivotTableAnalyzeActionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem182)
			Me.pivotTableAnalyzeActionsRibbonPageGroup1.Name = "pivotTableAnalyzeActionsRibbonPageGroup1"
			' 
			' pivotTableAnalyzeCalculationsRibbonPageGroup1
			' 
			Me.pivotTableAnalyzeCalculationsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableAnalyzeCalculationsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem35)
			Me.pivotTableAnalyzeCalculationsRibbonPageGroup1.Name = "pivotTableAnalyzeCalculationsRibbonPageGroup1"
			' 
			' pivotTableAnalyzeShowRibbonPageGroup1
			' 
			Me.pivotTableAnalyzeShowRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableAnalyzeShowRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem34)
			Me.pivotTableAnalyzeShowRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem35)
			Me.pivotTableAnalyzeShowRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem36)
			Me.pivotTableAnalyzeShowRibbonPageGroup1.Name = "pivotTableAnalyzeShowRibbonPageGroup1"
			' 
			' pivotTableDesignRibbonPage1
			' 
			Me.pivotTableDesignRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.pivotTableDesignLayoutRibbonPageGroup1, Me.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1, Me.pivotTableDesignPivotTableStylesRibbonPageGroup1})
			Me.pivotTableDesignRibbonPage1.Name = "pivotTableDesignRibbonPage1"
			Me.pivotTableDesignRibbonPage1.Visible = False
			' 
			' pivotTableDesignLayoutRibbonPageGroup1
			' 
			Me.pivotTableDesignLayoutRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem36)
			Me.pivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem37)
			Me.pivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem38)
			Me.pivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem39)
			Me.pivotTableDesignLayoutRibbonPageGroup1.Name = "pivotTableDesignLayoutRibbonPageGroup1"
			' 
			' pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1
			' 
			Me.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem37)
			Me.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem38)
			Me.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem39)
			Me.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem40)
			Me.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.TwoRows
			Me.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.Name = "pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1"
			' 
			' pivotTableDesignPivotTableStylesRibbonPageGroup1
			' 
			Me.pivotTableDesignPivotTableStylesRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pivotTableDesignPivotTableStylesRibbonPageGroup1.ItemLinks.Add(Me.galleryPivotStylesItem1)
			Me.pivotTableDesignPivotTableStylesRibbonPageGroup1.Name = "pivotTableDesignPivotTableStylesRibbonPageGroup1"
			' 
			' fileRibbonPage1
			' 
			Me.fileRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.commonRibbonPageGroup1, Me.infoRibbonPageGroup1})
			Me.fileRibbonPage1.Name = "fileRibbonPage1"
			' 
			' commonRibbonPageGroup1
			' 
			Me.commonRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem1)
			Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem2)
			Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem3)
			Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem4)
			Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem5)
			Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem6)
			Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem7)
			Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem8)
			Me.commonRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem9)
			Me.commonRibbonPageGroup1.Name = "commonRibbonPageGroup1"
			' 
			' infoRibbonPageGroup1
			' 
			Me.infoRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.infoRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem10)
			Me.infoRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem11)
			Me.infoRibbonPageGroup1.Name = "infoRibbonPageGroup1"
			' 
			' homeRibbonPage1
			' 
			Me.homeRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.clipboardRibbonPageGroup1, Me.fontRibbonPageGroup1, Me.alignmentRibbonPageGroup1, Me.numberRibbonPageGroup1, Me.stylesRibbonPageGroup1, Me.cellsRibbonPageGroup1, Me.editingRibbonPageGroup1})
			Me.homeRibbonPage1.Name = "homeRibbonPage1"
			reduceOperation1.Behavior = DevExpress.XtraBars.Ribbon.ReduceOperationBehavior.UntilAvailable
			reduceOperation1.GroupName = "stylesRibbonPageGroup1"
			reduceOperation1.ItemLinkIndex = 2
			reduceOperation1.ItemLinksCount = 0
			reduceOperation1.Operation = DevExpress.XtraBars.Ribbon.ReduceOperationType.Gallery
			Me.homeRibbonPage1.ReduceOperations.Add(reduceOperation1)
			' 
			' clipboardRibbonPageGroup1
			' 
			Me.clipboardRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.clipboardRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem12)
			Me.clipboardRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem13)
			Me.clipboardRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem14)
			Me.clipboardRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem15)
			Me.clipboardRibbonPageGroup1.Name = "clipboardRibbonPageGroup1"
			' 
			' fontRibbonPageGroup1
			' 
			Me.fontRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.True
			Me.fontRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup1)
			Me.fontRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup2)
			Me.fontRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup3)
			Me.fontRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup4)
			Me.fontRibbonPageGroup1.Name = "fontRibbonPageGroup1"
			' 
			' alignmentRibbonPageGroup1
			' 
			Me.alignmentRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.True
			Me.alignmentRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup5)
			Me.alignmentRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup6)
			Me.alignmentRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup7)
			Me.alignmentRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem11)
			Me.alignmentRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem2)
			Me.alignmentRibbonPageGroup1.Name = "alignmentRibbonPageGroup1"
			' 
			' numberRibbonPageGroup1
			' 
			Me.numberRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.True
			Me.numberRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup8)
			Me.numberRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup9)
			Me.numberRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup10)
			Me.numberRibbonPageGroup1.Name = "numberRibbonPageGroup1"
			' 
			' stylesRibbonPageGroup1
			' 
			Me.stylesRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.stylesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem7)
			Me.stylesRibbonPageGroup1.ItemLinks.Add(Me.galleryFormatAsTableItem1)
			Me.stylesRibbonPageGroup1.ItemLinks.Add(Me.galleryChangeStyleItem1)
			Me.stylesRibbonPageGroup1.Name = "stylesRibbonPageGroup1"
			' 
			' cellsRibbonPageGroup1
			' 
			Me.cellsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.cellsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem8)
			Me.cellsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem9)
			Me.cellsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem11)
			Me.cellsRibbonPageGroup1.Name = "cellsRibbonPageGroup1"
			' 
			' editingRibbonPageGroup1
			' 
			Me.editingRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.editingRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem12)
			Me.editingRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem13)
			Me.editingRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem14)
			Me.editingRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem15)
			Me.editingRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem16)
			Me.editingRibbonPageGroup1.Name = "editingRibbonPageGroup1"
			' 
			' insertRibbonPage1
			' 
			Me.insertRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.tablesRibbonPageGroup1, Me.illustrationsRibbonPageGroup1, Me.chartsRibbonPageGroup1, Me.linksRibbonPageGroup1, Me.symbolsRibbonPageGroup1})
			Me.insertRibbonPage1.Name = "insertRibbonPage1"
			' 
			' tablesRibbonPageGroup1
			' 
			Me.tablesRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.tablesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem118)
			Me.tablesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem119)
			Me.tablesRibbonPageGroup1.Name = "tablesRibbonPageGroup1"
			' 
			' illustrationsRibbonPageGroup1
			' 
			Me.illustrationsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.illustrationsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem120)
			Me.illustrationsRibbonPageGroup1.Name = "illustrationsRibbonPageGroup1"
			' 
			' chartsRibbonPageGroup1
			' 
			Me.chartsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.chartsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem4)
			Me.chartsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem5)
			Me.chartsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem6)
			Me.chartsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem7)
			Me.chartsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem8)
			Me.chartsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem9)
			Me.chartsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem10)
			Me.chartsRibbonPageGroup1.Name = "chartsRibbonPageGroup1"
			' 
			' linksRibbonPageGroup1
			' 
			Me.linksRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.linksRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem121)
			Me.linksRibbonPageGroup1.Name = "linksRibbonPageGroup1"
			' 
			' symbolsRibbonPageGroup1
			' 
			Me.symbolsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.symbolsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem122)
			Me.symbolsRibbonPageGroup1.Name = "symbolsRibbonPageGroup1"
			' 
			' pageLayoutRibbonPage1
			' 
			Me.pageLayoutRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.pageSetupRibbonPageGroup1, Me.pageSetupShowRibbonPageGroup1, Me.pageSetupPrintRibbonPageGroup1, Me.arrangeRibbonPageGroup1})
			Me.pageLayoutRibbonPage1.Name = "pageLayoutRibbonPage1"
			' 
			' pageSetupRibbonPageGroup1
			' 
			Me.pageSetupRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.True
			Me.pageSetupRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem17)
			Me.pageSetupRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem18)
			Me.pageSetupRibbonPageGroup1.ItemLinks.Add(Me.pageSetupPaperKindItem1)
			Me.pageSetupRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem19)
			Me.pageSetupRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem127)
			Me.pageSetupRibbonPageGroup1.Name = "pageSetupRibbonPageGroup1"
			' 
			' pageSetupShowRibbonPageGroup1
			' 
			Me.pageSetupShowRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.pageSetupShowRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem20)
			Me.pageSetupShowRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem21)
			Me.pageSetupShowRibbonPageGroup1.Name = "pageSetupShowRibbonPageGroup1"
			' 
			' pageSetupPrintRibbonPageGroup1
			' 
			Me.pageSetupPrintRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.True
			Me.pageSetupPrintRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem22)
			Me.pageSetupPrintRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem23)
			Me.pageSetupPrintRibbonPageGroup1.Name = "pageSetupPrintRibbonPageGroup1"
			' 
			' arrangeRibbonPageGroup1
			' 
			Me.arrangeRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.arrangeRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem20)
			Me.arrangeRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem21)
			Me.arrangeRibbonPageGroup1.Name = "arrangeRibbonPageGroup1"
			' 
			' formulasRibbonPage1
			' 
			Me.formulasRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.functionLibraryRibbonPageGroup1, Me.formulaDefinedNamesRibbonPageGroup1, Me.formulaAuditingRibbonPageGroup1, Me.formulaCalculationRibbonPageGroup1})
			Me.formulasRibbonPage1.Name = "formulasRibbonPage1"
			' 
			' functionLibraryRibbonPageGroup1
			' 
			Me.functionLibraryRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.functionLibraryRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem22)
			Me.functionLibraryRibbonPageGroup1.ItemLinks.Add(Me.functionsFinancialItem1)
			Me.functionLibraryRibbonPageGroup1.ItemLinks.Add(Me.functionsLogicalItem1)
			Me.functionLibraryRibbonPageGroup1.ItemLinks.Add(Me.functionsTextItem1)
			Me.functionLibraryRibbonPageGroup1.ItemLinks.Add(Me.functionsDateAndTimeItem1)
			Me.functionLibraryRibbonPageGroup1.ItemLinks.Add(Me.functionsLookupAndReferenceItem1)
			Me.functionLibraryRibbonPageGroup1.ItemLinks.Add(Me.functionsMathAndTrigonometryItem1)
			Me.functionLibraryRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem23)
			Me.functionLibraryRibbonPageGroup1.Name = "functionLibraryRibbonPageGroup1"
			' 
			' formulaDefinedNamesRibbonPageGroup1
			' 
			Me.formulaDefinedNamesRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.formulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem132)
			Me.formulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem133)
			Me.formulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(Me.definedNameListItem1)
			Me.formulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem134)
			Me.formulaDefinedNamesRibbonPageGroup1.Name = "formulaDefinedNamesRibbonPageGroup1"
			' 
			' formulaAuditingRibbonPageGroup1
			' 
			Me.formulaAuditingRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.formulaAuditingRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem24)
			Me.formulaAuditingRibbonPageGroup1.Name = "formulaAuditingRibbonPageGroup1"
			' 
			' formulaCalculationRibbonPageGroup1
			' 
			Me.formulaCalculationRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.formulaCalculationRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem24)
			Me.formulaCalculationRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem135)
			Me.formulaCalculationRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem136)
			Me.formulaCalculationRibbonPageGroup1.Name = "formulaCalculationRibbonPageGroup1"
			' 
			' dataRibbonPage1
			' 
			Me.dataRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.sortAndFilterRibbonPageGroup1, Me.dataToolsRibbonPageGroup1, Me.outlineRibbonPageGroup1})
			Me.dataRibbonPage1.Name = "dataRibbonPage1"
			' 
			' sortAndFilterRibbonPageGroup1
			' 
			Me.sortAndFilterRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.sortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem107)
			Me.sortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem108)
			Me.sortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem14)
			Me.sortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem109)
			Me.sortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem110)
			Me.sortAndFilterRibbonPageGroup1.Name = "sortAndFilterRibbonPageGroup1"
			' 
			' dataToolsRibbonPageGroup1
			' 
			Me.dataToolsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.dataToolsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem25)
			Me.dataToolsRibbonPageGroup1.Name = "dataToolsRibbonPageGroup1"
			' 
			' outlineRibbonPageGroup1
			' 
			Me.outlineRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.True
			Me.outlineRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem26)
			Me.outlineRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem27)
			Me.outlineRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem144)
			Me.outlineRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem145)
			Me.outlineRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem146)
			Me.outlineRibbonPageGroup1.Name = "outlineRibbonPageGroup1"
			' 
			' reviewRibbonPage1
			' 
			Me.reviewRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.commentsRibbonPageGroup1, Me.changesRibbonPageGroup1})
			Me.reviewRibbonPage1.Name = "reviewRibbonPage1"
			' 
			' commentsRibbonPageGroup1
			' 
			Me.commentsRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.commentsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem147)
			Me.commentsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem148)
			Me.commentsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem149)
			Me.commentsRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem150)
			Me.commentsRibbonPageGroup1.Name = "commentsRibbonPageGroup1"
			' 
			' changesRibbonPageGroup1
			' 
			Me.changesRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.changesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem90)
			Me.changesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem151)
			Me.changesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem152)
			Me.changesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem153)
			Me.changesRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem154)
			Me.changesRibbonPageGroup1.Name = "changesRibbonPageGroup1"
			' 
			' viewRibbonPage1
			' 
			Me.viewRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.showRibbonPageGroup1, Me.zoomRibbonPageGroup1, Me.windowRibbonPageGroup1})
			Me.viewRibbonPage1.Name = "viewRibbonPage1"
			' 
			' showRibbonPageGroup1
			' 
			Me.showRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.showRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem20)
			Me.showRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarCheckItem21)
			Me.showRibbonPageGroup1.Name = "showRibbonPageGroup1"
			' 
			' zoomRibbonPageGroup1
			' 
			Me.zoomRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.zoomRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem155)
			Me.zoomRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem156)
			Me.zoomRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem157)
			Me.zoomRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarButtonItem158)
			Me.zoomRibbonPageGroup1.Name = "zoomRibbonPageGroup1"
			' 
			' windowRibbonPageGroup1
			' 
			Me.windowRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False
			Me.windowRibbonPageGroup1.ItemLinks.Add(Me.spreadsheetCommandBarSubItem28)
			Me.windowRibbonPageGroup1.Name = "windowRibbonPageGroup1"
			' 
			' repositoryItemProgressBar1
			' 
			Me.repositoryItemProgressBar1.Name = "repositoryItemProgressBar1"
			' 
			' ribbonStatusBar1
			' 
			Me.ribbonStatusBar1.ItemLinks.Add(Me.endModeInfoStaticItem1)
			Me.ribbonStatusBar1.ItemLinks.Add(Me.averageInfoStaticItem1)
			Me.ribbonStatusBar1.ItemLinks.Add(Me.countInfoStaticItem1)
			Me.ribbonStatusBar1.ItemLinks.Add(Me.numericalCountInfoStaticItem1)
			Me.ribbonStatusBar1.ItemLinks.Add(Me.minInfoStaticItem1)
			Me.ribbonStatusBar1.ItemLinks.Add(Me.maxInfoStaticItem1)
			Me.ribbonStatusBar1.ItemLinks.Add(Me.sumInfoStaticItem1)
			Me.ribbonStatusBar1.ItemLinks.Add(Me.zoomEditItem1)
			Me.ribbonStatusBar1.ItemLinks.Add(Me.showZoomButtonItem1)
			Me.ribbonStatusBar1.Location = New System.Drawing.Point(0, 417)
			Me.ribbonStatusBar1.Margin = New System.Windows.Forms.Padding(2)
			Me.ribbonStatusBar1.Name = "ribbonStatusBar1"
			Me.ribbonStatusBar1.Ribbon = Me.ribbonControl1
			Me.ribbonStatusBar1.Size = New System.Drawing.Size(892, 22)
			' 
			' spreadsheetFormulaBar1
			' 
			Me.spreadsheetFormulaBar1.Dock = System.Windows.Forms.DockStyle.Top
			Me.spreadsheetFormulaBar1.Location = New System.Drawing.Point(0, 158)
			Me.spreadsheetFormulaBar1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
			Me.spreadsheetFormulaBar1.MinimumSize = New System.Drawing.Size(0, 20)
			Me.spreadsheetFormulaBar1.Name = "spreadsheetFormulaBar1"
			Me.spreadsheetFormulaBar1.Size = New System.Drawing.Size(892, 24)
			Me.spreadsheetFormulaBar1.SpreadsheetControl = Me.spreadsheetControl1
			Me.spreadsheetFormulaBar1.TabIndex = 2
			' 
			' splitterControl1
			' 
			Me.splitterControl1.Dock = System.Windows.Forms.DockStyle.Top
			Me.splitterControl1.Location = New System.Drawing.Point(0, 182)
			Me.splitterControl1.Margin = New System.Windows.Forms.Padding(2)
			Me.splitterControl1.MinSize = 20
			Me.splitterControl1.Name = "splitterControl1"
			Me.splitterControl1.Size = New System.Drawing.Size(892, 10)
			Me.splitterControl1.TabIndex = 1
			Me.splitterControl1.TabStop = False
			' 
			' spreadsheetBarController1
			' 
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem2)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem3)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem4)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem5)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem6)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem7)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem8)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem9)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem10)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem11)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem12)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem13)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem14)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem15)
			Me.spreadsheetBarController1.BarItems.Add(Me.changeFontNameItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.changeFontSizeItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem16)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem17)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem2)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem3)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem4)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem18)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem19)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem20)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem21)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem22)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem23)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem24)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem25)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem26)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem27)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem28)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem29)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem30)
			Me.spreadsheetBarController1.BarItems.Add(Me.changeBorderLineColorItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.changeBorderLineStyleItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.changeCellFillColorItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.changeFontColorItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem5)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem6)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem7)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem8)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem9)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem10)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem31)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem32)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem11)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem12)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem33)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem34)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem35)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem2)
			Me.spreadsheetBarController1.BarItems.Add(Me.changeNumberFormatItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem36)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem37)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem38)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem39)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem40)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem41)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem3)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem42)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem43)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem44)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem45)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem46)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem47)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem48)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem49)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem50)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem51)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem52)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem4)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem53)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem54)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem55)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem56)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem57)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem58)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem5)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem2)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem3)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem59)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem60)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem61)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem6)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem62)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem7)
			Me.spreadsheetBarController1.BarItems.Add(Me.galleryFormatAsTableItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.galleryChangeStyleItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem63)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem64)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem65)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem66)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem67)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem68)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem69)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem70)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem8)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem71)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem72)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem73)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem74)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem75)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem76)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem9)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem77)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem78)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem79)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem80)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem81)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem82)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem83)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem84)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem85)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem86)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem87)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem10)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem88)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem89)
			Me.spreadsheetBarController1.BarItems.Add(Me.changeSheetTabColorItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem90)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem13)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem91)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem11)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem92)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem93)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem94)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem95)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem96)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem12)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem97)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem98)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem99)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem100)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem13)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem101)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem102)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem103)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem104)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem105)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem106)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem14)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem107)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem108)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem14)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem109)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem110)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem15)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem111)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem112)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem113)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem114)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem115)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem116)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem117)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem16)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem118)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem119)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem120)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem4)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem5)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem6)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem7)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem8)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem9)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem10)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem121)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem122)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem15)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem16)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem17)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem123)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem17)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem18)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem19)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem18)
			Me.spreadsheetBarController1.BarItems.Add(Me.pageSetupPaperKindItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem124)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem125)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem126)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem19)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem127)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem20)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem21)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem22)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem23)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem128)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem129)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem20)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem130)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem131)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem21)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem22)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsFinancialItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsLogicalItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsTextItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsDateAndTimeItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsLookupAndReferenceItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsMathAndTrigonometryItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsStatisticalItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsEngineeringItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsInformationItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsCompatibilityItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.functionsWebItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem23)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem132)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem133)
			Me.spreadsheetBarController1.BarItems.Add(Me.definedNameListItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem134)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem24)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem25)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem26)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem24)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem135)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem136)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem137)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem138)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem139)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem25)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem140)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem141)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem26)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem142)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem143)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem27)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem144)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem145)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem146)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem147)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem148)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem149)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem150)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem151)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem152)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem153)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem154)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem155)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem156)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem157)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem158)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem159)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem160)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem161)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem162)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem28)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem163)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem164)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem165)
			Me.spreadsheetBarController1.BarItems.Add(Me.galleryChartLayoutItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.galleryChartStyleItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem166)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem11)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem12)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem29)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem13)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem14)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem30)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem15)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem16)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem17)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem31)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem18)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem19)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem20)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem21)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonGalleryDropDownItem22)
			Me.spreadsheetBarController1.BarItems.Add(Me.renameTableItemCaption1)
			Me.spreadsheetBarController1.BarItems.Add(Me.renameTableItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem27)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem28)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem29)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem30)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem31)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem32)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem33)
			Me.spreadsheetBarController1.BarItems.Add(Me.galleryTableStylesItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem167)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem168)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem169)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem170)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem171)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem172)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem173)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem174)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem175)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem32)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem176)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem177)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem178)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem33)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem179)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem180)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem181)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem34)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem182)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem183)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem184)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem185)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem186)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem35)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem34)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem35)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem36)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem187)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem188)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem189)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem36)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem190)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem191)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem192)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem193)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem37)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem194)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem195)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem196)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem197)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem198)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem38)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem199)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarButtonItem200)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarSubItem39)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem37)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem38)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem39)
			Me.spreadsheetBarController1.BarItems.Add(Me.spreadsheetCommandBarCheckItem40)
			Me.spreadsheetBarController1.BarItems.Add(Me.galleryPivotStylesItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.endModeInfoStaticItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.averageInfoStaticItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.countInfoStaticItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.numericalCountInfoStaticItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.minInfoStaticItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.maxInfoStaticItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.sumInfoStaticItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.zoomEditItem1)
			Me.spreadsheetBarController1.BarItems.Add(Me.showZoomButtonItem1)
			Me.spreadsheetBarController1.Control = Me.spreadsheetControl1
			' 
			' Form1
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(892, 439)
			Me.Controls.Add(Me.spreadsheetControl1)
			Me.Controls.Add(Me.splitterControl1)
			Me.Controls.Add(Me.spreadsheetFormulaBar1)
			Me.Controls.Add(Me.ribbonStatusBar1)
			Me.Controls.Add(Me.ribbonControl1)
			Me.Margin = New System.Windows.Forms.Padding(2)
			Me.Name = "Form1"
			Me.Ribbon = Me.ribbonControl1
			Me.StatusBar = Me.ribbonStatusBar1
			Me.Text = "Spreadsheet Progress Indication"
			Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
			CType(Me.ribbonControl1, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.repositoryItemFontEdit1, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.repositoryItemSpreadsheetFontSizeEdit1, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown1, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.repositoryItemPopupGalleryEdit1, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown2, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown3, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown4, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown5, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown6, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown7, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown8, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown9, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown10, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown11, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown12, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown13, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown14, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown15, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown16, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown17, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown18, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown19, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown20, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown21, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown22, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown23, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.commandBarGalleryDropDown24, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.repositoryItemTextEdit1, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.repositoryItemZoomTrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.repositoryItemProgressBar1, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.spreadsheetBarController1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private WithEvents spreadsheetControl1 As DevExpress.XtraSpreadsheet.SpreadsheetControl
		Private spreadsheetFormulaBar1 As DevExpress.XtraSpreadsheet.SpreadsheetFormulaBar
		Private splitterControl1 As DevExpress.XtraEditors.SplitterControl
		Private ribbonControl1 As DevExpress.XtraBars.Ribbon.RibbonControl
		Private spreadsheetCommandBarButtonItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private barButtonGroup1 As DevExpress.XtraBars.BarButtonGroup
		Private changeFontNameItem1 As DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem
		Private repositoryItemFontEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemFontEdit
		Private changeFontSizeItem1 As DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem
		Private repositoryItemSpreadsheetFontSizeEdit1 As DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit
		Private spreadsheetCommandBarButtonItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private barButtonGroup2 As DevExpress.XtraBars.BarButtonGroup
		Private spreadsheetCommandBarCheckItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private barButtonGroup3 As DevExpress.XtraBars.BarButtonGroup
		Private spreadsheetCommandBarSubItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private changeBorderLineColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem
		Private changeBorderLineStyleItem1 As DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem
		Private commandBarGalleryDropDown1 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private barButtonGroup4 As DevExpress.XtraBars.BarButtonGroup
		Private changeCellFillColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem
		Private changeFontColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem
		Private barButtonGroup5 As DevExpress.XtraBars.BarButtonGroup
		Private spreadsheetCommandBarCheckItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private barButtonGroup6 As DevExpress.XtraBars.BarButtonGroup
		Private spreadsheetCommandBarCheckItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private barButtonGroup7 As DevExpress.XtraBars.BarButtonGroup
		Private spreadsheetCommandBarButtonItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarCheckItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarSubItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarCheckItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarButtonItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private barButtonGroup8 As DevExpress.XtraBars.BarButtonGroup
		Private changeNumberFormatItem1 As DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem
		Private repositoryItemPopupGalleryEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit
		Private barButtonGroup9 As DevExpress.XtraBars.BarButtonGroup
		Private spreadsheetCommandBarSubItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem41 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem42 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem43 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private barButtonGroup10 As DevExpress.XtraBars.BarButtonGroup
		Private spreadsheetCommandBarButtonItem44 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem45 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarSubItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem46 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem47 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem48 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem49 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem50 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem51 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem52 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem53 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem54 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem55 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem56 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem57 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem58 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonGalleryDropDownItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown2 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown3 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown4 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonItem59 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem60 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem61 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem62 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private galleryFormatAsTableItem1 As DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem
		Private commandBarGalleryDropDown5 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private galleryChangeStyleItem1 As DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem
		Private spreadsheetCommandBarSubItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem63 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem64 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem65 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem66 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem67 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem68 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem69 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem70 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem71 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem72 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem73 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem74 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem75 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem76 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem77 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem78 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem79 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem80 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem81 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem82 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem83 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem84 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem85 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem86 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem87 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem88 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem89 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private changeSheetTabColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem
		Private spreadsheetCommandBarButtonItem90 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarCheckItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarButtonItem91 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem92 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem93 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem94 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem95 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem96 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem97 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem98 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem99 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem100 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem101 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem102 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem103 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem104 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem105 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem106 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem107 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem108 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarCheckItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarButtonItem109 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem110 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem111 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem112 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem113 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem114 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem115 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem116 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem117 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem118 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem119 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem120 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonGalleryDropDownItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown6 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown7 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown8 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown9 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown10 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown11 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown12 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonItem121 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem122 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarCheckItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarButtonItem123 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarCheckItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private pageSetupPaperKindItem1 As DevExpress.XtraSpreadsheet.UI.PageSetupPaperKindItem
		Private spreadsheetCommandBarSubItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem124 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem125 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem126 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem127 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarCheckItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarSubItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem128 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem129 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem130 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem131 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private functionsFinancialItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsFinancialItem
		Private functionsLogicalItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsLogicalItem
		Private functionsTextItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsTextItem
		Private functionsDateAndTimeItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsDateAndTimeItem
		Private functionsLookupAndReferenceItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsLookupAndReferenceItem
		Private functionsMathAndTrigonometryItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsMathAndTrigonometryItem
		Private spreadsheetCommandBarSubItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private functionsStatisticalItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsStatisticalItem
		Private functionsEngineeringItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsEngineeringItem
		Private functionsInformationItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsInformationItem
		Private functionsCompatibilityItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsCompatibilityItem
		Private functionsWebItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsWebItem
		Private spreadsheetCommandBarButtonItem132 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem133 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private definedNameListItem1 As DevExpress.XtraSpreadsheet.UI.DefinedNameListItem
		Private spreadsheetCommandBarButtonItem134 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarCheckItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarSubItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarCheckItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarButtonItem135 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem136 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem137 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem138 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem139 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem140 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem141 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem142 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem143 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem144 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem145 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem146 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem147 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem148 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem149 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem150 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem151 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem152 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem153 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem154 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem155 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem156 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem157 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem158 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem159 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem160 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem161 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem162 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem163 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem164 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem165 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private galleryChartLayoutItem1 As DevExpress.XtraSpreadsheet.UI.GalleryChartLayoutItem
		Private galleryChartStyleItem1 As DevExpress.XtraSpreadsheet.UI.GalleryChartStyleItem
		Private spreadsheetCommandBarButtonItem166 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonGalleryDropDownItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown13 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown14 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarSubItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonGalleryDropDownItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown15 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown16 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown17 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarSubItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonGalleryDropDownItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown18 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown19 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown20 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown21 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown22 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown23 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private spreadsheetCommandBarButtonGalleryDropDownItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
		Private commandBarGalleryDropDown24 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private renameTableItemCaption1 As DevExpress.XtraSpreadsheet.UI.RenameTableItemCaption
		Private renameTableItem1 As DevExpress.XtraSpreadsheet.UI.RenameTableItem
		Private repositoryItemTextEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemTextEdit
		Private spreadsheetCommandBarCheckItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private galleryTableStylesItem1 As DevExpress.XtraSpreadsheet.UI.GalleryTableStylesItem
		Private spreadsheetCommandBarButtonItem167 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem168 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem169 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem170 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem171 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem172 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem173 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem174 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem175 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem176 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem177 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem178 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem179 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem180 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem181 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem182 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem183 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem184 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem185 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem186 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarCheckItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarSubItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem187 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem188 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem189 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem190 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem191 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem192 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem193 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem194 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem195 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem196 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem197 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem198 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarSubItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
		Private spreadsheetCommandBarButtonItem199 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarButtonItem200 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
		Private spreadsheetCommandBarCheckItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private spreadsheetCommandBarCheckItem40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
		Private galleryPivotStylesItem1 As DevExpress.XtraSpreadsheet.UI.GalleryPivotStylesItem
		Private endModeInfoStaticItem1 As DevExpress.XtraSpreadsheet.UI.EndModeInfoStaticItem
		Private averageInfoStaticItem1 As DevExpress.XtraSpreadsheet.UI.AverageInfoStaticItem
		Private countInfoStaticItem1 As DevExpress.XtraSpreadsheet.UI.CountInfoStaticItem
		Private numericalCountInfoStaticItem1 As DevExpress.XtraSpreadsheet.UI.NumericalCountInfoStaticItem
		Private minInfoStaticItem1 As DevExpress.XtraSpreadsheet.UI.MinInfoStaticItem
		Private maxInfoStaticItem1 As DevExpress.XtraSpreadsheet.UI.MaxInfoStaticItem
		Private sumInfoStaticItem1 As DevExpress.XtraSpreadsheet.UI.SumInfoStaticItem
		Private zoomEditItem1 As DevExpress.XtraSpreadsheet.UI.ZoomEditItem
		Private repositoryItemZoomTrackBar1 As DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar
		Private showZoomButtonItem1 As DevExpress.XtraSpreadsheet.UI.ShowZoomButtonItem
		Private chartToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.ChartToolsRibbonPageCategory
		Private chartsDesignRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignRibbonPage
		Private chartsDesignTypeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignTypeRibbonPageGroup
		Private chartsDesignDataRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignDataRibbonPageGroup
		Private chartsDesignLayoutsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignLayoutsRibbonPageGroup
		Private chartsDesignStylesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignStylesRibbonPageGroup
		Private chartsDesignLocationRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignLocationRibbonPageGroup
		Private chartsLayoutRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ChartsLayoutRibbonPage
		Private chartsLayoutAxesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsLayoutAxesRibbonPageGroup
		Private chartsLayoutLabelsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsLayoutLabelsRibbonPageGroup
		Private chartsLayoutAnalysisRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsLayoutAnalysisRibbonPageGroup
		Private chartsFormatRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ChartsFormatRibbonPage
		Private chartsFormatArrangeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsFormatArrangeRibbonPageGroup
		Private tableToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageCategory
		Private tableToolsDesignRibbonPage1 As DevExpress.XtraSpreadsheet.UI.TableToolsDesignRibbonPage
		Private tablePropertiesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TablePropertiesRibbonPageGroup
		Private tableToolsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageGroup
		Private tableStyleOptionsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TableStyleOptionsRibbonPageGroup
		Private tableStylesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TableStylesRibbonPageGroup
		Private drawingToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.DrawingToolsRibbonPageCategory
		Private drawingFormatRibbonPage1 As DevExpress.XtraSpreadsheet.UI.DrawingFormatRibbonPage
		Private drawingFormatArrangeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.DrawingFormatArrangeRibbonPageGroup
		Private pictureToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.PictureToolsRibbonPageCategory
		Private pictureFormatRibbonPage1 As DevExpress.XtraSpreadsheet.UI.PictureFormatRibbonPage
		Private pictureFormatArrangeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PictureFormatArrangeRibbonPageGroup
		Private pivotTableToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.PivotTableToolsRibbonPageCategory
		Private pivotTableAnalyzeRibbonPage1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeRibbonPage
		Private pivotTableAnalyzePivotTableRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzePivotTableRibbonPageGroup
		Private pivotTableAnalyzeActiveFieldRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActiveFieldRibbonPageGroup
		Private pivotTableAnalyzeGroupRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeGroupRibbonPageGroup
		Private pivotTableAnalyzeDataRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeDataRibbonPageGroup
		Private pivotTableAnalyzeActionsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActionsRibbonPageGroup
		Private pivotTableAnalyzeCalculationsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeCalculationsRibbonPageGroup
		Private pivotTableAnalyzeShowRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeShowRibbonPageGroup
		Private pivotTableDesignRibbonPage1 As DevExpress.XtraSpreadsheet.UI.PivotTableDesignRibbonPage
		Private pivotTableDesignLayoutRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableDesignLayoutRibbonPageGroup
		Private pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup
		Private pivotTableDesignPivotTableStylesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStylesRibbonPageGroup
		Private fileRibbonPage1 As DevExpress.XtraSpreadsheet.UI.FileRibbonPage
		Private commonRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.CommonRibbonPageGroup
		Private infoRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.InfoRibbonPageGroup
		Private homeRibbonPage1 As DevExpress.XtraSpreadsheet.UI.HomeRibbonPage
		Private clipboardRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ClipboardRibbonPageGroup
		Private fontRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FontRibbonPageGroup
		Private alignmentRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.AlignmentRibbonPageGroup
		Private numberRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.NumberRibbonPageGroup
		Private stylesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.StylesRibbonPageGroup
		Private cellsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.CellsRibbonPageGroup
		Private editingRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.EditingRibbonPageGroup
		Private insertRibbonPage1 As DevExpress.XtraSpreadsheet.UI.InsertRibbonPage
		Private tablesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TablesRibbonPageGroup
		Private illustrationsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.IllustrationsRibbonPageGroup
		Private chartsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsRibbonPageGroup
		Private linksRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.LinksRibbonPageGroup
		Private symbolsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.SymbolsRibbonPageGroup
		Private pageLayoutRibbonPage1 As DevExpress.XtraSpreadsheet.UI.PageLayoutRibbonPage
		Private pageSetupRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PageSetupRibbonPageGroup
		Private pageSetupShowRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PageSetupShowRibbonPageGroup
		Private pageSetupPrintRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PageSetupPrintRibbonPageGroup
		Private arrangeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ArrangeRibbonPageGroup
		Private formulasRibbonPage1 As DevExpress.XtraSpreadsheet.UI.FormulasRibbonPage
		Private functionLibraryRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FunctionLibraryRibbonPageGroup
		Private formulaDefinedNamesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FormulaDefinedNamesRibbonPageGroup
		Private formulaAuditingRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FormulaAuditingRibbonPageGroup
		Private formulaCalculationRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FormulaCalculationRibbonPageGroup
		Private dataRibbonPage1 As DevExpress.XtraSpreadsheet.UI.DataRibbonPage
		Private sortAndFilterRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.SortAndFilterRibbonPageGroup
		Private dataToolsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.DataToolsRibbonPageGroup
		Private outlineRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.OutlineRibbonPageGroup
		Private reviewRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ReviewRibbonPage
		Private commentsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.CommentsRibbonPageGroup
		Private changesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChangesRibbonPageGroup
		Private viewRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ViewRibbonPage
		Private showRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ShowRibbonPageGroup
		Private zoomRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ZoomRibbonPageGroup
		Private windowRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.WindowRibbonPageGroup
		Private ribbonStatusBar1 As DevExpress.XtraBars.Ribbon.RibbonStatusBar
		Private spreadsheetBarController1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController
		Private repositoryItemProgressBar1 As DevExpress.XtraEditors.Repository.RepositoryItemProgressBar
		Private splashScreenManager1 As DevExpress.XtraSplashScreen.SplashScreenManager
	End Class
End Namespace


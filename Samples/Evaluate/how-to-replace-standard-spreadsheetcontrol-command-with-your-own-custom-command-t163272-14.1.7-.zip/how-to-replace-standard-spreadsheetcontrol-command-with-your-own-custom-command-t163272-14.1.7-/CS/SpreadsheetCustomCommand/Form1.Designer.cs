﻿namespace SpreadsheetCustomCommand
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup1 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem17 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem18 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem19 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem20 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem21 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem22 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem23 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem24 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem25 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem26 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem27 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem28 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem29 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem30 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem31 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem32 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem33 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem34 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem35 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem36 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem37 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem38 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem39 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem40 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem41 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem42 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem43 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem44 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem45 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem46 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem47 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem48 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem49 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem50 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem51 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem52 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem53 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem54 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem55 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem56 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem57 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem58 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem59 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem60 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem61 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem62 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem63 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem64 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem65 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem66 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem67 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem68 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem69 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem70 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem71 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem72 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem73 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem74 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem75 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem76 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem77 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem78 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem79 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem80 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem81 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem82 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem83 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem84 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem85 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup17 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem86 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem87 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup18 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem88 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem89 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem90 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup19 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem91 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem92 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem93 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup20 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem94 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem95 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem96 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup21 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem97 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem98 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem99 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup22 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem100 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem101 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem102 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup23 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem103 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem104 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem105 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup24 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem106 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem107 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem108 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup25 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem109 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem110 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem111 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem112 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem113 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup26 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem114 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem115 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup27 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem116 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem117 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem118 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem119 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup28 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem120 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem121 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem122 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraBars.Ribbon.ReduceOperation reduceOperation1 = new DevExpress.XtraBars.Ribbon.ReduceOperation();
            this.spreadsheetCommandBarSubItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarSubItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem34 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem35 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem36 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem37 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem38 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem39 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem40 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem41 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem42 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem43 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem44 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem45 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem46 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonGalleryDropDownItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown2 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.spreadsheetCommandBarButtonItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.changeFontNameItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem();
            this.repositoryItemFontEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemFontEdit();
            this.changeFontSizeItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem();
            this.repositoryItemSpreadsheetFontSizeEdit1 = new DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit();
            this.spreadsheetControl1 = new DevExpress.XtraSpreadsheet.SpreadsheetControl();
            this.spreadsheetCommandBarButtonItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.barButtonGroup2 = new DevExpress.XtraBars.BarButtonGroup();
            this.spreadsheetCommandBarCheckItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.barButtonGroup3 = new DevExpress.XtraBars.BarButtonGroup();
            this.spreadsheetCommandBarSubItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem17 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem18 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem19 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.changeBorderLineColorItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem();
            this.changeBorderLineStyleItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem();
            this.commandBarGalleryDropDown1 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.barButtonGroup4 = new DevExpress.XtraBars.BarButtonGroup();
            this.changeCellFillColorItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem();
            this.changeFontColorItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem();
            this.barButtonGroup5 = new DevExpress.XtraBars.BarButtonGroup();
            this.spreadsheetCommandBarCheckItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.barButtonGroup6 = new DevExpress.XtraBars.BarButtonGroup();
            this.spreadsheetCommandBarCheckItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.barButtonGroup7 = new DevExpress.XtraBars.BarButtonGroup();
            this.spreadsheetCommandBarButtonItem20 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem21 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarCheckItem11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarSubItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarCheckItem12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarButtonItem22 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem23 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem24 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.barButtonGroup8 = new DevExpress.XtraBars.BarButtonGroup();
            this.changeNumberFormatItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem();
            this.repositoryItemPopupGalleryEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit();
            this.barButtonGroup9 = new DevExpress.XtraBars.BarButtonGroup();
            this.spreadsheetCommandBarSubItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem25 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem26 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem27 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem28 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem29 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem30 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem31 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.barButtonGroup10 = new DevExpress.XtraBars.BarButtonGroup();
            this.spreadsheetCommandBarButtonItem32 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem33 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonGalleryDropDownItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown3 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown4 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonItem47 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem48 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.galleryFormatAsTableItem1 = new DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem();
            this.commandBarGalleryDropDown5 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.galleryChangeStyleItem1 = new DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem();
            this.spreadsheetCommandBarSubItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem49 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem50 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem51 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem52 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem53 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem54 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem55 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem56 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem57 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem58 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem59 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem60 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem61 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem62 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem63 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem64 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem65 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem66 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.changeSheetTabColorItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem();
            this.spreadsheetCommandBarButtonItem67 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarCheckItem13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarButtonItem68 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem69 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem70 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem71 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem72 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem73 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem74 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem75 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem76 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem77 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem78 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem79 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem80 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem81 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem82 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem83 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem84 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem85 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem86 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem87 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem88 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem89 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem90 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem91 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem92 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem93 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem94 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem95 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem96 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem97 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem98 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem99 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem100 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem101 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem102 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem103 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonGalleryDropDownItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown6 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown7 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown8 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown9 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown10 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown11 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown12 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonItem104 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem105 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.barButtonGroup11 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup12 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup13 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup14 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup15 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup16 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup17 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup18 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup19 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup20 = new DevExpress.XtraBars.BarButtonGroup();
            this.spreadsheetCommandBarSubItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.barStaticItem2 = new DevExpress.XtraBars.BarStaticItem();
            this.homeRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.HomeRibbonPage();
            this.editingRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.EditingRibbonPageGroup();
            this.spreadsheetBarController1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController();
            this.spreadsheetCommandBarButtonItem106 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem107 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem108 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpreadsheetFontSizeEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupGalleryEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spreadsheetBarController1)).BeginInit();
            this.SuspendLayout();
            // 
            // spreadsheetCommandBarSubItem4
            // 
            this.spreadsheetCommandBarSubItem4.CommandName = "ConditionalFormattingCommandGroup";
            this.spreadsheetCommandBarSubItem4.Id = 66;
            this.spreadsheetCommandBarSubItem4.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarSubItem5),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarSubItem6),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem2),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem3),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarSubItem7)});
            this.spreadsheetCommandBarSubItem4.Name = "spreadsheetCommandBarSubItem4";
            // 
            // spreadsheetCommandBarSubItem5
            // 
            this.spreadsheetCommandBarSubItem5.CommandName = "ConditionalFormattingHighlightCellsRuleCommandGroup";
            this.spreadsheetCommandBarSubItem5.Id = 74;
            this.spreadsheetCommandBarSubItem5.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem34),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem35),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem36),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem37),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem38),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem39),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem40)});
            this.spreadsheetCommandBarSubItem5.Name = "spreadsheetCommandBarSubItem5";
            // 
            // spreadsheetCommandBarButtonItem34
            // 
            this.spreadsheetCommandBarButtonItem34.CommandName = "ConditionalFormattingGreaterThanRuleCommand";
            this.spreadsheetCommandBarButtonItem34.Id = 67;
            this.spreadsheetCommandBarButtonItem34.Name = "spreadsheetCommandBarButtonItem34";
            this.spreadsheetCommandBarButtonItem34.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem35
            // 
            this.spreadsheetCommandBarButtonItem35.CommandName = "ConditionalFormattingLessThanRuleCommand";
            this.spreadsheetCommandBarButtonItem35.Id = 68;
            this.spreadsheetCommandBarButtonItem35.Name = "spreadsheetCommandBarButtonItem35";
            this.spreadsheetCommandBarButtonItem35.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem36
            // 
            this.spreadsheetCommandBarButtonItem36.CommandName = "ConditionalFormattingBetweenRuleCommand";
            this.spreadsheetCommandBarButtonItem36.Id = 69;
            this.spreadsheetCommandBarButtonItem36.Name = "spreadsheetCommandBarButtonItem36";
            this.spreadsheetCommandBarButtonItem36.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem37
            // 
            this.spreadsheetCommandBarButtonItem37.CommandName = "ConditionalFormattingEqualToRuleCommand";
            this.spreadsheetCommandBarButtonItem37.Id = 70;
            this.spreadsheetCommandBarButtonItem37.Name = "spreadsheetCommandBarButtonItem37";
            this.spreadsheetCommandBarButtonItem37.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem38
            // 
            this.spreadsheetCommandBarButtonItem38.CommandName = "ConditionalFormattingTextContainsRuleCommand";
            this.spreadsheetCommandBarButtonItem38.Id = 71;
            this.spreadsheetCommandBarButtonItem38.Name = "spreadsheetCommandBarButtonItem38";
            this.spreadsheetCommandBarButtonItem38.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem39
            // 
            this.spreadsheetCommandBarButtonItem39.CommandName = "ConditionalFormattingDateOccurringRuleCommand";
            this.spreadsheetCommandBarButtonItem39.Id = 72;
            this.spreadsheetCommandBarButtonItem39.Name = "spreadsheetCommandBarButtonItem39";
            this.spreadsheetCommandBarButtonItem39.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem40
            // 
            this.spreadsheetCommandBarButtonItem40.CommandName = "ConditionalFormattingDuplicateValuesRuleCommand";
            this.spreadsheetCommandBarButtonItem40.Id = 73;
            this.spreadsheetCommandBarButtonItem40.Name = "spreadsheetCommandBarButtonItem40";
            this.spreadsheetCommandBarButtonItem40.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarSubItem6
            // 
            this.spreadsheetCommandBarSubItem6.CommandName = "ConditionalFormattingTopBottomRuleCommandGroup";
            this.spreadsheetCommandBarSubItem6.Id = 81;
            this.spreadsheetCommandBarSubItem6.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem41),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem42),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem43),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem44),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem45),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem46)});
            this.spreadsheetCommandBarSubItem6.Name = "spreadsheetCommandBarSubItem6";
            // 
            // spreadsheetCommandBarButtonItem41
            // 
            this.spreadsheetCommandBarButtonItem41.CommandName = "ConditionalFormattingTop10RuleCommand";
            this.spreadsheetCommandBarButtonItem41.Id = 75;
            this.spreadsheetCommandBarButtonItem41.Name = "spreadsheetCommandBarButtonItem41";
            this.spreadsheetCommandBarButtonItem41.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem42
            // 
            this.spreadsheetCommandBarButtonItem42.CommandName = "ConditionalFormattingTop10PercentRuleCommand";
            this.spreadsheetCommandBarButtonItem42.Id = 76;
            this.spreadsheetCommandBarButtonItem42.Name = "spreadsheetCommandBarButtonItem42";
            this.spreadsheetCommandBarButtonItem42.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem43
            // 
            this.spreadsheetCommandBarButtonItem43.CommandName = "ConditionalFormattingBottom10RuleCommand";
            this.spreadsheetCommandBarButtonItem43.Id = 77;
            this.spreadsheetCommandBarButtonItem43.Name = "spreadsheetCommandBarButtonItem43";
            this.spreadsheetCommandBarButtonItem43.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem44
            // 
            this.spreadsheetCommandBarButtonItem44.CommandName = "ConditionalFormattingBottom10PercentRuleCommand";
            this.spreadsheetCommandBarButtonItem44.Id = 78;
            this.spreadsheetCommandBarButtonItem44.Name = "spreadsheetCommandBarButtonItem44";
            this.spreadsheetCommandBarButtonItem44.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem45
            // 
            this.spreadsheetCommandBarButtonItem45.CommandName = "ConditionalFormattingAboveAverageRuleCommand";
            this.spreadsheetCommandBarButtonItem45.Id = 79;
            this.spreadsheetCommandBarButtonItem45.Name = "spreadsheetCommandBarButtonItem45";
            this.spreadsheetCommandBarButtonItem45.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem46
            // 
            this.spreadsheetCommandBarButtonItem46.CommandName = "ConditionalFormattingBelowAverageRuleCommand";
            this.spreadsheetCommandBarButtonItem46.Id = 80;
            this.spreadsheetCommandBarButtonItem46.Name = "spreadsheetCommandBarButtonItem46";
            this.spreadsheetCommandBarButtonItem46.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem1
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.CommandName = "ConditionalFormattingDataBarsCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.DropDownControl = this.commandBarGalleryDropDown2;
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.Id = 82;
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.Name = "spreadsheetCommandBarButtonGalleryDropDownItem1";
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // commandBarGalleryDropDown2
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown2.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup1.CommandName = "ConditionalFormattingDataBarsGradientFillCommandGroup";
            spreadsheetCommandGalleryItem1.CommandName = "ConditionalFormattingDataBarGradientBlue";
            spreadsheetCommandGalleryItem2.CommandName = "ConditionalFormattingDataBarGradientGreen";
            spreadsheetCommandGalleryItem3.CommandName = "ConditionalFormattingDataBarGradientRed";
            spreadsheetCommandGalleryItem4.CommandName = "ConditionalFormattingDataBarGradientOrange";
            spreadsheetCommandGalleryItem5.CommandName = "ConditionalFormattingDataBarGradientLightBlue";
            spreadsheetCommandGalleryItem6.CommandName = "ConditionalFormattingDataBarGradientPurple";
            spreadsheetCommandGalleryItemGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem1,
            spreadsheetCommandGalleryItem2,
            spreadsheetCommandGalleryItem3,
            spreadsheetCommandGalleryItem4,
            spreadsheetCommandGalleryItem5,
            spreadsheetCommandGalleryItem6});
            spreadsheetCommandGalleryItemGroup2.CommandName = "ConditionalFormattingDataBarsSolidFillCommandGroup";
            spreadsheetCommandGalleryItem7.CommandName = "ConditionalFormattingDataBarSolidBlue";
            spreadsheetCommandGalleryItem8.CommandName = "ConditionalFormattingDataBarSolidGreen";
            spreadsheetCommandGalleryItem9.CommandName = "ConditionalFormattingDataBarSolidRed";
            spreadsheetCommandGalleryItem10.CommandName = "ConditionalFormattingDataBarSolidOrange";
            spreadsheetCommandGalleryItem11.CommandName = "ConditionalFormattingDataBarSolidLightBlue";
            spreadsheetCommandGalleryItem12.CommandName = "ConditionalFormattingDataBarSolidPurple";
            spreadsheetCommandGalleryItemGroup2.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem7,
            spreadsheetCommandGalleryItem8,
            spreadsheetCommandGalleryItem9,
            spreadsheetCommandGalleryItem10,
            spreadsheetCommandGalleryItem11,
            spreadsheetCommandGalleryItem12});
            this.commandBarGalleryDropDown2.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup1,
            spreadsheetCommandGalleryItemGroup2});
            this.commandBarGalleryDropDown2.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown2.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown2.Name = "commandBarGalleryDropDown2";
            this.commandBarGalleryDropDown2.Ribbon = this.ribbonControl1;
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.spreadsheetCommandBarButtonItem1,
            this.spreadsheetCommandBarButtonItem2,
            this.spreadsheetCommandBarButtonItem3,
            this.spreadsheetCommandBarButtonItem4,
            this.barButtonGroup1,
            this.changeFontNameItem1,
            this.changeFontSizeItem1,
            this.spreadsheetCommandBarButtonItem5,
            this.spreadsheetCommandBarButtonItem6,
            this.barButtonGroup2,
            this.spreadsheetCommandBarCheckItem1,
            this.spreadsheetCommandBarCheckItem2,
            this.spreadsheetCommandBarCheckItem3,
            this.spreadsheetCommandBarCheckItem4,
            this.barButtonGroup3,
            this.spreadsheetCommandBarSubItem1,
            this.spreadsheetCommandBarButtonItem7,
            this.spreadsheetCommandBarButtonItem8,
            this.spreadsheetCommandBarButtonItem9,
            this.spreadsheetCommandBarButtonItem10,
            this.spreadsheetCommandBarButtonItem11,
            this.spreadsheetCommandBarButtonItem12,
            this.spreadsheetCommandBarButtonItem13,
            this.spreadsheetCommandBarButtonItem14,
            this.spreadsheetCommandBarButtonItem15,
            this.spreadsheetCommandBarButtonItem16,
            this.spreadsheetCommandBarButtonItem17,
            this.spreadsheetCommandBarButtonItem18,
            this.spreadsheetCommandBarButtonItem19,
            this.changeBorderLineColorItem1,
            this.changeBorderLineStyleItem1,
            this.barButtonGroup4,
            this.changeCellFillColorItem1,
            this.changeFontColorItem1,
            this.barButtonGroup5,
            this.spreadsheetCommandBarCheckItem5,
            this.spreadsheetCommandBarCheckItem6,
            this.spreadsheetCommandBarCheckItem7,
            this.barButtonGroup6,
            this.spreadsheetCommandBarCheckItem8,
            this.spreadsheetCommandBarCheckItem9,
            this.spreadsheetCommandBarCheckItem10,
            this.barButtonGroup7,
            this.spreadsheetCommandBarButtonItem20,
            this.spreadsheetCommandBarButtonItem21,
            this.spreadsheetCommandBarCheckItem11,
            this.spreadsheetCommandBarSubItem2,
            this.spreadsheetCommandBarCheckItem12,
            this.spreadsheetCommandBarButtonItem22,
            this.spreadsheetCommandBarButtonItem23,
            this.spreadsheetCommandBarButtonItem24,
            this.barButtonGroup8,
            this.changeNumberFormatItem1,
            this.barButtonGroup9,
            this.spreadsheetCommandBarSubItem3,
            this.spreadsheetCommandBarButtonItem25,
            this.spreadsheetCommandBarButtonItem26,
            this.spreadsheetCommandBarButtonItem27,
            this.spreadsheetCommandBarButtonItem28,
            this.spreadsheetCommandBarButtonItem29,
            this.spreadsheetCommandBarButtonItem30,
            this.spreadsheetCommandBarButtonItem31,
            this.barButtonGroup10,
            this.spreadsheetCommandBarButtonItem32,
            this.spreadsheetCommandBarButtonItem33,
            this.spreadsheetCommandBarSubItem4,
            this.spreadsheetCommandBarButtonItem34,
            this.spreadsheetCommandBarButtonItem35,
            this.spreadsheetCommandBarButtonItem36,
            this.spreadsheetCommandBarButtonItem37,
            this.spreadsheetCommandBarButtonItem38,
            this.spreadsheetCommandBarButtonItem39,
            this.spreadsheetCommandBarButtonItem40,
            this.spreadsheetCommandBarSubItem5,
            this.spreadsheetCommandBarButtonItem41,
            this.spreadsheetCommandBarButtonItem42,
            this.spreadsheetCommandBarButtonItem43,
            this.spreadsheetCommandBarButtonItem44,
            this.spreadsheetCommandBarButtonItem45,
            this.spreadsheetCommandBarButtonItem46,
            this.spreadsheetCommandBarSubItem6,
            this.spreadsheetCommandBarButtonGalleryDropDownItem1,
            this.spreadsheetCommandBarButtonGalleryDropDownItem2,
            this.spreadsheetCommandBarButtonGalleryDropDownItem3,
            this.spreadsheetCommandBarButtonItem47,
            this.spreadsheetCommandBarButtonItem48,
            this.spreadsheetCommandBarSubItem7,
            this.galleryFormatAsTableItem1,
            this.galleryChangeStyleItem1,
            this.spreadsheetCommandBarSubItem8,
            this.spreadsheetCommandBarButtonItem49,
            this.spreadsheetCommandBarButtonItem50,
            this.spreadsheetCommandBarButtonItem51,
            this.spreadsheetCommandBarButtonItem52,
            this.spreadsheetCommandBarButtonItem53,
            this.spreadsheetCommandBarButtonItem54,
            this.spreadsheetCommandBarSubItem10,
            this.spreadsheetCommandBarButtonItem55,
            this.spreadsheetCommandBarButtonItem56,
            this.spreadsheetCommandBarButtonItem57,
            this.spreadsheetCommandBarButtonItem58,
            this.spreadsheetCommandBarButtonItem59,
            this.spreadsheetCommandBarButtonItem60,
            this.spreadsheetCommandBarButtonItem61,
            this.spreadsheetCommandBarButtonItem62,
            this.spreadsheetCommandBarButtonItem63,
            this.spreadsheetCommandBarButtonItem64,
            this.spreadsheetCommandBarButtonItem65,
            this.spreadsheetCommandBarSubItem11,
            this.spreadsheetCommandBarButtonItem66,
            this.changeSheetTabColorItem1,
            this.spreadsheetCommandBarButtonItem67,
            this.spreadsheetCommandBarCheckItem13,
            this.spreadsheetCommandBarButtonItem68,
            this.spreadsheetCommandBarSubItem12,
            this.spreadsheetCommandBarButtonItem69,
            this.spreadsheetCommandBarButtonItem70,
            this.spreadsheetCommandBarButtonItem71,
            this.spreadsheetCommandBarButtonItem72,
            this.spreadsheetCommandBarButtonItem73,
            this.spreadsheetCommandBarSubItem13,
            this.spreadsheetCommandBarButtonItem74,
            this.spreadsheetCommandBarButtonItem75,
            this.spreadsheetCommandBarButtonItem76,
            this.spreadsheetCommandBarButtonItem77,
            this.spreadsheetCommandBarSubItem14,
            this.spreadsheetCommandBarButtonItem78,
            this.spreadsheetCommandBarButtonItem79,
            this.spreadsheetCommandBarButtonItem80,
            this.spreadsheetCommandBarButtonItem81,
            this.spreadsheetCommandBarButtonItem82,
            this.spreadsheetCommandBarButtonItem83,
            this.spreadsheetCommandBarSubItem15,
            this.spreadsheetCommandBarButtonItem84,
            this.spreadsheetCommandBarButtonItem85,
            this.spreadsheetCommandBarSubItem16,
            this.spreadsheetCommandBarButtonItem86,
            this.spreadsheetCommandBarButtonItem87,
            this.spreadsheetCommandBarButtonItem88,
            this.spreadsheetCommandBarButtonItem89,
            this.spreadsheetCommandBarButtonItem90,
            this.spreadsheetCommandBarButtonItem91,
            this.spreadsheetCommandBarButtonItem92,
            this.spreadsheetCommandBarButtonItem93,
            this.spreadsheetCommandBarButtonItem94,
            this.spreadsheetCommandBarButtonItem95,
            this.spreadsheetCommandBarButtonItem96,
            this.spreadsheetCommandBarButtonItem97,
            this.spreadsheetCommandBarButtonItem98,
            this.spreadsheetCommandBarButtonItem99,
            this.spreadsheetCommandBarButtonItem100,
            this.spreadsheetCommandBarButtonItem101,
            this.spreadsheetCommandBarButtonItem102,
            this.spreadsheetCommandBarButtonItem103,
            this.spreadsheetCommandBarButtonGalleryDropDownItem4,
            this.spreadsheetCommandBarButtonGalleryDropDownItem5,
            this.spreadsheetCommandBarButtonGalleryDropDownItem6,
            this.spreadsheetCommandBarButtonGalleryDropDownItem7,
            this.spreadsheetCommandBarButtonGalleryDropDownItem8,
            this.spreadsheetCommandBarButtonGalleryDropDownItem9,
            this.spreadsheetCommandBarButtonGalleryDropDownItem10,
            this.spreadsheetCommandBarButtonItem104,
            this.spreadsheetCommandBarButtonItem105,
            this.barButtonGroup11,
            this.barButtonGroup12,
            this.barButtonGroup13,
            this.barButtonGroup14,
            this.barButtonGroup15,
            this.barButtonGroup16,
            this.barButtonGroup17,
            this.barButtonGroup18,
            this.barButtonGroup19,
            this.barButtonGroup20,
            this.spreadsheetCommandBarSubItem9,
            this.barStaticItem1,
            this.barStaticItem2});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 188;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.homeRibbonPage1});
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemFontEdit1,
            this.repositoryItemSpreadsheetFontSizeEdit1,
            this.repositoryItemPopupGalleryEdit1});
            this.ribbonControl1.Size = new System.Drawing.Size(752, 144);
            // 
            // spreadsheetCommandBarButtonItem1
            // 
            this.spreadsheetCommandBarButtonItem1.CommandName = "PasteSelection";
            this.spreadsheetCommandBarButtonItem1.Id = 11;
            this.spreadsheetCommandBarButtonItem1.Name = "spreadsheetCommandBarButtonItem1";
            this.spreadsheetCommandBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem2
            // 
            this.spreadsheetCommandBarButtonItem2.CommandName = "CutSelection";
            this.spreadsheetCommandBarButtonItem2.Id = 12;
            this.spreadsheetCommandBarButtonItem2.Name = "spreadsheetCommandBarButtonItem2";
            this.spreadsheetCommandBarButtonItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem3
            // 
            this.spreadsheetCommandBarButtonItem3.CommandName = "CopySelection";
            this.spreadsheetCommandBarButtonItem3.Id = 13;
            this.spreadsheetCommandBarButtonItem3.Name = "spreadsheetCommandBarButtonItem3";
            this.spreadsheetCommandBarButtonItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem4
            // 
            this.spreadsheetCommandBarButtonItem4.CommandName = "ShowPasteSpecialForm";
            this.spreadsheetCommandBarButtonItem4.Id = 14;
            this.spreadsheetCommandBarButtonItem4.Name = "spreadsheetCommandBarButtonItem4";
            this.spreadsheetCommandBarButtonItem4.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)((DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Id = 1;
            this.barButtonGroup1.ItemLinks.Add(this.changeFontNameItem1);
            this.barButtonGroup1.ItemLinks.Add(this.changeFontSizeItem1);
            this.barButtonGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem5);
            this.barButtonGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem6);
            this.barButtonGroup1.Name = "barButtonGroup1";
            this.barButtonGroup1.Tag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}";
            // 
            // changeFontNameItem1
            // 
            this.changeFontNameItem1.Edit = this.repositoryItemFontEdit1;
            this.changeFontNameItem1.Id = 15;
            this.changeFontNameItem1.Name = "changeFontNameItem1";
            // 
            // repositoryItemFontEdit1
            // 
            this.repositoryItemFontEdit1.AutoHeight = false;
            this.repositoryItemFontEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemFontEdit1.Name = "repositoryItemFontEdit1";
            // 
            // changeFontSizeItem1
            // 
            this.changeFontSizeItem1.Edit = this.repositoryItemSpreadsheetFontSizeEdit1;
            this.changeFontSizeItem1.Id = 16;
            this.changeFontSizeItem1.Name = "changeFontSizeItem1";
            // 
            // repositoryItemSpreadsheetFontSizeEdit1
            // 
            this.repositoryItemSpreadsheetFontSizeEdit1.AutoHeight = false;
            this.repositoryItemSpreadsheetFontSizeEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpreadsheetFontSizeEdit1.Control = this.spreadsheetControl1;
            this.repositoryItemSpreadsheetFontSizeEdit1.Name = "repositoryItemSpreadsheetFontSizeEdit1";
            // 
            // spreadsheetControl1
            // 
            this.spreadsheetControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spreadsheetControl1.Location = new System.Drawing.Point(0, 144);
            this.spreadsheetControl1.MenuManager = this.ribbonControl1;
            this.spreadsheetControl1.Name = "spreadsheetControl1";
            this.spreadsheetControl1.Size = new System.Drawing.Size(752, 323);
            this.spreadsheetControl1.TabIndex = 0;
            this.spreadsheetControl1.Text = "spreadsheetControl1";
            // 
            // spreadsheetCommandBarButtonItem5
            // 
            this.spreadsheetCommandBarButtonItem5.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}";
            this.spreadsheetCommandBarButtonItem5.CommandName = "FormatIncreaseFontSize";
            this.spreadsheetCommandBarButtonItem5.Id = 17;
            this.spreadsheetCommandBarButtonItem5.Name = "spreadsheetCommandBarButtonItem5";
            this.spreadsheetCommandBarButtonItem5.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem6
            // 
            this.spreadsheetCommandBarButtonItem6.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}";
            this.spreadsheetCommandBarButtonItem6.CommandName = "FormatDecreaseFontSize";
            this.spreadsheetCommandBarButtonItem6.Id = 18;
            this.spreadsheetCommandBarButtonItem6.Name = "spreadsheetCommandBarButtonItem6";
            this.spreadsheetCommandBarButtonItem6.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // barButtonGroup2
            // 
            this.barButtonGroup2.Id = 2;
            this.barButtonGroup2.ItemLinks.Add(this.spreadsheetCommandBarCheckItem1);
            this.barButtonGroup2.ItemLinks.Add(this.spreadsheetCommandBarCheckItem2);
            this.barButtonGroup2.ItemLinks.Add(this.spreadsheetCommandBarCheckItem3);
            this.barButtonGroup2.ItemLinks.Add(this.spreadsheetCommandBarCheckItem4);
            this.barButtonGroup2.Name = "barButtonGroup2";
            this.barButtonGroup2.Tag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            // 
            // spreadsheetCommandBarCheckItem1
            // 
            this.spreadsheetCommandBarCheckItem1.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            this.spreadsheetCommandBarCheckItem1.CommandName = "FormatFontBold";
            this.spreadsheetCommandBarCheckItem1.Id = 19;
            this.spreadsheetCommandBarCheckItem1.Name = "spreadsheetCommandBarCheckItem1";
            this.spreadsheetCommandBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem2
            // 
            this.spreadsheetCommandBarCheckItem2.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            this.spreadsheetCommandBarCheckItem2.CommandName = "FormatFontItalic";
            this.spreadsheetCommandBarCheckItem2.Id = 20;
            this.spreadsheetCommandBarCheckItem2.Name = "spreadsheetCommandBarCheckItem2";
            this.spreadsheetCommandBarCheckItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem3
            // 
            this.spreadsheetCommandBarCheckItem3.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            this.spreadsheetCommandBarCheckItem3.CommandName = "FormatFontUnderline";
            this.spreadsheetCommandBarCheckItem3.Id = 21;
            this.spreadsheetCommandBarCheckItem3.Name = "spreadsheetCommandBarCheckItem3";
            this.spreadsheetCommandBarCheckItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem4
            // 
            this.spreadsheetCommandBarCheckItem4.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            this.spreadsheetCommandBarCheckItem4.CommandName = "FormatFontStrikeout";
            this.spreadsheetCommandBarCheckItem4.Id = 22;
            this.spreadsheetCommandBarCheckItem4.Name = "spreadsheetCommandBarCheckItem4";
            this.spreadsheetCommandBarCheckItem4.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // barButtonGroup3
            // 
            this.barButtonGroup3.Id = 3;
            this.barButtonGroup3.ItemLinks.Add(this.spreadsheetCommandBarSubItem1);
            this.barButtonGroup3.Name = "barButtonGroup3";
            this.barButtonGroup3.Tag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}";
            // 
            // spreadsheetCommandBarSubItem1
            // 
            this.spreadsheetCommandBarSubItem1.ButtonGroupTag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}";
            this.spreadsheetCommandBarSubItem1.CommandName = "FormatBordersCommandGroup";
            this.spreadsheetCommandBarSubItem1.Id = 23;
            this.spreadsheetCommandBarSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem7),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem8),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem9),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem10),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem11),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem12),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem13),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem14),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem15),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem16),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem17),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem18),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem19),
            new DevExpress.XtraBars.LinkPersistInfo(this.changeBorderLineColorItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.changeBorderLineStyleItem1)});
            this.spreadsheetCommandBarSubItem1.Name = "spreadsheetCommandBarSubItem1";
            this.spreadsheetCommandBarSubItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem7
            // 
            this.spreadsheetCommandBarButtonItem7.CommandName = "FormatBottomBorder";
            this.spreadsheetCommandBarButtonItem7.Id = 24;
            this.spreadsheetCommandBarButtonItem7.Name = "spreadsheetCommandBarButtonItem7";
            // 
            // spreadsheetCommandBarButtonItem8
            // 
            this.spreadsheetCommandBarButtonItem8.CommandName = "FormatTopBorder";
            this.spreadsheetCommandBarButtonItem8.Id = 25;
            this.spreadsheetCommandBarButtonItem8.Name = "spreadsheetCommandBarButtonItem8";
            // 
            // spreadsheetCommandBarButtonItem9
            // 
            this.spreadsheetCommandBarButtonItem9.CommandName = "FormatLeftBorder";
            this.spreadsheetCommandBarButtonItem9.Id = 26;
            this.spreadsheetCommandBarButtonItem9.Name = "spreadsheetCommandBarButtonItem9";
            // 
            // spreadsheetCommandBarButtonItem10
            // 
            this.spreadsheetCommandBarButtonItem10.CommandName = "FormatRightBorder";
            this.spreadsheetCommandBarButtonItem10.Id = 27;
            this.spreadsheetCommandBarButtonItem10.Name = "spreadsheetCommandBarButtonItem10";
            // 
            // spreadsheetCommandBarButtonItem11
            // 
            this.spreadsheetCommandBarButtonItem11.CommandName = "FormatNoBorders";
            this.spreadsheetCommandBarButtonItem11.Id = 28;
            this.spreadsheetCommandBarButtonItem11.Name = "spreadsheetCommandBarButtonItem11";
            // 
            // spreadsheetCommandBarButtonItem12
            // 
            this.spreadsheetCommandBarButtonItem12.CommandName = "FormatAllBorders";
            this.spreadsheetCommandBarButtonItem12.Id = 29;
            this.spreadsheetCommandBarButtonItem12.Name = "spreadsheetCommandBarButtonItem12";
            // 
            // spreadsheetCommandBarButtonItem13
            // 
            this.spreadsheetCommandBarButtonItem13.CommandName = "FormatOutsideBorders";
            this.spreadsheetCommandBarButtonItem13.Id = 30;
            this.spreadsheetCommandBarButtonItem13.Name = "spreadsheetCommandBarButtonItem13";
            // 
            // spreadsheetCommandBarButtonItem14
            // 
            this.spreadsheetCommandBarButtonItem14.CommandName = "FormatThickBorder";
            this.spreadsheetCommandBarButtonItem14.Id = 31;
            this.spreadsheetCommandBarButtonItem14.Name = "spreadsheetCommandBarButtonItem14";
            // 
            // spreadsheetCommandBarButtonItem15
            // 
            this.spreadsheetCommandBarButtonItem15.CommandName = "FormatBottomDoubleBorder";
            this.spreadsheetCommandBarButtonItem15.Id = 32;
            this.spreadsheetCommandBarButtonItem15.Name = "spreadsheetCommandBarButtonItem15";
            // 
            // spreadsheetCommandBarButtonItem16
            // 
            this.spreadsheetCommandBarButtonItem16.CommandName = "FormatBottomThickBorder";
            this.spreadsheetCommandBarButtonItem16.Id = 33;
            this.spreadsheetCommandBarButtonItem16.Name = "spreadsheetCommandBarButtonItem16";
            // 
            // spreadsheetCommandBarButtonItem17
            // 
            this.spreadsheetCommandBarButtonItem17.CommandName = "FormatTopAndBottomBorder";
            this.spreadsheetCommandBarButtonItem17.Id = 34;
            this.spreadsheetCommandBarButtonItem17.Name = "spreadsheetCommandBarButtonItem17";
            // 
            // spreadsheetCommandBarButtonItem18
            // 
            this.spreadsheetCommandBarButtonItem18.CommandName = "FormatTopAndThickBottomBorder";
            this.spreadsheetCommandBarButtonItem18.Id = 35;
            this.spreadsheetCommandBarButtonItem18.Name = "spreadsheetCommandBarButtonItem18";
            // 
            // spreadsheetCommandBarButtonItem19
            // 
            this.spreadsheetCommandBarButtonItem19.CommandName = "FormatTopAndDoubleBottomBorder";
            this.spreadsheetCommandBarButtonItem19.Id = 36;
            this.spreadsheetCommandBarButtonItem19.Name = "spreadsheetCommandBarButtonItem19";
            // 
            // changeBorderLineColorItem1
            // 
            this.changeBorderLineColorItem1.ActAsDropDown = true;
            this.changeBorderLineColorItem1.Id = 37;
            this.changeBorderLineColorItem1.Name = "changeBorderLineColorItem1";
            // 
            // changeBorderLineStyleItem1
            // 
            this.changeBorderLineStyleItem1.DropDownControl = this.commandBarGalleryDropDown1;
            this.changeBorderLineStyleItem1.Id = 38;
            this.changeBorderLineStyleItem1.Name = "changeBorderLineStyleItem1";
            // 
            // commandBarGalleryDropDown1
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown1.Gallery.AllowFilter = false;
            this.commandBarGalleryDropDown1.Gallery.ColumnCount = 1;
            this.commandBarGalleryDropDown1.Gallery.DrawImageBackground = false;
            this.commandBarGalleryDropDown1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.commandBarGalleryDropDown1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None;
            this.commandBarGalleryDropDown1.Gallery.ItemSize = new System.Drawing.Size(136, 26);
            this.commandBarGalleryDropDown1.Gallery.RowCount = 14;
            this.commandBarGalleryDropDown1.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown1.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown1.Name = "commandBarGalleryDropDown1";
            this.commandBarGalleryDropDown1.Ribbon = this.ribbonControl1;
            // 
            // barButtonGroup4
            // 
            this.barButtonGroup4.Id = 4;
            this.barButtonGroup4.ItemLinks.Add(this.changeCellFillColorItem1);
            this.barButtonGroup4.ItemLinks.Add(this.changeFontColorItem1);
            this.barButtonGroup4.Name = "barButtonGroup4";
            this.barButtonGroup4.Tag = "{C2275623-04A3-41E8-8D6A-EB5C7F8541D1}";
            // 
            // changeCellFillColorItem1
            // 
            this.changeCellFillColorItem1.Id = 39;
            this.changeCellFillColorItem1.Name = "changeCellFillColorItem1";
            // 
            // changeFontColorItem1
            // 
            this.changeFontColorItem1.Id = 40;
            this.changeFontColorItem1.Name = "changeFontColorItem1";
            // 
            // barButtonGroup5
            // 
            this.barButtonGroup5.Id = 5;
            this.barButtonGroup5.ItemLinks.Add(this.spreadsheetCommandBarCheckItem5);
            this.barButtonGroup5.ItemLinks.Add(this.spreadsheetCommandBarCheckItem6);
            this.barButtonGroup5.ItemLinks.Add(this.spreadsheetCommandBarCheckItem7);
            this.barButtonGroup5.Name = "barButtonGroup5";
            this.barButtonGroup5.Tag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}";
            // 
            // spreadsheetCommandBarCheckItem5
            // 
            this.spreadsheetCommandBarCheckItem5.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}";
            this.spreadsheetCommandBarCheckItem5.CommandName = "FormatAlignmentTop";
            this.spreadsheetCommandBarCheckItem5.Id = 41;
            this.spreadsheetCommandBarCheckItem5.Name = "spreadsheetCommandBarCheckItem5";
            this.spreadsheetCommandBarCheckItem5.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem6
            // 
            this.spreadsheetCommandBarCheckItem6.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}";
            this.spreadsheetCommandBarCheckItem6.CommandName = "FormatAlignmentMiddle";
            this.spreadsheetCommandBarCheckItem6.Id = 42;
            this.spreadsheetCommandBarCheckItem6.Name = "spreadsheetCommandBarCheckItem6";
            this.spreadsheetCommandBarCheckItem6.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem7
            // 
            this.spreadsheetCommandBarCheckItem7.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}";
            this.spreadsheetCommandBarCheckItem7.CommandName = "FormatAlignmentBottom";
            this.spreadsheetCommandBarCheckItem7.Id = 43;
            this.spreadsheetCommandBarCheckItem7.Name = "spreadsheetCommandBarCheckItem7";
            this.spreadsheetCommandBarCheckItem7.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // barButtonGroup6
            // 
            this.barButtonGroup6.Id = 6;
            this.barButtonGroup6.ItemLinks.Add(this.spreadsheetCommandBarCheckItem8);
            this.barButtonGroup6.ItemLinks.Add(this.spreadsheetCommandBarCheckItem9);
            this.barButtonGroup6.ItemLinks.Add(this.spreadsheetCommandBarCheckItem10);
            this.barButtonGroup6.Name = "barButtonGroup6";
            this.barButtonGroup6.Tag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}";
            // 
            // spreadsheetCommandBarCheckItem8
            // 
            this.spreadsheetCommandBarCheckItem8.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}";
            this.spreadsheetCommandBarCheckItem8.CommandName = "FormatAlignmentLeft";
            this.spreadsheetCommandBarCheckItem8.Id = 44;
            this.spreadsheetCommandBarCheckItem8.Name = "spreadsheetCommandBarCheckItem8";
            this.spreadsheetCommandBarCheckItem8.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem9
            // 
            this.spreadsheetCommandBarCheckItem9.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}";
            this.spreadsheetCommandBarCheckItem9.CommandName = "FormatAlignmentCenter";
            this.spreadsheetCommandBarCheckItem9.Id = 45;
            this.spreadsheetCommandBarCheckItem9.Name = "spreadsheetCommandBarCheckItem9";
            this.spreadsheetCommandBarCheckItem9.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem10
            // 
            this.spreadsheetCommandBarCheckItem10.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}";
            this.spreadsheetCommandBarCheckItem10.CommandName = "FormatAlignmentRight";
            this.spreadsheetCommandBarCheckItem10.Id = 46;
            this.spreadsheetCommandBarCheckItem10.Name = "spreadsheetCommandBarCheckItem10";
            this.spreadsheetCommandBarCheckItem10.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // barButtonGroup7
            // 
            this.barButtonGroup7.Id = 7;
            this.barButtonGroup7.ItemLinks.Add(this.spreadsheetCommandBarButtonItem20);
            this.barButtonGroup7.ItemLinks.Add(this.spreadsheetCommandBarButtonItem21);
            this.barButtonGroup7.Name = "barButtonGroup7";
            this.barButtonGroup7.Tag = "{A5E37DED-106E-44FC-8044-CE3824C08225}";
            // 
            // spreadsheetCommandBarButtonItem20
            // 
            this.spreadsheetCommandBarButtonItem20.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}";
            this.spreadsheetCommandBarButtonItem20.CommandName = "FormatDecreaseIndent";
            this.spreadsheetCommandBarButtonItem20.Id = 47;
            this.spreadsheetCommandBarButtonItem20.Name = "spreadsheetCommandBarButtonItem20";
            this.spreadsheetCommandBarButtonItem20.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem21
            // 
            this.spreadsheetCommandBarButtonItem21.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}";
            this.spreadsheetCommandBarButtonItem21.CommandName = "FormatIncreaseIndent";
            this.spreadsheetCommandBarButtonItem21.Id = 48;
            this.spreadsheetCommandBarButtonItem21.Name = "spreadsheetCommandBarButtonItem21";
            this.spreadsheetCommandBarButtonItem21.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem11
            // 
            this.spreadsheetCommandBarCheckItem11.CommandName = "FormatWrapText";
            this.spreadsheetCommandBarCheckItem11.Id = 49;
            this.spreadsheetCommandBarCheckItem11.Name = "spreadsheetCommandBarCheckItem11";
            this.spreadsheetCommandBarCheckItem11.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarSubItem2
            // 
            this.spreadsheetCommandBarSubItem2.CommandName = "EditingMergeCellsCommandGroup";
            this.spreadsheetCommandBarSubItem2.Id = 50;
            this.spreadsheetCommandBarSubItem2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem12),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem22),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem23),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem24)});
            this.spreadsheetCommandBarSubItem2.Name = "spreadsheetCommandBarSubItem2";
            this.spreadsheetCommandBarSubItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarCheckItem12
            // 
            this.spreadsheetCommandBarCheckItem12.CommandName = "EditingMergeAndCenterCells";
            this.spreadsheetCommandBarCheckItem12.Id = 51;
            this.spreadsheetCommandBarCheckItem12.Name = "spreadsheetCommandBarCheckItem12";
            // 
            // spreadsheetCommandBarButtonItem22
            // 
            this.spreadsheetCommandBarButtonItem22.CommandName = "EditingMergeCellsAcross";
            this.spreadsheetCommandBarButtonItem22.Id = 52;
            this.spreadsheetCommandBarButtonItem22.Name = "spreadsheetCommandBarButtonItem22";
            // 
            // spreadsheetCommandBarButtonItem23
            // 
            this.spreadsheetCommandBarButtonItem23.CommandName = "EditingMergeCells";
            this.spreadsheetCommandBarButtonItem23.Id = 53;
            this.spreadsheetCommandBarButtonItem23.Name = "spreadsheetCommandBarButtonItem23";
            // 
            // spreadsheetCommandBarButtonItem24
            // 
            this.spreadsheetCommandBarButtonItem24.CommandName = "EditingUnmergeCells";
            this.spreadsheetCommandBarButtonItem24.Id = 54;
            this.spreadsheetCommandBarButtonItem24.Name = "spreadsheetCommandBarButtonItem24";
            // 
            // barButtonGroup8
            // 
            this.barButtonGroup8.Id = 8;
            this.barButtonGroup8.ItemLinks.Add(this.changeNumberFormatItem1);
            this.barButtonGroup8.Name = "barButtonGroup8";
            this.barButtonGroup8.Tag = "{0B3A7A43-3079-4ce0-83A8-3789F5F6DC9F}";
            // 
            // changeNumberFormatItem1
            // 
            this.changeNumberFormatItem1.Edit = this.repositoryItemPopupGalleryEdit1;
            this.changeNumberFormatItem1.Id = 55;
            this.changeNumberFormatItem1.Name = "changeNumberFormatItem1";
            // 
            // repositoryItemPopupGalleryEdit1
            // 
            this.repositoryItemPopupGalleryEdit1.AutoHeight = false;
            this.repositoryItemPopupGalleryEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            // 
            // 
            // 
            this.repositoryItemPopupGalleryEdit1.Gallery.AllowFilter = false;
            this.repositoryItemPopupGalleryEdit1.Gallery.AutoFitColumns = false;
            this.repositoryItemPopupGalleryEdit1.Gallery.ColumnCount = 1;
            this.repositoryItemPopupGalleryEdit1.Gallery.FixedImageSize = false;
            spreadsheetCommandGalleryItem13.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem13.CaptionAsValue = true;
            spreadsheetCommandGalleryItem13.CommandName = "FormatNumberGeneral";
            spreadsheetCommandGalleryItem13.IsEmptyHint = true;
            spreadsheetCommandGalleryItem14.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem14.CaptionAsValue = true;
            spreadsheetCommandGalleryItem14.CommandName = "FormatNumberDecimal";
            spreadsheetCommandGalleryItem14.IsEmptyHint = true;
            spreadsheetCommandGalleryItem15.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem15.CaptionAsValue = true;
            spreadsheetCommandGalleryItem15.CommandName = "FormatNumberAccountingCurrency";
            spreadsheetCommandGalleryItem15.IsEmptyHint = true;
            spreadsheetCommandGalleryItem16.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem16.CaptionAsValue = true;
            spreadsheetCommandGalleryItem16.CommandName = "FormatNumberAccountingRegular";
            spreadsheetCommandGalleryItem16.IsEmptyHint = true;
            spreadsheetCommandGalleryItem17.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem17.CaptionAsValue = true;
            spreadsheetCommandGalleryItem17.CommandName = "FormatNumberShortDate";
            spreadsheetCommandGalleryItem17.IsEmptyHint = true;
            spreadsheetCommandGalleryItem18.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem18.CaptionAsValue = true;
            spreadsheetCommandGalleryItem18.CommandName = "FormatNumberLongDate";
            spreadsheetCommandGalleryItem18.IsEmptyHint = true;
            spreadsheetCommandGalleryItem19.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem19.CaptionAsValue = true;
            spreadsheetCommandGalleryItem19.CommandName = "FormatNumberTime";
            spreadsheetCommandGalleryItem19.IsEmptyHint = true;
            spreadsheetCommandGalleryItem20.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem20.CaptionAsValue = true;
            spreadsheetCommandGalleryItem20.CommandName = "FormatNumberPercentage";
            spreadsheetCommandGalleryItem20.IsEmptyHint = true;
            spreadsheetCommandGalleryItem21.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem21.CaptionAsValue = true;
            spreadsheetCommandGalleryItem21.CommandName = "FormatNumberFraction";
            spreadsheetCommandGalleryItem21.IsEmptyHint = true;
            spreadsheetCommandGalleryItem22.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem22.CaptionAsValue = true;
            spreadsheetCommandGalleryItem22.CommandName = "FormatNumberScientific";
            spreadsheetCommandGalleryItem22.IsEmptyHint = true;
            spreadsheetCommandGalleryItem23.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem23.CaptionAsValue = true;
            spreadsheetCommandGalleryItem23.CommandName = "FormatNumberText";
            spreadsheetCommandGalleryItem23.IsEmptyHint = true;
            galleryItemGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem13,
            spreadsheetCommandGalleryItem14,
            spreadsheetCommandGalleryItem15,
            spreadsheetCommandGalleryItem16,
            spreadsheetCommandGalleryItem17,
            spreadsheetCommandGalleryItem18,
            spreadsheetCommandGalleryItem19,
            spreadsheetCommandGalleryItem20,
            spreadsheetCommandGalleryItem21,
            spreadsheetCommandGalleryItem22,
            spreadsheetCommandGalleryItem23});
            this.repositoryItemPopupGalleryEdit1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup1});
            this.repositoryItemPopupGalleryEdit1.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.repositoryItemPopupGalleryEdit1.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.repositoryItemPopupGalleryEdit1.Gallery.RowCount = 11;
            this.repositoryItemPopupGalleryEdit1.Gallery.ShowGroupCaption = false;
            this.repositoryItemPopupGalleryEdit1.Gallery.ShowItemText = true;
            this.repositoryItemPopupGalleryEdit1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Hide;
            this.repositoryItemPopupGalleryEdit1.Gallery.StretchItems = true;
            this.repositoryItemPopupGalleryEdit1.Name = "repositoryItemPopupGalleryEdit1";
            this.repositoryItemPopupGalleryEdit1.ShowButtons = false;
            this.repositoryItemPopupGalleryEdit1.ShowPopupCloseButton = false;
            this.repositoryItemPopupGalleryEdit1.ShowSizeGrip = false;
            // 
            // barButtonGroup9
            // 
            this.barButtonGroup9.Id = 9;
            this.barButtonGroup9.ItemLinks.Add(this.spreadsheetCommandBarSubItem3);
            this.barButtonGroup9.ItemLinks.Add(this.spreadsheetCommandBarButtonItem30);
            this.barButtonGroup9.ItemLinks.Add(this.spreadsheetCommandBarButtonItem31);
            this.barButtonGroup9.Name = "barButtonGroup9";
            this.barButtonGroup9.Tag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}";
            // 
            // spreadsheetCommandBarSubItem3
            // 
            this.spreadsheetCommandBarSubItem3.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}";
            this.spreadsheetCommandBarSubItem3.CommandName = "FormatNumberAccountingCommandGroup";
            this.spreadsheetCommandBarSubItem3.Id = 56;
            this.spreadsheetCommandBarSubItem3.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem25),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem26),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem27),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem28),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem29)});
            this.spreadsheetCommandBarSubItem3.Name = "spreadsheetCommandBarSubItem3";
            this.spreadsheetCommandBarSubItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem25
            // 
            this.spreadsheetCommandBarButtonItem25.CommandName = "FormatNumberAccountingUS";
            this.spreadsheetCommandBarButtonItem25.Id = 57;
            this.spreadsheetCommandBarButtonItem25.Name = "spreadsheetCommandBarButtonItem25";
            // 
            // spreadsheetCommandBarButtonItem26
            // 
            this.spreadsheetCommandBarButtonItem26.CommandName = "FormatNumberAccountingUK";
            this.spreadsheetCommandBarButtonItem26.Id = 58;
            this.spreadsheetCommandBarButtonItem26.Name = "spreadsheetCommandBarButtonItem26";
            // 
            // spreadsheetCommandBarButtonItem27
            // 
            this.spreadsheetCommandBarButtonItem27.CommandName = "FormatNumberAccountingEuro";
            this.spreadsheetCommandBarButtonItem27.Id = 59;
            this.spreadsheetCommandBarButtonItem27.Name = "spreadsheetCommandBarButtonItem27";
            // 
            // spreadsheetCommandBarButtonItem28
            // 
            this.spreadsheetCommandBarButtonItem28.CommandName = "FormatNumberAccountingPRC";
            this.spreadsheetCommandBarButtonItem28.Id = 60;
            this.spreadsheetCommandBarButtonItem28.Name = "spreadsheetCommandBarButtonItem28";
            // 
            // spreadsheetCommandBarButtonItem29
            // 
            this.spreadsheetCommandBarButtonItem29.CommandName = "FormatNumberAccountingSwiss";
            this.spreadsheetCommandBarButtonItem29.Id = 61;
            this.spreadsheetCommandBarButtonItem29.Name = "spreadsheetCommandBarButtonItem29";
            // 
            // spreadsheetCommandBarButtonItem30
            // 
            this.spreadsheetCommandBarButtonItem30.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}";
            this.spreadsheetCommandBarButtonItem30.CommandName = "FormatNumberPercent";
            this.spreadsheetCommandBarButtonItem30.Id = 62;
            this.spreadsheetCommandBarButtonItem30.Name = "spreadsheetCommandBarButtonItem30";
            this.spreadsheetCommandBarButtonItem30.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem31
            // 
            this.spreadsheetCommandBarButtonItem31.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}";
            this.spreadsheetCommandBarButtonItem31.CommandName = "FormatNumberAccounting";
            this.spreadsheetCommandBarButtonItem31.Id = 63;
            this.spreadsheetCommandBarButtonItem31.Name = "spreadsheetCommandBarButtonItem31";
            this.spreadsheetCommandBarButtonItem31.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // barButtonGroup10
            // 
            this.barButtonGroup10.Id = 10;
            this.barButtonGroup10.ItemLinks.Add(this.spreadsheetCommandBarButtonItem32);
            this.barButtonGroup10.ItemLinks.Add(this.spreadsheetCommandBarButtonItem33);
            this.barButtonGroup10.Name = "barButtonGroup10";
            this.barButtonGroup10.Tag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}";
            // 
            // spreadsheetCommandBarButtonItem32
            // 
            this.spreadsheetCommandBarButtonItem32.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}";
            this.spreadsheetCommandBarButtonItem32.CommandName = "FormatNumberIncreaseDecimal";
            this.spreadsheetCommandBarButtonItem32.Id = 64;
            this.spreadsheetCommandBarButtonItem32.Name = "spreadsheetCommandBarButtonItem32";
            this.spreadsheetCommandBarButtonItem32.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem33
            // 
            this.spreadsheetCommandBarButtonItem33.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}";
            this.spreadsheetCommandBarButtonItem33.CommandName = "FormatNumberDecreaseDecimal";
            this.spreadsheetCommandBarButtonItem33.Id = 65;
            this.spreadsheetCommandBarButtonItem33.Name = "spreadsheetCommandBarButtonItem33";
            this.spreadsheetCommandBarButtonItem33.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem2
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.CommandName = "ConditionalFormattingColorScalesCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.DropDownControl = this.commandBarGalleryDropDown3;
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.Id = 83;
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.Name = "spreadsheetCommandBarButtonGalleryDropDownItem2";
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // commandBarGalleryDropDown3
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown3.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup3.CommandName = "ConditionalFormattingColorScalesCommandGroup";
            spreadsheetCommandGalleryItem24.CommandName = "ConditionalFormattingColorScaleGreenYellowRed";
            spreadsheetCommandGalleryItem25.CommandName = "ConditionalFormattingColorScaleRedYellowGreen";
            spreadsheetCommandGalleryItem26.CommandName = "ConditionalFormattingColorScaleGreenWhiteRed";
            spreadsheetCommandGalleryItem27.CommandName = "ConditionalFormattingColorScaleRedWhiteGreen";
            spreadsheetCommandGalleryItem28.CommandName = "ConditionalFormattingColorScaleBlueWhiteRed";
            spreadsheetCommandGalleryItem29.CommandName = "ConditionalFormattingColorScaleRedWhiteBlue";
            spreadsheetCommandGalleryItem30.CommandName = "ConditionalFormattingColorScaleWhiteRed";
            spreadsheetCommandGalleryItem31.CommandName = "ConditionalFormattingColorScaleRedWhite";
            spreadsheetCommandGalleryItem32.CommandName = "ConditionalFormattingColorScaleGreenWhite";
            spreadsheetCommandGalleryItem33.CommandName = "ConditionalFormattingColorScaleWhiteGreen";
            spreadsheetCommandGalleryItem34.CommandName = "ConditionalFormattingColorScaleGreenYellow";
            spreadsheetCommandGalleryItem35.CommandName = "ConditionalFormattingColorScaleYellowGreen";
            spreadsheetCommandGalleryItemGroup3.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem24,
            spreadsheetCommandGalleryItem25,
            spreadsheetCommandGalleryItem26,
            spreadsheetCommandGalleryItem27,
            spreadsheetCommandGalleryItem28,
            spreadsheetCommandGalleryItem29,
            spreadsheetCommandGalleryItem30,
            spreadsheetCommandGalleryItem31,
            spreadsheetCommandGalleryItem32,
            spreadsheetCommandGalleryItem33,
            spreadsheetCommandGalleryItem34,
            spreadsheetCommandGalleryItem35});
            this.commandBarGalleryDropDown3.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup3});
            this.commandBarGalleryDropDown3.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown3.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown3.Name = "commandBarGalleryDropDown3";
            this.commandBarGalleryDropDown3.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem3
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.CommandName = "ConditionalFormattingIconSetsCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.DropDownControl = this.commandBarGalleryDropDown4;
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.Id = 84;
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.Name = "spreadsheetCommandBarButtonGalleryDropDownItem3";
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // commandBarGalleryDropDown4
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown4.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup4.CommandName = "ConditionalFormattingIconSetsDirectionalCommandGroup";
            spreadsheetCommandGalleryItem36.CommandName = "ConditionalFormattingIconSetArrows3Colored";
            spreadsheetCommandGalleryItem37.CommandName = "ConditionalFormattingIconSetArrows3Grayed";
            spreadsheetCommandGalleryItem38.CommandName = "ConditionalFormattingIconSetArrows4Colored";
            spreadsheetCommandGalleryItem39.CommandName = "ConditionalFormattingIconSetArrows4Grayed";
            spreadsheetCommandGalleryItem40.CommandName = "ConditionalFormattingIconSetArrows5Colored";
            spreadsheetCommandGalleryItem41.CommandName = "ConditionalFormattingIconSetArrows5Grayed";
            spreadsheetCommandGalleryItem42.CommandName = "ConditionalFormattingIconSetTriangles3";
            spreadsheetCommandGalleryItemGroup4.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem36,
            spreadsheetCommandGalleryItem37,
            spreadsheetCommandGalleryItem38,
            spreadsheetCommandGalleryItem39,
            spreadsheetCommandGalleryItem40,
            spreadsheetCommandGalleryItem41,
            spreadsheetCommandGalleryItem42});
            spreadsheetCommandGalleryItemGroup5.CommandName = "ConditionalFormattingIconSetsShapesCommandGroup";
            spreadsheetCommandGalleryItem43.CommandName = "ConditionalFormattingIconSetTrafficLights3";
            spreadsheetCommandGalleryItem44.CommandName = "ConditionalFormattingIconSetTrafficLights3Rimmed";
            spreadsheetCommandGalleryItem45.CommandName = "ConditionalFormattingIconSetTrafficLights4";
            spreadsheetCommandGalleryItem46.CommandName = "ConditionalFormattingIconSetSigns3";
            spreadsheetCommandGalleryItem47.CommandName = "ConditionalFormattingIconSetRedToBlack";
            spreadsheetCommandGalleryItemGroup5.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem43,
            spreadsheetCommandGalleryItem44,
            spreadsheetCommandGalleryItem45,
            spreadsheetCommandGalleryItem46,
            spreadsheetCommandGalleryItem47});
            spreadsheetCommandGalleryItemGroup6.CommandName = "ConditionalFormattingIconSetsIndicatorsCommandGroup";
            spreadsheetCommandGalleryItem48.CommandName = "ConditionalFormattingIconSetSymbols3Circled";
            spreadsheetCommandGalleryItem49.CommandName = "ConditionalFormattingIconSetSymbols3";
            spreadsheetCommandGalleryItem50.CommandName = "ConditionalFormattingIconSetFlags3";
            spreadsheetCommandGalleryItemGroup6.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem48,
            spreadsheetCommandGalleryItem49,
            spreadsheetCommandGalleryItem50});
            spreadsheetCommandGalleryItemGroup7.CommandName = "ConditionalFormattingIconSetsRatingsCommandGroup";
            spreadsheetCommandGalleryItem51.CommandName = "ConditionalFormattingIconSetStars3";
            spreadsheetCommandGalleryItem52.CommandName = "ConditionalFormattingIconSetRatings4";
            spreadsheetCommandGalleryItem53.CommandName = "ConditionalFormattingIconSetRatings5";
            spreadsheetCommandGalleryItem54.CommandName = "ConditionalFormattingIconSetQuarters5";
            spreadsheetCommandGalleryItem55.CommandName = "ConditionalFormattingIconSetBoxes5";
            spreadsheetCommandGalleryItemGroup7.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem51,
            spreadsheetCommandGalleryItem52,
            spreadsheetCommandGalleryItem53,
            spreadsheetCommandGalleryItem54,
            spreadsheetCommandGalleryItem55});
            this.commandBarGalleryDropDown4.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup4,
            spreadsheetCommandGalleryItemGroup5,
            spreadsheetCommandGalleryItemGroup6,
            spreadsheetCommandGalleryItemGroup7});
            this.commandBarGalleryDropDown4.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown4.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown4.Name = "commandBarGalleryDropDown4";
            this.commandBarGalleryDropDown4.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonItem47
            // 
            this.spreadsheetCommandBarButtonItem47.CommandName = "ConditionalFormattingRemoveFromSheet";
            this.spreadsheetCommandBarButtonItem47.Id = 85;
            this.spreadsheetCommandBarButtonItem47.Name = "spreadsheetCommandBarButtonItem47";
            // 
            // spreadsheetCommandBarButtonItem48
            // 
            this.spreadsheetCommandBarButtonItem48.CommandName = "ConditionalFormattingRemove";
            this.spreadsheetCommandBarButtonItem48.Id = 86;
            this.spreadsheetCommandBarButtonItem48.Name = "spreadsheetCommandBarButtonItem48";
            // 
            // spreadsheetCommandBarSubItem7
            // 
            this.spreadsheetCommandBarSubItem7.CommandName = "ConditionalFormattingRemoveCommandGroup";
            this.spreadsheetCommandBarSubItem7.Id = 87;
            this.spreadsheetCommandBarSubItem7.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem47),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem48)});
            this.spreadsheetCommandBarSubItem7.Name = "spreadsheetCommandBarSubItem7";
            // 
            // galleryFormatAsTableItem1
            // 
            this.galleryFormatAsTableItem1.DropDownControl = this.commandBarGalleryDropDown5;
            this.galleryFormatAsTableItem1.Id = 88;
            this.galleryFormatAsTableItem1.Name = "galleryFormatAsTableItem1";
            // 
            // commandBarGalleryDropDown5
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown5.Gallery.AllowFilter = false;
            this.commandBarGalleryDropDown5.Gallery.ColumnCount = 7;
            this.commandBarGalleryDropDown5.Gallery.DrawImageBackground = false;
            this.commandBarGalleryDropDown5.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None;
            this.commandBarGalleryDropDown5.Gallery.ItemSize = new System.Drawing.Size(73, 58);
            this.commandBarGalleryDropDown5.Gallery.RowCount = 10;
            this.commandBarGalleryDropDown5.Name = "commandBarGalleryDropDown5";
            this.commandBarGalleryDropDown5.Ribbon = this.ribbonControl1;
            // 
            // galleryChangeStyleItem1
            // 
            // 
            // 
            // 
            this.galleryChangeStyleItem1.Gallery.DrawImageBackground = false;
            this.galleryChangeStyleItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.galleryChangeStyleItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None;
            this.galleryChangeStyleItem1.Gallery.ItemSize = new System.Drawing.Size(106, 28);
            this.galleryChangeStyleItem1.Gallery.RowCount = 9;
            this.galleryChangeStyleItem1.Gallery.ShowItemText = true;
            this.galleryChangeStyleItem1.Id = 89;
            this.galleryChangeStyleItem1.Name = "galleryChangeStyleItem1";
            // 
            // spreadsheetCommandBarSubItem8
            // 
            this.spreadsheetCommandBarSubItem8.CommandName = "InsertCellsCommandGroup";
            this.spreadsheetCommandBarSubItem8.Id = 90;
            this.spreadsheetCommandBarSubItem8.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem49),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem50),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem51)});
            this.spreadsheetCommandBarSubItem8.Name = "spreadsheetCommandBarSubItem8";
            // 
            // spreadsheetCommandBarButtonItem49
            // 
            this.spreadsheetCommandBarButtonItem49.CommandName = "InsertSheetRows";
            this.spreadsheetCommandBarButtonItem49.Id = 91;
            this.spreadsheetCommandBarButtonItem49.Name = "spreadsheetCommandBarButtonItem49";
            // 
            // spreadsheetCommandBarButtonItem50
            // 
            this.spreadsheetCommandBarButtonItem50.CommandName = "InsertSheetColumns";
            this.spreadsheetCommandBarButtonItem50.Id = 92;
            this.spreadsheetCommandBarButtonItem50.Name = "spreadsheetCommandBarButtonItem50";
            // 
            // spreadsheetCommandBarButtonItem51
            // 
            this.spreadsheetCommandBarButtonItem51.CommandName = "InsertSheet";
            this.spreadsheetCommandBarButtonItem51.Id = 93;
            this.spreadsheetCommandBarButtonItem51.Name = "spreadsheetCommandBarButtonItem51";
            // 
            // spreadsheetCommandBarButtonItem52
            // 
            this.spreadsheetCommandBarButtonItem52.CommandName = "RemoveSheetRows";
            this.spreadsheetCommandBarButtonItem52.Id = 95;
            this.spreadsheetCommandBarButtonItem52.Name = "spreadsheetCommandBarButtonItem52";
            // 
            // spreadsheetCommandBarButtonItem53
            // 
            this.spreadsheetCommandBarButtonItem53.CommandName = "RemoveSheetColumns";
            this.spreadsheetCommandBarButtonItem53.Id = 96;
            this.spreadsheetCommandBarButtonItem53.Name = "spreadsheetCommandBarButtonItem53";
            // 
            // spreadsheetCommandBarButtonItem54
            // 
            this.spreadsheetCommandBarButtonItem54.CommandName = "RemoveSheet";
            this.spreadsheetCommandBarButtonItem54.Id = 97;
            this.spreadsheetCommandBarButtonItem54.Name = "spreadsheetCommandBarButtonItem54";
            // 
            // spreadsheetCommandBarSubItem10
            // 
            this.spreadsheetCommandBarSubItem10.CommandName = "FormatCommandGroup";
            this.spreadsheetCommandBarSubItem10.Id = 98;
            this.spreadsheetCommandBarSubItem10.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem55),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem56),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem57),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem58),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem59),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarSubItem11),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem66),
            new DevExpress.XtraBars.LinkPersistInfo(this.changeSheetTabColorItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem67),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem13),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem68)});
            this.spreadsheetCommandBarSubItem10.Name = "spreadsheetCommandBarSubItem10";
            // 
            // spreadsheetCommandBarButtonItem55
            // 
            this.spreadsheetCommandBarButtonItem55.CommandName = "FormatRowHeight";
            this.spreadsheetCommandBarButtonItem55.Id = 99;
            this.spreadsheetCommandBarButtonItem55.Name = "spreadsheetCommandBarButtonItem55";
            // 
            // spreadsheetCommandBarButtonItem56
            // 
            this.spreadsheetCommandBarButtonItem56.CommandName = "FormatAutoFitRowHeight";
            this.spreadsheetCommandBarButtonItem56.Id = 100;
            this.spreadsheetCommandBarButtonItem56.Name = "spreadsheetCommandBarButtonItem56";
            // 
            // spreadsheetCommandBarButtonItem57
            // 
            this.spreadsheetCommandBarButtonItem57.CommandName = "FormatColumnWidth";
            this.spreadsheetCommandBarButtonItem57.Id = 101;
            this.spreadsheetCommandBarButtonItem57.Name = "spreadsheetCommandBarButtonItem57";
            // 
            // spreadsheetCommandBarButtonItem58
            // 
            this.spreadsheetCommandBarButtonItem58.CommandName = "FormatAutoFitColumnWidth";
            this.spreadsheetCommandBarButtonItem58.Id = 102;
            this.spreadsheetCommandBarButtonItem58.Name = "spreadsheetCommandBarButtonItem58";
            // 
            // spreadsheetCommandBarButtonItem59
            // 
            this.spreadsheetCommandBarButtonItem59.CommandName = "FormatDefaultColumnWidth";
            this.spreadsheetCommandBarButtonItem59.Id = 103;
            this.spreadsheetCommandBarButtonItem59.Name = "spreadsheetCommandBarButtonItem59";
            // 
            // spreadsheetCommandBarSubItem11
            // 
            this.spreadsheetCommandBarSubItem11.CommandName = "HideAndUnhideCommandGroup";
            this.spreadsheetCommandBarSubItem11.Id = 110;
            this.spreadsheetCommandBarSubItem11.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem60),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem61),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem62),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem63),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem64),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem65)});
            this.spreadsheetCommandBarSubItem11.Name = "spreadsheetCommandBarSubItem11";
            // 
            // spreadsheetCommandBarButtonItem60
            // 
            this.spreadsheetCommandBarButtonItem60.CommandName = "HideRows";
            this.spreadsheetCommandBarButtonItem60.Id = 104;
            this.spreadsheetCommandBarButtonItem60.Name = "spreadsheetCommandBarButtonItem60";
            // 
            // spreadsheetCommandBarButtonItem61
            // 
            this.spreadsheetCommandBarButtonItem61.CommandName = "HideColumns";
            this.spreadsheetCommandBarButtonItem61.Id = 105;
            this.spreadsheetCommandBarButtonItem61.Name = "spreadsheetCommandBarButtonItem61";
            // 
            // spreadsheetCommandBarButtonItem62
            // 
            this.spreadsheetCommandBarButtonItem62.CommandName = "HideSheet";
            this.spreadsheetCommandBarButtonItem62.Id = 106;
            this.spreadsheetCommandBarButtonItem62.Name = "spreadsheetCommandBarButtonItem62";
            // 
            // spreadsheetCommandBarButtonItem63
            // 
            this.spreadsheetCommandBarButtonItem63.CommandName = "UnhideRows";
            this.spreadsheetCommandBarButtonItem63.Id = 107;
            this.spreadsheetCommandBarButtonItem63.Name = "spreadsheetCommandBarButtonItem63";
            // 
            // spreadsheetCommandBarButtonItem64
            // 
            this.spreadsheetCommandBarButtonItem64.CommandName = "UnhideColumns";
            this.spreadsheetCommandBarButtonItem64.Id = 108;
            this.spreadsheetCommandBarButtonItem64.Name = "spreadsheetCommandBarButtonItem64";
            // 
            // spreadsheetCommandBarButtonItem65
            // 
            this.spreadsheetCommandBarButtonItem65.CommandName = "UnhideSheet";
            this.spreadsheetCommandBarButtonItem65.Id = 109;
            this.spreadsheetCommandBarButtonItem65.Name = "spreadsheetCommandBarButtonItem65";
            // 
            // spreadsheetCommandBarButtonItem66
            // 
            this.spreadsheetCommandBarButtonItem66.CommandName = "RenameSheet";
            this.spreadsheetCommandBarButtonItem66.Id = 111;
            this.spreadsheetCommandBarButtonItem66.Name = "spreadsheetCommandBarButtonItem66";
            // 
            // changeSheetTabColorItem1
            // 
            this.changeSheetTabColorItem1.ActAsDropDown = true;
            this.changeSheetTabColorItem1.Id = 112;
            this.changeSheetTabColorItem1.Name = "changeSheetTabColorItem1";
            // 
            // spreadsheetCommandBarButtonItem67
            // 
            this.spreadsheetCommandBarButtonItem67.CommandName = "ReviewProtectSheet";
            this.spreadsheetCommandBarButtonItem67.Id = 113;
            this.spreadsheetCommandBarButtonItem67.Name = "spreadsheetCommandBarButtonItem67";
            // 
            // spreadsheetCommandBarCheckItem13
            // 
            this.spreadsheetCommandBarCheckItem13.CommandName = "FormatCellLocked";
            this.spreadsheetCommandBarCheckItem13.Id = 114;
            this.spreadsheetCommandBarCheckItem13.Name = "spreadsheetCommandBarCheckItem13";
            // 
            // spreadsheetCommandBarButtonItem68
            // 
            this.spreadsheetCommandBarButtonItem68.CommandName = "FormatCellsContextMenuItem";
            this.spreadsheetCommandBarButtonItem68.Id = 115;
            this.spreadsheetCommandBarButtonItem68.Name = "spreadsheetCommandBarButtonItem68";
            // 
            // spreadsheetCommandBarSubItem12
            // 
            this.spreadsheetCommandBarSubItem12.CommandName = "EditingAutoSumCommandGroup";
            this.spreadsheetCommandBarSubItem12.Id = 116;
            this.spreadsheetCommandBarSubItem12.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem69),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem70),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem71),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem72),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem73)});
            this.spreadsheetCommandBarSubItem12.Name = "spreadsheetCommandBarSubItem12";
            this.spreadsheetCommandBarSubItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem69
            // 
            this.spreadsheetCommandBarButtonItem69.CommandName = "FunctionsInsertSum";
            this.spreadsheetCommandBarButtonItem69.Id = 117;
            this.spreadsheetCommandBarButtonItem69.Name = "spreadsheetCommandBarButtonItem69";
            // 
            // spreadsheetCommandBarButtonItem70
            // 
            this.spreadsheetCommandBarButtonItem70.CommandName = "FunctionsInsertAverage";
            this.spreadsheetCommandBarButtonItem70.Id = 118;
            this.spreadsheetCommandBarButtonItem70.Name = "spreadsheetCommandBarButtonItem70";
            // 
            // spreadsheetCommandBarButtonItem71
            // 
            this.spreadsheetCommandBarButtonItem71.CommandName = "FunctionsInsertCountNumbers";
            this.spreadsheetCommandBarButtonItem71.Id = 119;
            this.spreadsheetCommandBarButtonItem71.Name = "spreadsheetCommandBarButtonItem71";
            // 
            // spreadsheetCommandBarButtonItem72
            // 
            this.spreadsheetCommandBarButtonItem72.CommandName = "FunctionsInsertMax";
            this.spreadsheetCommandBarButtonItem72.Id = 120;
            this.spreadsheetCommandBarButtonItem72.Name = "spreadsheetCommandBarButtonItem72";
            // 
            // spreadsheetCommandBarButtonItem73
            // 
            this.spreadsheetCommandBarButtonItem73.CommandName = "FunctionsInsertMin";
            this.spreadsheetCommandBarButtonItem73.Id = 121;
            this.spreadsheetCommandBarButtonItem73.Name = "spreadsheetCommandBarButtonItem73";
            // 
            // spreadsheetCommandBarSubItem13
            // 
            this.spreadsheetCommandBarSubItem13.CommandName = "EditingFillCommandGroup";
            this.spreadsheetCommandBarSubItem13.Id = 122;
            this.spreadsheetCommandBarSubItem13.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem74),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem75),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem76),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem77)});
            this.spreadsheetCommandBarSubItem13.Name = "spreadsheetCommandBarSubItem13";
            this.spreadsheetCommandBarSubItem13.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText)));
            // 
            // spreadsheetCommandBarButtonItem74
            // 
            this.spreadsheetCommandBarButtonItem74.CommandName = "EditingFillDown";
            this.spreadsheetCommandBarButtonItem74.Id = 123;
            this.spreadsheetCommandBarButtonItem74.Name = "spreadsheetCommandBarButtonItem74";
            // 
            // spreadsheetCommandBarButtonItem75
            // 
            this.spreadsheetCommandBarButtonItem75.CommandName = "EditingFillRight";
            this.spreadsheetCommandBarButtonItem75.Id = 124;
            this.spreadsheetCommandBarButtonItem75.Name = "spreadsheetCommandBarButtonItem75";
            // 
            // spreadsheetCommandBarButtonItem76
            // 
            this.spreadsheetCommandBarButtonItem76.CommandName = "EditingFillUp";
            this.spreadsheetCommandBarButtonItem76.Id = 125;
            this.spreadsheetCommandBarButtonItem76.Name = "spreadsheetCommandBarButtonItem76";
            // 
            // spreadsheetCommandBarButtonItem77
            // 
            this.spreadsheetCommandBarButtonItem77.CommandName = "EditingFillLeft";
            this.spreadsheetCommandBarButtonItem77.Id = 126;
            this.spreadsheetCommandBarButtonItem77.Name = "spreadsheetCommandBarButtonItem77";
            // 
            // spreadsheetCommandBarSubItem14
            // 
            this.spreadsheetCommandBarSubItem14.CommandName = "FormatClearCommandGroup";
            this.spreadsheetCommandBarSubItem14.Id = 127;
            this.spreadsheetCommandBarSubItem14.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem78),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem79),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem80),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem81),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem82),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem83)});
            this.spreadsheetCommandBarSubItem14.Name = "spreadsheetCommandBarSubItem14";
            this.spreadsheetCommandBarSubItem14.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem78
            // 
            this.spreadsheetCommandBarButtonItem78.CommandName = "FormatClearAll";
            this.spreadsheetCommandBarButtonItem78.Id = 128;
            this.spreadsheetCommandBarButtonItem78.Name = "spreadsheetCommandBarButtonItem78";
            // 
            // spreadsheetCommandBarButtonItem79
            // 
            this.spreadsheetCommandBarButtonItem79.CommandName = "FormatClearFormats";
            this.spreadsheetCommandBarButtonItem79.Id = 129;
            this.spreadsheetCommandBarButtonItem79.Name = "spreadsheetCommandBarButtonItem79";
            // 
            // spreadsheetCommandBarButtonItem80
            // 
            this.spreadsheetCommandBarButtonItem80.CommandName = "FormatClearContents";
            this.spreadsheetCommandBarButtonItem80.Id = 130;
            this.spreadsheetCommandBarButtonItem80.Name = "spreadsheetCommandBarButtonItem80";
            // 
            // spreadsheetCommandBarButtonItem81
            // 
            this.spreadsheetCommandBarButtonItem81.CommandName = "FormatClearComments";
            this.spreadsheetCommandBarButtonItem81.Id = 131;
            this.spreadsheetCommandBarButtonItem81.Name = "spreadsheetCommandBarButtonItem81";
            // 
            // spreadsheetCommandBarButtonItem82
            // 
            this.spreadsheetCommandBarButtonItem82.CommandName = "FormatClearHyperlinks";
            this.spreadsheetCommandBarButtonItem82.Id = 132;
            this.spreadsheetCommandBarButtonItem82.Name = "spreadsheetCommandBarButtonItem82";
            // 
            // spreadsheetCommandBarButtonItem83
            // 
            this.spreadsheetCommandBarButtonItem83.CommandName = "FormatRemoveHyperlinks";
            this.spreadsheetCommandBarButtonItem83.Id = 133;
            this.spreadsheetCommandBarButtonItem83.Name = "spreadsheetCommandBarButtonItem83";
            // 
            // spreadsheetCommandBarSubItem15
            // 
            this.spreadsheetCommandBarSubItem15.CommandName = "EditingSortAndFilterCommandGroup";
            this.spreadsheetCommandBarSubItem15.Id = 134;
            this.spreadsheetCommandBarSubItem15.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem84),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem85)});
            this.spreadsheetCommandBarSubItem15.Name = "spreadsheetCommandBarSubItem15";
            // 
            // spreadsheetCommandBarButtonItem84
            // 
            this.spreadsheetCommandBarButtonItem84.CommandName = "DataSortAscending";
            this.spreadsheetCommandBarButtonItem84.Id = 135;
            this.spreadsheetCommandBarButtonItem84.Name = "spreadsheetCommandBarButtonItem84";
            // 
            // spreadsheetCommandBarButtonItem85
            // 
            this.spreadsheetCommandBarButtonItem85.CommandName = "DataSortDescending";
            this.spreadsheetCommandBarButtonItem85.Id = 136;
            this.spreadsheetCommandBarButtonItem85.Name = "spreadsheetCommandBarButtonItem85";
            // 
            // spreadsheetCommandBarSubItem16
            // 
            this.spreadsheetCommandBarSubItem16.CommandName = "EditingFindAndSelectCommandGroup";
            this.spreadsheetCommandBarSubItem16.Id = 137;
            this.spreadsheetCommandBarSubItem16.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem86),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem87),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem88),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem89),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem90),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem91),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem92)});
            this.spreadsheetCommandBarSubItem16.Name = "spreadsheetCommandBarSubItem16";
            // 
            // spreadsheetCommandBarButtonItem86
            // 
            this.spreadsheetCommandBarButtonItem86.CommandName = "EditingFind";
            this.spreadsheetCommandBarButtonItem86.Id = 138;
            this.spreadsheetCommandBarButtonItem86.Name = "spreadsheetCommandBarButtonItem86";
            // 
            // spreadsheetCommandBarButtonItem87
            // 
            this.spreadsheetCommandBarButtonItem87.CommandName = "EditingReplace";
            this.spreadsheetCommandBarButtonItem87.Id = 139;
            this.spreadsheetCommandBarButtonItem87.Name = "spreadsheetCommandBarButtonItem87";
            // 
            // spreadsheetCommandBarButtonItem88
            // 
            this.spreadsheetCommandBarButtonItem88.CommandName = "EditingSelectFormulas";
            this.spreadsheetCommandBarButtonItem88.Id = 140;
            this.spreadsheetCommandBarButtonItem88.Name = "spreadsheetCommandBarButtonItem88";
            // 
            // spreadsheetCommandBarButtonItem89
            // 
            this.spreadsheetCommandBarButtonItem89.CommandName = "EditingSelectComments";
            this.spreadsheetCommandBarButtonItem89.Id = 141;
            this.spreadsheetCommandBarButtonItem89.Name = "spreadsheetCommandBarButtonItem89";
            // 
            // spreadsheetCommandBarButtonItem90
            // 
            this.spreadsheetCommandBarButtonItem90.CommandName = "EditingSelectConditionalFormatting";
            this.spreadsheetCommandBarButtonItem90.Id = 142;
            this.spreadsheetCommandBarButtonItem90.Name = "spreadsheetCommandBarButtonItem90";
            // 
            // spreadsheetCommandBarButtonItem91
            // 
            this.spreadsheetCommandBarButtonItem91.CommandName = "EditingSelectConstants";
            this.spreadsheetCommandBarButtonItem91.Id = 143;
            this.spreadsheetCommandBarButtonItem91.Name = "spreadsheetCommandBarButtonItem91";
            // 
            // spreadsheetCommandBarButtonItem92
            // 
            this.spreadsheetCommandBarButtonItem92.CommandName = "EditingSelectDataValidation";
            this.spreadsheetCommandBarButtonItem92.Id = 144;
            this.spreadsheetCommandBarButtonItem92.Name = "spreadsheetCommandBarButtonItem92";
            // 
            // spreadsheetCommandBarButtonItem93
            // 
            this.spreadsheetCommandBarButtonItem93.CommandName = "FileNew";
            this.spreadsheetCommandBarButtonItem93.Id = 146;
            this.spreadsheetCommandBarButtonItem93.Name = "spreadsheetCommandBarButtonItem93";
            // 
            // spreadsheetCommandBarButtonItem94
            // 
            this.spreadsheetCommandBarButtonItem94.CommandName = "FileOpen";
            this.spreadsheetCommandBarButtonItem94.Id = 147;
            this.spreadsheetCommandBarButtonItem94.Name = "spreadsheetCommandBarButtonItem94";
            // 
            // spreadsheetCommandBarButtonItem95
            // 
            this.spreadsheetCommandBarButtonItem95.CommandName = "FileSave";
            this.spreadsheetCommandBarButtonItem95.Id = 148;
            this.spreadsheetCommandBarButtonItem95.Name = "spreadsheetCommandBarButtonItem95";
            // 
            // spreadsheetCommandBarButtonItem96
            // 
            this.spreadsheetCommandBarButtonItem96.CommandName = "FileSaveAs";
            this.spreadsheetCommandBarButtonItem96.Id = 149;
            this.spreadsheetCommandBarButtonItem96.Name = "spreadsheetCommandBarButtonItem96";
            // 
            // spreadsheetCommandBarButtonItem97
            // 
            this.spreadsheetCommandBarButtonItem97.CommandName = "FileQuickPrint";
            this.spreadsheetCommandBarButtonItem97.Id = 150;
            this.spreadsheetCommandBarButtonItem97.Name = "spreadsheetCommandBarButtonItem97";
            // 
            // spreadsheetCommandBarButtonItem98
            // 
            this.spreadsheetCommandBarButtonItem98.CommandName = "FilePrint";
            this.spreadsheetCommandBarButtonItem98.Id = 151;
            this.spreadsheetCommandBarButtonItem98.Name = "spreadsheetCommandBarButtonItem98";
            // 
            // spreadsheetCommandBarButtonItem99
            // 
            this.spreadsheetCommandBarButtonItem99.CommandName = "FilePrintPreview";
            this.spreadsheetCommandBarButtonItem99.Id = 152;
            this.spreadsheetCommandBarButtonItem99.Name = "spreadsheetCommandBarButtonItem99";
            // 
            // spreadsheetCommandBarButtonItem100
            // 
            this.spreadsheetCommandBarButtonItem100.CommandName = "FileUndo";
            this.spreadsheetCommandBarButtonItem100.Id = 153;
            this.spreadsheetCommandBarButtonItem100.Name = "spreadsheetCommandBarButtonItem100";
            // 
            // spreadsheetCommandBarButtonItem101
            // 
            this.spreadsheetCommandBarButtonItem101.CommandName = "FileRedo";
            this.spreadsheetCommandBarButtonItem101.Id = 154;
            this.spreadsheetCommandBarButtonItem101.Name = "spreadsheetCommandBarButtonItem101";
            // 
            // spreadsheetCommandBarButtonItem102
            // 
            this.spreadsheetCommandBarButtonItem102.CommandName = "InsertTable";
            this.spreadsheetCommandBarButtonItem102.Id = 155;
            this.spreadsheetCommandBarButtonItem102.Name = "spreadsheetCommandBarButtonItem102";
            // 
            // spreadsheetCommandBarButtonItem103
            // 
            this.spreadsheetCommandBarButtonItem103.CommandName = "InsertPicture";
            this.spreadsheetCommandBarButtonItem103.Id = 156;
            this.spreadsheetCommandBarButtonItem103.Name = "spreadsheetCommandBarButtonItem103";
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem4
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem4.CommandName = "InsertChartColumnCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem4.DropDownControl = this.commandBarGalleryDropDown6;
            this.spreadsheetCommandBarButtonGalleryDropDownItem4.Id = 157;
            this.spreadsheetCommandBarButtonGalleryDropDownItem4.Name = "spreadsheetCommandBarButtonGalleryDropDownItem4";
            // 
            // commandBarGalleryDropDown6
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown6.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup8.CommandName = "InsertChartColumn2DCommandGroup";
            spreadsheetCommandGalleryItem56.CommandName = "InsertChartColumnClustered2D";
            spreadsheetCommandGalleryItem57.CommandName = "InsertChartColumnStacked2D";
            spreadsheetCommandGalleryItem58.CommandName = "InsertChartColumnPercentStacked2D";
            spreadsheetCommandGalleryItemGroup8.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem56,
            spreadsheetCommandGalleryItem57,
            spreadsheetCommandGalleryItem58});
            spreadsheetCommandGalleryItemGroup9.CommandName = "InsertChartColumn3DCommandGroup";
            spreadsheetCommandGalleryItem59.CommandName = "InsertChartColumnClustered3D";
            spreadsheetCommandGalleryItem60.CommandName = "InsertChartColumnStacked3D";
            spreadsheetCommandGalleryItem61.CommandName = "InsertChartColumnPercentStacked3D";
            spreadsheetCommandGalleryItem62.CommandName = "InsertChartColumn3D";
            spreadsheetCommandGalleryItemGroup9.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem59,
            spreadsheetCommandGalleryItem60,
            spreadsheetCommandGalleryItem61,
            spreadsheetCommandGalleryItem62});
            spreadsheetCommandGalleryItemGroup10.CommandName = "InsertChartCylinderCommandGroup";
            spreadsheetCommandGalleryItem63.CommandName = "InsertChartCylinderClustered";
            spreadsheetCommandGalleryItem64.CommandName = "InsertChartCylinderStacked";
            spreadsheetCommandGalleryItem65.CommandName = "InsertChartCylinderPercentStacked";
            spreadsheetCommandGalleryItem66.CommandName = "InsertChartCylinder";
            spreadsheetCommandGalleryItemGroup10.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem63,
            spreadsheetCommandGalleryItem64,
            spreadsheetCommandGalleryItem65,
            spreadsheetCommandGalleryItem66});
            spreadsheetCommandGalleryItemGroup11.CommandName = "InsertChartConeCommandGroup";
            spreadsheetCommandGalleryItem67.CommandName = "InsertChartConeClustered";
            spreadsheetCommandGalleryItem68.CommandName = "InsertChartConeStacked";
            spreadsheetCommandGalleryItem69.CommandName = "InsertChartConePercentStacked";
            spreadsheetCommandGalleryItem70.CommandName = "InsertChartCone";
            spreadsheetCommandGalleryItemGroup11.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem67,
            spreadsheetCommandGalleryItem68,
            spreadsheetCommandGalleryItem69,
            spreadsheetCommandGalleryItem70});
            spreadsheetCommandGalleryItemGroup12.CommandName = "InsertChartPyramidCommandGroup";
            spreadsheetCommandGalleryItem71.CommandName = "InsertChartPyramidClustered";
            spreadsheetCommandGalleryItem72.CommandName = "InsertChartPyramidStacked";
            spreadsheetCommandGalleryItem73.CommandName = "InsertChartPyramidPercentStacked";
            spreadsheetCommandGalleryItem74.CommandName = "InsertChartPyramid";
            spreadsheetCommandGalleryItemGroup12.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem71,
            spreadsheetCommandGalleryItem72,
            spreadsheetCommandGalleryItem73,
            spreadsheetCommandGalleryItem74});
            this.commandBarGalleryDropDown6.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup8,
            spreadsheetCommandGalleryItemGroup9,
            spreadsheetCommandGalleryItemGroup10,
            spreadsheetCommandGalleryItemGroup11,
            spreadsheetCommandGalleryItemGroup12});
            this.commandBarGalleryDropDown6.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown6.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown6.Name = "commandBarGalleryDropDown6";
            this.commandBarGalleryDropDown6.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem5
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem5.CommandName = "InsertChartLineCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem5.DropDownControl = this.commandBarGalleryDropDown7;
            this.spreadsheetCommandBarButtonGalleryDropDownItem5.Id = 158;
            this.spreadsheetCommandBarButtonGalleryDropDownItem5.Name = "spreadsheetCommandBarButtonGalleryDropDownItem5";
            // 
            // commandBarGalleryDropDown7
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown7.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup13.CommandName = "InsertChartLine2DCommandGroup";
            spreadsheetCommandGalleryItem75.CommandName = "InsertChartLine";
            spreadsheetCommandGalleryItem76.CommandName = "InsertChartStackedLine";
            spreadsheetCommandGalleryItem77.CommandName = "InsertChartPercentStackedLine";
            spreadsheetCommandGalleryItem78.CommandName = "InsertChartLineWithMarkers";
            spreadsheetCommandGalleryItem79.CommandName = "InsertChartStackedLineWithMarkers";
            spreadsheetCommandGalleryItem80.CommandName = "InsertChartPercentStackedLineWithMarkers";
            spreadsheetCommandGalleryItemGroup13.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem75,
            spreadsheetCommandGalleryItem76,
            spreadsheetCommandGalleryItem77,
            spreadsheetCommandGalleryItem78,
            spreadsheetCommandGalleryItem79,
            spreadsheetCommandGalleryItem80});
            spreadsheetCommandGalleryItemGroup14.CommandName = "InsertChartLine3DCommandGroup";
            spreadsheetCommandGalleryItem81.CommandName = "InsertChartLine3D";
            spreadsheetCommandGalleryItemGroup14.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem81});
            this.commandBarGalleryDropDown7.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup13,
            spreadsheetCommandGalleryItemGroup14});
            this.commandBarGalleryDropDown7.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown7.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown7.Name = "commandBarGalleryDropDown7";
            this.commandBarGalleryDropDown7.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem6
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem6.CommandName = "InsertChartPieCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem6.DropDownControl = this.commandBarGalleryDropDown8;
            this.spreadsheetCommandBarButtonGalleryDropDownItem6.Id = 159;
            this.spreadsheetCommandBarButtonGalleryDropDownItem6.Name = "spreadsheetCommandBarButtonGalleryDropDownItem6";
            // 
            // commandBarGalleryDropDown8
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown8.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup15.CommandName = "InsertChartPie2DCommandGroup";
            spreadsheetCommandGalleryItem82.CommandName = "InsertChartPie2D";
            spreadsheetCommandGalleryItem83.CommandName = "InsertChartPieExploded2D";
            spreadsheetCommandGalleryItemGroup15.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem82,
            spreadsheetCommandGalleryItem83});
            spreadsheetCommandGalleryItemGroup16.CommandName = "InsertChartPie3DCommandGroup";
            spreadsheetCommandGalleryItem84.CommandName = "InsertChartPie3D";
            spreadsheetCommandGalleryItem85.CommandName = "InsertChartPieExploded3D";
            spreadsheetCommandGalleryItemGroup16.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem84,
            spreadsheetCommandGalleryItem85});
            spreadsheetCommandGalleryItemGroup17.CommandName = "InsertChartDoughnut2DCommandGroup";
            spreadsheetCommandGalleryItem86.CommandName = "InsertChartDoughnut2D";
            spreadsheetCommandGalleryItem87.CommandName = "InsertChartDoughnutExploded2D";
            spreadsheetCommandGalleryItemGroup17.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem86,
            spreadsheetCommandGalleryItem87});
            this.commandBarGalleryDropDown8.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup15,
            spreadsheetCommandGalleryItemGroup16,
            spreadsheetCommandGalleryItemGroup17});
            this.commandBarGalleryDropDown8.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown8.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown8.Name = "commandBarGalleryDropDown8";
            this.commandBarGalleryDropDown8.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem7
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem7.CommandName = "InsertChartBarCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem7.DropDownControl = this.commandBarGalleryDropDown9;
            this.spreadsheetCommandBarButtonGalleryDropDownItem7.Id = 160;
            this.spreadsheetCommandBarButtonGalleryDropDownItem7.Name = "spreadsheetCommandBarButtonGalleryDropDownItem7";
            // 
            // commandBarGalleryDropDown9
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown9.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup18.CommandName = "InsertChartBar2DCommandGroup";
            spreadsheetCommandGalleryItem88.CommandName = "InsertChartBarClustered2D";
            spreadsheetCommandGalleryItem89.CommandName = "InsertChartBarStacked2D";
            spreadsheetCommandGalleryItem90.CommandName = "InsertChartBarPercentStacked2D";
            spreadsheetCommandGalleryItemGroup18.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem88,
            spreadsheetCommandGalleryItem89,
            spreadsheetCommandGalleryItem90});
            spreadsheetCommandGalleryItemGroup19.CommandName = "InsertChartBar3DCommandGroup";
            spreadsheetCommandGalleryItem91.CommandName = "InsertChartBarClustered3D";
            spreadsheetCommandGalleryItem92.CommandName = "InsertChartBarStacked3D";
            spreadsheetCommandGalleryItem93.CommandName = "InsertChartBarPercentStacked3D";
            spreadsheetCommandGalleryItemGroup19.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem91,
            spreadsheetCommandGalleryItem92,
            spreadsheetCommandGalleryItem93});
            spreadsheetCommandGalleryItemGroup20.CommandName = "InsertChartHorizontalCylinderCommandGroup";
            spreadsheetCommandGalleryItem94.CommandName = "InsertChartHorizontalCylinderClustered";
            spreadsheetCommandGalleryItem95.CommandName = "InsertChartHorizontalCylinderStacked";
            spreadsheetCommandGalleryItem96.CommandName = "InsertChartHorizontalCylinderPercentStacked";
            spreadsheetCommandGalleryItemGroup20.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem94,
            spreadsheetCommandGalleryItem95,
            spreadsheetCommandGalleryItem96});
            spreadsheetCommandGalleryItemGroup21.CommandName = "InsertChartHorizontalConeCommandGroup";
            spreadsheetCommandGalleryItem97.CommandName = "InsertChartHorizontalConeClustered";
            spreadsheetCommandGalleryItem98.CommandName = "InsertChartHorizontalConeStacked";
            spreadsheetCommandGalleryItem99.CommandName = "InsertChartHorizontalConePercentStacked";
            spreadsheetCommandGalleryItemGroup21.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem97,
            spreadsheetCommandGalleryItem98,
            spreadsheetCommandGalleryItem99});
            spreadsheetCommandGalleryItemGroup22.CommandName = "InsertChartHorizontalPyramidCommandGroup";
            spreadsheetCommandGalleryItem100.CommandName = "InsertChartHorizontalPyramidClustered";
            spreadsheetCommandGalleryItem101.CommandName = "InsertChartHorizontalPyramidStacked";
            spreadsheetCommandGalleryItem102.CommandName = "InsertChartHorizontalPyramidPercentStacked";
            spreadsheetCommandGalleryItemGroup22.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem100,
            spreadsheetCommandGalleryItem101,
            spreadsheetCommandGalleryItem102});
            this.commandBarGalleryDropDown9.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup18,
            spreadsheetCommandGalleryItemGroup19,
            spreadsheetCommandGalleryItemGroup20,
            spreadsheetCommandGalleryItemGroup21,
            spreadsheetCommandGalleryItemGroup22});
            this.commandBarGalleryDropDown9.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown9.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown9.Name = "commandBarGalleryDropDown9";
            this.commandBarGalleryDropDown9.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem8
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem8.CommandName = "InsertChartAreaCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem8.DropDownControl = this.commandBarGalleryDropDown10;
            this.spreadsheetCommandBarButtonGalleryDropDownItem8.Id = 161;
            this.spreadsheetCommandBarButtonGalleryDropDownItem8.Name = "spreadsheetCommandBarButtonGalleryDropDownItem8";
            // 
            // commandBarGalleryDropDown10
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown10.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup23.CommandName = "InsertChartArea2DCommandGroup";
            spreadsheetCommandGalleryItem103.CommandName = "InsertChartArea";
            spreadsheetCommandGalleryItem104.CommandName = "InsertChartStackedArea";
            spreadsheetCommandGalleryItem105.CommandName = "InsertChartPercentStackedArea";
            spreadsheetCommandGalleryItemGroup23.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem103,
            spreadsheetCommandGalleryItem104,
            spreadsheetCommandGalleryItem105});
            spreadsheetCommandGalleryItemGroup24.CommandName = "InsertChartArea3DCommandGroup";
            spreadsheetCommandGalleryItem106.CommandName = "InsertChartArea3D";
            spreadsheetCommandGalleryItem107.CommandName = "InsertChartStackedArea3D";
            spreadsheetCommandGalleryItem108.CommandName = "InsertChartPercentStackedArea3D";
            spreadsheetCommandGalleryItemGroup24.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem106,
            spreadsheetCommandGalleryItem107,
            spreadsheetCommandGalleryItem108});
            this.commandBarGalleryDropDown10.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup23,
            spreadsheetCommandGalleryItemGroup24});
            this.commandBarGalleryDropDown10.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown10.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown10.Name = "commandBarGalleryDropDown10";
            this.commandBarGalleryDropDown10.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem9
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem9.CommandName = "InsertChartScatterCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem9.DropDownControl = this.commandBarGalleryDropDown11;
            this.spreadsheetCommandBarButtonGalleryDropDownItem9.Id = 162;
            this.spreadsheetCommandBarButtonGalleryDropDownItem9.Name = "spreadsheetCommandBarButtonGalleryDropDownItem9";
            // 
            // commandBarGalleryDropDown11
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown11.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup25.CommandName = "InsertChartScatterCommandGroup";
            spreadsheetCommandGalleryItem109.CommandName = "InsertChartScatterMarkers";
            spreadsheetCommandGalleryItem110.CommandName = "InsertChartScatterSmoothLinesAndMarkers";
            spreadsheetCommandGalleryItem111.CommandName = "InsertChartScatterSmoothLines";
            spreadsheetCommandGalleryItem112.CommandName = "InsertChartScatterLinesAndMarkers";
            spreadsheetCommandGalleryItem113.CommandName = "InsertChartScatterLines";
            spreadsheetCommandGalleryItemGroup25.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem109,
            spreadsheetCommandGalleryItem110,
            spreadsheetCommandGalleryItem111,
            spreadsheetCommandGalleryItem112,
            spreadsheetCommandGalleryItem113});
            spreadsheetCommandGalleryItemGroup26.CommandName = "InsertChartBubbleCommandGroup";
            spreadsheetCommandGalleryItem114.CommandName = "InsertChartBubble";
            spreadsheetCommandGalleryItem115.CommandName = "InsertChartBubble3D";
            spreadsheetCommandGalleryItemGroup26.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem114,
            spreadsheetCommandGalleryItem115});
            this.commandBarGalleryDropDown11.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup25,
            spreadsheetCommandGalleryItemGroup26});
            this.commandBarGalleryDropDown11.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown11.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown11.Name = "commandBarGalleryDropDown11";
            this.commandBarGalleryDropDown11.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem10
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem10.CommandName = "InsertChartOtherCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem10.DropDownControl = this.commandBarGalleryDropDown12;
            this.spreadsheetCommandBarButtonGalleryDropDownItem10.Id = 163;
            this.spreadsheetCommandBarButtonGalleryDropDownItem10.Name = "spreadsheetCommandBarButtonGalleryDropDownItem10";
            // 
            // commandBarGalleryDropDown12
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown12.Gallery.AllowFilter = false;
            spreadsheetCommandGalleryItemGroup27.CommandName = "InsertChartStockCommandGroup";
            spreadsheetCommandGalleryItem116.CommandName = "InsertChartStockHighLowClose";
            spreadsheetCommandGalleryItem117.CommandName = "InsertChartStockOpenHighLowClose";
            spreadsheetCommandGalleryItem118.CommandName = "InsertChartStockVolumeHighLowClose";
            spreadsheetCommandGalleryItem119.CommandName = "InsertChartStockVolumeOpenHighLowClose";
            spreadsheetCommandGalleryItemGroup27.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem116,
            spreadsheetCommandGalleryItem117,
            spreadsheetCommandGalleryItem118,
            spreadsheetCommandGalleryItem119});
            spreadsheetCommandGalleryItemGroup28.CommandName = "InsertChartRadarCommandGroup";
            spreadsheetCommandGalleryItem120.CommandName = "InsertChartRadar";
            spreadsheetCommandGalleryItem121.CommandName = "InsertChartRadarWithMarkers";
            spreadsheetCommandGalleryItem122.CommandName = "InsertChartRadarFilled";
            spreadsheetCommandGalleryItemGroup28.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem120,
            spreadsheetCommandGalleryItem121,
            spreadsheetCommandGalleryItem122});
            this.commandBarGalleryDropDown12.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup27,
            spreadsheetCommandGalleryItemGroup28});
            this.commandBarGalleryDropDown12.Gallery.ImageSize = new System.Drawing.Size(32, 32);
            this.commandBarGalleryDropDown12.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto;
            this.commandBarGalleryDropDown12.Name = "commandBarGalleryDropDown12";
            this.commandBarGalleryDropDown12.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonItem104
            // 
            this.spreadsheetCommandBarButtonItem104.CommandName = "InsertHyperlink";
            this.spreadsheetCommandBarButtonItem104.Id = 164;
            this.spreadsheetCommandBarButtonItem104.Name = "spreadsheetCommandBarButtonItem104";
            // 
            // spreadsheetCommandBarButtonItem105
            // 
            this.spreadsheetCommandBarButtonItem105.CommandName = "InsertSymbol";
            this.spreadsheetCommandBarButtonItem105.Id = 165;
            this.spreadsheetCommandBarButtonItem105.Name = "spreadsheetCommandBarButtonItem105";
            // 
            // barButtonGroup11
            // 
            this.barButtonGroup11.Id = 168;
            this.barButtonGroup11.ItemLinks.Add(this.changeFontNameItem1);
            this.barButtonGroup11.ItemLinks.Add(this.changeFontSizeItem1);
            this.barButtonGroup11.ItemLinks.Add(this.spreadsheetCommandBarButtonItem5);
            this.barButtonGroup11.ItemLinks.Add(this.spreadsheetCommandBarButtonItem6);
            this.barButtonGroup11.Name = "barButtonGroup11";
            this.barButtonGroup11.Tag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}";
            // 
            // barButtonGroup12
            // 
            this.barButtonGroup12.Id = 169;
            this.barButtonGroup12.ItemLinks.Add(this.spreadsheetCommandBarCheckItem1);
            this.barButtonGroup12.ItemLinks.Add(this.spreadsheetCommandBarCheckItem2);
            this.barButtonGroup12.ItemLinks.Add(this.spreadsheetCommandBarCheckItem3);
            this.barButtonGroup12.ItemLinks.Add(this.spreadsheetCommandBarCheckItem4);
            this.barButtonGroup12.Name = "barButtonGroup12";
            this.barButtonGroup12.Tag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            // 
            // barButtonGroup13
            // 
            this.barButtonGroup13.Id = 170;
            this.barButtonGroup13.ItemLinks.Add(this.spreadsheetCommandBarSubItem1);
            this.barButtonGroup13.Name = "barButtonGroup13";
            this.barButtonGroup13.Tag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}";
            // 
            // barButtonGroup14
            // 
            this.barButtonGroup14.Id = 171;
            this.barButtonGroup14.ItemLinks.Add(this.changeCellFillColorItem1);
            this.barButtonGroup14.ItemLinks.Add(this.changeFontColorItem1);
            this.barButtonGroup14.Name = "barButtonGroup14";
            this.barButtonGroup14.Tag = "{C2275623-04A3-41E8-8D6A-EB5C7F8541D1}";
            // 
            // barButtonGroup15
            // 
            this.barButtonGroup15.Id = 172;
            this.barButtonGroup15.ItemLinks.Add(this.spreadsheetCommandBarCheckItem5);
            this.barButtonGroup15.ItemLinks.Add(this.spreadsheetCommandBarCheckItem6);
            this.barButtonGroup15.ItemLinks.Add(this.spreadsheetCommandBarCheckItem7);
            this.barButtonGroup15.Name = "barButtonGroup15";
            this.barButtonGroup15.Tag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}";
            // 
            // barButtonGroup16
            // 
            this.barButtonGroup16.Id = 173;
            this.barButtonGroup16.ItemLinks.Add(this.spreadsheetCommandBarCheckItem8);
            this.barButtonGroup16.ItemLinks.Add(this.spreadsheetCommandBarCheckItem9);
            this.barButtonGroup16.ItemLinks.Add(this.spreadsheetCommandBarCheckItem10);
            this.barButtonGroup16.Name = "barButtonGroup16";
            this.barButtonGroup16.Tag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}";
            // 
            // barButtonGroup17
            // 
            this.barButtonGroup17.Id = 174;
            this.barButtonGroup17.ItemLinks.Add(this.spreadsheetCommandBarButtonItem20);
            this.barButtonGroup17.ItemLinks.Add(this.spreadsheetCommandBarButtonItem21);
            this.barButtonGroup17.Name = "barButtonGroup17";
            this.barButtonGroup17.Tag = "{A5E37DED-106E-44FC-8044-CE3824C08225}";
            // 
            // barButtonGroup18
            // 
            this.barButtonGroup18.Id = 175;
            this.barButtonGroup18.ItemLinks.Add(this.changeNumberFormatItem1);
            this.barButtonGroup18.Name = "barButtonGroup18";
            this.barButtonGroup18.Tag = "{0B3A7A43-3079-4ce0-83A8-3789F5F6DC9F}";
            // 
            // barButtonGroup19
            // 
            this.barButtonGroup19.Id = 176;
            this.barButtonGroup19.ItemLinks.Add(this.spreadsheetCommandBarSubItem3);
            this.barButtonGroup19.ItemLinks.Add(this.spreadsheetCommandBarButtonItem30);
            this.barButtonGroup19.ItemLinks.Add(this.spreadsheetCommandBarButtonItem31);
            this.barButtonGroup19.Name = "barButtonGroup19";
            this.barButtonGroup19.Tag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}";
            // 
            // barButtonGroup20
            // 
            this.barButtonGroup20.Id = 177;
            this.barButtonGroup20.ItemLinks.Add(this.spreadsheetCommandBarButtonItem32);
            this.barButtonGroup20.ItemLinks.Add(this.spreadsheetCommandBarButtonItem33);
            this.barButtonGroup20.Name = "barButtonGroup20";
            this.barButtonGroup20.Tag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}";
            // 
            // spreadsheetCommandBarSubItem9
            // 
            this.spreadsheetCommandBarSubItem9.CommandName = "RemoveCellsCommandGroup";
            this.spreadsheetCommandBarSubItem9.Id = 178;
            this.spreadsheetCommandBarSubItem9.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem52),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem53),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem54)});
            this.spreadsheetCommandBarSubItem9.Name = "spreadsheetCommandBarSubItem9";
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Caption = "barStaticItem1";
            this.barStaticItem1.Id = 181;
            this.barStaticItem1.Name = "barStaticItem1";
            this.barStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barStaticItem2
            // 
            this.barStaticItem2.Caption = "Select Clear->Clear Contents to execute a custom command.\r\nAlternatively you can " +
    "right-click any cell and select Clear Contents.";
            this.barStaticItem2.Id = 149;
            this.barStaticItem2.Name = "barStaticItem2";
            this.barStaticItem2.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.barStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // homeRibbonPage1
            // 
            this.homeRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.editingRibbonPageGroup1});
            this.homeRibbonPage1.Name = "homeRibbonPage1";
            reduceOperation1.Behavior = DevExpress.XtraBars.Ribbon.ReduceOperationBehavior.UntilAvailable;
            reduceOperation1.Group = null;
            reduceOperation1.ItemLinkIndex = 2;
            reduceOperation1.ItemLinksCount = 0;
            reduceOperation1.Operation = DevExpress.XtraBars.Ribbon.ReduceOperationType.Gallery;
            this.homeRibbonPage1.ReduceOperations.Add(reduceOperation1);
            // 
            // editingRibbonPageGroup1
            // 
            this.editingRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem14);
            this.editingRibbonPageGroup1.ItemLinks.Add(this.barStaticItem2);
            this.editingRibbonPageGroup1.Name = "editingRibbonPageGroup1";
            // 
            // spreadsheetBarController1
            // 
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem2);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem3);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem4);
            this.spreadsheetBarController1.BarItems.Add(this.changeFontNameItem1);
            this.spreadsheetBarController1.BarItems.Add(this.changeFontSizeItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem5);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem6);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem2);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem3);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem4);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem7);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem8);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem9);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem10);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem11);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem12);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem13);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem14);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem15);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem16);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem17);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem18);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem19);
            this.spreadsheetBarController1.BarItems.Add(this.changeBorderLineColorItem1);
            this.spreadsheetBarController1.BarItems.Add(this.changeBorderLineStyleItem1);
            this.spreadsheetBarController1.BarItems.Add(this.changeCellFillColorItem1);
            this.spreadsheetBarController1.BarItems.Add(this.changeFontColorItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem5);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem6);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem7);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem8);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem9);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem10);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem20);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem21);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem11);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem2);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem12);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem22);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem23);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem24);
            this.spreadsheetBarController1.BarItems.Add(this.changeNumberFormatItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem3);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem25);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem26);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem27);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem28);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem29);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem30);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem31);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem32);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem33);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem4);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem5);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem34);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem35);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem36);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem37);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem38);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem39);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem40);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem6);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem41);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem42);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem43);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem44);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem45);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem46);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem2);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem3);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem7);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem47);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem48);
            this.spreadsheetBarController1.BarItems.Add(this.galleryFormatAsTableItem1);
            this.spreadsheetBarController1.BarItems.Add(this.galleryChangeStyleItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem8);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem49);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem50);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem51);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem52);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem53);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem54);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem10);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem55);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem56);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem57);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem58);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem59);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem11);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem60);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem61);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem62);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem63);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem64);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem65);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem66);
            this.spreadsheetBarController1.BarItems.Add(this.changeSheetTabColorItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem67);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem13);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem68);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem12);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem69);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem70);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem71);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem72);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem73);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem13);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem74);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem75);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem76);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem77);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem14);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem78);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem79);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem80);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem81);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem82);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem83);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem15);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem84);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem85);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem16);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem86);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem87);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem88);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem89);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem90);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem91);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem92);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem93);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem94);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem95);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem96);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem97);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem98);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem99);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem100);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem101);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem102);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem103);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem4);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem5);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem6);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem7);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem8);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem9);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem10);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem104);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem105);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem9);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem106);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem107);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem108);
            this.spreadsheetBarController1.Control = this.spreadsheetControl1;
            // 
            // spreadsheetCommandBarButtonItem106
            // 
            this.spreadsheetCommandBarButtonItem106.CommandName = "RemoveSheetRows";
            this.spreadsheetCommandBarButtonItem106.Id = -1;
            this.spreadsheetCommandBarButtonItem106.Name = "spreadsheetCommandBarButtonItem106";
            // 
            // spreadsheetCommandBarButtonItem107
            // 
            this.spreadsheetCommandBarButtonItem107.CommandName = "RemoveSheetColumns";
            this.spreadsheetCommandBarButtonItem107.Id = -1;
            this.spreadsheetCommandBarButtonItem107.Name = "spreadsheetCommandBarButtonItem107";
            // 
            // spreadsheetCommandBarButtonItem108
            // 
            this.spreadsheetCommandBarButtonItem108.CommandName = "RemoveSheet";
            this.spreadsheetCommandBarButtonItem108.Id = -1;
            this.spreadsheetCommandBarButtonItem108.Name = "spreadsheetCommandBarButtonItem108";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 467);
            this.Controls.Add(this.spreadsheetControl1);
            this.Controls.Add(this.ribbonControl1);
            this.Name = "Form1";
            this.Ribbon = this.ribbonControl1;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpreadsheetFontSizeEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupGalleryEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spreadsheetBarController1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraSpreadsheet.SpreadsheetControl spreadsheetControl1;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem4;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem changeFontNameItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemFontEdit repositoryItemFontEdit1;
        private DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem changeFontSizeItem1;
        private DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit repositoryItemSpreadsheetFontSizeEdit1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem5;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem6;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem4;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem7;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem8;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem9;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem10;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem11;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem12;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem13;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem14;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem15;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem16;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem17;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem18;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem19;
        private DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem changeBorderLineColorItem1;
        private DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem changeBorderLineStyleItem1;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup4;
        private DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem changeCellFillColorItem1;
        private DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem changeFontColorItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup5;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem5;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem6;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem7;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup6;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem8;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem9;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem10;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup7;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem20;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem21;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem11;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem12;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem22;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem23;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem24;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup8;
        private DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem changeNumberFormatItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit repositoryItemPopupGalleryEdit1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup9;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem25;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem26;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem27;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem28;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem29;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem30;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem31;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup10;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem32;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem33;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem4;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem5;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem34;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem35;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem36;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem37;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem38;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem39;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem40;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem6;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem41;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem42;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem43;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem44;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem45;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem46;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem1;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem2;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem3;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown4;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem7;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem47;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem48;
        private DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem galleryFormatAsTableItem1;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown5;
        private DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem galleryChangeStyleItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem8;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem49;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem50;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem51;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem52;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem53;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem54;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem10;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem55;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem56;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem57;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem58;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem59;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem11;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem60;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem61;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem62;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem63;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem64;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem65;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem66;
        private DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem changeSheetTabColorItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem67;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem13;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem68;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem12;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem69;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem70;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem71;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem72;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem73;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem13;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem74;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem75;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem76;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem77;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem14;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem78;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem79;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem80;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem81;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem82;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem83;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem15;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem84;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem85;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem16;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem86;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem87;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem88;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem89;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem90;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem91;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem92;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController spreadsheetBarController1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem93;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem94;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem95;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem96;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem97;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem98;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem99;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem100;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem101;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem102;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem103;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem4;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown6;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem5;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown7;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem6;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown8;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem7;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown9;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem8;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown10;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem9;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown11;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem10;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown12;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem104;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem105;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup11;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup12;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup13;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup14;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup15;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup16;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup17;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup18;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup19;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup20;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem9;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraBars.BarStaticItem barStaticItem2;
        private DevExpress.XtraSpreadsheet.UI.HomeRibbonPage homeRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.EditingRibbonPageGroup editingRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem106;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem107;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem108;

    }
}


﻿Imports DevExpress.Skins
Imports DevExpress.LookAndFeel
Imports DevExpress.UserSkins
Imports DevExpress.XtraBars.Helpers
Imports DevExpress.XtraBars.Ribbon


<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits RibbonForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim SpreadsheetCommandGalleryItemGroup1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem41 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem42 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem43 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem44 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem45 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem46 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem47 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem48 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem49 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem50 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem51 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem52 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem53 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem54 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem55 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem56 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem57 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem58 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem59 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem60 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem61 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem62 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem63 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem64 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem65 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem66 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem67 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem68 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem69 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem70 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem71 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem72 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem73 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem74 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem75 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem76 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem77 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem78 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem79 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem80 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem81 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem82 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem83 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem84 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem85 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem86 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem87 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem88 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem89 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem90 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem91 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem92 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem93 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem94 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem95 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem96 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem97 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem98 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem99 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem100 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem101 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem102 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem103 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem104 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem105 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem106 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem107 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem108 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem109 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem110 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem111 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem112 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem113 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem114 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem115 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem116 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem117 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem118 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem119 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem120 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem121 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem122 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem123 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem124 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem125 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem126 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem127 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem128 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem129 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem130 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem131 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim GalleryItemGroup1 As DevExpress.XtraBars.Ribbon.GalleryItemGroup = New DevExpress.XtraBars.Ribbon.GalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem132 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem133 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem134 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem135 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem136 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem137 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem138 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem139 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem140 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem141 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem142 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem143 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem144 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem145 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem146 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem147 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem148 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem149 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem150 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem151 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem152 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem153 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem154 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem155 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem156 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem157 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem158 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem159 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem160 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem161 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem162 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem163 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem164 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem165 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem166 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem167 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem168 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem169 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem170 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem171 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem172 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem173 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem174 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem175 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem176 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem177 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem178 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem179 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem180 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem181 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItemGroup40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup()
        Dim SpreadsheetCommandGalleryItem182 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem183 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem184 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem185 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim SpreadsheetCommandGalleryItem186 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem()
        Dim ReduceOperation1 As DevExpress.XtraBars.Ribbon.ReduceOperation = New DevExpress.XtraBars.Ribbon.ReduceOperation()
        Me.ribbonControl = New DevExpress.XtraBars.Ribbon.RibbonControl()
        Me.appMenu = New DevExpress.XtraBars.Ribbon.ApplicationMenu(Me.components)
        Me.popupControlContainer2 = New DevExpress.XtraBars.PopupControlContainer(Me.components)
        Me.buttonEdit = New DevExpress.XtraEditors.ButtonEdit()
        Me.iExit = New DevExpress.XtraBars.BarButtonItem()
        Me.popupControlContainer1 = New DevExpress.XtraBars.PopupControlContainer(Me.components)
        Me.someLabelControl2 = New DevExpress.XtraEditors.LabelControl()
        Me.someLabelControl1 = New DevExpress.XtraEditors.LabelControl()
        Me.ribbonImageCollection = New DevExpress.Utils.ImageCollection(Me.components)
        Me.iHelp = New DevExpress.XtraBars.BarButtonItem()
        Me.iAbout = New DevExpress.XtraBars.BarButtonItem()
        Me.siStatus = New DevExpress.XtraBars.BarStaticItem()
        Me.siInfo = New DevExpress.XtraBars.BarStaticItem()
        Me.rgbiSkins = New DevExpress.XtraBars.RibbonGalleryBarItem()
        Me.SpreadsheetCommandBarSubItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarCheckItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.GalleryPivotStylesItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryPivotStylesItem()
        Me.SpreadsheetCommandBarButtonItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem25 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem26 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem27 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem28 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem29 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem30 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem31 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem32 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem33 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem34 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarCheckItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarSubItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem35 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem36 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem37 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem38 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.RenameTableItemCaption1 = New DevExpress.XtraSpreadsheet.UI.RenameTableItemCaption()
        Me.RenameTableItem1 = New DevExpress.XtraSpreadsheet.UI.RenameTableItem()
        Me.RepositoryItemTextEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemTextEdit()
        Me.SpreadsheetCommandBarCheckItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.GalleryTableStylesItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryTableStylesItem()
        Me.SpreadsheetCommandBarSubItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown1 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem2 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown2 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarSubItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem3 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown3 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem4 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown4 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem5 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown5 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarSubItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem6 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown6 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem7 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown7 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem8 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown8 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem9 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown9 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem10 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown10 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem11 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown11 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem12 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown12 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonItem39 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem40 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem41 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.GalleryChartLayoutItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryChartLayoutItem()
        Me.GalleryChartStyleItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryChartStyleItem()
        Me.SpreadsheetCommandBarButtonItem42 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarCheckItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarButtonItem43 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem44 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem45 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem46 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem47 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem48 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem49 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem50 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem51 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem52 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem53 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem54 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem55 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem56 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem57 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem58 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem59 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem60 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem61 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarCheckItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarButtonItem62 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem63 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem64 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem65 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem66 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem67 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem68 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem69 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem70 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem71 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem72 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem73 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem74 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem75 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem76 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem77 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem78 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.FunctionsFinancialItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsFinancialItem()
        Me.FunctionsLogicalItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsLogicalItem()
        Me.FunctionsTextItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsTextItem()
        Me.FunctionsDateAndTimeItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsDateAndTimeItem()
        Me.FunctionsLookupAndReferenceItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsLookupAndReferenceItem()
        Me.FunctionsMathAndTrigonometryItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsMathAndTrigonometryItem()
        Me.SpreadsheetCommandBarSubItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.FunctionsStatisticalItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsStatisticalItem()
        Me.FunctionsEngineeringItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsEngineeringItem()
        Me.FunctionsInformationItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsInformationItem()
        Me.FunctionsCompatibilityItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsCompatibilityItem()
        Me.FunctionsWebItem1 = New DevExpress.XtraSpreadsheet.UI.FunctionsWebItem()
        Me.SpreadsheetCommandBarButtonItem79 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem80 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.DefinedNameListItem1 = New DevExpress.XtraSpreadsheet.UI.DefinedNameListItem()
        Me.SpreadsheetCommandBarButtonItem81 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarCheckItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarSubItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarCheckItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarButtonItem82 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem83 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarCheckItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarButtonItem84 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarCheckItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem25 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.PageSetupPaperKindItem1 = New DevExpress.XtraSpreadsheet.UI.PageSetupPaperKindItem()
        Me.SpreadsheetCommandBarSubItem23 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem85 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem86 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem87 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem88 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarCheckItem26 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem27 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarButtonItem89 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem90 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem91 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem13 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown13 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem14 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown14 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem15 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown15 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem16 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown16 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem17 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown17 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem18 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown18 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem19 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown19 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonItem92 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem93 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem94 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem95 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem96 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem97 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.BarButtonGroup1 = New DevExpress.XtraBars.BarButtonGroup()
        Me.ChangeFontNameItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem()
        Me.RepositoryItemFontEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemFontEdit()
        Me.ChangeFontSizeItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem()
        Me.RepositoryItemSpreadsheetFontSizeEdit1 = New DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit()
        Me.spreadsheetControl = New DevExpress.XtraSpreadsheet.SpreadsheetControl()
        Me.SpreadsheetCommandBarButtonItem98 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem99 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.BarButtonGroup2 = New DevExpress.XtraBars.BarButtonGroup()
        Me.SpreadsheetCommandBarCheckItem28 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem29 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem30 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem31 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.BarButtonGroup3 = New DevExpress.XtraBars.BarButtonGroup()
        Me.SpreadsheetCommandBarSubItem24 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem100 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem101 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem102 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem103 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem104 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem105 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem106 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem107 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem108 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem109 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem110 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem111 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem112 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.ChangeBorderLineColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem()
        Me.ChangeBorderLineStyleItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem()
        Me.CommandBarGalleryDropDown20 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.BarButtonGroup4 = New DevExpress.XtraBars.BarButtonGroup()
        Me.ChangeCellFillColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem()
        Me.ChangeFontColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem()
        Me.BarButtonGroup5 = New DevExpress.XtraBars.BarButtonGroup()
        Me.SpreadsheetCommandBarCheckItem32 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem33 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem34 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.BarButtonGroup6 = New DevExpress.XtraBars.BarButtonGroup()
        Me.SpreadsheetCommandBarCheckItem35 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem36 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarCheckItem37 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.BarButtonGroup7 = New DevExpress.XtraBars.BarButtonGroup()
        Me.SpreadsheetCommandBarButtonItem113 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem114 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarCheckItem38 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarSubItem25 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarCheckItem39 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarButtonItem115 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem116 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem117 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.BarButtonGroup8 = New DevExpress.XtraBars.BarButtonGroup()
        Me.ChangeNumberFormatItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem()
        Me.RepositoryItemPopupGalleryEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit()
        Me.BarButtonGroup9 = New DevExpress.XtraBars.BarButtonGroup()
        Me.SpreadsheetCommandBarSubItem26 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem118 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem119 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem120 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem121 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem122 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem123 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem124 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem125 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.BarButtonGroup10 = New DevExpress.XtraBars.BarButtonGroup()
        Me.SpreadsheetCommandBarButtonItem126 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem127 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem30 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarSubItem27 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem128 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem129 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem130 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem131 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem132 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem133 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem134 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem28 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem135 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem136 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem137 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem138 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem139 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem140 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem20 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown21 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem21 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown22 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem22 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem()
        Me.CommandBarGalleryDropDown23 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.SpreadsheetCommandBarButtonItem141 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem29 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem142 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem143 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem144 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.GalleryFormatAsTableItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem()
        Me.CommandBarGalleryDropDown24 = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
        Me.GalleryChangeStyleItem1 = New DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem()
        Me.SpreadsheetCommandBarSubItem31 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem145 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem146 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem147 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem148 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem149 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem150 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem151 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem32 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem152 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem153 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem154 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem155 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem156 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem34 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem157 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem158 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem159 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem160 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem161 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem33 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem162 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem163 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem164 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem165 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem166 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem167 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem168 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem169 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.ChangeSheetTabColorItem1 = New DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem()
        Me.SpreadsheetCommandBarCheckItem40 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem()
        Me.SpreadsheetCommandBarButtonItem170 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem35 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarSubItem36 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem171 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem172 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem173 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem174 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem37 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem175 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem176 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem177 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem178 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem179 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem180 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarSubItem38 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarSubItem39 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem()
        Me.SpreadsheetCommandBarButtonItem181 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem182 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem183 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem184 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem185 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem186 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem187 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem188 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem189 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem190 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem191 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem192 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem193 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem194 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem195 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem196 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem197 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.SpreadsheetCommandBarButtonItem198 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem()
        Me.ribbonImageCollectionLarge = New DevExpress.Utils.ImageCollection(Me.components)
        Me.PivotTableToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.PivotTableToolsRibbonPageCategory()
        Me.PivotTableAnalyzeRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeRibbonPage()
        Me.PivotTableAnalyzePivotTableRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzePivotTableRibbonPageGroup()
        Me.PivotTableAnalyzeActiveFieldRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActiveFieldRibbonPageGroup()
        Me.PivotTableAnalyzeGroupRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeGroupRibbonPageGroup()
        Me.PivotTableAnalyzeDataRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeDataRibbonPageGroup()
        Me.PivotTableAnalyzeActionsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActionsRibbonPageGroup()
        Me.PivotTableAnalyzeCalculationsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeCalculationsRibbonPageGroup()
        Me.PivotTableAnalyzeShowRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeShowRibbonPageGroup()
        Me.PivotTableDesignRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.PivotTableDesignRibbonPage()
        Me.PivotTableDesignLayoutRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableDesignLayoutRibbonPageGroup()
        Me.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup()
        Me.PivotTableDesignPivotTableStylesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStylesRibbonPageGroup()
        Me.PictureToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.PictureToolsRibbonPageCategory()
        Me.PictureFormatRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.PictureFormatRibbonPage()
        Me.PictureFormatArrangeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PictureFormatArrangeRibbonPageGroup()
        Me.DrawingToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.DrawingToolsRibbonPageCategory()
        Me.DrawingFormatRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.DrawingFormatRibbonPage()
        Me.DrawingFormatArrangeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.DrawingFormatArrangeRibbonPageGroup()
        Me.TableToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageCategory()
        Me.TableToolsDesignRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.TableToolsDesignRibbonPage()
        Me.TablePropertiesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TablePropertiesRibbonPageGroup()
        Me.TableToolsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageGroup()
        Me.TableStyleOptionsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TableStyleOptionsRibbonPageGroup()
        Me.TableStylesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TableStylesRibbonPageGroup()
        Me.ChartToolsRibbonPageCategory1 = New DevExpress.XtraSpreadsheet.UI.ChartToolsRibbonPageCategory()
        Me.ChartsDesignRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignRibbonPage()
        Me.ChartsDesignTypeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignTypeRibbonPageGroup()
        Me.ChartsDesignDataRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignDataRibbonPageGroup()
        Me.ChartsDesignLayoutsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignLayoutsRibbonPageGroup()
        Me.ChartsDesignStylesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignStylesRibbonPageGroup()
        Me.ChartsDesignLocationRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsDesignLocationRibbonPageGroup()
        Me.ChartsLayoutRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ChartsLayoutRibbonPage()
        Me.ChartsLayoutAxesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsLayoutAxesRibbonPageGroup()
        Me.ChartsLayoutLabelsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsLayoutLabelsRibbonPageGroup()
        Me.ChartsLayoutAnalysisRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsLayoutAnalysisRibbonPageGroup()
        Me.ChartsFormatRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ChartsFormatRibbonPage()
        Me.ChartsFormatArrangeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsFormatArrangeRibbonPageGroup()
        Me.FileRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.FileRibbonPage()
        Me.CommonRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.CommonRibbonPageGroup()
        Me.InfoRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.InfoRibbonPageGroup()
        Me.HomeRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.HomeRibbonPage()
        Me.ClipboardRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ClipboardRibbonPageGroup()
        Me.FontRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FontRibbonPageGroup()
        Me.AlignmentRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.AlignmentRibbonPageGroup()
        Me.NumberRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.NumberRibbonPageGroup()
        Me.StylesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.StylesRibbonPageGroup()
        Me.CellsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.CellsRibbonPageGroup()
        Me.EditingRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.EditingRibbonPageGroup()
        Me.InsertRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.InsertRibbonPage()
        Me.TablesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.TablesRibbonPageGroup()
        Me.IllustrationsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.IllustrationsRibbonPageGroup()
        Me.ChartsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChartsRibbonPageGroup()
        Me.LinksRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.LinksRibbonPageGroup()
        Me.SymbolsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.SymbolsRibbonPageGroup()
        Me.PageLayoutRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.PageLayoutRibbonPage()
        Me.PageSetupRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PageSetupRibbonPageGroup()
        Me.PageSetupShowRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PageSetupShowRibbonPageGroup()
        Me.PageSetupPrintRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.PageSetupPrintRibbonPageGroup()
        Me.ArrangeRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ArrangeRibbonPageGroup()
        Me.FormulasRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.FormulasRibbonPage()
        Me.FunctionLibraryRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FunctionLibraryRibbonPageGroup()
        Me.FormulaDefinedNamesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FormulaDefinedNamesRibbonPageGroup()
        Me.FormulaAuditingRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FormulaAuditingRibbonPageGroup()
        Me.FormulaCalculationRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.FormulaCalculationRibbonPageGroup()
        Me.DataRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.DataRibbonPage()
        Me.SortAndFilterRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.SortAndFilterRibbonPageGroup()
        Me.DataToolsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.DataToolsRibbonPageGroup()
        Me.OutlineRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.OutlineRibbonPageGroup()
        Me.ReviewRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ReviewRibbonPage()
        Me.CommentsRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.CommentsRibbonPageGroup()
        Me.ChangesRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ChangesRibbonPageGroup()
        Me.ViewRibbonPage1 = New DevExpress.XtraSpreadsheet.UI.ViewRibbonPage()
        Me.ShowRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ShowRibbonPageGroup()
        Me.ZoomRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.ZoomRibbonPageGroup()
        Me.WindowRibbonPageGroup1 = New DevExpress.XtraSpreadsheet.UI.WindowRibbonPageGroup()
        Me.RibbonPageSkins = New DevExpress.XtraBars.Ribbon.RibbonPage()
        Me.skinsRibbonPageGroup = New DevExpress.XtraBars.Ribbon.RibbonPageGroup()
        Me.helpRibbonPage = New DevExpress.XtraBars.Ribbon.RibbonPage()
        Me.helpRibbonPageGroup = New DevExpress.XtraBars.Ribbon.RibbonPageGroup()
        Me.ribbonStatusBar = New DevExpress.XtraBars.Ribbon.RibbonStatusBar()
        Me.spreadsheetFormulaBarPanel = New System.Windows.Forms.Panel()
        Me.splitterControl = New DevExpress.XtraEditors.SplitterControl()
        Me.formulaBarNameBoxSplitContainerControl = New DevExpress.XtraEditors.SplitContainerControl()
        Me.spreadsheetNameBoxControl = New DevExpress.XtraSpreadsheet.SpreadsheetNameBoxControl()
        Me.spreadsheetFormulaBarControl1 = New DevExpress.XtraSpreadsheet.SpreadsheetFormulaBarControl()
        Me.SpreadsheetBarController1 = New DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController(Me.components)
        CType(Me.ribbonControl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.appMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.popupControlContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.popupControlContainer2.SuspendLayout()
        CType(Me.buttonEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.popupControlContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.popupControlContainer1.SuspendLayout()
        CType(Me.ribbonImageCollection, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemTextEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemFontEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemSpreadsheetFontSizeEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemPopupGalleryEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommandBarGalleryDropDown24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ribbonImageCollectionLarge, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.spreadsheetFormulaBarPanel.SuspendLayout()
        CType(Me.formulaBarNameBoxSplitContainerControl, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.formulaBarNameBoxSplitContainerControl.SuspendLayout()
        CType(Me.spreadsheetNameBoxControl.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SpreadsheetBarController1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ribbonControl
        '
        Me.ribbonControl.ApplicationButtonDropDownControl = Me.appMenu
        Me.ribbonControl.ApplicationButtonText = Nothing
        Me.ribbonControl.ExpandCollapseItem.Id = 0
        Me.ribbonControl.Images = Me.ribbonImageCollection
        Me.ribbonControl.Items.AddRange(New DevExpress.XtraBars.BarItem() {Me.ribbonControl.SearchEditItem, Me.ribbonControl.ExpandCollapseItem, Me.iExit, Me.iHelp, Me.iAbout, Me.siStatus, Me.siInfo, Me.rgbiSkins, Me.SpreadsheetCommandBarSubItem1, Me.SpreadsheetCommandBarButtonItem1, Me.SpreadsheetCommandBarButtonItem2, Me.SpreadsheetCommandBarButtonItem3, Me.SpreadsheetCommandBarSubItem2, Me.SpreadsheetCommandBarButtonItem4, Me.SpreadsheetCommandBarButtonItem5, Me.SpreadsheetCommandBarButtonItem6, Me.SpreadsheetCommandBarButtonItem7, Me.SpreadsheetCommandBarSubItem3, Me.SpreadsheetCommandBarButtonItem8, Me.SpreadsheetCommandBarButtonItem9, Me.SpreadsheetCommandBarButtonItem10, Me.SpreadsheetCommandBarButtonItem11, Me.SpreadsheetCommandBarButtonItem12, Me.SpreadsheetCommandBarSubItem4, Me.SpreadsheetCommandBarButtonItem13, Me.SpreadsheetCommandBarButtonItem14, Me.SpreadsheetCommandBarCheckItem1, Me.SpreadsheetCommandBarCheckItem2, Me.SpreadsheetCommandBarCheckItem3, Me.SpreadsheetCommandBarCheckItem4, Me.GalleryPivotStylesItem1, Me.SpreadsheetCommandBarButtonItem15, Me.SpreadsheetCommandBarButtonItem16, Me.SpreadsheetCommandBarButtonItem17, Me.SpreadsheetCommandBarButtonItem18, Me.SpreadsheetCommandBarButtonItem19, Me.SpreadsheetCommandBarButtonItem20, Me.SpreadsheetCommandBarButtonItem21, Me.SpreadsheetCommandBarSubItem5, Me.SpreadsheetCommandBarButtonItem22, Me.SpreadsheetCommandBarButtonItem23, Me.SpreadsheetCommandBarButtonItem24, Me.SpreadsheetCommandBarSubItem6, Me.SpreadsheetCommandBarButtonItem25, Me.SpreadsheetCommandBarButtonItem26, Me.SpreadsheetCommandBarSubItem7, Me.SpreadsheetCommandBarButtonItem27, Me.SpreadsheetCommandBarButtonItem28, Me.SpreadsheetCommandBarButtonItem29, Me.SpreadsheetCommandBarButtonItem30, Me.SpreadsheetCommandBarSubItem8, Me.SpreadsheetCommandBarButtonItem31, Me.SpreadsheetCommandBarButtonItem32, Me.SpreadsheetCommandBarButtonItem33, Me.SpreadsheetCommandBarButtonItem34, Me.SpreadsheetCommandBarCheckItem5, Me.SpreadsheetCommandBarCheckItem6, Me.SpreadsheetCommandBarCheckItem7, Me.SpreadsheetCommandBarSubItem9, Me.SpreadsheetCommandBarButtonItem35, Me.SpreadsheetCommandBarButtonItem36, Me.SpreadsheetCommandBarSubItem10, Me.SpreadsheetCommandBarButtonItem37, Me.SpreadsheetCommandBarButtonItem38, Me.RenameTableItemCaption1, Me.RenameTableItem1, Me.SpreadsheetCommandBarCheckItem8, Me.SpreadsheetCommandBarCheckItem9, Me.SpreadsheetCommandBarCheckItem10, Me.SpreadsheetCommandBarCheckItem11, Me.SpreadsheetCommandBarCheckItem12, Me.SpreadsheetCommandBarCheckItem13, Me.SpreadsheetCommandBarCheckItem14, Me.GalleryTableStylesItem1, Me.SpreadsheetCommandBarSubItem11, Me.SpreadsheetCommandBarButtonGalleryDropDownItem1, Me.SpreadsheetCommandBarButtonGalleryDropDownItem2, Me.SpreadsheetCommandBarSubItem12, Me.SpreadsheetCommandBarButtonGalleryDropDownItem3, Me.SpreadsheetCommandBarButtonGalleryDropDownItem4, Me.SpreadsheetCommandBarButtonGalleryDropDownItem5, Me.SpreadsheetCommandBarSubItem13, Me.SpreadsheetCommandBarButtonGalleryDropDownItem6, Me.SpreadsheetCommandBarButtonGalleryDropDownItem7, Me.SpreadsheetCommandBarButtonGalleryDropDownItem8, Me.SpreadsheetCommandBarButtonGalleryDropDownItem9, Me.SpreadsheetCommandBarButtonGalleryDropDownItem10, Me.SpreadsheetCommandBarButtonGalleryDropDownItem11, Me.SpreadsheetCommandBarButtonGalleryDropDownItem12, Me.SpreadsheetCommandBarButtonItem39, Me.SpreadsheetCommandBarButtonItem40, Me.SpreadsheetCommandBarButtonItem41, Me.GalleryChartLayoutItem1, Me.GalleryChartStyleItem1, Me.SpreadsheetCommandBarButtonItem42, Me.SpreadsheetCommandBarCheckItem15, Me.SpreadsheetCommandBarCheckItem16, Me.SpreadsheetCommandBarButtonItem43, Me.SpreadsheetCommandBarButtonItem44, Me.SpreadsheetCommandBarButtonItem45, Me.SpreadsheetCommandBarButtonItem46, Me.SpreadsheetCommandBarSubItem14, Me.SpreadsheetCommandBarButtonItem47, Me.SpreadsheetCommandBarButtonItem48, Me.SpreadsheetCommandBarButtonItem49, Me.SpreadsheetCommandBarButtonItem50, Me.SpreadsheetCommandBarButtonItem51, Me.SpreadsheetCommandBarButtonItem52, Me.SpreadsheetCommandBarButtonItem53, Me.SpreadsheetCommandBarButtonItem54, Me.SpreadsheetCommandBarButtonItem55, Me.SpreadsheetCommandBarButtonItem56, Me.SpreadsheetCommandBarButtonItem57, Me.SpreadsheetCommandBarButtonItem58, Me.SpreadsheetCommandBarButtonItem59, Me.SpreadsheetCommandBarButtonItem60, Me.SpreadsheetCommandBarButtonItem61, Me.SpreadsheetCommandBarCheckItem17, Me.SpreadsheetCommandBarButtonItem62, Me.SpreadsheetCommandBarButtonItem63, Me.SpreadsheetCommandBarSubItem15, Me.SpreadsheetCommandBarButtonItem64, Me.SpreadsheetCommandBarButtonItem65, Me.SpreadsheetCommandBarButtonItem66, Me.SpreadsheetCommandBarSubItem16, Me.SpreadsheetCommandBarButtonItem67, Me.SpreadsheetCommandBarButtonItem68, Me.SpreadsheetCommandBarSubItem17, Me.SpreadsheetCommandBarButtonItem69, Me.SpreadsheetCommandBarButtonItem70, Me.SpreadsheetCommandBarButtonItem71, Me.SpreadsheetCommandBarButtonItem72, Me.SpreadsheetCommandBarButtonItem73, Me.SpreadsheetCommandBarSubItem18, Me.SpreadsheetCommandBarButtonItem74, Me.SpreadsheetCommandBarButtonItem75, Me.SpreadsheetCommandBarButtonItem76, Me.SpreadsheetCommandBarButtonItem77, Me.SpreadsheetCommandBarButtonItem78, Me.FunctionsFinancialItem1, Me.FunctionsLogicalItem1, Me.FunctionsTextItem1, Me.FunctionsDateAndTimeItem1, Me.FunctionsLookupAndReferenceItem1, Me.FunctionsMathAndTrigonometryItem1, Me.SpreadsheetCommandBarSubItem19, Me.FunctionsStatisticalItem1, Me.FunctionsEngineeringItem1, Me.FunctionsInformationItem1, Me.FunctionsCompatibilityItem1, Me.FunctionsWebItem1, Me.SpreadsheetCommandBarButtonItem79, Me.SpreadsheetCommandBarButtonItem80, Me.DefinedNameListItem1, Me.SpreadsheetCommandBarButtonItem81, Me.SpreadsheetCommandBarCheckItem18, Me.SpreadsheetCommandBarSubItem20, Me.SpreadsheetCommandBarCheckItem19, Me.SpreadsheetCommandBarCheckItem20, Me.SpreadsheetCommandBarButtonItem82, Me.SpreadsheetCommandBarButtonItem83, Me.SpreadsheetCommandBarSubItem21, Me.SpreadsheetCommandBarCheckItem21, Me.SpreadsheetCommandBarCheckItem22, Me.SpreadsheetCommandBarCheckItem23, Me.SpreadsheetCommandBarButtonItem84, Me.SpreadsheetCommandBarSubItem22, Me.SpreadsheetCommandBarCheckItem24, Me.SpreadsheetCommandBarCheckItem25, Me.PageSetupPaperKindItem1, Me.SpreadsheetCommandBarSubItem23, Me.SpreadsheetCommandBarButtonItem85, Me.SpreadsheetCommandBarButtonItem86, Me.SpreadsheetCommandBarButtonItem87, Me.SpreadsheetCommandBarButtonItem88, Me.SpreadsheetCommandBarCheckItem26, Me.SpreadsheetCommandBarCheckItem27, Me.SpreadsheetCommandBarButtonItem89, Me.SpreadsheetCommandBarButtonItem90, Me.SpreadsheetCommandBarButtonItem91, Me.SpreadsheetCommandBarButtonGalleryDropDownItem13, Me.SpreadsheetCommandBarButtonGalleryDropDownItem14, Me.SpreadsheetCommandBarButtonGalleryDropDownItem15, Me.SpreadsheetCommandBarButtonGalleryDropDownItem16, Me.SpreadsheetCommandBarButtonGalleryDropDownItem17, Me.SpreadsheetCommandBarButtonGalleryDropDownItem18, Me.SpreadsheetCommandBarButtonGalleryDropDownItem19, Me.SpreadsheetCommandBarButtonItem92, Me.SpreadsheetCommandBarButtonItem93, Me.SpreadsheetCommandBarButtonItem94, Me.SpreadsheetCommandBarButtonItem95, Me.SpreadsheetCommandBarButtonItem96, Me.SpreadsheetCommandBarButtonItem97, Me.BarButtonGroup1, Me.ChangeFontNameItem1, Me.ChangeFontSizeItem1, Me.SpreadsheetCommandBarButtonItem98, Me.SpreadsheetCommandBarButtonItem99, Me.BarButtonGroup2, Me.SpreadsheetCommandBarCheckItem28, Me.SpreadsheetCommandBarCheckItem29, Me.SpreadsheetCommandBarCheckItem30, Me.SpreadsheetCommandBarCheckItem31, Me.BarButtonGroup3, Me.SpreadsheetCommandBarSubItem24, Me.SpreadsheetCommandBarButtonItem100, Me.SpreadsheetCommandBarButtonItem101, Me.SpreadsheetCommandBarButtonItem102, Me.SpreadsheetCommandBarButtonItem103, Me.SpreadsheetCommandBarButtonItem104, Me.SpreadsheetCommandBarButtonItem105, Me.SpreadsheetCommandBarButtonItem106, Me.SpreadsheetCommandBarButtonItem107, Me.SpreadsheetCommandBarButtonItem108, Me.SpreadsheetCommandBarButtonItem109, Me.SpreadsheetCommandBarButtonItem110, Me.SpreadsheetCommandBarButtonItem111, Me.SpreadsheetCommandBarButtonItem112, Me.ChangeBorderLineColorItem1, Me.ChangeBorderLineStyleItem1, Me.BarButtonGroup4, Me.ChangeCellFillColorItem1, Me.ChangeFontColorItem1, Me.BarButtonGroup5, Me.SpreadsheetCommandBarCheckItem32, Me.SpreadsheetCommandBarCheckItem33, Me.SpreadsheetCommandBarCheckItem34, Me.BarButtonGroup6, Me.SpreadsheetCommandBarCheckItem35, Me.SpreadsheetCommandBarCheckItem36, Me.SpreadsheetCommandBarCheckItem37, Me.BarButtonGroup7, Me.SpreadsheetCommandBarButtonItem113, Me.SpreadsheetCommandBarButtonItem114, Me.SpreadsheetCommandBarCheckItem38, Me.SpreadsheetCommandBarSubItem25, Me.SpreadsheetCommandBarCheckItem39, Me.SpreadsheetCommandBarButtonItem115, Me.SpreadsheetCommandBarButtonItem116, Me.SpreadsheetCommandBarButtonItem117, Me.BarButtonGroup8, Me.ChangeNumberFormatItem1, Me.BarButtonGroup9, Me.SpreadsheetCommandBarSubItem26, Me.SpreadsheetCommandBarButtonItem118, Me.SpreadsheetCommandBarButtonItem119, Me.SpreadsheetCommandBarButtonItem120, Me.SpreadsheetCommandBarButtonItem121, Me.SpreadsheetCommandBarButtonItem122, Me.SpreadsheetCommandBarButtonItem123, Me.SpreadsheetCommandBarButtonItem124, Me.SpreadsheetCommandBarButtonItem125, Me.BarButtonGroup10, Me.SpreadsheetCommandBarButtonItem126, Me.SpreadsheetCommandBarButtonItem127, Me.SpreadsheetCommandBarSubItem30, Me.SpreadsheetCommandBarButtonItem128, Me.SpreadsheetCommandBarButtonItem129, Me.SpreadsheetCommandBarButtonItem130, Me.SpreadsheetCommandBarButtonItem131, Me.SpreadsheetCommandBarButtonItem132, Me.SpreadsheetCommandBarButtonItem133, Me.SpreadsheetCommandBarButtonItem134, Me.SpreadsheetCommandBarSubItem27, Me.SpreadsheetCommandBarButtonItem135, Me.SpreadsheetCommandBarButtonItem136, Me.SpreadsheetCommandBarButtonItem137, Me.SpreadsheetCommandBarButtonItem138, Me.SpreadsheetCommandBarButtonItem139, Me.SpreadsheetCommandBarButtonItem140, Me.SpreadsheetCommandBarSubItem28, Me.SpreadsheetCommandBarButtonGalleryDropDownItem20, Me.SpreadsheetCommandBarButtonGalleryDropDownItem21, Me.SpreadsheetCommandBarButtonGalleryDropDownItem22, Me.SpreadsheetCommandBarButtonItem141, Me.SpreadsheetCommandBarButtonItem142, Me.SpreadsheetCommandBarButtonItem143, Me.SpreadsheetCommandBarSubItem29, Me.SpreadsheetCommandBarButtonItem144, Me.GalleryFormatAsTableItem1, Me.GalleryChangeStyleItem1, Me.SpreadsheetCommandBarSubItem31, Me.SpreadsheetCommandBarButtonItem145, Me.SpreadsheetCommandBarButtonItem146, Me.SpreadsheetCommandBarButtonItem147, Me.SpreadsheetCommandBarButtonItem148, Me.SpreadsheetCommandBarButtonItem149, Me.SpreadsheetCommandBarButtonItem150, Me.SpreadsheetCommandBarButtonItem151, Me.SpreadsheetCommandBarSubItem32, Me.SpreadsheetCommandBarButtonItem152, Me.SpreadsheetCommandBarButtonItem153, Me.SpreadsheetCommandBarButtonItem154, Me.SpreadsheetCommandBarButtonItem155, Me.SpreadsheetCommandBarButtonItem156, Me.SpreadsheetCommandBarSubItem34, Me.SpreadsheetCommandBarButtonItem157, Me.SpreadsheetCommandBarButtonItem158, Me.SpreadsheetCommandBarButtonItem159, Me.SpreadsheetCommandBarButtonItem160, Me.SpreadsheetCommandBarButtonItem161, Me.SpreadsheetCommandBarButtonItem162, Me.SpreadsheetCommandBarButtonItem163, Me.SpreadsheetCommandBarButtonItem164, Me.SpreadsheetCommandBarButtonItem165, Me.SpreadsheetCommandBarButtonItem166, Me.SpreadsheetCommandBarButtonItem167, Me.SpreadsheetCommandBarSubItem33, Me.SpreadsheetCommandBarButtonItem168, Me.SpreadsheetCommandBarButtonItem169, Me.ChangeSheetTabColorItem1, Me.SpreadsheetCommandBarCheckItem40, Me.SpreadsheetCommandBarButtonItem170, Me.SpreadsheetCommandBarSubItem35, Me.SpreadsheetCommandBarSubItem36, Me.SpreadsheetCommandBarButtonItem171, Me.SpreadsheetCommandBarButtonItem172, Me.SpreadsheetCommandBarButtonItem173, Me.SpreadsheetCommandBarButtonItem174, Me.SpreadsheetCommandBarSubItem37, Me.SpreadsheetCommandBarButtonItem175, Me.SpreadsheetCommandBarButtonItem176, Me.SpreadsheetCommandBarButtonItem177, Me.SpreadsheetCommandBarButtonItem178, Me.SpreadsheetCommandBarButtonItem179, Me.SpreadsheetCommandBarButtonItem180, Me.SpreadsheetCommandBarSubItem38, Me.SpreadsheetCommandBarSubItem39, Me.SpreadsheetCommandBarButtonItem181, Me.SpreadsheetCommandBarButtonItem182, Me.SpreadsheetCommandBarButtonItem183, Me.SpreadsheetCommandBarButtonItem184, Me.SpreadsheetCommandBarButtonItem185, Me.SpreadsheetCommandBarButtonItem186, Me.SpreadsheetCommandBarButtonItem187, Me.SpreadsheetCommandBarButtonItem188, Me.SpreadsheetCommandBarButtonItem189, Me.SpreadsheetCommandBarButtonItem190, Me.SpreadsheetCommandBarButtonItem191, Me.SpreadsheetCommandBarButtonItem192, Me.SpreadsheetCommandBarButtonItem193, Me.SpreadsheetCommandBarButtonItem194, Me.SpreadsheetCommandBarButtonItem195, Me.SpreadsheetCommandBarButtonItem196, Me.SpreadsheetCommandBarButtonItem197, Me.SpreadsheetCommandBarButtonItem198})
        Me.ribbonControl.LargeImages = Me.ribbonImageCollectionLarge
        Me.ribbonControl.Location = New System.Drawing.Point(0, 0)
        Me.ribbonControl.MaxItemId = 400
        Me.ribbonControl.Name = "ribbonControl"
        Me.ribbonControl.PageCategories.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageCategory() {Me.PivotTableToolsRibbonPageCategory1, Me.PictureToolsRibbonPageCategory1, Me.DrawingToolsRibbonPageCategory1, Me.TableToolsRibbonPageCategory1, Me.ChartToolsRibbonPageCategory1})
        Me.ribbonControl.PageHeaderItemLinks.Add(Me.iAbout)
        Me.ribbonControl.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.FileRibbonPage1, Me.HomeRibbonPage1, Me.InsertRibbonPage1, Me.PageLayoutRibbonPage1, Me.FormulasRibbonPage1, Me.DataRibbonPage1, Me.ReviewRibbonPage1, Me.ViewRibbonPage1, Me.RibbonPageSkins, Me.helpRibbonPage})
        Me.ribbonControl.QuickToolbarItemLinks.Add(Me.iHelp)
        Me.ribbonControl.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.RepositoryItemTextEdit1, Me.RepositoryItemFontEdit1, Me.RepositoryItemSpreadsheetFontSizeEdit1, Me.RepositoryItemPopupGalleryEdit1})
        Me.ribbonControl.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2010
        Me.ribbonControl.Size = New System.Drawing.Size(1108, 146)
        Me.ribbonControl.StatusBar = Me.ribbonStatusBar
        '
        'appMenu
        '
        Me.appMenu.BottomPaneControlContainer = Me.popupControlContainer2
        Me.appMenu.ItemLinks.Add(Me.iExit)
        Me.appMenu.Name = "appMenu"
        Me.appMenu.Ribbon = Me.ribbonControl
        Me.appMenu.RightPaneControlContainer = Me.popupControlContainer1
        Me.appMenu.ShowRightPane = True
        '
        'popupControlContainer2
        '
        Me.popupControlContainer2.Appearance.BackColor = System.Drawing.Color.Transparent
        Me.popupControlContainer2.Appearance.Options.UseBackColor = True
        Me.popupControlContainer2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.popupControlContainer2.Controls.Add(Me.buttonEdit)
        Me.popupControlContainer2.Location = New System.Drawing.Point(238, 289)
        Me.popupControlContainer2.Name = "popupControlContainer2"
        Me.popupControlContainer2.Ribbon = Me.ribbonControl
        Me.popupControlContainer2.Size = New System.Drawing.Size(118, 28)
        Me.popupControlContainer2.TabIndex = 7
        Me.popupControlContainer2.Visible = False
        '
        'buttonEdit
        '
        Me.buttonEdit.EditValue = "Some Text"
        Me.buttonEdit.Location = New System.Drawing.Point(3, 5)
        Me.buttonEdit.MenuManager = Me.ribbonControl
        Me.buttonEdit.Name = "buttonEdit"
        Me.buttonEdit.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton()})
        Me.buttonEdit.Size = New System.Drawing.Size(100, 20)
        Me.buttonEdit.TabIndex = 0
        '
        'iExit
        '
        Me.iExit.Caption = "Exit"
        Me.iExit.Description = "Closes this program after prompting you to save unsaved data."
        Me.iExit.Hint = "Closes this program after prompting you to save unsaved data"
        Me.iExit.Id = 20
        Me.iExit.ImageOptions.ImageIndex = 6
        Me.iExit.ImageOptions.LargeImageIndex = 6
        Me.iExit.Name = "iExit"
        '
        'popupControlContainer1
        '
        Me.popupControlContainer1.Appearance.BackColor = System.Drawing.Color.Transparent
        Me.popupControlContainer1.Appearance.Options.UseBackColor = True
        Me.popupControlContainer1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.popupControlContainer1.Controls.Add(Me.someLabelControl2)
        Me.popupControlContainer1.Controls.Add(Me.someLabelControl1)
        Me.popupControlContainer1.Location = New System.Drawing.Point(111, 197)
        Me.popupControlContainer1.Name = "popupControlContainer1"
        Me.popupControlContainer1.Ribbon = Me.ribbonControl
        Me.popupControlContainer1.Size = New System.Drawing.Size(76, 70)
        Me.popupControlContainer1.TabIndex = 6
        Me.popupControlContainer1.Visible = False
        '
        'someLabelControl2
        '
        Me.someLabelControl2.Location = New System.Drawing.Point(3, 57)
        Me.someLabelControl2.Name = "someLabelControl2"
        Me.someLabelControl2.Size = New System.Drawing.Size(49, 13)
        Me.someLabelControl2.TabIndex = 0
        Me.someLabelControl2.Text = "Some Info"
        '
        'someLabelControl1
        '
        Me.someLabelControl1.Location = New System.Drawing.Point(3, 3)
        Me.someLabelControl1.Name = "someLabelControl1"
        Me.someLabelControl1.Size = New System.Drawing.Size(49, 13)
        Me.someLabelControl1.TabIndex = 0
        Me.someLabelControl1.Text = "Some Info"
        '
        'ribbonImageCollection
        '
        Me.ribbonImageCollection.ImageStream = CType(resources.GetObject("ribbonImageCollection.ImageStream"), DevExpress.Utils.ImageCollectionStreamer)
        Me.ribbonImageCollection.Images.SetKeyName(0, "Ribbon_New_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(1, "Ribbon_Open_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(2, "Ribbon_Close_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(3, "Ribbon_Find_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(4, "Ribbon_Save_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(5, "Ribbon_SaveAs_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(6, "Ribbon_Exit_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(7, "Ribbon_Content_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(8, "Ribbon_Info_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(9, "Ribbon_Bold_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(10, "Ribbon_Italic_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(11, "Ribbon_Underline_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(12, "Ribbon_AlignLeft_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(13, "Ribbon_AlignCenter_16x16.png")
        Me.ribbonImageCollection.Images.SetKeyName(14, "Ribbon_AlignRight_16x16.png")
        '
        'iHelp
        '
        Me.iHelp.Caption = "Help"
        Me.iHelp.Description = "Start the program help system."
        Me.iHelp.Hint = "Start the program help system"
        Me.iHelp.Id = 22
        Me.iHelp.ImageOptions.ImageIndex = 7
        Me.iHelp.ImageOptions.LargeImageIndex = 7
        Me.iHelp.Name = "iHelp"
        '
        'iAbout
        '
        Me.iAbout.Caption = "About"
        Me.iAbout.Description = "Displays general program information."
        Me.iAbout.Hint = "Displays general program information"
        Me.iAbout.Id = 24
        Me.iAbout.ImageOptions.ImageIndex = 8
        Me.iAbout.ImageOptions.LargeImageIndex = 8
        Me.iAbout.Name = "iAbout"
        '
        'siStatus
        '
        Me.siStatus.Caption = "Some Status Info"
        Me.siStatus.Id = 31
        Me.siStatus.Name = "siStatus"
        '
        'siInfo
        '
        Me.siInfo.Caption = "Some Info"
        Me.siInfo.Id = 32
        Me.siInfo.Name = "siInfo"
        '
        'rgbiSkins
        '
        Me.rgbiSkins.Caption = "Skins"
        '
        '
        '
        Me.rgbiSkins.Gallery.AllowHoverImages = True
        Me.rgbiSkins.Gallery.Appearance.ItemCaptionAppearance.Normal.Options.UseFont = True
        Me.rgbiSkins.Gallery.Appearance.ItemCaptionAppearance.Normal.Options.UseTextOptions = True
        Me.rgbiSkins.Gallery.Appearance.ItemCaptionAppearance.Normal.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.rgbiSkins.Gallery.ColumnCount = 4
        Me.rgbiSkins.Gallery.FixedHoverImageSize = False
        Me.rgbiSkins.Gallery.ImageSize = New System.Drawing.Size(32, 17)
        Me.rgbiSkins.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Top
        Me.rgbiSkins.Gallery.RowCount = 4
        Me.rgbiSkins.Id = 60
        Me.rgbiSkins.Name = "rgbiSkins"
        '
        'SpreadsheetCommandBarSubItem1
        '
        Me.SpreadsheetCommandBarSubItem1.CommandName = "PivotTableLayoutSubtotalsGroup"
        Me.SpreadsheetCommandBarSubItem1.Id = 62
        Me.SpreadsheetCommandBarSubItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem2), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem3)})
        Me.SpreadsheetCommandBarSubItem1.Name = "SpreadsheetCommandBarSubItem1"
        '
        'SpreadsheetCommandBarButtonItem1
        '
        Me.SpreadsheetCommandBarButtonItem1.CommandName = "PivotTableDoNotShowSubtotals"
        Me.SpreadsheetCommandBarButtonItem1.Id = 63
        Me.SpreadsheetCommandBarButtonItem1.Name = "SpreadsheetCommandBarButtonItem1"
        Me.SpreadsheetCommandBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem2
        '
        Me.SpreadsheetCommandBarButtonItem2.CommandName = "PivotTableShowAllSubtotalsAtBottom"
        Me.SpreadsheetCommandBarButtonItem2.Id = 64
        Me.SpreadsheetCommandBarButtonItem2.Name = "SpreadsheetCommandBarButtonItem2"
        Me.SpreadsheetCommandBarButtonItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem3
        '
        Me.SpreadsheetCommandBarButtonItem3.CommandName = "PivotTableShowAllSubtotalsAtTop"
        Me.SpreadsheetCommandBarButtonItem3.Id = 65
        Me.SpreadsheetCommandBarButtonItem3.Name = "SpreadsheetCommandBarButtonItem3"
        Me.SpreadsheetCommandBarButtonItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarSubItem2
        '
        Me.SpreadsheetCommandBarSubItem2.CommandName = "PivotTableLayoutGrandTotalsGroup"
        Me.SpreadsheetCommandBarSubItem2.Id = 66
        Me.SpreadsheetCommandBarSubItem2.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem4), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem5), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem6), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem7)})
        Me.SpreadsheetCommandBarSubItem2.Name = "SpreadsheetCommandBarSubItem2"
        '
        'SpreadsheetCommandBarButtonItem4
        '
        Me.SpreadsheetCommandBarButtonItem4.CommandName = "PivotTableGrandTotalsOffRowsColumns"
        Me.SpreadsheetCommandBarButtonItem4.Id = 67
        Me.SpreadsheetCommandBarButtonItem4.Name = "SpreadsheetCommandBarButtonItem4"
        Me.SpreadsheetCommandBarButtonItem4.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem5
        '
        Me.SpreadsheetCommandBarButtonItem5.CommandName = "PivotTableGrandTotalsOnRowsColumns"
        Me.SpreadsheetCommandBarButtonItem5.Id = 68
        Me.SpreadsheetCommandBarButtonItem5.Name = "SpreadsheetCommandBarButtonItem5"
        Me.SpreadsheetCommandBarButtonItem5.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem6
        '
        Me.SpreadsheetCommandBarButtonItem6.CommandName = "PivotTableGrandTotalsOnRowsOnly"
        Me.SpreadsheetCommandBarButtonItem6.Id = 69
        Me.SpreadsheetCommandBarButtonItem6.Name = "SpreadsheetCommandBarButtonItem6"
        Me.SpreadsheetCommandBarButtonItem6.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem7
        '
        Me.SpreadsheetCommandBarButtonItem7.CommandName = "PivotTableGrandTotalsOnColumnsOnly"
        Me.SpreadsheetCommandBarButtonItem7.Id = 70
        Me.SpreadsheetCommandBarButtonItem7.Name = "SpreadsheetCommandBarButtonItem7"
        Me.SpreadsheetCommandBarButtonItem7.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarSubItem3
        '
        Me.SpreadsheetCommandBarSubItem3.CommandName = "PivotTableLayoutReportLayoutGroup"
        Me.SpreadsheetCommandBarSubItem3.Id = 71
        Me.SpreadsheetCommandBarSubItem3.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem8), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem9), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem10), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem11), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem12)})
        Me.SpreadsheetCommandBarSubItem3.Name = "SpreadsheetCommandBarSubItem3"
        '
        'SpreadsheetCommandBarButtonItem8
        '
        Me.SpreadsheetCommandBarButtonItem8.CommandName = "PivotTableShowCompactForm"
        Me.SpreadsheetCommandBarButtonItem8.Id = 72
        Me.SpreadsheetCommandBarButtonItem8.Name = "SpreadsheetCommandBarButtonItem8"
        Me.SpreadsheetCommandBarButtonItem8.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem9
        '
        Me.SpreadsheetCommandBarButtonItem9.CommandName = "PivotTableShowOutlineForm"
        Me.SpreadsheetCommandBarButtonItem9.Id = 73
        Me.SpreadsheetCommandBarButtonItem9.Name = "SpreadsheetCommandBarButtonItem9"
        Me.SpreadsheetCommandBarButtonItem9.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem10
        '
        Me.SpreadsheetCommandBarButtonItem10.CommandName = "PivotTableShowTabularForm"
        Me.SpreadsheetCommandBarButtonItem10.Id = 74
        Me.SpreadsheetCommandBarButtonItem10.Name = "SpreadsheetCommandBarButtonItem10"
        Me.SpreadsheetCommandBarButtonItem10.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem11
        '
        Me.SpreadsheetCommandBarButtonItem11.CommandName = "PivotTableRepeatAllItemLabels"
        Me.SpreadsheetCommandBarButtonItem11.Id = 75
        Me.SpreadsheetCommandBarButtonItem11.Name = "SpreadsheetCommandBarButtonItem11"
        Me.SpreadsheetCommandBarButtonItem11.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem12
        '
        Me.SpreadsheetCommandBarButtonItem12.CommandName = "PivotTableDoNotRepeatItemLabels"
        Me.SpreadsheetCommandBarButtonItem12.Id = 76
        Me.SpreadsheetCommandBarButtonItem12.Name = "SpreadsheetCommandBarButtonItem12"
        Me.SpreadsheetCommandBarButtonItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarSubItem4
        '
        Me.SpreadsheetCommandBarSubItem4.CommandName = "PivotTableLayoutBlankRowsGroup"
        Me.SpreadsheetCommandBarSubItem4.Id = 77
        Me.SpreadsheetCommandBarSubItem4.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem13), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem14)})
        Me.SpreadsheetCommandBarSubItem4.Name = "SpreadsheetCommandBarSubItem4"
        '
        'SpreadsheetCommandBarButtonItem13
        '
        Me.SpreadsheetCommandBarButtonItem13.CommandName = "PivotTableInsertBlankLineEachItem"
        Me.SpreadsheetCommandBarButtonItem13.Id = 78
        Me.SpreadsheetCommandBarButtonItem13.Name = "SpreadsheetCommandBarButtonItem13"
        Me.SpreadsheetCommandBarButtonItem13.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem14
        '
        Me.SpreadsheetCommandBarButtonItem14.CommandName = "PivotTableRemoveBlankLineEachItem"
        Me.SpreadsheetCommandBarButtonItem14.Id = 79
        Me.SpreadsheetCommandBarButtonItem14.Name = "SpreadsheetCommandBarButtonItem14"
        Me.SpreadsheetCommandBarButtonItem14.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarCheckItem1
        '
        Me.SpreadsheetCommandBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem1.CommandName = "PivotTableToggleRowHeaders"
        Me.SpreadsheetCommandBarCheckItem1.Id = 80
        Me.SpreadsheetCommandBarCheckItem1.Name = "SpreadsheetCommandBarCheckItem1"
        '
        'SpreadsheetCommandBarCheckItem2
        '
        Me.SpreadsheetCommandBarCheckItem2.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem2.CommandName = "PivotTableToggleColumnHeaders"
        Me.SpreadsheetCommandBarCheckItem2.Id = 81
        Me.SpreadsheetCommandBarCheckItem2.Name = "SpreadsheetCommandBarCheckItem2"
        '
        'SpreadsheetCommandBarCheckItem3
        '
        Me.SpreadsheetCommandBarCheckItem3.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem3.CommandName = "PivotTableToggleBandedRows"
        Me.SpreadsheetCommandBarCheckItem3.Id = 82
        Me.SpreadsheetCommandBarCheckItem3.Name = "SpreadsheetCommandBarCheckItem3"
        '
        'SpreadsheetCommandBarCheckItem4
        '
        Me.SpreadsheetCommandBarCheckItem4.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem4.CommandName = "PivotTableToggleBandedColumns"
        Me.SpreadsheetCommandBarCheckItem4.Id = 83
        Me.SpreadsheetCommandBarCheckItem4.Name = "SpreadsheetCommandBarCheckItem4"
        '
        'GalleryPivotStylesItem1
        '
        '
        '
        '
        Me.GalleryPivotStylesItem1.Gallery.ColumnCount = 7
        Me.GalleryPivotStylesItem1.Gallery.DrawImageBackground = False
        Me.GalleryPivotStylesItem1.Gallery.ImageSize = New System.Drawing.Size(65, 46)
        Me.GalleryPivotStylesItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
        Me.GalleryPivotStylesItem1.Gallery.ItemSize = New System.Drawing.Size(73, 61)
        Me.GalleryPivotStylesItem1.Gallery.RowCount = 10
        Me.GalleryPivotStylesItem1.Id = 84
        Me.GalleryPivotStylesItem1.Name = "GalleryPivotStylesItem1"
        '
        'SpreadsheetCommandBarButtonItem15
        '
        Me.SpreadsheetCommandBarButtonItem15.CommandName = "OptionsPivotTable"
        Me.SpreadsheetCommandBarButtonItem15.Id = 85
        Me.SpreadsheetCommandBarButtonItem15.Name = "SpreadsheetCommandBarButtonItem15"
        '
        'SpreadsheetCommandBarButtonItem16
        '
        Me.SpreadsheetCommandBarButtonItem16.CommandName = "SelectFieldTypePivotTable"
        Me.SpreadsheetCommandBarButtonItem16.Id = 86
        Me.SpreadsheetCommandBarButtonItem16.Name = "SpreadsheetCommandBarButtonItem16"
        '
        'SpreadsheetCommandBarButtonItem17
        '
        Me.SpreadsheetCommandBarButtonItem17.CommandName = "PivotTableExpandField"
        Me.SpreadsheetCommandBarButtonItem17.Id = 87
        Me.SpreadsheetCommandBarButtonItem17.Name = "SpreadsheetCommandBarButtonItem17"
        Me.SpreadsheetCommandBarButtonItem17.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem18
        '
        Me.SpreadsheetCommandBarButtonItem18.CommandName = "PivotTableCollapseField"
        Me.SpreadsheetCommandBarButtonItem18.Id = 88
        Me.SpreadsheetCommandBarButtonItem18.Name = "SpreadsheetCommandBarButtonItem18"
        Me.SpreadsheetCommandBarButtonItem18.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem19
        '
        Me.SpreadsheetCommandBarButtonItem19.CommandName = "PivotTableGroupSelection"
        Me.SpreadsheetCommandBarButtonItem19.Id = 89
        Me.SpreadsheetCommandBarButtonItem19.Name = "SpreadsheetCommandBarButtonItem19"
        Me.SpreadsheetCommandBarButtonItem19.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem20
        '
        Me.SpreadsheetCommandBarButtonItem20.CommandName = "PivotTableUngroup"
        Me.SpreadsheetCommandBarButtonItem20.Id = 90
        Me.SpreadsheetCommandBarButtonItem20.Name = "SpreadsheetCommandBarButtonItem20"
        Me.SpreadsheetCommandBarButtonItem20.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem21
        '
        Me.SpreadsheetCommandBarButtonItem21.CommandName = "PivotTableGroupField"
        Me.SpreadsheetCommandBarButtonItem21.Id = 91
        Me.SpreadsheetCommandBarButtonItem21.Name = "SpreadsheetCommandBarButtonItem21"
        Me.SpreadsheetCommandBarButtonItem21.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarSubItem5
        '
        Me.SpreadsheetCommandBarSubItem5.CommandName = "PivotTableDataRefreshGroup"
        Me.SpreadsheetCommandBarSubItem5.Id = 92
        Me.SpreadsheetCommandBarSubItem5.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem22), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem23)})
        Me.SpreadsheetCommandBarSubItem5.Name = "SpreadsheetCommandBarSubItem5"
        '
        'SpreadsheetCommandBarButtonItem22
        '
        Me.SpreadsheetCommandBarButtonItem22.CommandName = "RefreshPivotTable"
        Me.SpreadsheetCommandBarButtonItem22.Id = 93
        Me.SpreadsheetCommandBarButtonItem22.Name = "SpreadsheetCommandBarButtonItem22"
        '
        'SpreadsheetCommandBarButtonItem23
        '
        Me.SpreadsheetCommandBarButtonItem23.CommandName = "RefreshAllPivotTable"
        Me.SpreadsheetCommandBarButtonItem23.Id = 94
        Me.SpreadsheetCommandBarButtonItem23.Name = "SpreadsheetCommandBarButtonItem23"
        '
        'SpreadsheetCommandBarButtonItem24
        '
        Me.SpreadsheetCommandBarButtonItem24.CommandName = "ChangeDataSourcePivotTable"
        Me.SpreadsheetCommandBarButtonItem24.Id = 95
        Me.SpreadsheetCommandBarButtonItem24.Name = "SpreadsheetCommandBarButtonItem24"
        '
        'SpreadsheetCommandBarSubItem6
        '
        Me.SpreadsheetCommandBarSubItem6.CommandName = "PivotTableActionsClearGroup"
        Me.SpreadsheetCommandBarSubItem6.Id = 96
        Me.SpreadsheetCommandBarSubItem6.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem25), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem26)})
        Me.SpreadsheetCommandBarSubItem6.Name = "SpreadsheetCommandBarSubItem6"
        '
        'SpreadsheetCommandBarButtonItem25
        '
        Me.SpreadsheetCommandBarButtonItem25.CommandName = "ClearAllPivotTable"
        Me.SpreadsheetCommandBarButtonItem25.Id = 97
        Me.SpreadsheetCommandBarButtonItem25.Name = "SpreadsheetCommandBarButtonItem25"
        '
        'SpreadsheetCommandBarButtonItem26
        '
        Me.SpreadsheetCommandBarButtonItem26.CommandName = "ClearFiltersPivotTable"
        Me.SpreadsheetCommandBarButtonItem26.Id = 98
        Me.SpreadsheetCommandBarButtonItem26.Name = "SpreadsheetCommandBarButtonItem26"
        '
        'SpreadsheetCommandBarSubItem7
        '
        Me.SpreadsheetCommandBarSubItem7.CommandName = "PivotTableActionsSelectGroup"
        Me.SpreadsheetCommandBarSubItem7.Id = 99
        Me.SpreadsheetCommandBarSubItem7.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem27), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem28), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem29)})
        Me.SpreadsheetCommandBarSubItem7.Name = "SpreadsheetCommandBarSubItem7"
        '
        'SpreadsheetCommandBarButtonItem27
        '
        Me.SpreadsheetCommandBarButtonItem27.CommandName = "SelectValuesPivotTable"
        Me.SpreadsheetCommandBarButtonItem27.Id = 100
        Me.SpreadsheetCommandBarButtonItem27.Name = "SpreadsheetCommandBarButtonItem27"
        '
        'SpreadsheetCommandBarButtonItem28
        '
        Me.SpreadsheetCommandBarButtonItem28.CommandName = "SelectLabelsPivotTable"
        Me.SpreadsheetCommandBarButtonItem28.Id = 101
        Me.SpreadsheetCommandBarButtonItem28.Name = "SpreadsheetCommandBarButtonItem28"
        '
        'SpreadsheetCommandBarButtonItem29
        '
        Me.SpreadsheetCommandBarButtonItem29.CommandName = "SelectEntirePivotTable"
        Me.SpreadsheetCommandBarButtonItem29.Id = 102
        Me.SpreadsheetCommandBarButtonItem29.Name = "SpreadsheetCommandBarButtonItem29"
        '
        'SpreadsheetCommandBarButtonItem30
        '
        Me.SpreadsheetCommandBarButtonItem30.CommandName = "MovePivotTable"
        Me.SpreadsheetCommandBarButtonItem30.Id = 103
        Me.SpreadsheetCommandBarButtonItem30.Name = "SpreadsheetCommandBarButtonItem30"
        '
        'SpreadsheetCommandBarSubItem8
        '
        Me.SpreadsheetCommandBarSubItem8.CommandName = "PivotTableCalculationFieldsItemsSetsGroup"
        Me.SpreadsheetCommandBarSubItem8.Id = 104
        Me.SpreadsheetCommandBarSubItem8.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem31), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem32), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem33), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem34)})
        Me.SpreadsheetCommandBarSubItem8.Name = "SpreadsheetCommandBarSubItem8"
        '
        'SpreadsheetCommandBarButtonItem31
        '
        Me.SpreadsheetCommandBarButtonItem31.CommandName = "PivotTableCalculatedField"
        Me.SpreadsheetCommandBarButtonItem31.Id = 105
        Me.SpreadsheetCommandBarButtonItem31.Name = "SpreadsheetCommandBarButtonItem31"
        '
        'SpreadsheetCommandBarButtonItem32
        '
        Me.SpreadsheetCommandBarButtonItem32.CommandName = "PivotTableCalculatedItem"
        Me.SpreadsheetCommandBarButtonItem32.Id = 106
        Me.SpreadsheetCommandBarButtonItem32.Name = "SpreadsheetCommandBarButtonItem32"
        '
        'SpreadsheetCommandBarButtonItem33
        '
        Me.SpreadsheetCommandBarButtonItem33.CommandName = "PivotTableCalculatedItemSolveOrder"
        Me.SpreadsheetCommandBarButtonItem33.Id = 107
        Me.SpreadsheetCommandBarButtonItem33.Name = "SpreadsheetCommandBarButtonItem33"
        '
        'SpreadsheetCommandBarButtonItem34
        '
        Me.SpreadsheetCommandBarButtonItem34.CommandName = "PivotTableListFormulas"
        Me.SpreadsheetCommandBarButtonItem34.Id = 108
        Me.SpreadsheetCommandBarButtonItem34.Name = "SpreadsheetCommandBarButtonItem34"
        '
        'SpreadsheetCommandBarCheckItem5
        '
        Me.SpreadsheetCommandBarCheckItem5.CommandName = "FieldListPanelPivotTable"
        Me.SpreadsheetCommandBarCheckItem5.Id = 109
        Me.SpreadsheetCommandBarCheckItem5.Name = "SpreadsheetCommandBarCheckItem5"
        '
        'SpreadsheetCommandBarCheckItem6
        '
        Me.SpreadsheetCommandBarCheckItem6.CommandName = "ShowPivotTableExpandCollapseButtons"
        Me.SpreadsheetCommandBarCheckItem6.Id = 110
        Me.SpreadsheetCommandBarCheckItem6.Name = "SpreadsheetCommandBarCheckItem6"
        '
        'SpreadsheetCommandBarCheckItem7
        '
        Me.SpreadsheetCommandBarCheckItem7.CommandName = "ShowPivotTableFieldHeaders"
        Me.SpreadsheetCommandBarCheckItem7.Id = 111
        Me.SpreadsheetCommandBarCheckItem7.Name = "SpreadsheetCommandBarCheckItem7"
        '
        'SpreadsheetCommandBarSubItem9
        '
        Me.SpreadsheetCommandBarSubItem9.CommandName = "ArrangeBringForwardCommandGroup"
        Me.SpreadsheetCommandBarSubItem9.Id = 112
        Me.SpreadsheetCommandBarSubItem9.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem35), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem36)})
        Me.SpreadsheetCommandBarSubItem9.Name = "SpreadsheetCommandBarSubItem9"
        '
        'SpreadsheetCommandBarButtonItem35
        '
        Me.SpreadsheetCommandBarButtonItem35.CommandName = "ArrangeBringForward"
        Me.SpreadsheetCommandBarButtonItem35.Id = 113
        Me.SpreadsheetCommandBarButtonItem35.Name = "SpreadsheetCommandBarButtonItem35"
        '
        'SpreadsheetCommandBarButtonItem36
        '
        Me.SpreadsheetCommandBarButtonItem36.CommandName = "ArrangeBringToFront"
        Me.SpreadsheetCommandBarButtonItem36.Id = 114
        Me.SpreadsheetCommandBarButtonItem36.Name = "SpreadsheetCommandBarButtonItem36"
        '
        'SpreadsheetCommandBarSubItem10
        '
        Me.SpreadsheetCommandBarSubItem10.CommandName = "ArrangeSendBackwardCommandGroup"
        Me.SpreadsheetCommandBarSubItem10.Id = 115
        Me.SpreadsheetCommandBarSubItem10.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem37), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem38)})
        Me.SpreadsheetCommandBarSubItem10.Name = "SpreadsheetCommandBarSubItem10"
        '
        'SpreadsheetCommandBarButtonItem37
        '
        Me.SpreadsheetCommandBarButtonItem37.CommandName = "ArrangeSendBackward"
        Me.SpreadsheetCommandBarButtonItem37.Id = 116
        Me.SpreadsheetCommandBarButtonItem37.Name = "SpreadsheetCommandBarButtonItem37"
        '
        'SpreadsheetCommandBarButtonItem38
        '
        Me.SpreadsheetCommandBarButtonItem38.CommandName = "ArrangeSendToBack"
        Me.SpreadsheetCommandBarButtonItem38.Id = 117
        Me.SpreadsheetCommandBarButtonItem38.Name = "SpreadsheetCommandBarButtonItem38"
        '
        'RenameTableItemCaption1
        '
        Me.RenameTableItemCaption1.Id = 118
        Me.RenameTableItemCaption1.Name = "RenameTableItemCaption1"
        '
        'RenameTableItem1
        '
        Me.RenameTableItem1.Edit = Me.RepositoryItemTextEdit1
        Me.RenameTableItem1.Id = 119
        Me.RenameTableItem1.Name = "RenameTableItem1"
        '
        'RepositoryItemTextEdit1
        '
        Me.RepositoryItemTextEdit1.AutoHeight = False
        Me.RepositoryItemTextEdit1.Name = "RepositoryItemTextEdit1"
        '
        'SpreadsheetCommandBarCheckItem8
        '
        Me.SpreadsheetCommandBarCheckItem8.CommandName = "TableToolsConvertToRange"
        Me.SpreadsheetCommandBarCheckItem8.Id = 120
        Me.SpreadsheetCommandBarCheckItem8.Name = "SpreadsheetCommandBarCheckItem8"
        Me.SpreadsheetCommandBarCheckItem8.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarCheckItem9
        '
        Me.SpreadsheetCommandBarCheckItem9.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem9.CommandName = "TableToolsToggleHeaderRow"
        Me.SpreadsheetCommandBarCheckItem9.Id = 121
        Me.SpreadsheetCommandBarCheckItem9.Name = "SpreadsheetCommandBarCheckItem9"
        '
        'SpreadsheetCommandBarCheckItem10
        '
        Me.SpreadsheetCommandBarCheckItem10.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem10.CommandName = "TableToolsToggleTotalRow"
        Me.SpreadsheetCommandBarCheckItem10.Id = 122
        Me.SpreadsheetCommandBarCheckItem10.Name = "SpreadsheetCommandBarCheckItem10"
        '
        'SpreadsheetCommandBarCheckItem11
        '
        Me.SpreadsheetCommandBarCheckItem11.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem11.CommandName = "TableToolsToggleBandedColumns"
        Me.SpreadsheetCommandBarCheckItem11.Id = 123
        Me.SpreadsheetCommandBarCheckItem11.Name = "SpreadsheetCommandBarCheckItem11"
        '
        'SpreadsheetCommandBarCheckItem12
        '
        Me.SpreadsheetCommandBarCheckItem12.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem12.CommandName = "TableToolsToggleFirstColumn"
        Me.SpreadsheetCommandBarCheckItem12.Id = 124
        Me.SpreadsheetCommandBarCheckItem12.Name = "SpreadsheetCommandBarCheckItem12"
        '
        'SpreadsheetCommandBarCheckItem13
        '
        Me.SpreadsheetCommandBarCheckItem13.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem13.CommandName = "TableToolsToggleLastColumn"
        Me.SpreadsheetCommandBarCheckItem13.Id = 125
        Me.SpreadsheetCommandBarCheckItem13.Name = "SpreadsheetCommandBarCheckItem13"
        '
        'SpreadsheetCommandBarCheckItem14
        '
        Me.SpreadsheetCommandBarCheckItem14.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem14.CommandName = "TableToolsToggleBandedRows"
        Me.SpreadsheetCommandBarCheckItem14.Id = 126
        Me.SpreadsheetCommandBarCheckItem14.Name = "SpreadsheetCommandBarCheckItem14"
        '
        'GalleryTableStylesItem1
        '
        '
        '
        '
        Me.GalleryTableStylesItem1.Gallery.ColumnCount = 7
        Me.GalleryTableStylesItem1.Gallery.DrawImageBackground = False
        Me.GalleryTableStylesItem1.Gallery.ImageSize = New System.Drawing.Size(65, 46)
        Me.GalleryTableStylesItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
        Me.GalleryTableStylesItem1.Gallery.ItemSize = New System.Drawing.Size(73, 58)
        Me.GalleryTableStylesItem1.Gallery.RowCount = 10
        Me.GalleryTableStylesItem1.Id = 127
        Me.GalleryTableStylesItem1.Name = "GalleryTableStylesItem1"
        '
        'SpreadsheetCommandBarSubItem11
        '
        Me.SpreadsheetCommandBarSubItem11.CommandName = "ChartAxesCommandGroup"
        Me.SpreadsheetCommandBarSubItem11.Id = 128
        Me.SpreadsheetCommandBarSubItem11.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonGalleryDropDownItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonGalleryDropDownItem2)})
        Me.SpreadsheetCommandBarSubItem11.Name = "SpreadsheetCommandBarSubItem11"
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem1
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem1.CommandName = "ChartPrimaryHorizontalAxisCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem1.DropDownControl = Me.CommandBarGalleryDropDown1
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem1.Id = 129
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem1.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem1"
        '
        'CommandBarGalleryDropDown1
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown1.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown1.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup1.CommandName = "ChartPrimaryHorizontalAxisCommandGroup"
        SpreadsheetCommandGalleryItem1.CommandName = "ChartHidePrimaryHorizontalAxis"
        SpreadsheetCommandGalleryItem1.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem2.CommandName = "ChartPrimaryHorizontalAxisLeftToRight"
        SpreadsheetCommandGalleryItem2.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage1"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem3.CommandName = "ChartPrimaryHorizontalAxisHideLabels"
        SpreadsheetCommandGalleryItem3.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage2"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem4.CommandName = "ChartPrimaryHorizontalAxisRightToLeft"
        SpreadsheetCommandGalleryItem4.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage3"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem5.CommandName = "ChartPrimaryHorizontalAxisDefault"
        SpreadsheetCommandGalleryItem5.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage4"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem6.CommandName = "ChartPrimaryHorizontalAxisScaleThousands"
        SpreadsheetCommandGalleryItem6.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage5"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem7.CommandName = "ChartPrimaryHorizontalAxisScaleMillions"
        SpreadsheetCommandGalleryItem7.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage6"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem8.CommandName = "ChartPrimaryHorizontalAxisScaleBillions"
        SpreadsheetCommandGalleryItem8.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage7"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem9.CommandName = "ChartPrimaryHorizontalAxisScaleLogarithm"
        SpreadsheetCommandGalleryItem9.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage8"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup1.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem1, SpreadsheetCommandGalleryItem2, SpreadsheetCommandGalleryItem3, SpreadsheetCommandGalleryItem4, SpreadsheetCommandGalleryItem5, SpreadsheetCommandGalleryItem6, SpreadsheetCommandGalleryItem7, SpreadsheetCommandGalleryItem8, SpreadsheetCommandGalleryItem9})
        Me.CommandBarGalleryDropDown1.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup1})
        Me.CommandBarGalleryDropDown1.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown1.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown1.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown1.Name = "CommandBarGalleryDropDown1"
        Me.CommandBarGalleryDropDown1.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem2
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem2.CommandName = "ChartPrimaryVerticalAxisCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem2.DropDownControl = Me.CommandBarGalleryDropDown2
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem2.Id = 130
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem2.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem2"
        '
        'CommandBarGalleryDropDown2
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown2.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown2.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup2.CommandName = "ChartPrimaryVerticalAxisCommandGroup"
        SpreadsheetCommandGalleryItem10.CommandName = "ChartHidePrimaryVerticalAxis"
        SpreadsheetCommandGalleryItem10.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage9"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem11.CommandName = "ChartPrimaryVerticalAxisLeftToRight"
        SpreadsheetCommandGalleryItem11.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage10"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem12.CommandName = "ChartPrimaryVerticalAxisHideLabels"
        SpreadsheetCommandGalleryItem12.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage11"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem13.CommandName = "ChartPrimaryVerticalAxisRightToLeft"
        SpreadsheetCommandGalleryItem13.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage12"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem14.CommandName = "ChartPrimaryVerticalAxisDefault"
        SpreadsheetCommandGalleryItem14.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage13"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem15.CommandName = "ChartPrimaryVerticalAxisScaleThousands"
        SpreadsheetCommandGalleryItem15.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage14"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem16.CommandName = "ChartPrimaryVerticalAxisScaleMillions"
        SpreadsheetCommandGalleryItem16.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage15"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem17.CommandName = "ChartPrimaryVerticalAxisScaleBillions"
        SpreadsheetCommandGalleryItem17.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage16"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem18.CommandName = "ChartPrimaryVerticalAxisScaleLogarithm"
        SpreadsheetCommandGalleryItem18.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage17"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup2.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem10, SpreadsheetCommandGalleryItem11, SpreadsheetCommandGalleryItem12, SpreadsheetCommandGalleryItem13, SpreadsheetCommandGalleryItem14, SpreadsheetCommandGalleryItem15, SpreadsheetCommandGalleryItem16, SpreadsheetCommandGalleryItem17, SpreadsheetCommandGalleryItem18})
        Me.CommandBarGalleryDropDown2.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup2})
        Me.CommandBarGalleryDropDown2.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown2.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown2.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown2.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown2.Name = "CommandBarGalleryDropDown2"
        Me.CommandBarGalleryDropDown2.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarSubItem12
        '
        Me.SpreadsheetCommandBarSubItem12.CommandName = "ChartGridlinesCommandGroup"
        Me.SpreadsheetCommandBarSubItem12.Id = 131
        Me.SpreadsheetCommandBarSubItem12.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonGalleryDropDownItem3), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonGalleryDropDownItem4)})
        Me.SpreadsheetCommandBarSubItem12.Name = "SpreadsheetCommandBarSubItem12"
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem3
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem3.CommandName = "ChartPrimaryHorizontalGridlinesCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem3.DropDownControl = Me.CommandBarGalleryDropDown3
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem3.Id = 132
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem3.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem3"
        '
        'CommandBarGalleryDropDown3
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown3.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown3.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup3.CommandName = "ChartPrimaryHorizontalGridlinesCommandGroup"
        SpreadsheetCommandGalleryItem19.CommandName = "ChartPrimaryHorizontalGridlinesNone"
        SpreadsheetCommandGalleryItem19.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage18"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem20.CommandName = "ChartPrimaryHorizontalGridlinesMajor"
        SpreadsheetCommandGalleryItem20.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage19"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem21.CommandName = "ChartPrimaryHorizontalGridlinesMinor"
        SpreadsheetCommandGalleryItem21.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage20"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem22.CommandName = "ChartPrimaryHorizontalGridlinesMajorAndMinor"
        SpreadsheetCommandGalleryItem22.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage21"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup3.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem19, SpreadsheetCommandGalleryItem20, SpreadsheetCommandGalleryItem21, SpreadsheetCommandGalleryItem22})
        Me.CommandBarGalleryDropDown3.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup3})
        Me.CommandBarGalleryDropDown3.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown3.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown3.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown3.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown3.Name = "CommandBarGalleryDropDown3"
        Me.CommandBarGalleryDropDown3.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem4
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem4.CommandName = "ChartPrimaryVerticalGridlinesCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem4.DropDownControl = Me.CommandBarGalleryDropDown4
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem4.Id = 133
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem4.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem4"
        '
        'CommandBarGalleryDropDown4
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown4.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown4.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup4.CommandName = "ChartPrimaryVerticalGridlinesCommandGroup"
        SpreadsheetCommandGalleryItem23.CommandName = "ChartPrimaryVerticalGridlinesNone"
        SpreadsheetCommandGalleryItem23.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage22"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem24.CommandName = "ChartPrimaryVerticalGridlinesMajor"
        SpreadsheetCommandGalleryItem24.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage23"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem25.CommandName = "ChartPrimaryVerticalGridlinesMinor"
        SpreadsheetCommandGalleryItem25.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage24"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem26.CommandName = "ChartPrimaryVerticalGridlinesMajorAndMinor"
        SpreadsheetCommandGalleryItem26.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage25"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup4.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem23, SpreadsheetCommandGalleryItem24, SpreadsheetCommandGalleryItem25, SpreadsheetCommandGalleryItem26})
        Me.CommandBarGalleryDropDown4.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup4})
        Me.CommandBarGalleryDropDown4.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown4.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown4.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown4.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown4.Name = "CommandBarGalleryDropDown4"
        Me.CommandBarGalleryDropDown4.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem5
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem5.CommandName = "ChartTitleCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem5.DropDownControl = Me.CommandBarGalleryDropDown5
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem5.Id = 134
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem5.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem5"
        '
        'CommandBarGalleryDropDown5
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown5.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown5.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup5.CommandName = "ChartTitleCommandGroup"
        SpreadsheetCommandGalleryItem27.CommandName = "ChartTitleNone"
        SpreadsheetCommandGalleryItem27.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage26"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem28.CommandName = "ChartTitleCenteredOverlay"
        SpreadsheetCommandGalleryItem28.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage27"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem29.CommandName = "ChartTitleAbove"
        SpreadsheetCommandGalleryItem29.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage28"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup5.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem27, SpreadsheetCommandGalleryItem28, SpreadsheetCommandGalleryItem29})
        Me.CommandBarGalleryDropDown5.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup5})
        Me.CommandBarGalleryDropDown5.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown5.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown5.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown5.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown5.Name = "CommandBarGalleryDropDown5"
        Me.CommandBarGalleryDropDown5.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarSubItem13
        '
        Me.SpreadsheetCommandBarSubItem13.CommandName = "ChartAxisTitlesCommandGroup"
        Me.SpreadsheetCommandBarSubItem13.Id = 135
        Me.SpreadsheetCommandBarSubItem13.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonGalleryDropDownItem6), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonGalleryDropDownItem7)})
        Me.SpreadsheetCommandBarSubItem13.Name = "SpreadsheetCommandBarSubItem13"
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem6
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem6.CommandName = "ChartPrimaryHorizontalAxisTitleCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem6.DropDownControl = Me.CommandBarGalleryDropDown6
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem6.Id = 136
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem6.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem6"
        '
        'CommandBarGalleryDropDown6
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown6.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown6.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup6.CommandName = "ChartPrimaryHorizontalAxisTitleCommandGroup"
        SpreadsheetCommandGalleryItem30.CommandName = "ChartPrimaryHorizontalAxisTitleNone"
        SpreadsheetCommandGalleryItem30.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage29"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem31.CommandName = "ChartPrimaryHorizontalAxisTitleBelow"
        SpreadsheetCommandGalleryItem31.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage30"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup6.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem30, SpreadsheetCommandGalleryItem31})
        Me.CommandBarGalleryDropDown6.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup6})
        Me.CommandBarGalleryDropDown6.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown6.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown6.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown6.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown6.Name = "CommandBarGalleryDropDown6"
        Me.CommandBarGalleryDropDown6.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem7
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem7.CommandName = "ChartPrimaryVerticalAxisTitleCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem7.DropDownControl = Me.CommandBarGalleryDropDown7
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem7.Id = 137
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem7.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem7"
        '
        'CommandBarGalleryDropDown7
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown7.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown7.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup7.CommandName = "ChartPrimaryVerticalAxisTitleCommandGroup"
        SpreadsheetCommandGalleryItem32.CommandName = "ChartPrimaryVerticalAxisTitleNone"
        SpreadsheetCommandGalleryItem32.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage31"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem33.CommandName = "ChartPrimaryVerticalAxisTitleRotated"
        SpreadsheetCommandGalleryItem33.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage32"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem34.CommandName = "ChartPrimaryVerticalAxisTitleVertical"
        SpreadsheetCommandGalleryItem34.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage33"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem35.CommandName = "ChartPrimaryVerticalAxisTitleHorizontal"
        SpreadsheetCommandGalleryItem35.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage34"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup7.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem32, SpreadsheetCommandGalleryItem33, SpreadsheetCommandGalleryItem34, SpreadsheetCommandGalleryItem35})
        Me.CommandBarGalleryDropDown7.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup7})
        Me.CommandBarGalleryDropDown7.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown7.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown7.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown7.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown7.Name = "CommandBarGalleryDropDown7"
        Me.CommandBarGalleryDropDown7.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem8
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem8.CommandName = "ChartLegendCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem8.DropDownControl = Me.CommandBarGalleryDropDown8
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem8.Id = 138
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem8.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem8"
        '
        'CommandBarGalleryDropDown8
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown8.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown8.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup8.CommandName = "ChartLegendCommandGroup"
        SpreadsheetCommandGalleryItem36.CommandName = "ChartLegendNone"
        SpreadsheetCommandGalleryItem36.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage35"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem37.CommandName = "ChartLegendAtRight"
        SpreadsheetCommandGalleryItem37.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage36"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem38.CommandName = "ChartLegendAtTop"
        SpreadsheetCommandGalleryItem38.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage37"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem39.CommandName = "ChartLegendAtLeft"
        SpreadsheetCommandGalleryItem39.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage38"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem40.CommandName = "ChartLegendAtBottom"
        SpreadsheetCommandGalleryItem40.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage39"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem41.CommandName = "ChartLegendOverlayAtRight"
        SpreadsheetCommandGalleryItem41.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage40"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem42.CommandName = "ChartLegendOverlayAtLeft"
        SpreadsheetCommandGalleryItem42.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage41"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup8.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem36, SpreadsheetCommandGalleryItem37, SpreadsheetCommandGalleryItem38, SpreadsheetCommandGalleryItem39, SpreadsheetCommandGalleryItem40, SpreadsheetCommandGalleryItem41, SpreadsheetCommandGalleryItem42})
        Me.CommandBarGalleryDropDown8.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup8})
        Me.CommandBarGalleryDropDown8.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown8.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown8.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown8.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown8.Name = "CommandBarGalleryDropDown8"
        Me.CommandBarGalleryDropDown8.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem9
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem9.CommandName = "ChartDataLabelsCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem9.DropDownControl = Me.CommandBarGalleryDropDown9
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem9.Id = 139
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem9.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem9"
        '
        'CommandBarGalleryDropDown9
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown9.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown9.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup9.CommandName = "ChartDataLabelsCommandGroup"
        SpreadsheetCommandGalleryItem43.CommandName = "ChartDataLabelsNone"
        SpreadsheetCommandGalleryItem43.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage42"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem44.CommandName = "ChartDataLabelsDefault"
        SpreadsheetCommandGalleryItem44.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage43"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem45.CommandName = "ChartDataLabelsCenter"
        SpreadsheetCommandGalleryItem45.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage44"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem46.CommandName = "ChartDataLabelsInsideEnd"
        SpreadsheetCommandGalleryItem46.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage45"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem47.CommandName = "ChartDataLabelsInsideBase"
        SpreadsheetCommandGalleryItem47.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage46"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem48.CommandName = "ChartDataLabelsOutsideEnd"
        SpreadsheetCommandGalleryItem48.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage47"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem49.CommandName = "ChartDataLabelsBestFit"
        SpreadsheetCommandGalleryItem49.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage48"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem50.CommandName = "ChartDataLabelsLeft"
        SpreadsheetCommandGalleryItem50.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage49"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem51.CommandName = "ChartDataLabelsRight"
        SpreadsheetCommandGalleryItem51.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage50"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem52.CommandName = "ChartDataLabelsAbove"
        SpreadsheetCommandGalleryItem52.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage51"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem53.CommandName = "ChartDataLabelsBelow"
        SpreadsheetCommandGalleryItem53.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage52"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup9.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem43, SpreadsheetCommandGalleryItem44, SpreadsheetCommandGalleryItem45, SpreadsheetCommandGalleryItem46, SpreadsheetCommandGalleryItem47, SpreadsheetCommandGalleryItem48, SpreadsheetCommandGalleryItem49, SpreadsheetCommandGalleryItem50, SpreadsheetCommandGalleryItem51, SpreadsheetCommandGalleryItem52, SpreadsheetCommandGalleryItem53})
        Me.CommandBarGalleryDropDown9.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup9})
        Me.CommandBarGalleryDropDown9.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown9.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown9.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown9.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown9.Name = "CommandBarGalleryDropDown9"
        Me.CommandBarGalleryDropDown9.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem10
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem10.CommandName = "ChartLinesCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem10.DropDownControl = Me.CommandBarGalleryDropDown10
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem10.Id = 140
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem10.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem10"
        '
        'CommandBarGalleryDropDown10
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown10.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown10.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup10.CommandName = "ChartLinesCommandGroup"
        SpreadsheetCommandGalleryItem54.CommandName = "ChartLinesNone"
        SpreadsheetCommandGalleryItem54.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage53"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem55.CommandName = "ChartShowDropLines"
        SpreadsheetCommandGalleryItem55.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage54"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem56.CommandName = "ChartShowHighLowLines"
        SpreadsheetCommandGalleryItem56.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage55"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem57.CommandName = "ChartShowDropLinesAndHighLowLines"
        SpreadsheetCommandGalleryItem57.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage56"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem58.CommandName = "ChartShowSeriesLines"
        SpreadsheetCommandGalleryItem58.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage57"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup10.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem54, SpreadsheetCommandGalleryItem55, SpreadsheetCommandGalleryItem56, SpreadsheetCommandGalleryItem57, SpreadsheetCommandGalleryItem58})
        Me.CommandBarGalleryDropDown10.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup10})
        Me.CommandBarGalleryDropDown10.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown10.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown10.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown10.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown10.Name = "CommandBarGalleryDropDown10"
        Me.CommandBarGalleryDropDown10.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem11
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem11.CommandName = "ChartUpDownBarsCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem11.DropDownControl = Me.CommandBarGalleryDropDown11
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem11.Id = 141
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem11.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem11"
        '
        'CommandBarGalleryDropDown11
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown11.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown11.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup11.CommandName = "ChartUpDownBarsCommandGroup"
        SpreadsheetCommandGalleryItem59.CommandName = "ChartHideUpDownBars"
        SpreadsheetCommandGalleryItem59.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage58"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem60.CommandName = "ChartShowUpDownBars"
        SpreadsheetCommandGalleryItem60.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage59"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup11.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem59, SpreadsheetCommandGalleryItem60})
        Me.CommandBarGalleryDropDown11.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup11})
        Me.CommandBarGalleryDropDown11.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown11.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown11.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown11.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown11.Name = "CommandBarGalleryDropDown11"
        Me.CommandBarGalleryDropDown11.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem12
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem12.CommandName = "ChartErrorBarsCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem12.DropDownControl = Me.CommandBarGalleryDropDown12
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem12.Id = 142
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem12.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem12"
        '
        'CommandBarGalleryDropDown12
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown12.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown12.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Vertical
        SpreadsheetCommandGalleryItemGroup12.CommandName = "ChartErrorBarsCommandGroup"
        SpreadsheetCommandGalleryItem61.CommandName = "ChartErrorBarsNone"
        SpreadsheetCommandGalleryItem61.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage60"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem62.CommandName = "ChartErrorBarsStandardError"
        SpreadsheetCommandGalleryItem62.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage61"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem63.CommandName = "ChartErrorBarsPercentage"
        SpreadsheetCommandGalleryItem63.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage62"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem64.CommandName = "ChartErrorBarsStandardDeviation"
        SpreadsheetCommandGalleryItem64.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage63"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup12.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem61, SpreadsheetCommandGalleryItem62, SpreadsheetCommandGalleryItem63, SpreadsheetCommandGalleryItem64})
        Me.CommandBarGalleryDropDown12.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup12})
        Me.CommandBarGalleryDropDown12.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown12.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.CommandBarGalleryDropDown12.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.CommandBarGalleryDropDown12.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown12.Name = "CommandBarGalleryDropDown12"
        Me.CommandBarGalleryDropDown12.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonItem39
        '
        Me.SpreadsheetCommandBarButtonItem39.CommandName = "ChartChangeType"
        Me.SpreadsheetCommandBarButtonItem39.Id = 143
        Me.SpreadsheetCommandBarButtonItem39.Name = "SpreadsheetCommandBarButtonItem39"
        '
        'SpreadsheetCommandBarButtonItem40
        '
        Me.SpreadsheetCommandBarButtonItem40.CommandName = "ChartSwitchRowColumn"
        Me.SpreadsheetCommandBarButtonItem40.Id = 144
        Me.SpreadsheetCommandBarButtonItem40.Name = "SpreadsheetCommandBarButtonItem40"
        '
        'SpreadsheetCommandBarButtonItem41
        '
        Me.SpreadsheetCommandBarButtonItem41.CommandName = "ChartSelectData"
        Me.SpreadsheetCommandBarButtonItem41.Id = 145
        Me.SpreadsheetCommandBarButtonItem41.Name = "SpreadsheetCommandBarButtonItem41"
        '
        'GalleryChartLayoutItem1
        '
        '
        '
        '
        Me.GalleryChartLayoutItem1.Gallery.ColumnCount = 6
        Me.GalleryChartLayoutItem1.Gallery.DrawImageBackground = False
        Me.GalleryChartLayoutItem1.Gallery.ImageSize = New System.Drawing.Size(48, 48)
        Me.GalleryChartLayoutItem1.Gallery.RowCount = 2
        Me.GalleryChartLayoutItem1.Id = 146
        Me.GalleryChartLayoutItem1.Name = "GalleryChartLayoutItem1"
        '
        'GalleryChartStyleItem1
        '
        '
        '
        '
        Me.GalleryChartStyleItem1.Gallery.ColumnCount = 8
        Me.GalleryChartStyleItem1.Gallery.DrawImageBackground = False
        Me.GalleryChartStyleItem1.Gallery.ImageSize = New System.Drawing.Size(65, 46)
        Me.GalleryChartStyleItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
        Me.GalleryChartStyleItem1.Gallery.ItemSize = New System.Drawing.Size(93, 56)
        Me.GalleryChartStyleItem1.Gallery.MinimumColumnCount = 4
        Me.GalleryChartStyleItem1.Gallery.RowCount = 6
        Me.GalleryChartStyleItem1.Id = 147
        Me.GalleryChartStyleItem1.Name = "GalleryChartStyleItem1"
        '
        'SpreadsheetCommandBarButtonItem42
        '
        Me.SpreadsheetCommandBarButtonItem42.CommandName = "MoveChart"
        Me.SpreadsheetCommandBarButtonItem42.Id = 148
        Me.SpreadsheetCommandBarButtonItem42.Name = "SpreadsheetCommandBarButtonItem42"
        '
        'SpreadsheetCommandBarCheckItem15
        '
        Me.SpreadsheetCommandBarCheckItem15.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem15.CommandName = "ViewShowGridlines"
        Me.SpreadsheetCommandBarCheckItem15.Id = 149
        Me.SpreadsheetCommandBarCheckItem15.Name = "SpreadsheetCommandBarCheckItem15"
        '
        'SpreadsheetCommandBarCheckItem16
        '
        Me.SpreadsheetCommandBarCheckItem16.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem16.CommandName = "ViewShowHeadings"
        Me.SpreadsheetCommandBarCheckItem16.Id = 150
        Me.SpreadsheetCommandBarCheckItem16.Name = "SpreadsheetCommandBarCheckItem16"
        '
        'SpreadsheetCommandBarButtonItem43
        '
        Me.SpreadsheetCommandBarButtonItem43.CommandName = "ViewZoom"
        Me.SpreadsheetCommandBarButtonItem43.Id = 151
        Me.SpreadsheetCommandBarButtonItem43.Name = "SpreadsheetCommandBarButtonItem43"
        '
        'SpreadsheetCommandBarButtonItem44
        '
        Me.SpreadsheetCommandBarButtonItem44.CommandName = "ViewZoomOut"
        Me.SpreadsheetCommandBarButtonItem44.Id = 152
        Me.SpreadsheetCommandBarButtonItem44.Name = "SpreadsheetCommandBarButtonItem44"
        '
        'SpreadsheetCommandBarButtonItem45
        '
        Me.SpreadsheetCommandBarButtonItem45.CommandName = "ViewZoomIn"
        Me.SpreadsheetCommandBarButtonItem45.Id = 153
        Me.SpreadsheetCommandBarButtonItem45.Name = "SpreadsheetCommandBarButtonItem45"
        '
        'SpreadsheetCommandBarButtonItem46
        '
        Me.SpreadsheetCommandBarButtonItem46.CommandName = "ViewZoom100Percent"
        Me.SpreadsheetCommandBarButtonItem46.Id = 154
        Me.SpreadsheetCommandBarButtonItem46.Name = "SpreadsheetCommandBarButtonItem46"
        '
        'SpreadsheetCommandBarSubItem14
        '
        Me.SpreadsheetCommandBarSubItem14.CommandName = "ViewFreezePanesCommandGroup"
        Me.SpreadsheetCommandBarSubItem14.Id = 155
        Me.SpreadsheetCommandBarSubItem14.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem47), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem48), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem49), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem50)})
        Me.SpreadsheetCommandBarSubItem14.Name = "SpreadsheetCommandBarSubItem14"
        '
        'SpreadsheetCommandBarButtonItem47
        '
        Me.SpreadsheetCommandBarButtonItem47.CommandName = "ViewFreezePanes"
        Me.SpreadsheetCommandBarButtonItem47.Id = 156
        Me.SpreadsheetCommandBarButtonItem47.Name = "SpreadsheetCommandBarButtonItem47"
        '
        'SpreadsheetCommandBarButtonItem48
        '
        Me.SpreadsheetCommandBarButtonItem48.CommandName = "ViewUnfreezePanes"
        Me.SpreadsheetCommandBarButtonItem48.Id = 157
        Me.SpreadsheetCommandBarButtonItem48.Name = "SpreadsheetCommandBarButtonItem48"
        '
        'SpreadsheetCommandBarButtonItem49
        '
        Me.SpreadsheetCommandBarButtonItem49.CommandName = "ViewFreezeTopRow"
        Me.SpreadsheetCommandBarButtonItem49.Id = 158
        Me.SpreadsheetCommandBarButtonItem49.Name = "SpreadsheetCommandBarButtonItem49"
        '
        'SpreadsheetCommandBarButtonItem50
        '
        Me.SpreadsheetCommandBarButtonItem50.CommandName = "ViewFreezeFirstColumn"
        Me.SpreadsheetCommandBarButtonItem50.Id = 159
        Me.SpreadsheetCommandBarButtonItem50.Name = "SpreadsheetCommandBarButtonItem50"
        '
        'SpreadsheetCommandBarButtonItem51
        '
        Me.SpreadsheetCommandBarButtonItem51.CommandName = "ReviewInsertComment"
        Me.SpreadsheetCommandBarButtonItem51.Id = 160
        Me.SpreadsheetCommandBarButtonItem51.Name = "SpreadsheetCommandBarButtonItem51"
        '
        'SpreadsheetCommandBarButtonItem52
        '
        Me.SpreadsheetCommandBarButtonItem52.CommandName = "ReviewEditComment"
        Me.SpreadsheetCommandBarButtonItem52.Id = 161
        Me.SpreadsheetCommandBarButtonItem52.Name = "SpreadsheetCommandBarButtonItem52"
        '
        'SpreadsheetCommandBarButtonItem53
        '
        Me.SpreadsheetCommandBarButtonItem53.CommandName = "ReviewDeleteComment"
        Me.SpreadsheetCommandBarButtonItem53.Id = 162
        Me.SpreadsheetCommandBarButtonItem53.Name = "SpreadsheetCommandBarButtonItem53"
        '
        'SpreadsheetCommandBarButtonItem54
        '
        Me.SpreadsheetCommandBarButtonItem54.CommandName = "ReviewShowHideComment"
        Me.SpreadsheetCommandBarButtonItem54.Id = 163
        Me.SpreadsheetCommandBarButtonItem54.Name = "SpreadsheetCommandBarButtonItem54"
        Me.SpreadsheetCommandBarButtonItem54.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem55
        '
        Me.SpreadsheetCommandBarButtonItem55.CommandName = "ReviewProtectSheet"
        Me.SpreadsheetCommandBarButtonItem55.Id = 164
        Me.SpreadsheetCommandBarButtonItem55.Name = "SpreadsheetCommandBarButtonItem55"
        '
        'SpreadsheetCommandBarButtonItem56
        '
        Me.SpreadsheetCommandBarButtonItem56.CommandName = "ReviewUnprotectSheet"
        Me.SpreadsheetCommandBarButtonItem56.Id = 165
        Me.SpreadsheetCommandBarButtonItem56.Name = "SpreadsheetCommandBarButtonItem56"
        '
        'SpreadsheetCommandBarButtonItem57
        '
        Me.SpreadsheetCommandBarButtonItem57.CommandName = "ReviewProtectWorkbook"
        Me.SpreadsheetCommandBarButtonItem57.Id = 166
        Me.SpreadsheetCommandBarButtonItem57.Name = "SpreadsheetCommandBarButtonItem57"
        '
        'SpreadsheetCommandBarButtonItem58
        '
        Me.SpreadsheetCommandBarButtonItem58.CommandName = "ReviewUnprotectWorkbook"
        Me.SpreadsheetCommandBarButtonItem58.Id = 167
        Me.SpreadsheetCommandBarButtonItem58.Name = "SpreadsheetCommandBarButtonItem58"
        '
        'SpreadsheetCommandBarButtonItem59
        '
        Me.SpreadsheetCommandBarButtonItem59.CommandName = "ReviewShowProtectedRangeManager"
        Me.SpreadsheetCommandBarButtonItem59.Id = 168
        Me.SpreadsheetCommandBarButtonItem59.Name = "SpreadsheetCommandBarButtonItem59"
        '
        'SpreadsheetCommandBarButtonItem60
        '
        Me.SpreadsheetCommandBarButtonItem60.CommandName = "DataSortAscending"
        Me.SpreadsheetCommandBarButtonItem60.Id = 169
        Me.SpreadsheetCommandBarButtonItem60.Name = "SpreadsheetCommandBarButtonItem60"
        '
        'SpreadsheetCommandBarButtonItem61
        '
        Me.SpreadsheetCommandBarButtonItem61.CommandName = "DataSortDescending"
        Me.SpreadsheetCommandBarButtonItem61.Id = 170
        Me.SpreadsheetCommandBarButtonItem61.Name = "SpreadsheetCommandBarButtonItem61"
        '
        'SpreadsheetCommandBarCheckItem17
        '
        Me.SpreadsheetCommandBarCheckItem17.CommandName = "DataFilterToggle"
        Me.SpreadsheetCommandBarCheckItem17.Id = 171
        Me.SpreadsheetCommandBarCheckItem17.Name = "SpreadsheetCommandBarCheckItem17"
        '
        'SpreadsheetCommandBarButtonItem62
        '
        Me.SpreadsheetCommandBarButtonItem62.CommandName = "DataFilterClear"
        Me.SpreadsheetCommandBarButtonItem62.Id = 172
        Me.SpreadsheetCommandBarButtonItem62.Name = "SpreadsheetCommandBarButtonItem62"
        '
        'SpreadsheetCommandBarButtonItem63
        '
        Me.SpreadsheetCommandBarButtonItem63.CommandName = "DataFilterReApply"
        Me.SpreadsheetCommandBarButtonItem63.Id = 173
        Me.SpreadsheetCommandBarButtonItem63.Name = "SpreadsheetCommandBarButtonItem63"
        '
        'SpreadsheetCommandBarSubItem15
        '
        Me.SpreadsheetCommandBarSubItem15.CommandName = "DataToolsDataValidationCommandGroup"
        Me.SpreadsheetCommandBarSubItem15.Id = 174
        Me.SpreadsheetCommandBarSubItem15.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem64), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem65), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem66)})
        Me.SpreadsheetCommandBarSubItem15.Name = "SpreadsheetCommandBarSubItem15"
        '
        'SpreadsheetCommandBarButtonItem64
        '
        Me.SpreadsheetCommandBarButtonItem64.CommandName = "DataToolsDataValidation"
        Me.SpreadsheetCommandBarButtonItem64.Id = 175
        Me.SpreadsheetCommandBarButtonItem64.Name = "SpreadsheetCommandBarButtonItem64"
        '
        'SpreadsheetCommandBarButtonItem65
        '
        Me.SpreadsheetCommandBarButtonItem65.CommandName = "DataToolsCircleInvalidData"
        Me.SpreadsheetCommandBarButtonItem65.Id = 176
        Me.SpreadsheetCommandBarButtonItem65.Name = "SpreadsheetCommandBarButtonItem65"
        '
        'SpreadsheetCommandBarButtonItem66
        '
        Me.SpreadsheetCommandBarButtonItem66.CommandName = "DataToolsClearValidationCircles"
        Me.SpreadsheetCommandBarButtonItem66.Id = 177
        Me.SpreadsheetCommandBarButtonItem66.Name = "SpreadsheetCommandBarButtonItem66"
        '
        'SpreadsheetCommandBarSubItem16
        '
        Me.SpreadsheetCommandBarSubItem16.CommandName = "OutlineGroupCommandGroup"
        Me.SpreadsheetCommandBarSubItem16.Id = 178
        Me.SpreadsheetCommandBarSubItem16.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem67), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem68)})
        Me.SpreadsheetCommandBarSubItem16.Name = "SpreadsheetCommandBarSubItem16"
        Me.SpreadsheetCommandBarSubItem16.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem67
        '
        Me.SpreadsheetCommandBarButtonItem67.CommandName = "GroupOutline"
        Me.SpreadsheetCommandBarButtonItem67.Id = 179
        Me.SpreadsheetCommandBarButtonItem67.Name = "SpreadsheetCommandBarButtonItem67"
        '
        'SpreadsheetCommandBarButtonItem68
        '
        Me.SpreadsheetCommandBarButtonItem68.CommandName = "AutoOutline"
        Me.SpreadsheetCommandBarButtonItem68.Id = 180
        Me.SpreadsheetCommandBarButtonItem68.Name = "SpreadsheetCommandBarButtonItem68"
        '
        'SpreadsheetCommandBarSubItem17
        '
        Me.SpreadsheetCommandBarSubItem17.CommandName = "OutlineUngroupCommandGroup"
        Me.SpreadsheetCommandBarSubItem17.Id = 181
        Me.SpreadsheetCommandBarSubItem17.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem69), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem70)})
        Me.SpreadsheetCommandBarSubItem17.Name = "SpreadsheetCommandBarSubItem17"
        Me.SpreadsheetCommandBarSubItem17.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem69
        '
        Me.SpreadsheetCommandBarButtonItem69.CommandName = "UngroupOutline"
        Me.SpreadsheetCommandBarButtonItem69.Id = 182
        Me.SpreadsheetCommandBarButtonItem69.Name = "SpreadsheetCommandBarButtonItem69"
        '
        'SpreadsheetCommandBarButtonItem70
        '
        Me.SpreadsheetCommandBarButtonItem70.CommandName = "ClearOutline"
        Me.SpreadsheetCommandBarButtonItem70.Id = 183
        Me.SpreadsheetCommandBarButtonItem70.Name = "SpreadsheetCommandBarButtonItem70"
        '
        'SpreadsheetCommandBarButtonItem71
        '
        Me.SpreadsheetCommandBarButtonItem71.CommandName = "Subtotal"
        Me.SpreadsheetCommandBarButtonItem71.Id = 184
        Me.SpreadsheetCommandBarButtonItem71.Name = "SpreadsheetCommandBarButtonItem71"
        Me.SpreadsheetCommandBarButtonItem71.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem72
        '
        Me.SpreadsheetCommandBarButtonItem72.CommandName = "ShowDetail"
        Me.SpreadsheetCommandBarButtonItem72.Id = 185
        Me.SpreadsheetCommandBarButtonItem72.Name = "SpreadsheetCommandBarButtonItem72"
        Me.SpreadsheetCommandBarButtonItem72.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem73
        '
        Me.SpreadsheetCommandBarButtonItem73.CommandName = "HideDetail"
        Me.SpreadsheetCommandBarButtonItem73.Id = 186
        Me.SpreadsheetCommandBarButtonItem73.Name = "SpreadsheetCommandBarButtonItem73"
        Me.SpreadsheetCommandBarButtonItem73.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarSubItem18
        '
        Me.SpreadsheetCommandBarSubItem18.CommandName = "FunctionsAutoSumCommandGroup"
        Me.SpreadsheetCommandBarSubItem18.Id = 187
        Me.SpreadsheetCommandBarSubItem18.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem74), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem75), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem76), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem77), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem78)})
        Me.SpreadsheetCommandBarSubItem18.Name = "SpreadsheetCommandBarSubItem18"
        '
        'SpreadsheetCommandBarButtonItem74
        '
        Me.SpreadsheetCommandBarButtonItem74.CommandName = "FunctionsInsertSum"
        Me.SpreadsheetCommandBarButtonItem74.Id = 188
        Me.SpreadsheetCommandBarButtonItem74.Name = "SpreadsheetCommandBarButtonItem74"
        '
        'SpreadsheetCommandBarButtonItem75
        '
        Me.SpreadsheetCommandBarButtonItem75.CommandName = "FunctionsInsertAverage"
        Me.SpreadsheetCommandBarButtonItem75.Id = 189
        Me.SpreadsheetCommandBarButtonItem75.Name = "SpreadsheetCommandBarButtonItem75"
        '
        'SpreadsheetCommandBarButtonItem76
        '
        Me.SpreadsheetCommandBarButtonItem76.CommandName = "FunctionsInsertCountNumbers"
        Me.SpreadsheetCommandBarButtonItem76.Id = 190
        Me.SpreadsheetCommandBarButtonItem76.Name = "SpreadsheetCommandBarButtonItem76"
        '
        'SpreadsheetCommandBarButtonItem77
        '
        Me.SpreadsheetCommandBarButtonItem77.CommandName = "FunctionsInsertMax"
        Me.SpreadsheetCommandBarButtonItem77.Id = 191
        Me.SpreadsheetCommandBarButtonItem77.Name = "SpreadsheetCommandBarButtonItem77"
        '
        'SpreadsheetCommandBarButtonItem78
        '
        Me.SpreadsheetCommandBarButtonItem78.CommandName = "FunctionsInsertMin"
        Me.SpreadsheetCommandBarButtonItem78.Id = 192
        Me.SpreadsheetCommandBarButtonItem78.Name = "SpreadsheetCommandBarButtonItem78"
        '
        'FunctionsFinancialItem1
        '
        Me.FunctionsFinancialItem1.Id = 193
        Me.FunctionsFinancialItem1.Name = "FunctionsFinancialItem1"
        '
        'FunctionsLogicalItem1
        '
        Me.FunctionsLogicalItem1.Id = 194
        Me.FunctionsLogicalItem1.Name = "FunctionsLogicalItem1"
        '
        'FunctionsTextItem1
        '
        Me.FunctionsTextItem1.Id = 195
        Me.FunctionsTextItem1.Name = "FunctionsTextItem1"
        '
        'FunctionsDateAndTimeItem1
        '
        Me.FunctionsDateAndTimeItem1.Id = 196
        Me.FunctionsDateAndTimeItem1.Name = "FunctionsDateAndTimeItem1"
        '
        'FunctionsLookupAndReferenceItem1
        '
        Me.FunctionsLookupAndReferenceItem1.Id = 197
        Me.FunctionsLookupAndReferenceItem1.Name = "FunctionsLookupAndReferenceItem1"
        '
        'FunctionsMathAndTrigonometryItem1
        '
        Me.FunctionsMathAndTrigonometryItem1.Id = 198
        Me.FunctionsMathAndTrigonometryItem1.Name = "FunctionsMathAndTrigonometryItem1"
        '
        'SpreadsheetCommandBarSubItem19
        '
        Me.SpreadsheetCommandBarSubItem19.CommandName = "FunctionsMoreCommandGroup"
        Me.SpreadsheetCommandBarSubItem19.Id = 199
        Me.SpreadsheetCommandBarSubItem19.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.FunctionsStatisticalItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.FunctionsEngineeringItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.FunctionsInformationItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.FunctionsCompatibilityItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.FunctionsWebItem1)})
        Me.SpreadsheetCommandBarSubItem19.Name = "SpreadsheetCommandBarSubItem19"
        '
        'FunctionsStatisticalItem1
        '
        Me.FunctionsStatisticalItem1.Id = 200
        Me.FunctionsStatisticalItem1.Name = "FunctionsStatisticalItem1"
        '
        'FunctionsEngineeringItem1
        '
        Me.FunctionsEngineeringItem1.Id = 201
        Me.FunctionsEngineeringItem1.Name = "FunctionsEngineeringItem1"
        '
        'FunctionsInformationItem1
        '
        Me.FunctionsInformationItem1.Id = 202
        Me.FunctionsInformationItem1.Name = "FunctionsInformationItem1"
        '
        'FunctionsCompatibilityItem1
        '
        Me.FunctionsCompatibilityItem1.Id = 203
        Me.FunctionsCompatibilityItem1.Name = "FunctionsCompatibilityItem1"
        '
        'FunctionsWebItem1
        '
        Me.FunctionsWebItem1.Id = 204
        Me.FunctionsWebItem1.Name = "FunctionsWebItem1"
        '
        'SpreadsheetCommandBarButtonItem79
        '
        Me.SpreadsheetCommandBarButtonItem79.CommandName = "FormulasShowNameManager"
        Me.SpreadsheetCommandBarButtonItem79.Id = 205
        Me.SpreadsheetCommandBarButtonItem79.Name = "SpreadsheetCommandBarButtonItem79"
        '
        'SpreadsheetCommandBarButtonItem80
        '
        Me.SpreadsheetCommandBarButtonItem80.CommandName = "FormulasDefineNameCommand"
        Me.SpreadsheetCommandBarButtonItem80.Id = 206
        Me.SpreadsheetCommandBarButtonItem80.Name = "SpreadsheetCommandBarButtonItem80"
        Me.SpreadsheetCommandBarButtonItem80.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'DefinedNameListItem1
        '
        Me.DefinedNameListItem1.Id = 207
        Me.DefinedNameListItem1.Name = "DefinedNameListItem1"
        Me.DefinedNameListItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem81
        '
        Me.SpreadsheetCommandBarButtonItem81.CommandName = "FormulasCreateDefinedNamesFromSelection"
        Me.SpreadsheetCommandBarButtonItem81.Id = 208
        Me.SpreadsheetCommandBarButtonItem81.Name = "SpreadsheetCommandBarButtonItem81"
        Me.SpreadsheetCommandBarButtonItem81.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarCheckItem18
        '
        Me.SpreadsheetCommandBarCheckItem18.CommandName = "ViewShowFormulas"
        Me.SpreadsheetCommandBarCheckItem18.Id = 209
        Me.SpreadsheetCommandBarCheckItem18.Name = "SpreadsheetCommandBarCheckItem18"
        '
        'SpreadsheetCommandBarSubItem20
        '
        Me.SpreadsheetCommandBarSubItem20.CommandName = "FormulasCalculationOptionsCommandGroup"
        Me.SpreadsheetCommandBarSubItem20.Id = 210
        Me.SpreadsheetCommandBarSubItem20.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem19), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem20)})
        Me.SpreadsheetCommandBarSubItem20.Name = "SpreadsheetCommandBarSubItem20"
        '
        'SpreadsheetCommandBarCheckItem19
        '
        Me.SpreadsheetCommandBarCheckItem19.CommandName = "FormulasCalculationModeAutomatic"
        Me.SpreadsheetCommandBarCheckItem19.Id = 211
        Me.SpreadsheetCommandBarCheckItem19.Name = "SpreadsheetCommandBarCheckItem19"
        '
        'SpreadsheetCommandBarCheckItem20
        '
        Me.SpreadsheetCommandBarCheckItem20.CommandName = "FormulasCalculationModeManual"
        Me.SpreadsheetCommandBarCheckItem20.Id = 212
        Me.SpreadsheetCommandBarCheckItem20.Name = "SpreadsheetCommandBarCheckItem20"
        '
        'SpreadsheetCommandBarButtonItem82
        '
        Me.SpreadsheetCommandBarButtonItem82.CommandName = "FormulasCalculateNow"
        Me.SpreadsheetCommandBarButtonItem82.Id = 213
        Me.SpreadsheetCommandBarButtonItem82.Name = "SpreadsheetCommandBarButtonItem82"
        Me.SpreadsheetCommandBarButtonItem82.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem83
        '
        Me.SpreadsheetCommandBarButtonItem83.CommandName = "FormulasCalculateSheet"
        Me.SpreadsheetCommandBarButtonItem83.Id = 214
        Me.SpreadsheetCommandBarButtonItem83.Name = "SpreadsheetCommandBarButtonItem83"
        Me.SpreadsheetCommandBarButtonItem83.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarSubItem21
        '
        Me.SpreadsheetCommandBarSubItem21.CommandName = "PageSetupMarginsCommandGroup"
        Me.SpreadsheetCommandBarSubItem21.Id = 215
        Me.SpreadsheetCommandBarSubItem21.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem21), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem22), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem23), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem84)})
        Me.SpreadsheetCommandBarSubItem21.Name = "SpreadsheetCommandBarSubItem21"
        '
        'SpreadsheetCommandBarCheckItem21
        '
        Me.SpreadsheetCommandBarCheckItem21.CaptionDependOnUnits = True
        Me.SpreadsheetCommandBarCheckItem21.CommandName = "PageSetupMarginsNormal"
        Me.SpreadsheetCommandBarCheckItem21.Id = 216
        Me.SpreadsheetCommandBarCheckItem21.Name = "SpreadsheetCommandBarCheckItem21"
        '
        'SpreadsheetCommandBarCheckItem22
        '
        Me.SpreadsheetCommandBarCheckItem22.CaptionDependOnUnits = True
        Me.SpreadsheetCommandBarCheckItem22.CommandName = "PageSetupMarginsWide"
        Me.SpreadsheetCommandBarCheckItem22.Id = 217
        Me.SpreadsheetCommandBarCheckItem22.Name = "SpreadsheetCommandBarCheckItem22"
        '
        'SpreadsheetCommandBarCheckItem23
        '
        Me.SpreadsheetCommandBarCheckItem23.CaptionDependOnUnits = True
        Me.SpreadsheetCommandBarCheckItem23.CommandName = "PageSetupMarginsNarrow"
        Me.SpreadsheetCommandBarCheckItem23.Id = 218
        Me.SpreadsheetCommandBarCheckItem23.Name = "SpreadsheetCommandBarCheckItem23"
        '
        'SpreadsheetCommandBarButtonItem84
        '
        Me.SpreadsheetCommandBarButtonItem84.CommandName = "PageSetupCustomMargins"
        Me.SpreadsheetCommandBarButtonItem84.Id = 219
        Me.SpreadsheetCommandBarButtonItem84.Name = "SpreadsheetCommandBarButtonItem84"
        '
        'SpreadsheetCommandBarSubItem22
        '
        Me.SpreadsheetCommandBarSubItem22.CommandName = "PageSetupOrientationCommandGroup"
        Me.SpreadsheetCommandBarSubItem22.Id = 220
        Me.SpreadsheetCommandBarSubItem22.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem24), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem25)})
        Me.SpreadsheetCommandBarSubItem22.Name = "SpreadsheetCommandBarSubItem22"
        '
        'SpreadsheetCommandBarCheckItem24
        '
        Me.SpreadsheetCommandBarCheckItem24.CommandName = "PageSetupOrientationPortrait"
        Me.SpreadsheetCommandBarCheckItem24.Id = 221
        Me.SpreadsheetCommandBarCheckItem24.Name = "SpreadsheetCommandBarCheckItem24"
        '
        'SpreadsheetCommandBarCheckItem25
        '
        Me.SpreadsheetCommandBarCheckItem25.CommandName = "PageSetupOrientationLandscape"
        Me.SpreadsheetCommandBarCheckItem25.Id = 222
        Me.SpreadsheetCommandBarCheckItem25.Name = "SpreadsheetCommandBarCheckItem25"
        '
        'PageSetupPaperKindItem1
        '
        Me.PageSetupPaperKindItem1.Id = 223
        Me.PageSetupPaperKindItem1.Name = "PageSetupPaperKindItem1"
        '
        'SpreadsheetCommandBarSubItem23
        '
        Me.SpreadsheetCommandBarSubItem23.CommandName = "PageSetupPrintAreaCommandGroup"
        Me.SpreadsheetCommandBarSubItem23.Id = 224
        Me.SpreadsheetCommandBarSubItem23.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem85), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem86), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem87)})
        Me.SpreadsheetCommandBarSubItem23.Name = "SpreadsheetCommandBarSubItem23"
        '
        'SpreadsheetCommandBarButtonItem85
        '
        Me.SpreadsheetCommandBarButtonItem85.CommandName = "PageSetupSetPrintArea"
        Me.SpreadsheetCommandBarButtonItem85.Id = 225
        Me.SpreadsheetCommandBarButtonItem85.Name = "SpreadsheetCommandBarButtonItem85"
        '
        'SpreadsheetCommandBarButtonItem86
        '
        Me.SpreadsheetCommandBarButtonItem86.CommandName = "PageSetupClearPrintArea"
        Me.SpreadsheetCommandBarButtonItem86.Id = 226
        Me.SpreadsheetCommandBarButtonItem86.Name = "SpreadsheetCommandBarButtonItem86"
        '
        'SpreadsheetCommandBarButtonItem87
        '
        Me.SpreadsheetCommandBarButtonItem87.CommandName = "PageSetupAddPrintArea"
        Me.SpreadsheetCommandBarButtonItem87.Id = 227
        Me.SpreadsheetCommandBarButtonItem87.Name = "SpreadsheetCommandBarButtonItem87"
        '
        'SpreadsheetCommandBarButtonItem88
        '
        Me.SpreadsheetCommandBarButtonItem88.CommandName = "PageSetupPrintTitles"
        Me.SpreadsheetCommandBarButtonItem88.Id = 228
        Me.SpreadsheetCommandBarButtonItem88.Name = "SpreadsheetCommandBarButtonItem88"
        '
        'SpreadsheetCommandBarCheckItem26
        '
        Me.SpreadsheetCommandBarCheckItem26.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem26.CommandName = "PageSetupPrintGridlines"
        Me.SpreadsheetCommandBarCheckItem26.Id = 229
        Me.SpreadsheetCommandBarCheckItem26.Name = "SpreadsheetCommandBarCheckItem26"
        '
        'SpreadsheetCommandBarCheckItem27
        '
        Me.SpreadsheetCommandBarCheckItem27.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
        Me.SpreadsheetCommandBarCheckItem27.CommandName = "PageSetupPrintHeadings"
        Me.SpreadsheetCommandBarCheckItem27.Id = 230
        Me.SpreadsheetCommandBarCheckItem27.Name = "SpreadsheetCommandBarCheckItem27"
        '
        'SpreadsheetCommandBarButtonItem89
        '
        Me.SpreadsheetCommandBarButtonItem89.CommandName = "InsertPivotTable"
        Me.SpreadsheetCommandBarButtonItem89.Id = 231
        Me.SpreadsheetCommandBarButtonItem89.Name = "SpreadsheetCommandBarButtonItem89"
        '
        'SpreadsheetCommandBarButtonItem90
        '
        Me.SpreadsheetCommandBarButtonItem90.CommandName = "InsertTable"
        Me.SpreadsheetCommandBarButtonItem90.Id = 232
        Me.SpreadsheetCommandBarButtonItem90.Name = "SpreadsheetCommandBarButtonItem90"
        '
        'SpreadsheetCommandBarButtonItem91
        '
        Me.SpreadsheetCommandBarButtonItem91.CommandName = "InsertPicture"
        Me.SpreadsheetCommandBarButtonItem91.Id = 233
        Me.SpreadsheetCommandBarButtonItem91.Name = "SpreadsheetCommandBarButtonItem91"
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem13
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem13.CommandName = "InsertChartColumnCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem13.DropDownControl = Me.CommandBarGalleryDropDown13
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem13.Id = 234
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem13.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem13"
        '
        'CommandBarGalleryDropDown13
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown13.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup13.CommandName = "InsertChartColumn2DCommandGroup"
        SpreadsheetCommandGalleryItem65.CommandName = "InsertChartColumnClustered2D"
        SpreadsheetCommandGalleryItem65.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage64"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem66.CommandName = "InsertChartColumnStacked2D"
        SpreadsheetCommandGalleryItem66.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage65"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem67.CommandName = "InsertChartColumnPercentStacked2D"
        SpreadsheetCommandGalleryItem67.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage66"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup13.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem65, SpreadsheetCommandGalleryItem66, SpreadsheetCommandGalleryItem67})
        SpreadsheetCommandGalleryItemGroup14.CommandName = "InsertChartColumn3DCommandGroup"
        SpreadsheetCommandGalleryItem68.CommandName = "InsertChartColumnClustered3D"
        SpreadsheetCommandGalleryItem68.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage67"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem69.CommandName = "InsertChartColumnStacked3D"
        SpreadsheetCommandGalleryItem69.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage68"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem70.CommandName = "InsertChartColumnPercentStacked3D"
        SpreadsheetCommandGalleryItem70.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage69"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem71.CommandName = "InsertChartColumn3D"
        SpreadsheetCommandGalleryItem71.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage70"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup14.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem68, SpreadsheetCommandGalleryItem69, SpreadsheetCommandGalleryItem70, SpreadsheetCommandGalleryItem71})
        SpreadsheetCommandGalleryItemGroup15.CommandName = "InsertChartCylinderCommandGroup"
        SpreadsheetCommandGalleryItem72.CommandName = "InsertChartCylinderClustered"
        SpreadsheetCommandGalleryItem72.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage71"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem73.CommandName = "InsertChartCylinderStacked"
        SpreadsheetCommandGalleryItem73.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage72"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem74.CommandName = "InsertChartCylinderPercentStacked"
        SpreadsheetCommandGalleryItem74.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage73"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem75.CommandName = "InsertChartCylinder"
        SpreadsheetCommandGalleryItem75.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage74"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup15.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem72, SpreadsheetCommandGalleryItem73, SpreadsheetCommandGalleryItem74, SpreadsheetCommandGalleryItem75})
        SpreadsheetCommandGalleryItemGroup16.CommandName = "InsertChartConeCommandGroup"
        SpreadsheetCommandGalleryItem76.CommandName = "InsertChartConeClustered"
        SpreadsheetCommandGalleryItem76.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage75"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem77.CommandName = "InsertChartConeStacked"
        SpreadsheetCommandGalleryItem77.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage76"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem78.CommandName = "InsertChartConePercentStacked"
        SpreadsheetCommandGalleryItem78.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage77"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem79.CommandName = "InsertChartCone"
        SpreadsheetCommandGalleryItem79.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage78"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup16.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem76, SpreadsheetCommandGalleryItem77, SpreadsheetCommandGalleryItem78, SpreadsheetCommandGalleryItem79})
        SpreadsheetCommandGalleryItemGroup17.CommandName = "InsertChartPyramidCommandGroup"
        SpreadsheetCommandGalleryItem80.CommandName = "InsertChartPyramidClustered"
        SpreadsheetCommandGalleryItem80.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage79"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem81.CommandName = "InsertChartPyramidStacked"
        SpreadsheetCommandGalleryItem81.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage80"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem82.CommandName = "InsertChartPyramidPercentStacked"
        SpreadsheetCommandGalleryItem82.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage81"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem83.CommandName = "InsertChartPyramid"
        SpreadsheetCommandGalleryItem83.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage82"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup17.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem80, SpreadsheetCommandGalleryItem81, SpreadsheetCommandGalleryItem82, SpreadsheetCommandGalleryItem83})
        Me.CommandBarGalleryDropDown13.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup13, SpreadsheetCommandGalleryItemGroup14, SpreadsheetCommandGalleryItemGroup15, SpreadsheetCommandGalleryItemGroup16, SpreadsheetCommandGalleryItemGroup17})
        Me.CommandBarGalleryDropDown13.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown13.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown13.Name = "CommandBarGalleryDropDown13"
        Me.CommandBarGalleryDropDown13.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem14
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem14.CommandName = "InsertChartLineCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem14.DropDownControl = Me.CommandBarGalleryDropDown14
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem14.Id = 235
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem14.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem14"
        '
        'CommandBarGalleryDropDown14
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown14.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup18.CommandName = "InsertChartLine2DCommandGroup"
        SpreadsheetCommandGalleryItem84.CommandName = "InsertChartLine"
        SpreadsheetCommandGalleryItem84.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage83"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem85.CommandName = "InsertChartStackedLine"
        SpreadsheetCommandGalleryItem85.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage84"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem86.CommandName = "InsertChartPercentStackedLine"
        SpreadsheetCommandGalleryItem86.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage85"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem87.CommandName = "InsertChartLineWithMarkers"
        SpreadsheetCommandGalleryItem87.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage86"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem88.CommandName = "InsertChartStackedLineWithMarkers"
        SpreadsheetCommandGalleryItem88.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage87"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem89.CommandName = "InsertChartPercentStackedLineWithMarkers"
        SpreadsheetCommandGalleryItem89.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage88"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup18.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem84, SpreadsheetCommandGalleryItem85, SpreadsheetCommandGalleryItem86, SpreadsheetCommandGalleryItem87, SpreadsheetCommandGalleryItem88, SpreadsheetCommandGalleryItem89})
        SpreadsheetCommandGalleryItemGroup19.CommandName = "InsertChartLine3DCommandGroup"
        SpreadsheetCommandGalleryItem90.CommandName = "InsertChartLine3D"
        SpreadsheetCommandGalleryItem90.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage89"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup19.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem90})
        Me.CommandBarGalleryDropDown14.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup18, SpreadsheetCommandGalleryItemGroup19})
        Me.CommandBarGalleryDropDown14.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown14.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown14.Name = "CommandBarGalleryDropDown14"
        Me.CommandBarGalleryDropDown14.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem15
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem15.CommandName = "InsertChartPieCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem15.DropDownControl = Me.CommandBarGalleryDropDown15
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem15.Id = 236
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem15.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem15"
        '
        'CommandBarGalleryDropDown15
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown15.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup20.CommandName = "InsertChartPie2DCommandGroup"
        SpreadsheetCommandGalleryItem91.CommandName = "InsertChartPie2D"
        SpreadsheetCommandGalleryItem91.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage90"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem92.CommandName = "InsertChartPieExploded2D"
        SpreadsheetCommandGalleryItem92.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage91"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup20.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem91, SpreadsheetCommandGalleryItem92})
        SpreadsheetCommandGalleryItemGroup21.CommandName = "InsertChartPie3DCommandGroup"
        SpreadsheetCommandGalleryItem93.CommandName = "InsertChartPie3D"
        SpreadsheetCommandGalleryItem93.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage92"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem94.CommandName = "InsertChartPieExploded3D"
        SpreadsheetCommandGalleryItem94.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage93"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup21.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem93, SpreadsheetCommandGalleryItem94})
        SpreadsheetCommandGalleryItemGroup22.CommandName = "InsertChartDoughnut2DCommandGroup"
        SpreadsheetCommandGalleryItem95.CommandName = "InsertChartDoughnut2D"
        SpreadsheetCommandGalleryItem95.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage94"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem96.CommandName = "InsertChartDoughnutExploded2D"
        SpreadsheetCommandGalleryItem96.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage95"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup22.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem95, SpreadsheetCommandGalleryItem96})
        Me.CommandBarGalleryDropDown15.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup20, SpreadsheetCommandGalleryItemGroup21, SpreadsheetCommandGalleryItemGroup22})
        Me.CommandBarGalleryDropDown15.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown15.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown15.Name = "CommandBarGalleryDropDown15"
        Me.CommandBarGalleryDropDown15.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem16
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem16.CommandName = "InsertChartBarCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem16.DropDownControl = Me.CommandBarGalleryDropDown16
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem16.Id = 237
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem16.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem16"
        '
        'CommandBarGalleryDropDown16
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown16.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup23.CommandName = "InsertChartBar2DCommandGroup"
        SpreadsheetCommandGalleryItem97.CommandName = "InsertChartBarClustered2D"
        SpreadsheetCommandGalleryItem97.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage96"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem98.CommandName = "InsertChartBarStacked2D"
        SpreadsheetCommandGalleryItem98.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage97"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem99.CommandName = "InsertChartBarPercentStacked2D"
        SpreadsheetCommandGalleryItem99.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage98"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup23.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem97, SpreadsheetCommandGalleryItem98, SpreadsheetCommandGalleryItem99})
        SpreadsheetCommandGalleryItemGroup24.CommandName = "InsertChartBar3DCommandGroup"
        SpreadsheetCommandGalleryItem100.CommandName = "InsertChartBarClustered3D"
        SpreadsheetCommandGalleryItem100.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage99"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem101.CommandName = "InsertChartBarStacked3D"
        SpreadsheetCommandGalleryItem101.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage100"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem102.CommandName = "InsertChartBarPercentStacked3D"
        SpreadsheetCommandGalleryItem102.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage101"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup24.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem100, SpreadsheetCommandGalleryItem101, SpreadsheetCommandGalleryItem102})
        SpreadsheetCommandGalleryItemGroup25.CommandName = "InsertChartHorizontalCylinderCommandGroup"
        SpreadsheetCommandGalleryItem103.CommandName = "InsertChartHorizontalCylinderClustered"
        SpreadsheetCommandGalleryItem103.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage102"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem104.CommandName = "InsertChartHorizontalCylinderStacked"
        SpreadsheetCommandGalleryItem104.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage103"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem105.CommandName = "InsertChartHorizontalCylinderPercentStacked"
        SpreadsheetCommandGalleryItem105.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage104"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup25.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem103, SpreadsheetCommandGalleryItem104, SpreadsheetCommandGalleryItem105})
        SpreadsheetCommandGalleryItemGroup26.CommandName = "InsertChartHorizontalConeCommandGroup"
        SpreadsheetCommandGalleryItem106.CommandName = "InsertChartHorizontalConeClustered"
        SpreadsheetCommandGalleryItem106.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage105"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem107.CommandName = "InsertChartHorizontalConeStacked"
        SpreadsheetCommandGalleryItem107.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage106"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem108.CommandName = "InsertChartHorizontalConePercentStacked"
        SpreadsheetCommandGalleryItem108.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage107"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup26.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem106, SpreadsheetCommandGalleryItem107, SpreadsheetCommandGalleryItem108})
        SpreadsheetCommandGalleryItemGroup27.CommandName = "InsertChartHorizontalPyramidCommandGroup"
        SpreadsheetCommandGalleryItem109.CommandName = "InsertChartHorizontalPyramidClustered"
        SpreadsheetCommandGalleryItem109.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage108"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem110.CommandName = "InsertChartHorizontalPyramidStacked"
        SpreadsheetCommandGalleryItem110.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage109"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem111.CommandName = "InsertChartHorizontalPyramidPercentStacked"
        SpreadsheetCommandGalleryItem111.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage110"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup27.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem109, SpreadsheetCommandGalleryItem110, SpreadsheetCommandGalleryItem111})
        Me.CommandBarGalleryDropDown16.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup23, SpreadsheetCommandGalleryItemGroup24, SpreadsheetCommandGalleryItemGroup25, SpreadsheetCommandGalleryItemGroup26, SpreadsheetCommandGalleryItemGroup27})
        Me.CommandBarGalleryDropDown16.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown16.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown16.Name = "CommandBarGalleryDropDown16"
        Me.CommandBarGalleryDropDown16.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem17
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem17.CommandName = "InsertChartAreaCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem17.DropDownControl = Me.CommandBarGalleryDropDown17
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem17.Id = 238
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem17.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem17"
        '
        'CommandBarGalleryDropDown17
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown17.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup28.CommandName = "InsertChartArea2DCommandGroup"
        SpreadsheetCommandGalleryItem112.CommandName = "InsertChartArea"
        SpreadsheetCommandGalleryItem112.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage111"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem113.CommandName = "InsertChartStackedArea"
        SpreadsheetCommandGalleryItem113.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage112"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem114.CommandName = "InsertChartPercentStackedArea"
        SpreadsheetCommandGalleryItem114.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage113"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup28.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem112, SpreadsheetCommandGalleryItem113, SpreadsheetCommandGalleryItem114})
        SpreadsheetCommandGalleryItemGroup29.CommandName = "InsertChartArea3DCommandGroup"
        SpreadsheetCommandGalleryItem115.CommandName = "InsertChartArea3D"
        SpreadsheetCommandGalleryItem115.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage114"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem116.CommandName = "InsertChartStackedArea3D"
        SpreadsheetCommandGalleryItem116.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage115"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem117.CommandName = "InsertChartPercentStackedArea3D"
        SpreadsheetCommandGalleryItem117.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage116"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup29.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem115, SpreadsheetCommandGalleryItem116, SpreadsheetCommandGalleryItem117})
        Me.CommandBarGalleryDropDown17.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup28, SpreadsheetCommandGalleryItemGroup29})
        Me.CommandBarGalleryDropDown17.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown17.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown17.Name = "CommandBarGalleryDropDown17"
        Me.CommandBarGalleryDropDown17.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem18
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem18.CommandName = "InsertChartScatterCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem18.DropDownControl = Me.CommandBarGalleryDropDown18
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem18.Id = 239
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem18.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem18"
        '
        'CommandBarGalleryDropDown18
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown18.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup30.CommandName = "InsertChartScatterCommandGroup"
        SpreadsheetCommandGalleryItem118.CommandName = "InsertChartScatterMarkers"
        SpreadsheetCommandGalleryItem118.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage117"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem119.CommandName = "InsertChartScatterSmoothLinesAndMarkers"
        SpreadsheetCommandGalleryItem119.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage118"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem120.CommandName = "InsertChartScatterSmoothLines"
        SpreadsheetCommandGalleryItem120.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage119"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem121.CommandName = "InsertChartScatterLinesAndMarkers"
        SpreadsheetCommandGalleryItem121.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage120"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem122.CommandName = "InsertChartScatterLines"
        SpreadsheetCommandGalleryItem122.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage121"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup30.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem118, SpreadsheetCommandGalleryItem119, SpreadsheetCommandGalleryItem120, SpreadsheetCommandGalleryItem121, SpreadsheetCommandGalleryItem122})
        SpreadsheetCommandGalleryItemGroup31.CommandName = "InsertChartBubbleCommandGroup"
        SpreadsheetCommandGalleryItem123.CommandName = "InsertChartBubble"
        SpreadsheetCommandGalleryItem123.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage122"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem124.CommandName = "InsertChartBubble3D"
        SpreadsheetCommandGalleryItem124.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage123"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup31.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem123, SpreadsheetCommandGalleryItem124})
        Me.CommandBarGalleryDropDown18.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup30, SpreadsheetCommandGalleryItemGroup31})
        Me.CommandBarGalleryDropDown18.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown18.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown18.Name = "CommandBarGalleryDropDown18"
        Me.CommandBarGalleryDropDown18.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem19
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem19.CommandName = "InsertChartOtherCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem19.DropDownControl = Me.CommandBarGalleryDropDown19
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem19.Id = 240
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem19.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem19"
        '
        'CommandBarGalleryDropDown19
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown19.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup32.CommandName = "InsertChartStockCommandGroup"
        SpreadsheetCommandGalleryItem125.CommandName = "InsertChartStockHighLowClose"
        SpreadsheetCommandGalleryItem125.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage124"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem126.CommandName = "InsertChartStockOpenHighLowClose"
        SpreadsheetCommandGalleryItem126.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage125"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem127.CommandName = "InsertChartStockVolumeHighLowClose"
        SpreadsheetCommandGalleryItem127.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage126"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem128.CommandName = "InsertChartStockVolumeOpenHighLowClose"
        SpreadsheetCommandGalleryItem128.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage127"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup32.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem125, SpreadsheetCommandGalleryItem126, SpreadsheetCommandGalleryItem127, SpreadsheetCommandGalleryItem128})
        SpreadsheetCommandGalleryItemGroup33.CommandName = "InsertChartRadarCommandGroup"
        SpreadsheetCommandGalleryItem129.CommandName = "InsertChartRadar"
        SpreadsheetCommandGalleryItem129.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage128"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem130.CommandName = "InsertChartRadarWithMarkers"
        SpreadsheetCommandGalleryItem130.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage129"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem131.CommandName = "InsertChartRadarFilled"
        SpreadsheetCommandGalleryItem131.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage130"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup33.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem129, SpreadsheetCommandGalleryItem130, SpreadsheetCommandGalleryItem131})
        Me.CommandBarGalleryDropDown19.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup32, SpreadsheetCommandGalleryItemGroup33})
        Me.CommandBarGalleryDropDown19.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown19.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown19.Name = "CommandBarGalleryDropDown19"
        Me.CommandBarGalleryDropDown19.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonItem92
        '
        Me.SpreadsheetCommandBarButtonItem92.CommandName = "InsertHyperlink"
        Me.SpreadsheetCommandBarButtonItem92.Id = 241
        Me.SpreadsheetCommandBarButtonItem92.Name = "SpreadsheetCommandBarButtonItem92"
        '
        'SpreadsheetCommandBarButtonItem93
        '
        Me.SpreadsheetCommandBarButtonItem93.CommandName = "InsertSymbol"
        Me.SpreadsheetCommandBarButtonItem93.Id = 242
        Me.SpreadsheetCommandBarButtonItem93.Name = "SpreadsheetCommandBarButtonItem93"
        '
        'SpreadsheetCommandBarButtonItem94
        '
        Me.SpreadsheetCommandBarButtonItem94.CommandName = "PasteSelection"
        Me.SpreadsheetCommandBarButtonItem94.Id = 253
        Me.SpreadsheetCommandBarButtonItem94.Name = "SpreadsheetCommandBarButtonItem94"
        Me.SpreadsheetCommandBarButtonItem94.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem95
        '
        Me.SpreadsheetCommandBarButtonItem95.CommandName = "CutSelection"
        Me.SpreadsheetCommandBarButtonItem95.Id = 254
        Me.SpreadsheetCommandBarButtonItem95.Name = "SpreadsheetCommandBarButtonItem95"
        Me.SpreadsheetCommandBarButtonItem95.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem96
        '
        Me.SpreadsheetCommandBarButtonItem96.CommandName = "CopySelection"
        Me.SpreadsheetCommandBarButtonItem96.Id = 255
        Me.SpreadsheetCommandBarButtonItem96.Name = "SpreadsheetCommandBarButtonItem96"
        Me.SpreadsheetCommandBarButtonItem96.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem97
        '
        Me.SpreadsheetCommandBarButtonItem97.CommandName = "ShowPasteSpecialForm"
        Me.SpreadsheetCommandBarButtonItem97.Id = 256
        Me.SpreadsheetCommandBarButtonItem97.Name = "SpreadsheetCommandBarButtonItem97"
        Me.SpreadsheetCommandBarButtonItem97.RibbonStyle = CType((DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText Or DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText), DevExpress.XtraBars.Ribbon.RibbonItemStyles)
        '
        'BarButtonGroup1
        '
        Me.BarButtonGroup1.Id = 243
        Me.BarButtonGroup1.ItemLinks.Add(Me.ChangeFontNameItem1)
        Me.BarButtonGroup1.ItemLinks.Add(Me.ChangeFontSizeItem1)
        Me.BarButtonGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem98)
        Me.BarButtonGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem99)
        Me.BarButtonGroup1.Name = "BarButtonGroup1"
        Me.BarButtonGroup1.Tag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}"
        '
        'ChangeFontNameItem1
        '
        Me.ChangeFontNameItem1.Edit = Me.RepositoryItemFontEdit1
        Me.ChangeFontNameItem1.Id = 257
        Me.ChangeFontNameItem1.Name = "ChangeFontNameItem1"
        '
        'RepositoryItemFontEdit1
        '
        Me.RepositoryItemFontEdit1.AutoHeight = False
        Me.RepositoryItemFontEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemFontEdit1.Name = "RepositoryItemFontEdit1"
        '
        'ChangeFontSizeItem1
        '
        Me.ChangeFontSizeItem1.Edit = Me.RepositoryItemSpreadsheetFontSizeEdit1
        Me.ChangeFontSizeItem1.Id = 258
        Me.ChangeFontSizeItem1.Name = "ChangeFontSizeItem1"
        '
        'RepositoryItemSpreadsheetFontSizeEdit1
        '
        Me.RepositoryItemSpreadsheetFontSizeEdit1.AutoHeight = False
        Me.RepositoryItemSpreadsheetFontSizeEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemSpreadsheetFontSizeEdit1.Control = Me.spreadsheetControl
        Me.RepositoryItemSpreadsheetFontSizeEdit1.Name = "RepositoryItemSpreadsheetFontSizeEdit1"
        '
        'spreadsheetControl
        '
        Me.spreadsheetControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spreadsheetControl.Location = New System.Drawing.Point(0, 36)
        Me.spreadsheetControl.MenuManager = Me.ribbonControl
        Me.spreadsheetControl.Name = "spreadsheetControl"
        Me.spreadsheetControl.Options.Import.Csv.Encoding = CType(resources.GetObject("spreadsheetControl.Options.Import.Csv.Encoding"), System.Text.Encoding)
        Me.spreadsheetControl.Options.Import.Txt.Encoding = CType(resources.GetObject("spreadsheetControl.Options.Import.Txt.Encoding"), System.Text.Encoding)
        Me.spreadsheetControl.Size = New System.Drawing.Size(1108, 497)
        Me.spreadsheetControl.TabIndex = 1
        Me.spreadsheetControl.Text = "spreadsheetControl1"
        '
        'SpreadsheetCommandBarButtonItem98
        '
        Me.SpreadsheetCommandBarButtonItem98.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}"
        Me.SpreadsheetCommandBarButtonItem98.CommandName = "FormatIncreaseFontSize"
        Me.SpreadsheetCommandBarButtonItem98.Id = 259
        Me.SpreadsheetCommandBarButtonItem98.Name = "SpreadsheetCommandBarButtonItem98"
        Me.SpreadsheetCommandBarButtonItem98.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarButtonItem99
        '
        Me.SpreadsheetCommandBarButtonItem99.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}"
        Me.SpreadsheetCommandBarButtonItem99.CommandName = "FormatDecreaseFontSize"
        Me.SpreadsheetCommandBarButtonItem99.Id = 260
        Me.SpreadsheetCommandBarButtonItem99.Name = "SpreadsheetCommandBarButtonItem99"
        Me.SpreadsheetCommandBarButtonItem99.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'BarButtonGroup2
        '
        Me.BarButtonGroup2.Id = 244
        Me.BarButtonGroup2.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem28)
        Me.BarButtonGroup2.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem29)
        Me.BarButtonGroup2.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem30)
        Me.BarButtonGroup2.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem31)
        Me.BarButtonGroup2.Name = "BarButtonGroup2"
        Me.BarButtonGroup2.Tag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
        '
        'SpreadsheetCommandBarCheckItem28
        '
        Me.SpreadsheetCommandBarCheckItem28.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
        Me.SpreadsheetCommandBarCheckItem28.CommandName = "FormatFontBold"
        Me.SpreadsheetCommandBarCheckItem28.Id = 261
        Me.SpreadsheetCommandBarCheckItem28.Name = "SpreadsheetCommandBarCheckItem28"
        Me.SpreadsheetCommandBarCheckItem28.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarCheckItem29
        '
        Me.SpreadsheetCommandBarCheckItem29.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
        Me.SpreadsheetCommandBarCheckItem29.CommandName = "FormatFontItalic"
        Me.SpreadsheetCommandBarCheckItem29.Id = 262
        Me.SpreadsheetCommandBarCheckItem29.Name = "SpreadsheetCommandBarCheckItem29"
        Me.SpreadsheetCommandBarCheckItem29.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarCheckItem30
        '
        Me.SpreadsheetCommandBarCheckItem30.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
        Me.SpreadsheetCommandBarCheckItem30.CommandName = "FormatFontUnderline"
        Me.SpreadsheetCommandBarCheckItem30.Id = 263
        Me.SpreadsheetCommandBarCheckItem30.Name = "SpreadsheetCommandBarCheckItem30"
        Me.SpreadsheetCommandBarCheckItem30.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarCheckItem31
        '
        Me.SpreadsheetCommandBarCheckItem31.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}"
        Me.SpreadsheetCommandBarCheckItem31.CommandName = "FormatFontStrikeout"
        Me.SpreadsheetCommandBarCheckItem31.Id = 264
        Me.SpreadsheetCommandBarCheckItem31.Name = "SpreadsheetCommandBarCheckItem31"
        Me.SpreadsheetCommandBarCheckItem31.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'BarButtonGroup3
        '
        Me.BarButtonGroup3.Id = 245
        Me.BarButtonGroup3.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem24)
        Me.BarButtonGroup3.Name = "BarButtonGroup3"
        Me.BarButtonGroup3.Tag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}"
        '
        'SpreadsheetCommandBarSubItem24
        '
        Me.SpreadsheetCommandBarSubItem24.ButtonGroupTag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}"
        Me.SpreadsheetCommandBarSubItem24.CommandName = "FormatBordersCommandGroup"
        Me.SpreadsheetCommandBarSubItem24.Id = 265
        Me.SpreadsheetCommandBarSubItem24.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem100), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem101), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem102), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem103), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem104), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem105), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem106), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem107), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem108), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem109), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem110), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem111), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem112), New DevExpress.XtraBars.LinkPersistInfo(Me.ChangeBorderLineColorItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.ChangeBorderLineStyleItem1)})
        Me.SpreadsheetCommandBarSubItem24.Name = "SpreadsheetCommandBarSubItem24"
        Me.SpreadsheetCommandBarSubItem24.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarButtonItem100
        '
        Me.SpreadsheetCommandBarButtonItem100.CommandName = "FormatBottomBorder"
        Me.SpreadsheetCommandBarButtonItem100.Id = 266
        Me.SpreadsheetCommandBarButtonItem100.Name = "SpreadsheetCommandBarButtonItem100"
        '
        'SpreadsheetCommandBarButtonItem101
        '
        Me.SpreadsheetCommandBarButtonItem101.CommandName = "FormatTopBorder"
        Me.SpreadsheetCommandBarButtonItem101.Id = 267
        Me.SpreadsheetCommandBarButtonItem101.Name = "SpreadsheetCommandBarButtonItem101"
        '
        'SpreadsheetCommandBarButtonItem102
        '
        Me.SpreadsheetCommandBarButtonItem102.CommandName = "FormatLeftBorder"
        Me.SpreadsheetCommandBarButtonItem102.Id = 268
        Me.SpreadsheetCommandBarButtonItem102.Name = "SpreadsheetCommandBarButtonItem102"
        '
        'SpreadsheetCommandBarButtonItem103
        '
        Me.SpreadsheetCommandBarButtonItem103.CommandName = "FormatRightBorder"
        Me.SpreadsheetCommandBarButtonItem103.Id = 269
        Me.SpreadsheetCommandBarButtonItem103.Name = "SpreadsheetCommandBarButtonItem103"
        '
        'SpreadsheetCommandBarButtonItem104
        '
        Me.SpreadsheetCommandBarButtonItem104.CommandName = "FormatNoBorders"
        Me.SpreadsheetCommandBarButtonItem104.Id = 270
        Me.SpreadsheetCommandBarButtonItem104.Name = "SpreadsheetCommandBarButtonItem104"
        '
        'SpreadsheetCommandBarButtonItem105
        '
        Me.SpreadsheetCommandBarButtonItem105.CommandName = "FormatAllBorders"
        Me.SpreadsheetCommandBarButtonItem105.Id = 271
        Me.SpreadsheetCommandBarButtonItem105.Name = "SpreadsheetCommandBarButtonItem105"
        '
        'SpreadsheetCommandBarButtonItem106
        '
        Me.SpreadsheetCommandBarButtonItem106.CommandName = "FormatOutsideBorders"
        Me.SpreadsheetCommandBarButtonItem106.Id = 272
        Me.SpreadsheetCommandBarButtonItem106.Name = "SpreadsheetCommandBarButtonItem106"
        '
        'SpreadsheetCommandBarButtonItem107
        '
        Me.SpreadsheetCommandBarButtonItem107.CommandName = "FormatThickBorder"
        Me.SpreadsheetCommandBarButtonItem107.Id = 273
        Me.SpreadsheetCommandBarButtonItem107.Name = "SpreadsheetCommandBarButtonItem107"
        '
        'SpreadsheetCommandBarButtonItem108
        '
        Me.SpreadsheetCommandBarButtonItem108.CommandName = "FormatBottomDoubleBorder"
        Me.SpreadsheetCommandBarButtonItem108.Id = 274
        Me.SpreadsheetCommandBarButtonItem108.Name = "SpreadsheetCommandBarButtonItem108"
        '
        'SpreadsheetCommandBarButtonItem109
        '
        Me.SpreadsheetCommandBarButtonItem109.CommandName = "FormatBottomThickBorder"
        Me.SpreadsheetCommandBarButtonItem109.Id = 275
        Me.SpreadsheetCommandBarButtonItem109.Name = "SpreadsheetCommandBarButtonItem109"
        '
        'SpreadsheetCommandBarButtonItem110
        '
        Me.SpreadsheetCommandBarButtonItem110.CommandName = "FormatTopAndBottomBorder"
        Me.SpreadsheetCommandBarButtonItem110.Id = 276
        Me.SpreadsheetCommandBarButtonItem110.Name = "SpreadsheetCommandBarButtonItem110"
        '
        'SpreadsheetCommandBarButtonItem111
        '
        Me.SpreadsheetCommandBarButtonItem111.CommandName = "FormatTopAndThickBottomBorder"
        Me.SpreadsheetCommandBarButtonItem111.Id = 277
        Me.SpreadsheetCommandBarButtonItem111.Name = "SpreadsheetCommandBarButtonItem111"
        '
        'SpreadsheetCommandBarButtonItem112
        '
        Me.SpreadsheetCommandBarButtonItem112.CommandName = "FormatTopAndDoubleBottomBorder"
        Me.SpreadsheetCommandBarButtonItem112.Id = 278
        Me.SpreadsheetCommandBarButtonItem112.Name = "SpreadsheetCommandBarButtonItem112"
        '
        'ChangeBorderLineColorItem1
        '
        Me.ChangeBorderLineColorItem1.ActAsDropDown = True
        Me.ChangeBorderLineColorItem1.Id = 279
        Me.ChangeBorderLineColorItem1.Name = "ChangeBorderLineColorItem1"
        '
        'ChangeBorderLineStyleItem1
        '
        Me.ChangeBorderLineStyleItem1.DropDownControl = Me.CommandBarGalleryDropDown20
        Me.ChangeBorderLineStyleItem1.Id = 280
        Me.ChangeBorderLineStyleItem1.Name = "ChangeBorderLineStyleItem1"
        '
        'CommandBarGalleryDropDown20
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown20.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown20.Gallery.ColumnCount = 1
        Me.CommandBarGalleryDropDown20.Gallery.DrawImageBackground = False
        Me.CommandBarGalleryDropDown20.Gallery.ImageSize = New System.Drawing.Size(65, 46)
        Me.CommandBarGalleryDropDown20.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
        Me.CommandBarGalleryDropDown20.Gallery.ItemSize = New System.Drawing.Size(136, 26)
        Me.CommandBarGalleryDropDown20.Gallery.RowCount = 14
        Me.CommandBarGalleryDropDown20.Gallery.ShowGroupCaption = False
        Me.CommandBarGalleryDropDown20.Gallery.ShowItemText = True
        Me.CommandBarGalleryDropDown20.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown20.Name = "CommandBarGalleryDropDown20"
        Me.CommandBarGalleryDropDown20.Ribbon = Me.ribbonControl
        '
        'BarButtonGroup4
        '
        Me.BarButtonGroup4.Id = 246
        Me.BarButtonGroup4.ItemLinks.Add(Me.ChangeCellFillColorItem1)
        Me.BarButtonGroup4.ItemLinks.Add(Me.ChangeFontColorItem1)
        Me.BarButtonGroup4.Name = "BarButtonGroup4"
        Me.BarButtonGroup4.Tag = "{C2275623-04A3-41E8-8D6A-EB5C7F8541D1}"
        '
        'ChangeCellFillColorItem1
        '
        Me.ChangeCellFillColorItem1.Id = 281
        Me.ChangeCellFillColorItem1.Name = "ChangeCellFillColorItem1"
        '
        'ChangeFontColorItem1
        '
        Me.ChangeFontColorItem1.Id = 282
        Me.ChangeFontColorItem1.Name = "ChangeFontColorItem1"
        '
        'BarButtonGroup5
        '
        Me.BarButtonGroup5.Id = 247
        Me.BarButtonGroup5.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem32)
        Me.BarButtonGroup5.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem33)
        Me.BarButtonGroup5.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem34)
        Me.BarButtonGroup5.Name = "BarButtonGroup5"
        Me.BarButtonGroup5.Tag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
        '
        'SpreadsheetCommandBarCheckItem32
        '
        Me.SpreadsheetCommandBarCheckItem32.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
        Me.SpreadsheetCommandBarCheckItem32.CommandName = "FormatAlignmentTop"
        Me.SpreadsheetCommandBarCheckItem32.Id = 283
        Me.SpreadsheetCommandBarCheckItem32.Name = "SpreadsheetCommandBarCheckItem32"
        Me.SpreadsheetCommandBarCheckItem32.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarCheckItem33
        '
        Me.SpreadsheetCommandBarCheckItem33.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
        Me.SpreadsheetCommandBarCheckItem33.CommandName = "FormatAlignmentMiddle"
        Me.SpreadsheetCommandBarCheckItem33.Id = 284
        Me.SpreadsheetCommandBarCheckItem33.Name = "SpreadsheetCommandBarCheckItem33"
        Me.SpreadsheetCommandBarCheckItem33.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarCheckItem34
        '
        Me.SpreadsheetCommandBarCheckItem34.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}"
        Me.SpreadsheetCommandBarCheckItem34.CommandName = "FormatAlignmentBottom"
        Me.SpreadsheetCommandBarCheckItem34.Id = 285
        Me.SpreadsheetCommandBarCheckItem34.Name = "SpreadsheetCommandBarCheckItem34"
        Me.SpreadsheetCommandBarCheckItem34.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'BarButtonGroup6
        '
        Me.BarButtonGroup6.Id = 248
        Me.BarButtonGroup6.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem35)
        Me.BarButtonGroup6.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem36)
        Me.BarButtonGroup6.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem37)
        Me.BarButtonGroup6.Name = "BarButtonGroup6"
        Me.BarButtonGroup6.Tag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
        '
        'SpreadsheetCommandBarCheckItem35
        '
        Me.SpreadsheetCommandBarCheckItem35.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
        Me.SpreadsheetCommandBarCheckItem35.CommandName = "FormatAlignmentLeft"
        Me.SpreadsheetCommandBarCheckItem35.Id = 286
        Me.SpreadsheetCommandBarCheckItem35.Name = "SpreadsheetCommandBarCheckItem35"
        Me.SpreadsheetCommandBarCheckItem35.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarCheckItem36
        '
        Me.SpreadsheetCommandBarCheckItem36.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
        Me.SpreadsheetCommandBarCheckItem36.CommandName = "FormatAlignmentCenter"
        Me.SpreadsheetCommandBarCheckItem36.Id = 287
        Me.SpreadsheetCommandBarCheckItem36.Name = "SpreadsheetCommandBarCheckItem36"
        Me.SpreadsheetCommandBarCheckItem36.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarCheckItem37
        '
        Me.SpreadsheetCommandBarCheckItem37.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}"
        Me.SpreadsheetCommandBarCheckItem37.CommandName = "FormatAlignmentRight"
        Me.SpreadsheetCommandBarCheckItem37.Id = 288
        Me.SpreadsheetCommandBarCheckItem37.Name = "SpreadsheetCommandBarCheckItem37"
        Me.SpreadsheetCommandBarCheckItem37.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'BarButtonGroup7
        '
        Me.BarButtonGroup7.Id = 249
        Me.BarButtonGroup7.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem113)
        Me.BarButtonGroup7.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem114)
        Me.BarButtonGroup7.Name = "BarButtonGroup7"
        Me.BarButtonGroup7.Tag = "{A5E37DED-106E-44FC-8044-CE3824C08225}"
        '
        'SpreadsheetCommandBarButtonItem113
        '
        Me.SpreadsheetCommandBarButtonItem113.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}"
        Me.SpreadsheetCommandBarButtonItem113.CommandName = "FormatDecreaseIndent"
        Me.SpreadsheetCommandBarButtonItem113.Id = 289
        Me.SpreadsheetCommandBarButtonItem113.Name = "SpreadsheetCommandBarButtonItem113"
        Me.SpreadsheetCommandBarButtonItem113.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarButtonItem114
        '
        Me.SpreadsheetCommandBarButtonItem114.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}"
        Me.SpreadsheetCommandBarButtonItem114.CommandName = "FormatIncreaseIndent"
        Me.SpreadsheetCommandBarButtonItem114.Id = 290
        Me.SpreadsheetCommandBarButtonItem114.Name = "SpreadsheetCommandBarButtonItem114"
        Me.SpreadsheetCommandBarButtonItem114.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarCheckItem38
        '
        Me.SpreadsheetCommandBarCheckItem38.CommandName = "FormatWrapText"
        Me.SpreadsheetCommandBarCheckItem38.Id = 291
        Me.SpreadsheetCommandBarCheckItem38.Name = "SpreadsheetCommandBarCheckItem38"
        Me.SpreadsheetCommandBarCheckItem38.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarSubItem25
        '
        Me.SpreadsheetCommandBarSubItem25.CommandName = "EditingMergeCellsCommandGroup"
        Me.SpreadsheetCommandBarSubItem25.Id = 292
        Me.SpreadsheetCommandBarSubItem25.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem39), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem115), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem116), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem117)})
        Me.SpreadsheetCommandBarSubItem25.Name = "SpreadsheetCommandBarSubItem25"
        Me.SpreadsheetCommandBarSubItem25.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarCheckItem39
        '
        Me.SpreadsheetCommandBarCheckItem39.CommandName = "EditingMergeAndCenterCells"
        Me.SpreadsheetCommandBarCheckItem39.Id = 293
        Me.SpreadsheetCommandBarCheckItem39.Name = "SpreadsheetCommandBarCheckItem39"
        '
        'SpreadsheetCommandBarButtonItem115
        '
        Me.SpreadsheetCommandBarButtonItem115.CommandName = "EditingMergeCellsAcross"
        Me.SpreadsheetCommandBarButtonItem115.Id = 294
        Me.SpreadsheetCommandBarButtonItem115.Name = "SpreadsheetCommandBarButtonItem115"
        '
        'SpreadsheetCommandBarButtonItem116
        '
        Me.SpreadsheetCommandBarButtonItem116.CommandName = "EditingMergeCells"
        Me.SpreadsheetCommandBarButtonItem116.Id = 295
        Me.SpreadsheetCommandBarButtonItem116.Name = "SpreadsheetCommandBarButtonItem116"
        '
        'SpreadsheetCommandBarButtonItem117
        '
        Me.SpreadsheetCommandBarButtonItem117.CommandName = "EditingUnmergeCells"
        Me.SpreadsheetCommandBarButtonItem117.Id = 296
        Me.SpreadsheetCommandBarButtonItem117.Name = "SpreadsheetCommandBarButtonItem117"
        '
        'BarButtonGroup8
        '
        Me.BarButtonGroup8.Id = 250
        Me.BarButtonGroup8.ItemLinks.Add(Me.ChangeNumberFormatItem1)
        Me.BarButtonGroup8.Name = "BarButtonGroup8"
        Me.BarButtonGroup8.Tag = "{0B3A7A43-3079-4ce0-83A8-3789F5F6DC9F}"
        '
        'ChangeNumberFormatItem1
        '
        Me.ChangeNumberFormatItem1.Edit = Me.RepositoryItemPopupGalleryEdit1
        Me.ChangeNumberFormatItem1.Id = 297
        Me.ChangeNumberFormatItem1.Name = "ChangeNumberFormatItem1"
        '
        'RepositoryItemPopupGalleryEdit1
        '
        Me.RepositoryItemPopupGalleryEdit1.AutoHeight = False
        Me.RepositoryItemPopupGalleryEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        '
        '
        '
        Me.RepositoryItemPopupGalleryEdit1.Gallery.AllowFilter = False
        Me.RepositoryItemPopupGalleryEdit1.Gallery.AutoFitColumns = False
        Me.RepositoryItemPopupGalleryEdit1.Gallery.ColumnCount = 1
        Me.RepositoryItemPopupGalleryEdit1.Gallery.FixedImageSize = False
        SpreadsheetCommandGalleryItem132.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem132.CaptionAsValue = True
        SpreadsheetCommandGalleryItem132.Checked = True
        SpreadsheetCommandGalleryItem132.CommandName = "FormatNumberGeneral"
        SpreadsheetCommandGalleryItem132.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage131"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem132.IsEmptyHint = True
        SpreadsheetCommandGalleryItem133.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem133.CaptionAsValue = True
        SpreadsheetCommandGalleryItem133.CommandName = "FormatNumberDecimal"
        SpreadsheetCommandGalleryItem133.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage132"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem133.IsEmptyHint = True
        SpreadsheetCommandGalleryItem134.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem134.CaptionAsValue = True
        SpreadsheetCommandGalleryItem134.CommandName = "FormatNumberAccountingCurrency"
        SpreadsheetCommandGalleryItem134.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage133"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem134.IsEmptyHint = True
        SpreadsheetCommandGalleryItem135.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem135.CaptionAsValue = True
        SpreadsheetCommandGalleryItem135.CommandName = "FormatNumberAccountingRegular"
        SpreadsheetCommandGalleryItem135.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage134"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem135.IsEmptyHint = True
        SpreadsheetCommandGalleryItem136.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem136.CaptionAsValue = True
        SpreadsheetCommandGalleryItem136.CommandName = "FormatNumberShortDate"
        SpreadsheetCommandGalleryItem136.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage135"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem136.IsEmptyHint = True
        SpreadsheetCommandGalleryItem137.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem137.CaptionAsValue = True
        SpreadsheetCommandGalleryItem137.CommandName = "FormatNumberLongDate"
        SpreadsheetCommandGalleryItem137.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage136"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem137.IsEmptyHint = True
        SpreadsheetCommandGalleryItem138.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem138.CaptionAsValue = True
        SpreadsheetCommandGalleryItem138.CommandName = "FormatNumberTime"
        SpreadsheetCommandGalleryItem138.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage137"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem138.IsEmptyHint = True
        SpreadsheetCommandGalleryItem139.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem139.CaptionAsValue = True
        SpreadsheetCommandGalleryItem139.CommandName = "FormatNumberPercentage"
        SpreadsheetCommandGalleryItem139.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage138"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem139.IsEmptyHint = True
        SpreadsheetCommandGalleryItem140.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem140.CaptionAsValue = True
        SpreadsheetCommandGalleryItem140.CommandName = "FormatNumberFraction"
        SpreadsheetCommandGalleryItem140.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage139"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem140.IsEmptyHint = True
        SpreadsheetCommandGalleryItem141.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem141.CaptionAsValue = True
        SpreadsheetCommandGalleryItem141.CommandName = "FormatNumberScientific"
        SpreadsheetCommandGalleryItem141.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage140"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem141.IsEmptyHint = True
        SpreadsheetCommandGalleryItem142.AlwaysUpdateDescription = True
        SpreadsheetCommandGalleryItem142.CaptionAsValue = True
        SpreadsheetCommandGalleryItem142.CommandName = "FormatNumberText"
        SpreadsheetCommandGalleryItem142.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage141"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem142.IsEmptyHint = True
        GalleryItemGroup1.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem132, SpreadsheetCommandGalleryItem133, SpreadsheetCommandGalleryItem134, SpreadsheetCommandGalleryItem135, SpreadsheetCommandGalleryItem136, SpreadsheetCommandGalleryItem137, SpreadsheetCommandGalleryItem138, SpreadsheetCommandGalleryItem139, SpreadsheetCommandGalleryItem140, SpreadsheetCommandGalleryItem141, SpreadsheetCommandGalleryItem142})
        Me.RepositoryItemPopupGalleryEdit1.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {GalleryItemGroup1})
        Me.RepositoryItemPopupGalleryEdit1.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft
        Me.RepositoryItemPopupGalleryEdit1.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left
        Me.RepositoryItemPopupGalleryEdit1.Gallery.RowCount = 11
        Me.RepositoryItemPopupGalleryEdit1.Gallery.ShowGroupCaption = False
        Me.RepositoryItemPopupGalleryEdit1.Gallery.ShowItemText = True
        Me.RepositoryItemPopupGalleryEdit1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Hide
        Me.RepositoryItemPopupGalleryEdit1.Gallery.StretchItems = True
        Me.RepositoryItemPopupGalleryEdit1.Name = "RepositoryItemPopupGalleryEdit1"
        Me.RepositoryItemPopupGalleryEdit1.ShowButtons = False
        Me.RepositoryItemPopupGalleryEdit1.ShowPopupCloseButton = False
        Me.RepositoryItemPopupGalleryEdit1.ShowSizeGrip = False
        '
        'BarButtonGroup9
        '
        Me.BarButtonGroup9.Id = 251
        Me.BarButtonGroup9.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem26)
        Me.BarButtonGroup9.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem124)
        Me.BarButtonGroup9.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem125)
        Me.BarButtonGroup9.Name = "BarButtonGroup9"
        Me.BarButtonGroup9.Tag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
        '
        'SpreadsheetCommandBarSubItem26
        '
        Me.SpreadsheetCommandBarSubItem26.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
        Me.SpreadsheetCommandBarSubItem26.CommandName = "FormatNumberAccountingCommandGroup"
        Me.SpreadsheetCommandBarSubItem26.Id = 298
        Me.SpreadsheetCommandBarSubItem26.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem118), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem119), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem120), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem121), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem122), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem123)})
        Me.SpreadsheetCommandBarSubItem26.Name = "SpreadsheetCommandBarSubItem26"
        Me.SpreadsheetCommandBarSubItem26.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarButtonItem118
        '
        Me.SpreadsheetCommandBarButtonItem118.CommandName = "FormatNumberAccountingDefault"
        Me.SpreadsheetCommandBarButtonItem118.Id = 299
        Me.SpreadsheetCommandBarButtonItem118.Name = "SpreadsheetCommandBarButtonItem118"
        '
        'SpreadsheetCommandBarButtonItem119
        '
        Me.SpreadsheetCommandBarButtonItem119.CommandName = "FormatNumberAccountingUS"
        Me.SpreadsheetCommandBarButtonItem119.Id = 300
        Me.SpreadsheetCommandBarButtonItem119.Name = "SpreadsheetCommandBarButtonItem119"
        '
        'SpreadsheetCommandBarButtonItem120
        '
        Me.SpreadsheetCommandBarButtonItem120.CommandName = "FormatNumberAccountingUK"
        Me.SpreadsheetCommandBarButtonItem120.Id = 301
        Me.SpreadsheetCommandBarButtonItem120.Name = "SpreadsheetCommandBarButtonItem120"
        '
        'SpreadsheetCommandBarButtonItem121
        '
        Me.SpreadsheetCommandBarButtonItem121.CommandName = "FormatNumberAccountingEuro"
        Me.SpreadsheetCommandBarButtonItem121.Id = 302
        Me.SpreadsheetCommandBarButtonItem121.Name = "SpreadsheetCommandBarButtonItem121"
        '
        'SpreadsheetCommandBarButtonItem122
        '
        Me.SpreadsheetCommandBarButtonItem122.CommandName = "FormatNumberAccountingPRC"
        Me.SpreadsheetCommandBarButtonItem122.Id = 303
        Me.SpreadsheetCommandBarButtonItem122.Name = "SpreadsheetCommandBarButtonItem122"
        '
        'SpreadsheetCommandBarButtonItem123
        '
        Me.SpreadsheetCommandBarButtonItem123.CommandName = "FormatNumberAccountingSwiss"
        Me.SpreadsheetCommandBarButtonItem123.Id = 304
        Me.SpreadsheetCommandBarButtonItem123.Name = "SpreadsheetCommandBarButtonItem123"
        '
        'SpreadsheetCommandBarButtonItem124
        '
        Me.SpreadsheetCommandBarButtonItem124.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
        Me.SpreadsheetCommandBarButtonItem124.CommandName = "FormatNumberPercent"
        Me.SpreadsheetCommandBarButtonItem124.Id = 305
        Me.SpreadsheetCommandBarButtonItem124.Name = "SpreadsheetCommandBarButtonItem124"
        Me.SpreadsheetCommandBarButtonItem124.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarButtonItem125
        '
        Me.SpreadsheetCommandBarButtonItem125.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}"
        Me.SpreadsheetCommandBarButtonItem125.CommandName = "FormatNumberAccounting"
        Me.SpreadsheetCommandBarButtonItem125.Id = 306
        Me.SpreadsheetCommandBarButtonItem125.Name = "SpreadsheetCommandBarButtonItem125"
        Me.SpreadsheetCommandBarButtonItem125.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'BarButtonGroup10
        '
        Me.BarButtonGroup10.Id = 252
        Me.BarButtonGroup10.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem126)
        Me.BarButtonGroup10.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem127)
        Me.BarButtonGroup10.Name = "BarButtonGroup10"
        Me.BarButtonGroup10.Tag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}"
        '
        'SpreadsheetCommandBarButtonItem126
        '
        Me.SpreadsheetCommandBarButtonItem126.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}"
        Me.SpreadsheetCommandBarButtonItem126.CommandName = "FormatNumberIncreaseDecimal"
        Me.SpreadsheetCommandBarButtonItem126.Id = 307
        Me.SpreadsheetCommandBarButtonItem126.Name = "SpreadsheetCommandBarButtonItem126"
        Me.SpreadsheetCommandBarButtonItem126.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarButtonItem127
        '
        Me.SpreadsheetCommandBarButtonItem127.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}"
        Me.SpreadsheetCommandBarButtonItem127.CommandName = "FormatNumberDecreaseDecimal"
        Me.SpreadsheetCommandBarButtonItem127.Id = 308
        Me.SpreadsheetCommandBarButtonItem127.Name = "SpreadsheetCommandBarButtonItem127"
        Me.SpreadsheetCommandBarButtonItem127.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        '
        'SpreadsheetCommandBarSubItem30
        '
        Me.SpreadsheetCommandBarSubItem30.CommandName = "ConditionalFormattingCommandGroup"
        Me.SpreadsheetCommandBarSubItem30.Id = 309
        Me.SpreadsheetCommandBarSubItem30.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarSubItem27), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarSubItem28), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonGalleryDropDownItem20), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonGalleryDropDownItem21), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonGalleryDropDownItem22), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem141), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarSubItem29), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem144)})
        Me.SpreadsheetCommandBarSubItem30.Name = "SpreadsheetCommandBarSubItem30"
        '
        'SpreadsheetCommandBarSubItem27
        '
        Me.SpreadsheetCommandBarSubItem27.CommandName = "ConditionalFormattingHighlightCellsRuleCommandGroup"
        Me.SpreadsheetCommandBarSubItem27.Id = 317
        Me.SpreadsheetCommandBarSubItem27.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem128), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem129), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem130), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem131), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem132), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem133), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem134)})
        Me.SpreadsheetCommandBarSubItem27.Name = "SpreadsheetCommandBarSubItem27"
        '
        'SpreadsheetCommandBarButtonItem128
        '
        Me.SpreadsheetCommandBarButtonItem128.CommandName = "ConditionalFormattingGreaterThanRuleCommand"
        Me.SpreadsheetCommandBarButtonItem128.Id = 310
        Me.SpreadsheetCommandBarButtonItem128.Name = "SpreadsheetCommandBarButtonItem128"
        Me.SpreadsheetCommandBarButtonItem128.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem129
        '
        Me.SpreadsheetCommandBarButtonItem129.CommandName = "ConditionalFormattingLessThanRuleCommand"
        Me.SpreadsheetCommandBarButtonItem129.Id = 311
        Me.SpreadsheetCommandBarButtonItem129.Name = "SpreadsheetCommandBarButtonItem129"
        Me.SpreadsheetCommandBarButtonItem129.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem130
        '
        Me.SpreadsheetCommandBarButtonItem130.CommandName = "ConditionalFormattingBetweenRuleCommand"
        Me.SpreadsheetCommandBarButtonItem130.Id = 312
        Me.SpreadsheetCommandBarButtonItem130.Name = "SpreadsheetCommandBarButtonItem130"
        Me.SpreadsheetCommandBarButtonItem130.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem131
        '
        Me.SpreadsheetCommandBarButtonItem131.CommandName = "ConditionalFormattingEqualToRuleCommand"
        Me.SpreadsheetCommandBarButtonItem131.Id = 313
        Me.SpreadsheetCommandBarButtonItem131.Name = "SpreadsheetCommandBarButtonItem131"
        Me.SpreadsheetCommandBarButtonItem131.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem132
        '
        Me.SpreadsheetCommandBarButtonItem132.CommandName = "ConditionalFormattingTextContainsRuleCommand"
        Me.SpreadsheetCommandBarButtonItem132.Id = 314
        Me.SpreadsheetCommandBarButtonItem132.Name = "SpreadsheetCommandBarButtonItem132"
        Me.SpreadsheetCommandBarButtonItem132.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem133
        '
        Me.SpreadsheetCommandBarButtonItem133.CommandName = "ConditionalFormattingDateOccurringRuleCommand"
        Me.SpreadsheetCommandBarButtonItem133.Id = 315
        Me.SpreadsheetCommandBarButtonItem133.Name = "SpreadsheetCommandBarButtonItem133"
        Me.SpreadsheetCommandBarButtonItem133.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem134
        '
        Me.SpreadsheetCommandBarButtonItem134.CommandName = "ConditionalFormattingDuplicateValuesRuleCommand"
        Me.SpreadsheetCommandBarButtonItem134.Id = 316
        Me.SpreadsheetCommandBarButtonItem134.Name = "SpreadsheetCommandBarButtonItem134"
        Me.SpreadsheetCommandBarButtonItem134.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarSubItem28
        '
        Me.SpreadsheetCommandBarSubItem28.CommandName = "ConditionalFormattingTopBottomRuleCommandGroup"
        Me.SpreadsheetCommandBarSubItem28.Id = 324
        Me.SpreadsheetCommandBarSubItem28.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem135), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem136), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem137), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem138), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem139), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem140)})
        Me.SpreadsheetCommandBarSubItem28.Name = "SpreadsheetCommandBarSubItem28"
        '
        'SpreadsheetCommandBarButtonItem135
        '
        Me.SpreadsheetCommandBarButtonItem135.CommandName = "ConditionalFormattingTop10RuleCommand"
        Me.SpreadsheetCommandBarButtonItem135.Id = 318
        Me.SpreadsheetCommandBarButtonItem135.Name = "SpreadsheetCommandBarButtonItem135"
        Me.SpreadsheetCommandBarButtonItem135.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem136
        '
        Me.SpreadsheetCommandBarButtonItem136.CommandName = "ConditionalFormattingTop10PercentRuleCommand"
        Me.SpreadsheetCommandBarButtonItem136.Id = 319
        Me.SpreadsheetCommandBarButtonItem136.Name = "SpreadsheetCommandBarButtonItem136"
        Me.SpreadsheetCommandBarButtonItem136.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem137
        '
        Me.SpreadsheetCommandBarButtonItem137.CommandName = "ConditionalFormattingBottom10RuleCommand"
        Me.SpreadsheetCommandBarButtonItem137.Id = 320
        Me.SpreadsheetCommandBarButtonItem137.Name = "SpreadsheetCommandBarButtonItem137"
        Me.SpreadsheetCommandBarButtonItem137.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem138
        '
        Me.SpreadsheetCommandBarButtonItem138.CommandName = "ConditionalFormattingBottom10PercentRuleCommand"
        Me.SpreadsheetCommandBarButtonItem138.Id = 321
        Me.SpreadsheetCommandBarButtonItem138.Name = "SpreadsheetCommandBarButtonItem138"
        Me.SpreadsheetCommandBarButtonItem138.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem139
        '
        Me.SpreadsheetCommandBarButtonItem139.CommandName = "ConditionalFormattingAboveAverageRuleCommand"
        Me.SpreadsheetCommandBarButtonItem139.Id = 322
        Me.SpreadsheetCommandBarButtonItem139.Name = "SpreadsheetCommandBarButtonItem139"
        Me.SpreadsheetCommandBarButtonItem139.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonItem140
        '
        Me.SpreadsheetCommandBarButtonItem140.CommandName = "ConditionalFormattingBelowAverageRuleCommand"
        Me.SpreadsheetCommandBarButtonItem140.Id = 323
        Me.SpreadsheetCommandBarButtonItem140.Name = "SpreadsheetCommandBarButtonItem140"
        Me.SpreadsheetCommandBarButtonItem140.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem20
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem20.CommandName = "ConditionalFormattingDataBarsCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem20.DropDownControl = Me.CommandBarGalleryDropDown21
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem20.Id = 325
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem20.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem20"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem20.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'CommandBarGalleryDropDown21
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown21.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup34.CommandName = "ConditionalFormattingDataBarsGradientFillCommandGroup"
        SpreadsheetCommandGalleryItem143.CommandName = "ConditionalFormattingDataBarGradientBlue"
        SpreadsheetCommandGalleryItem143.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage142"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem144.CommandName = "ConditionalFormattingDataBarGradientGreen"
        SpreadsheetCommandGalleryItem144.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage143"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem145.CommandName = "ConditionalFormattingDataBarGradientRed"
        SpreadsheetCommandGalleryItem145.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage144"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem146.CommandName = "ConditionalFormattingDataBarGradientOrange"
        SpreadsheetCommandGalleryItem146.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage145"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem147.CommandName = "ConditionalFormattingDataBarGradientLightBlue"
        SpreadsheetCommandGalleryItem147.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage146"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem148.CommandName = "ConditionalFormattingDataBarGradientPurple"
        SpreadsheetCommandGalleryItem148.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage147"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup34.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem143, SpreadsheetCommandGalleryItem144, SpreadsheetCommandGalleryItem145, SpreadsheetCommandGalleryItem146, SpreadsheetCommandGalleryItem147, SpreadsheetCommandGalleryItem148})
        SpreadsheetCommandGalleryItemGroup35.CommandName = "ConditionalFormattingDataBarsSolidFillCommandGroup"
        SpreadsheetCommandGalleryItem149.CommandName = "ConditionalFormattingDataBarSolidBlue"
        SpreadsheetCommandGalleryItem149.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage148"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem150.CommandName = "ConditionalFormattingDataBarSolidGreen"
        SpreadsheetCommandGalleryItem150.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage149"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem151.CommandName = "ConditionalFormattingDataBarSolidRed"
        SpreadsheetCommandGalleryItem151.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage150"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem152.CommandName = "ConditionalFormattingDataBarSolidOrange"
        SpreadsheetCommandGalleryItem152.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage151"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem153.CommandName = "ConditionalFormattingDataBarSolidLightBlue"
        SpreadsheetCommandGalleryItem153.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage152"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem154.CommandName = "ConditionalFormattingDataBarSolidPurple"
        SpreadsheetCommandGalleryItem154.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage153"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup35.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem149, SpreadsheetCommandGalleryItem150, SpreadsheetCommandGalleryItem151, SpreadsheetCommandGalleryItem152, SpreadsheetCommandGalleryItem153, SpreadsheetCommandGalleryItem154})
        Me.CommandBarGalleryDropDown21.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup34, SpreadsheetCommandGalleryItemGroup35})
        Me.CommandBarGalleryDropDown21.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown21.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown21.Name = "CommandBarGalleryDropDown21"
        Me.CommandBarGalleryDropDown21.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem21
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem21.CommandName = "ConditionalFormattingColorScalesCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem21.DropDownControl = Me.CommandBarGalleryDropDown22
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem21.Id = 326
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem21.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem21"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem21.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'CommandBarGalleryDropDown22
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown22.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup36.CommandName = "ConditionalFormattingColorScalesCommandGroup"
        SpreadsheetCommandGalleryItem155.CommandName = "ConditionalFormattingColorScaleGreenYellowRed"
        SpreadsheetCommandGalleryItem155.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage154"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem156.CommandName = "ConditionalFormattingColorScaleRedYellowGreen"
        SpreadsheetCommandGalleryItem156.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage155"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem157.CommandName = "ConditionalFormattingColorScaleGreenWhiteRed"
        SpreadsheetCommandGalleryItem157.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage156"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem158.CommandName = "ConditionalFormattingColorScaleRedWhiteGreen"
        SpreadsheetCommandGalleryItem158.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage157"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem159.CommandName = "ConditionalFormattingColorScaleBlueWhiteRed"
        SpreadsheetCommandGalleryItem159.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage158"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem160.CommandName = "ConditionalFormattingColorScaleRedWhiteBlue"
        SpreadsheetCommandGalleryItem160.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage159"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem161.CommandName = "ConditionalFormattingColorScaleWhiteRed"
        SpreadsheetCommandGalleryItem161.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage160"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem162.CommandName = "ConditionalFormattingColorScaleRedWhite"
        SpreadsheetCommandGalleryItem162.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage161"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem163.CommandName = "ConditionalFormattingColorScaleGreenWhite"
        SpreadsheetCommandGalleryItem163.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage162"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem164.CommandName = "ConditionalFormattingColorScaleWhiteGreen"
        SpreadsheetCommandGalleryItem164.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage163"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem165.CommandName = "ConditionalFormattingColorScaleGreenYellow"
        SpreadsheetCommandGalleryItem165.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage164"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem166.CommandName = "ConditionalFormattingColorScaleYellowGreen"
        SpreadsheetCommandGalleryItem166.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage165"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup36.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem155, SpreadsheetCommandGalleryItem156, SpreadsheetCommandGalleryItem157, SpreadsheetCommandGalleryItem158, SpreadsheetCommandGalleryItem159, SpreadsheetCommandGalleryItem160, SpreadsheetCommandGalleryItem161, SpreadsheetCommandGalleryItem162, SpreadsheetCommandGalleryItem163, SpreadsheetCommandGalleryItem164, SpreadsheetCommandGalleryItem165, SpreadsheetCommandGalleryItem166})
        Me.CommandBarGalleryDropDown22.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup36})
        Me.CommandBarGalleryDropDown22.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown22.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown22.Name = "CommandBarGalleryDropDown22"
        Me.CommandBarGalleryDropDown22.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonGalleryDropDownItem22
        '
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem22.CommandName = "ConditionalFormattingIconSetsCommandGroup"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem22.DropDownControl = Me.CommandBarGalleryDropDown23
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem22.Id = 327
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem22.Name = "SpreadsheetCommandBarButtonGalleryDropDownItem22"
        Me.SpreadsheetCommandBarButtonGalleryDropDownItem22.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
        '
        'CommandBarGalleryDropDown23
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown23.Gallery.AllowFilter = False
        SpreadsheetCommandGalleryItemGroup37.CommandName = "ConditionalFormattingIconSetsDirectionalCommandGroup"
        SpreadsheetCommandGalleryItem167.CommandName = "ConditionalFormattingIconSetArrows3Colored"
        SpreadsheetCommandGalleryItem167.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage166"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem168.CommandName = "ConditionalFormattingIconSetArrows3Grayed"
        SpreadsheetCommandGalleryItem168.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage167"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem169.CommandName = "ConditionalFormattingIconSetArrows4Colored"
        SpreadsheetCommandGalleryItem169.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage168"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem170.CommandName = "ConditionalFormattingIconSetArrows4Grayed"
        SpreadsheetCommandGalleryItem170.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage169"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem171.CommandName = "ConditionalFormattingIconSetArrows5Colored"
        SpreadsheetCommandGalleryItem171.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage170"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem172.CommandName = "ConditionalFormattingIconSetArrows5Grayed"
        SpreadsheetCommandGalleryItem172.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage171"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem173.CommandName = "ConditionalFormattingIconSetTriangles3"
        SpreadsheetCommandGalleryItem173.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage172"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup37.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem167, SpreadsheetCommandGalleryItem168, SpreadsheetCommandGalleryItem169, SpreadsheetCommandGalleryItem170, SpreadsheetCommandGalleryItem171, SpreadsheetCommandGalleryItem172, SpreadsheetCommandGalleryItem173})
        SpreadsheetCommandGalleryItemGroup38.CommandName = "ConditionalFormattingIconSetsShapesCommandGroup"
        SpreadsheetCommandGalleryItem174.CommandName = "ConditionalFormattingIconSetTrafficLights3"
        SpreadsheetCommandGalleryItem174.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage173"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem175.CommandName = "ConditionalFormattingIconSetTrafficLights3Rimmed"
        SpreadsheetCommandGalleryItem175.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage174"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem176.CommandName = "ConditionalFormattingIconSetTrafficLights4"
        SpreadsheetCommandGalleryItem176.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage175"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem177.CommandName = "ConditionalFormattingIconSetSigns3"
        SpreadsheetCommandGalleryItem177.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage176"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem178.CommandName = "ConditionalFormattingIconSetRedToBlack"
        SpreadsheetCommandGalleryItem178.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage177"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup38.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem174, SpreadsheetCommandGalleryItem175, SpreadsheetCommandGalleryItem176, SpreadsheetCommandGalleryItem177, SpreadsheetCommandGalleryItem178})
        SpreadsheetCommandGalleryItemGroup39.CommandName = "ConditionalFormattingIconSetsIndicatorsCommandGroup"
        SpreadsheetCommandGalleryItem179.CommandName = "ConditionalFormattingIconSetSymbols3Circled"
        SpreadsheetCommandGalleryItem179.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage178"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem180.CommandName = "ConditionalFormattingIconSetSymbols3"
        SpreadsheetCommandGalleryItem180.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage179"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem181.CommandName = "ConditionalFormattingIconSetFlags3"
        SpreadsheetCommandGalleryItem181.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage180"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup39.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem179, SpreadsheetCommandGalleryItem180, SpreadsheetCommandGalleryItem181})
        SpreadsheetCommandGalleryItemGroup40.CommandName = "ConditionalFormattingIconSetsRatingsCommandGroup"
        SpreadsheetCommandGalleryItem182.CommandName = "ConditionalFormattingIconSetStars3"
        SpreadsheetCommandGalleryItem182.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage181"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem183.CommandName = "ConditionalFormattingIconSetRatings4"
        SpreadsheetCommandGalleryItem183.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage182"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem184.CommandName = "ConditionalFormattingIconSetRatings5"
        SpreadsheetCommandGalleryItem184.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage183"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem185.CommandName = "ConditionalFormattingIconSetQuarters5"
        SpreadsheetCommandGalleryItem185.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage184"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItem186.CommandName = "ConditionalFormattingIconSetBoxes5"
        SpreadsheetCommandGalleryItem186.ImageOptions.SvgImage = CType(resources.GetObject("resource.SvgImage185"), DevExpress.Utils.Svg.SvgImage)
        SpreadsheetCommandGalleryItemGroup40.Items.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItem() {SpreadsheetCommandGalleryItem182, SpreadsheetCommandGalleryItem183, SpreadsheetCommandGalleryItem184, SpreadsheetCommandGalleryItem185, SpreadsheetCommandGalleryItem186})
        Me.CommandBarGalleryDropDown23.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() {SpreadsheetCommandGalleryItemGroup37, SpreadsheetCommandGalleryItemGroup38, SpreadsheetCommandGalleryItemGroup39, SpreadsheetCommandGalleryItemGroup40})
        Me.CommandBarGalleryDropDown23.Gallery.ImageSize = New System.Drawing.Size(32, 32)
        Me.CommandBarGalleryDropDown23.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.[Auto]
        Me.CommandBarGalleryDropDown23.Name = "CommandBarGalleryDropDown23"
        Me.CommandBarGalleryDropDown23.Ribbon = Me.ribbonControl
        '
        'SpreadsheetCommandBarButtonItem141
        '
        Me.SpreadsheetCommandBarButtonItem141.CommandName = "NewConditionalFormattingRule"
        Me.SpreadsheetCommandBarButtonItem141.Id = 328
        Me.SpreadsheetCommandBarButtonItem141.Name = "SpreadsheetCommandBarButtonItem141"
        '
        'SpreadsheetCommandBarSubItem29
        '
        Me.SpreadsheetCommandBarSubItem29.CommandName = "ConditionalFormattingRemoveCommandGroup"
        Me.SpreadsheetCommandBarSubItem29.Id = 331
        Me.SpreadsheetCommandBarSubItem29.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem142), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem143)})
        Me.SpreadsheetCommandBarSubItem29.Name = "SpreadsheetCommandBarSubItem29"
        '
        'SpreadsheetCommandBarButtonItem142
        '
        Me.SpreadsheetCommandBarButtonItem142.CommandName = "ConditionalFormattingRemoveFromSheet"
        Me.SpreadsheetCommandBarButtonItem142.Id = 329
        Me.SpreadsheetCommandBarButtonItem142.Name = "SpreadsheetCommandBarButtonItem142"
        '
        'SpreadsheetCommandBarButtonItem143
        '
        Me.SpreadsheetCommandBarButtonItem143.CommandName = "ConditionalFormattingRemove"
        Me.SpreadsheetCommandBarButtonItem143.Id = 330
        Me.SpreadsheetCommandBarButtonItem143.Name = "SpreadsheetCommandBarButtonItem143"
        '
        'SpreadsheetCommandBarButtonItem144
        '
        Me.SpreadsheetCommandBarButtonItem144.CommandName = "ConditionalFormattingRulesManager"
        Me.SpreadsheetCommandBarButtonItem144.Id = 332
        Me.SpreadsheetCommandBarButtonItem144.Name = "SpreadsheetCommandBarButtonItem144"
        '
        'GalleryFormatAsTableItem1
        '
        Me.GalleryFormatAsTableItem1.DropDownControl = Me.CommandBarGalleryDropDown24
        Me.GalleryFormatAsTableItem1.Id = 333
        Me.GalleryFormatAsTableItem1.Name = "GalleryFormatAsTableItem1"
        '
        'CommandBarGalleryDropDown24
        '
        '
        '
        '
        Me.CommandBarGalleryDropDown24.Gallery.AllowFilter = False
        Me.CommandBarGalleryDropDown24.Gallery.ColumnCount = 7
        Me.CommandBarGalleryDropDown24.Gallery.DrawImageBackground = False
        Me.CommandBarGalleryDropDown24.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
        Me.CommandBarGalleryDropDown24.Gallery.ItemSize = New System.Drawing.Size(73, 58)
        Me.CommandBarGalleryDropDown24.Gallery.RowCount = 10
        Me.CommandBarGalleryDropDown24.Name = "CommandBarGalleryDropDown24"
        Me.CommandBarGalleryDropDown24.Ribbon = Me.ribbonControl
        '
        'GalleryChangeStyleItem1
        '
        '
        '
        '
        Me.GalleryChangeStyleItem1.Gallery.DrawImageBackground = False
        Me.GalleryChangeStyleItem1.Gallery.ImageSize = New System.Drawing.Size(65, 46)
        Me.GalleryChangeStyleItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None
        Me.GalleryChangeStyleItem1.Gallery.ItemSize = New System.Drawing.Size(106, 28)
        Me.GalleryChangeStyleItem1.Gallery.RowCount = 9
        Me.GalleryChangeStyleItem1.Gallery.ShowItemText = True
        Me.GalleryChangeStyleItem1.Id = 334
        Me.GalleryChangeStyleItem1.Name = "GalleryChangeStyleItem1"
        '
        'SpreadsheetCommandBarSubItem31
        '
        Me.SpreadsheetCommandBarSubItem31.CommandName = "InsertCellsCommandGroup"
        Me.SpreadsheetCommandBarSubItem31.Id = 335
        Me.SpreadsheetCommandBarSubItem31.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem145), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem146), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem147), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem148), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem149), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem150), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem151)})
        Me.SpreadsheetCommandBarSubItem31.Name = "SpreadsheetCommandBarSubItem31"
        '
        'SpreadsheetCommandBarButtonItem145
        '
        Me.SpreadsheetCommandBarButtonItem145.CommandName = "InsertSheetRows"
        Me.SpreadsheetCommandBarButtonItem145.Id = 336
        Me.SpreadsheetCommandBarButtonItem145.Name = "SpreadsheetCommandBarButtonItem145"
        '
        'SpreadsheetCommandBarButtonItem146
        '
        Me.SpreadsheetCommandBarButtonItem146.CommandName = "InsertSheetColumns"
        Me.SpreadsheetCommandBarButtonItem146.Id = 337
        Me.SpreadsheetCommandBarButtonItem146.Name = "SpreadsheetCommandBarButtonItem146"
        '
        'SpreadsheetCommandBarButtonItem147
        '
        Me.SpreadsheetCommandBarButtonItem147.CommandName = "InsertTableRowsAbove"
        Me.SpreadsheetCommandBarButtonItem147.Id = 338
        Me.SpreadsheetCommandBarButtonItem147.Name = "SpreadsheetCommandBarButtonItem147"
        '
        'SpreadsheetCommandBarButtonItem148
        '
        Me.SpreadsheetCommandBarButtonItem148.CommandName = "InsertTableRowBelow"
        Me.SpreadsheetCommandBarButtonItem148.Id = 339
        Me.SpreadsheetCommandBarButtonItem148.Name = "SpreadsheetCommandBarButtonItem148"
        '
        'SpreadsheetCommandBarButtonItem149
        '
        Me.SpreadsheetCommandBarButtonItem149.CommandName = "InsertTableColumnsToTheLeft"
        Me.SpreadsheetCommandBarButtonItem149.Id = 340
        Me.SpreadsheetCommandBarButtonItem149.Name = "SpreadsheetCommandBarButtonItem149"
        '
        'SpreadsheetCommandBarButtonItem150
        '
        Me.SpreadsheetCommandBarButtonItem150.CommandName = "InsertTableColumnToTheRight"
        Me.SpreadsheetCommandBarButtonItem150.Id = 341
        Me.SpreadsheetCommandBarButtonItem150.Name = "SpreadsheetCommandBarButtonItem150"
        '
        'SpreadsheetCommandBarButtonItem151
        '
        Me.SpreadsheetCommandBarButtonItem151.CommandName = "InsertSheet"
        Me.SpreadsheetCommandBarButtonItem151.Id = 342
        Me.SpreadsheetCommandBarButtonItem151.Name = "SpreadsheetCommandBarButtonItem151"
        '
        'SpreadsheetCommandBarSubItem32
        '
        Me.SpreadsheetCommandBarSubItem32.CommandName = "RemoveCellsCommandGroup"
        Me.SpreadsheetCommandBarSubItem32.Id = 343
        Me.SpreadsheetCommandBarSubItem32.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem152), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem153), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem154), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem155), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem156)})
        Me.SpreadsheetCommandBarSubItem32.Name = "SpreadsheetCommandBarSubItem32"
        '
        'SpreadsheetCommandBarButtonItem152
        '
        Me.SpreadsheetCommandBarButtonItem152.CommandName = "RemoveSheetRows"
        Me.SpreadsheetCommandBarButtonItem152.Id = 344
        Me.SpreadsheetCommandBarButtonItem152.Name = "SpreadsheetCommandBarButtonItem152"
        '
        'SpreadsheetCommandBarButtonItem153
        '
        Me.SpreadsheetCommandBarButtonItem153.CommandName = "RemoveSheetColumns"
        Me.SpreadsheetCommandBarButtonItem153.Id = 345
        Me.SpreadsheetCommandBarButtonItem153.Name = "SpreadsheetCommandBarButtonItem153"
        '
        'SpreadsheetCommandBarButtonItem154
        '
        Me.SpreadsheetCommandBarButtonItem154.CommandName = "RemoveTableRows"
        Me.SpreadsheetCommandBarButtonItem154.Id = 346
        Me.SpreadsheetCommandBarButtonItem154.Name = "SpreadsheetCommandBarButtonItem154"
        '
        'SpreadsheetCommandBarButtonItem155
        '
        Me.SpreadsheetCommandBarButtonItem155.CommandName = "RemoveTableColumns"
        Me.SpreadsheetCommandBarButtonItem155.Id = 347
        Me.SpreadsheetCommandBarButtonItem155.Name = "SpreadsheetCommandBarButtonItem155"
        '
        'SpreadsheetCommandBarButtonItem156
        '
        Me.SpreadsheetCommandBarButtonItem156.CommandName = "RemoveSheet"
        Me.SpreadsheetCommandBarButtonItem156.Id = 348
        Me.SpreadsheetCommandBarButtonItem156.Name = "SpreadsheetCommandBarButtonItem156"
        '
        'SpreadsheetCommandBarSubItem34
        '
        Me.SpreadsheetCommandBarSubItem34.CommandName = "FormatCommandGroup"
        Me.SpreadsheetCommandBarSubItem34.Id = 349
        Me.SpreadsheetCommandBarSubItem34.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem157), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem158), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem159), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem160), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem161), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarSubItem33), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem168), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem169), New DevExpress.XtraBars.LinkPersistInfo(Me.ChangeSheetTabColorItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem55), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem40), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem170)})
        Me.SpreadsheetCommandBarSubItem34.Name = "SpreadsheetCommandBarSubItem34"
        '
        'SpreadsheetCommandBarButtonItem157
        '
        Me.SpreadsheetCommandBarButtonItem157.CommandName = "FormatRowHeight"
        Me.SpreadsheetCommandBarButtonItem157.Id = 350
        Me.SpreadsheetCommandBarButtonItem157.Name = "SpreadsheetCommandBarButtonItem157"
        '
        'SpreadsheetCommandBarButtonItem158
        '
        Me.SpreadsheetCommandBarButtonItem158.CommandName = "FormatAutoFitRowHeight"
        Me.SpreadsheetCommandBarButtonItem158.Id = 351
        Me.SpreadsheetCommandBarButtonItem158.Name = "SpreadsheetCommandBarButtonItem158"
        '
        'SpreadsheetCommandBarButtonItem159
        '
        Me.SpreadsheetCommandBarButtonItem159.CommandName = "FormatColumnWidth"
        Me.SpreadsheetCommandBarButtonItem159.Id = 352
        Me.SpreadsheetCommandBarButtonItem159.Name = "SpreadsheetCommandBarButtonItem159"
        '
        'SpreadsheetCommandBarButtonItem160
        '
        Me.SpreadsheetCommandBarButtonItem160.CommandName = "FormatAutoFitColumnWidth"
        Me.SpreadsheetCommandBarButtonItem160.Id = 353
        Me.SpreadsheetCommandBarButtonItem160.Name = "SpreadsheetCommandBarButtonItem160"
        '
        'SpreadsheetCommandBarButtonItem161
        '
        Me.SpreadsheetCommandBarButtonItem161.CommandName = "FormatDefaultColumnWidth"
        Me.SpreadsheetCommandBarButtonItem161.Id = 354
        Me.SpreadsheetCommandBarButtonItem161.Name = "SpreadsheetCommandBarButtonItem161"
        '
        'SpreadsheetCommandBarSubItem33
        '
        Me.SpreadsheetCommandBarSubItem33.CommandName = "HideAndUnhideCommandGroup"
        Me.SpreadsheetCommandBarSubItem33.Id = 361
        Me.SpreadsheetCommandBarSubItem33.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem162), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem163), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem164), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem165), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem166), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem167)})
        Me.SpreadsheetCommandBarSubItem33.Name = "SpreadsheetCommandBarSubItem33"
        '
        'SpreadsheetCommandBarButtonItem162
        '
        Me.SpreadsheetCommandBarButtonItem162.CommandName = "HideRows"
        Me.SpreadsheetCommandBarButtonItem162.Id = 355
        Me.SpreadsheetCommandBarButtonItem162.Name = "SpreadsheetCommandBarButtonItem162"
        '
        'SpreadsheetCommandBarButtonItem163
        '
        Me.SpreadsheetCommandBarButtonItem163.CommandName = "HideColumns"
        Me.SpreadsheetCommandBarButtonItem163.Id = 356
        Me.SpreadsheetCommandBarButtonItem163.Name = "SpreadsheetCommandBarButtonItem163"
        '
        'SpreadsheetCommandBarButtonItem164
        '
        Me.SpreadsheetCommandBarButtonItem164.CommandName = "HideSheet"
        Me.SpreadsheetCommandBarButtonItem164.Id = 357
        Me.SpreadsheetCommandBarButtonItem164.Name = "SpreadsheetCommandBarButtonItem164"
        '
        'SpreadsheetCommandBarButtonItem165
        '
        Me.SpreadsheetCommandBarButtonItem165.CommandName = "UnhideRows"
        Me.SpreadsheetCommandBarButtonItem165.Id = 358
        Me.SpreadsheetCommandBarButtonItem165.Name = "SpreadsheetCommandBarButtonItem165"
        '
        'SpreadsheetCommandBarButtonItem166
        '
        Me.SpreadsheetCommandBarButtonItem166.CommandName = "UnhideColumns"
        Me.SpreadsheetCommandBarButtonItem166.Id = 359
        Me.SpreadsheetCommandBarButtonItem166.Name = "SpreadsheetCommandBarButtonItem166"
        '
        'SpreadsheetCommandBarButtonItem167
        '
        Me.SpreadsheetCommandBarButtonItem167.CommandName = "UnhideSheet"
        Me.SpreadsheetCommandBarButtonItem167.Id = 360
        Me.SpreadsheetCommandBarButtonItem167.Name = "SpreadsheetCommandBarButtonItem167"
        '
        'SpreadsheetCommandBarButtonItem168
        '
        Me.SpreadsheetCommandBarButtonItem168.CommandName = "RenameSheet"
        Me.SpreadsheetCommandBarButtonItem168.Id = 362
        Me.SpreadsheetCommandBarButtonItem168.Name = "SpreadsheetCommandBarButtonItem168"
        '
        'SpreadsheetCommandBarButtonItem169
        '
        Me.SpreadsheetCommandBarButtonItem169.CommandName = "MoveOrCopySheet"
        Me.SpreadsheetCommandBarButtonItem169.Id = 363
        Me.SpreadsheetCommandBarButtonItem169.Name = "SpreadsheetCommandBarButtonItem169"
        '
        'ChangeSheetTabColorItem1
        '
        Me.ChangeSheetTabColorItem1.ActAsDropDown = True
        Me.ChangeSheetTabColorItem1.Id = 364
        Me.ChangeSheetTabColorItem1.Name = "ChangeSheetTabColorItem1"
        '
        'SpreadsheetCommandBarCheckItem40
        '
        Me.SpreadsheetCommandBarCheckItem40.CommandName = "FormatCellLocked"
        Me.SpreadsheetCommandBarCheckItem40.Id = 365
        Me.SpreadsheetCommandBarCheckItem40.Name = "SpreadsheetCommandBarCheckItem40"
        '
        'SpreadsheetCommandBarButtonItem170
        '
        Me.SpreadsheetCommandBarButtonItem170.CommandName = "FormatCellsContextMenuItem"
        Me.SpreadsheetCommandBarButtonItem170.Id = 366
        Me.SpreadsheetCommandBarButtonItem170.Name = "SpreadsheetCommandBarButtonItem170"
        '
        'SpreadsheetCommandBarSubItem35
        '
        Me.SpreadsheetCommandBarSubItem35.CommandName = "EditingAutoSumCommandGroup"
        Me.SpreadsheetCommandBarSubItem35.Id = 367
        Me.SpreadsheetCommandBarSubItem35.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem74), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem75), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem76), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem77), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem78)})
        Me.SpreadsheetCommandBarSubItem35.Name = "SpreadsheetCommandBarSubItem35"
        Me.SpreadsheetCommandBarSubItem35.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarSubItem36
        '
        Me.SpreadsheetCommandBarSubItem36.CommandName = "EditingFillCommandGroup"
        Me.SpreadsheetCommandBarSubItem36.Id = 368
        Me.SpreadsheetCommandBarSubItem36.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem171), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem172), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem173), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem174)})
        Me.SpreadsheetCommandBarSubItem36.Name = "SpreadsheetCommandBarSubItem36"
        Me.SpreadsheetCommandBarSubItem36.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem171
        '
        Me.SpreadsheetCommandBarButtonItem171.CommandName = "EditingFillDown"
        Me.SpreadsheetCommandBarButtonItem171.Id = 369
        Me.SpreadsheetCommandBarButtonItem171.Name = "SpreadsheetCommandBarButtonItem171"
        '
        'SpreadsheetCommandBarButtonItem172
        '
        Me.SpreadsheetCommandBarButtonItem172.CommandName = "EditingFillRight"
        Me.SpreadsheetCommandBarButtonItem172.Id = 370
        Me.SpreadsheetCommandBarButtonItem172.Name = "SpreadsheetCommandBarButtonItem172"
        '
        'SpreadsheetCommandBarButtonItem173
        '
        Me.SpreadsheetCommandBarButtonItem173.CommandName = "EditingFillUp"
        Me.SpreadsheetCommandBarButtonItem173.Id = 371
        Me.SpreadsheetCommandBarButtonItem173.Name = "SpreadsheetCommandBarButtonItem173"
        '
        'SpreadsheetCommandBarButtonItem174
        '
        Me.SpreadsheetCommandBarButtonItem174.CommandName = "EditingFillLeft"
        Me.SpreadsheetCommandBarButtonItem174.Id = 372
        Me.SpreadsheetCommandBarButtonItem174.Name = "SpreadsheetCommandBarButtonItem174"
        '
        'SpreadsheetCommandBarSubItem37
        '
        Me.SpreadsheetCommandBarSubItem37.CommandName = "FormatClearCommandGroup"
        Me.SpreadsheetCommandBarSubItem37.Id = 373
        Me.SpreadsheetCommandBarSubItem37.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem175), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem176), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem177), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem178), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem179), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem180)})
        Me.SpreadsheetCommandBarSubItem37.Name = "SpreadsheetCommandBarSubItem37"
        Me.SpreadsheetCommandBarSubItem37.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        '
        'SpreadsheetCommandBarButtonItem175
        '
        Me.SpreadsheetCommandBarButtonItem175.CommandName = "FormatClearAll"
        Me.SpreadsheetCommandBarButtonItem175.Id = 374
        Me.SpreadsheetCommandBarButtonItem175.Name = "SpreadsheetCommandBarButtonItem175"
        '
        'SpreadsheetCommandBarButtonItem176
        '
        Me.SpreadsheetCommandBarButtonItem176.CommandName = "FormatClearFormats"
        Me.SpreadsheetCommandBarButtonItem176.Id = 375
        Me.SpreadsheetCommandBarButtonItem176.Name = "SpreadsheetCommandBarButtonItem176"
        '
        'SpreadsheetCommandBarButtonItem177
        '
        Me.SpreadsheetCommandBarButtonItem177.CommandName = "FormatClearContents"
        Me.SpreadsheetCommandBarButtonItem177.Id = 376
        Me.SpreadsheetCommandBarButtonItem177.Name = "SpreadsheetCommandBarButtonItem177"
        '
        'SpreadsheetCommandBarButtonItem178
        '
        Me.SpreadsheetCommandBarButtonItem178.CommandName = "FormatClearComments"
        Me.SpreadsheetCommandBarButtonItem178.Id = 377
        Me.SpreadsheetCommandBarButtonItem178.Name = "SpreadsheetCommandBarButtonItem178"
        '
        'SpreadsheetCommandBarButtonItem179
        '
        Me.SpreadsheetCommandBarButtonItem179.CommandName = "FormatClearHyperlinks"
        Me.SpreadsheetCommandBarButtonItem179.Id = 378
        Me.SpreadsheetCommandBarButtonItem179.Name = "SpreadsheetCommandBarButtonItem179"
        '
        'SpreadsheetCommandBarButtonItem180
        '
        Me.SpreadsheetCommandBarButtonItem180.CommandName = "FormatRemoveHyperlinks"
        Me.SpreadsheetCommandBarButtonItem180.Id = 379
        Me.SpreadsheetCommandBarButtonItem180.Name = "SpreadsheetCommandBarButtonItem180"
        '
        'SpreadsheetCommandBarSubItem38
        '
        Me.SpreadsheetCommandBarSubItem38.CommandName = "EditingSortAndFilterCommandGroup"
        Me.SpreadsheetCommandBarSubItem38.Id = 380
        Me.SpreadsheetCommandBarSubItem38.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem60), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem61), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarCheckItem17), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem62), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem63)})
        Me.SpreadsheetCommandBarSubItem38.Name = "SpreadsheetCommandBarSubItem38"
        '
        'SpreadsheetCommandBarSubItem39
        '
        Me.SpreadsheetCommandBarSubItem39.CommandName = "EditingFindAndSelectCommandGroup"
        Me.SpreadsheetCommandBarSubItem39.Id = 381
        Me.SpreadsheetCommandBarSubItem39.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem181), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem182), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem183), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem184), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem185), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem186), New DevExpress.XtraBars.LinkPersistInfo(Me.SpreadsheetCommandBarButtonItem187)})
        Me.SpreadsheetCommandBarSubItem39.Name = "SpreadsheetCommandBarSubItem39"
        '
        'SpreadsheetCommandBarButtonItem181
        '
        Me.SpreadsheetCommandBarButtonItem181.CommandName = "EditingFind"
        Me.SpreadsheetCommandBarButtonItem181.Id = 382
        Me.SpreadsheetCommandBarButtonItem181.Name = "SpreadsheetCommandBarButtonItem181"
        '
        'SpreadsheetCommandBarButtonItem182
        '
        Me.SpreadsheetCommandBarButtonItem182.CommandName = "EditingReplace"
        Me.SpreadsheetCommandBarButtonItem182.Id = 383
        Me.SpreadsheetCommandBarButtonItem182.Name = "SpreadsheetCommandBarButtonItem182"
        '
        'SpreadsheetCommandBarButtonItem183
        '
        Me.SpreadsheetCommandBarButtonItem183.CommandName = "EditingSelectFormulas"
        Me.SpreadsheetCommandBarButtonItem183.Id = 384
        Me.SpreadsheetCommandBarButtonItem183.Name = "SpreadsheetCommandBarButtonItem183"
        '
        'SpreadsheetCommandBarButtonItem184
        '
        Me.SpreadsheetCommandBarButtonItem184.CommandName = "EditingSelectComments"
        Me.SpreadsheetCommandBarButtonItem184.Id = 385
        Me.SpreadsheetCommandBarButtonItem184.Name = "SpreadsheetCommandBarButtonItem184"
        '
        'SpreadsheetCommandBarButtonItem185
        '
        Me.SpreadsheetCommandBarButtonItem185.CommandName = "EditingSelectConditionalFormatting"
        Me.SpreadsheetCommandBarButtonItem185.Id = 386
        Me.SpreadsheetCommandBarButtonItem185.Name = "SpreadsheetCommandBarButtonItem185"
        '
        'SpreadsheetCommandBarButtonItem186
        '
        Me.SpreadsheetCommandBarButtonItem186.CommandName = "EditingSelectConstants"
        Me.SpreadsheetCommandBarButtonItem186.Id = 387
        Me.SpreadsheetCommandBarButtonItem186.Name = "SpreadsheetCommandBarButtonItem186"
        '
        'SpreadsheetCommandBarButtonItem187
        '
        Me.SpreadsheetCommandBarButtonItem187.CommandName = "EditingSelectDataValidation"
        Me.SpreadsheetCommandBarButtonItem187.Id = 388
        Me.SpreadsheetCommandBarButtonItem187.Name = "SpreadsheetCommandBarButtonItem187"
        '
        'SpreadsheetCommandBarButtonItem188
        '
        Me.SpreadsheetCommandBarButtonItem188.CommandName = "FileNew"
        Me.SpreadsheetCommandBarButtonItem188.Id = 389
        Me.SpreadsheetCommandBarButtonItem188.Name = "SpreadsheetCommandBarButtonItem188"
        '
        'SpreadsheetCommandBarButtonItem189
        '
        Me.SpreadsheetCommandBarButtonItem189.CommandName = "FileOpen"
        Me.SpreadsheetCommandBarButtonItem189.Id = 390
        Me.SpreadsheetCommandBarButtonItem189.Name = "SpreadsheetCommandBarButtonItem189"
        '
        'SpreadsheetCommandBarButtonItem190
        '
        Me.SpreadsheetCommandBarButtonItem190.CommandName = "FileSave"
        Me.SpreadsheetCommandBarButtonItem190.Id = 391
        Me.SpreadsheetCommandBarButtonItem190.Name = "SpreadsheetCommandBarButtonItem190"
        '
        'SpreadsheetCommandBarButtonItem191
        '
        Me.SpreadsheetCommandBarButtonItem191.CommandName = "FileSaveAs"
        Me.SpreadsheetCommandBarButtonItem191.Id = 392
        Me.SpreadsheetCommandBarButtonItem191.Name = "SpreadsheetCommandBarButtonItem191"
        '
        'SpreadsheetCommandBarButtonItem192
        '
        Me.SpreadsheetCommandBarButtonItem192.CommandName = "FileQuickPrint"
        Me.SpreadsheetCommandBarButtonItem192.Id = 393
        Me.SpreadsheetCommandBarButtonItem192.Name = "SpreadsheetCommandBarButtonItem192"
        '
        'SpreadsheetCommandBarButtonItem193
        '
        Me.SpreadsheetCommandBarButtonItem193.CommandName = "FilePrint"
        Me.SpreadsheetCommandBarButtonItem193.Id = 394
        Me.SpreadsheetCommandBarButtonItem193.Name = "SpreadsheetCommandBarButtonItem193"
        '
        'SpreadsheetCommandBarButtonItem194
        '
        Me.SpreadsheetCommandBarButtonItem194.CommandName = "FilePrintPreview"
        Me.SpreadsheetCommandBarButtonItem194.Id = 395
        Me.SpreadsheetCommandBarButtonItem194.Name = "SpreadsheetCommandBarButtonItem194"
        '
        'SpreadsheetCommandBarButtonItem195
        '
        Me.SpreadsheetCommandBarButtonItem195.CommandName = "FileUndo"
        Me.SpreadsheetCommandBarButtonItem195.Id = 396
        Me.SpreadsheetCommandBarButtonItem195.Name = "SpreadsheetCommandBarButtonItem195"
        '
        'SpreadsheetCommandBarButtonItem196
        '
        Me.SpreadsheetCommandBarButtonItem196.CommandName = "FileRedo"
        Me.SpreadsheetCommandBarButtonItem196.Id = 397
        Me.SpreadsheetCommandBarButtonItem196.Name = "SpreadsheetCommandBarButtonItem196"
        '
        'SpreadsheetCommandBarButtonItem197
        '
        Me.SpreadsheetCommandBarButtonItem197.CommandName = "FileEncrypt"
        Me.SpreadsheetCommandBarButtonItem197.Id = 398
        Me.SpreadsheetCommandBarButtonItem197.Name = "SpreadsheetCommandBarButtonItem197"
        '
        'SpreadsheetCommandBarButtonItem198
        '
        Me.SpreadsheetCommandBarButtonItem198.CommandName = "FileShowDocumentProperties"
        Me.SpreadsheetCommandBarButtonItem198.Id = 399
        Me.SpreadsheetCommandBarButtonItem198.Name = "SpreadsheetCommandBarButtonItem198"
        '
        'ribbonImageCollectionLarge
        '
        Me.ribbonImageCollectionLarge.ImageSize = New System.Drawing.Size(32, 32)
        Me.ribbonImageCollectionLarge.ImageStream = CType(resources.GetObject("ribbonImageCollectionLarge.ImageStream"), DevExpress.Utils.ImageCollectionStreamer)
        Me.ribbonImageCollectionLarge.Images.SetKeyName(0, "Ribbon_New_32x32.png")
        Me.ribbonImageCollectionLarge.Images.SetKeyName(1, "Ribbon_Open_32x32.png")
        Me.ribbonImageCollectionLarge.Images.SetKeyName(2, "Ribbon_Close_32x32.png")
        Me.ribbonImageCollectionLarge.Images.SetKeyName(3, "Ribbon_Find_32x32.png")
        Me.ribbonImageCollectionLarge.Images.SetKeyName(4, "Ribbon_Save_32x32.png")
        Me.ribbonImageCollectionLarge.Images.SetKeyName(5, "Ribbon_SaveAs_32x32.png")
        Me.ribbonImageCollectionLarge.Images.SetKeyName(6, "Ribbon_Exit_32x32.png")
        Me.ribbonImageCollectionLarge.Images.SetKeyName(7, "Ribbon_Content_32x32.png")
        Me.ribbonImageCollectionLarge.Images.SetKeyName(8, "Ribbon_Info_32x32.png")
        '
        'PivotTableToolsRibbonPageCategory1
        '
        Me.PivotTableToolsRibbonPageCategory1.Control = Me.spreadsheetControl
        Me.PivotTableToolsRibbonPageCategory1.Name = "PivotTableToolsRibbonPageCategory1"
        Me.PivotTableToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.PivotTableAnalyzeRibbonPage1, Me.PivotTableDesignRibbonPage1})
        Me.PivotTableToolsRibbonPageCategory1.Visible = False
        '
        'PivotTableAnalyzeRibbonPage1
        '
        Me.PivotTableAnalyzeRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.PivotTableAnalyzePivotTableRibbonPageGroup1, Me.PivotTableAnalyzeActiveFieldRibbonPageGroup1, Me.PivotTableAnalyzeGroupRibbonPageGroup1, Me.PivotTableAnalyzeDataRibbonPageGroup1, Me.PivotTableAnalyzeActionsRibbonPageGroup1, Me.PivotTableAnalyzeCalculationsRibbonPageGroup1, Me.PivotTableAnalyzeShowRibbonPageGroup1})
        Me.PivotTableAnalyzeRibbonPage1.Name = "PivotTableAnalyzeRibbonPage1"
        Me.PivotTableAnalyzeRibbonPage1.Visible = False
        '
        'PivotTableAnalyzePivotTableRibbonPageGroup1
        '
        Me.PivotTableAnalyzePivotTableRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem15)
        Me.PivotTableAnalyzePivotTableRibbonPageGroup1.Name = "PivotTableAnalyzePivotTableRibbonPageGroup1"
        '
        'PivotTableAnalyzeActiveFieldRibbonPageGroup1
        '
        Me.PivotTableAnalyzeActiveFieldRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem16)
        Me.PivotTableAnalyzeActiveFieldRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem17)
        Me.PivotTableAnalyzeActiveFieldRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem18)
        Me.PivotTableAnalyzeActiveFieldRibbonPageGroup1.Name = "PivotTableAnalyzeActiveFieldRibbonPageGroup1"
        '
        'PivotTableAnalyzeGroupRibbonPageGroup1
        '
        Me.PivotTableAnalyzeGroupRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem19)
        Me.PivotTableAnalyzeGroupRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem20)
        Me.PivotTableAnalyzeGroupRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem21)
        Me.PivotTableAnalyzeGroupRibbonPageGroup1.Name = "PivotTableAnalyzeGroupRibbonPageGroup1"
        '
        'PivotTableAnalyzeDataRibbonPageGroup1
        '
        Me.PivotTableAnalyzeDataRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem5)
        Me.PivotTableAnalyzeDataRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem24)
        Me.PivotTableAnalyzeDataRibbonPageGroup1.Name = "PivotTableAnalyzeDataRibbonPageGroup1"
        '
        'PivotTableAnalyzeActionsRibbonPageGroup1
        '
        Me.PivotTableAnalyzeActionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem6)
        Me.PivotTableAnalyzeActionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem7)
        Me.PivotTableAnalyzeActionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem30)
        Me.PivotTableAnalyzeActionsRibbonPageGroup1.Name = "PivotTableAnalyzeActionsRibbonPageGroup1"
        '
        'PivotTableAnalyzeCalculationsRibbonPageGroup1
        '
        Me.PivotTableAnalyzeCalculationsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem8)
        Me.PivotTableAnalyzeCalculationsRibbonPageGroup1.Name = "PivotTableAnalyzeCalculationsRibbonPageGroup1"
        '
        'PivotTableAnalyzeShowRibbonPageGroup1
        '
        Me.PivotTableAnalyzeShowRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem5)
        Me.PivotTableAnalyzeShowRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem6)
        Me.PivotTableAnalyzeShowRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem7)
        Me.PivotTableAnalyzeShowRibbonPageGroup1.Name = "PivotTableAnalyzeShowRibbonPageGroup1"
        '
        'PivotTableDesignRibbonPage1
        '
        Me.PivotTableDesignRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.PivotTableDesignLayoutRibbonPageGroup1, Me.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1, Me.PivotTableDesignPivotTableStylesRibbonPageGroup1})
        Me.PivotTableDesignRibbonPage1.Name = "PivotTableDesignRibbonPage1"
        Me.PivotTableDesignRibbonPage1.Visible = False
        '
        'PivotTableDesignLayoutRibbonPageGroup1
        '
        Me.PivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem1)
        Me.PivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem2)
        Me.PivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem3)
        Me.PivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem4)
        Me.PivotTableDesignLayoutRibbonPageGroup1.Name = "PivotTableDesignLayoutRibbonPageGroup1"
        '
        'PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1
        '
        Me.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem1)
        Me.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem2)
        Me.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem3)
        Me.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem4)
        Me.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.TwoRows
        Me.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.Name = "PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1"
        '
        'PivotTableDesignPivotTableStylesRibbonPageGroup1
        '
        Me.PivotTableDesignPivotTableStylesRibbonPageGroup1.ItemLinks.Add(Me.GalleryPivotStylesItem1)
        Me.PivotTableDesignPivotTableStylesRibbonPageGroup1.Name = "PivotTableDesignPivotTableStylesRibbonPageGroup1"
        '
        'PictureToolsRibbonPageCategory1
        '
        Me.PictureToolsRibbonPageCategory1.Control = Me.spreadsheetControl
        Me.PictureToolsRibbonPageCategory1.Name = "PictureToolsRibbonPageCategory1"
        Me.PictureToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.PictureFormatRibbonPage1})
        Me.PictureToolsRibbonPageCategory1.Visible = False
        '
        'PictureFormatRibbonPage1
        '
        Me.PictureFormatRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.PictureFormatArrangeRibbonPageGroup1})
        Me.PictureFormatRibbonPage1.Name = "PictureFormatRibbonPage1"
        Me.PictureFormatRibbonPage1.Visible = False
        '
        'PictureFormatArrangeRibbonPageGroup1
        '
        Me.PictureFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem9)
        Me.PictureFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem10)
        Me.PictureFormatArrangeRibbonPageGroup1.Name = "PictureFormatArrangeRibbonPageGroup1"
        '
        'DrawingToolsRibbonPageCategory1
        '
        Me.DrawingToolsRibbonPageCategory1.Control = Me.spreadsheetControl
        Me.DrawingToolsRibbonPageCategory1.Name = "DrawingToolsRibbonPageCategory1"
        Me.DrawingToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.DrawingFormatRibbonPage1})
        Me.DrawingToolsRibbonPageCategory1.Visible = False
        '
        'DrawingFormatRibbonPage1
        '
        Me.DrawingFormatRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.DrawingFormatArrangeRibbonPageGroup1})
        Me.DrawingFormatRibbonPage1.Name = "DrawingFormatRibbonPage1"
        Me.DrawingFormatRibbonPage1.Visible = False
        '
        'DrawingFormatArrangeRibbonPageGroup1
        '
        Me.DrawingFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem9)
        Me.DrawingFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem10)
        Me.DrawingFormatArrangeRibbonPageGroup1.Name = "DrawingFormatArrangeRibbonPageGroup1"
        '
        'TableToolsRibbonPageCategory1
        '
        Me.TableToolsRibbonPageCategory1.Control = Me.spreadsheetControl
        Me.TableToolsRibbonPageCategory1.Name = "TableToolsRibbonPageCategory1"
        Me.TableToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.TableToolsDesignRibbonPage1})
        Me.TableToolsRibbonPageCategory1.Visible = False
        '
        'TableToolsDesignRibbonPage1
        '
        Me.TableToolsDesignRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.TablePropertiesRibbonPageGroup1, Me.TableToolsRibbonPageGroup1, Me.TableStyleOptionsRibbonPageGroup1, Me.TableStylesRibbonPageGroup1})
        Me.TableToolsDesignRibbonPage1.Name = "TableToolsDesignRibbonPage1"
        Me.TableToolsDesignRibbonPage1.Visible = False
        '
        'TablePropertiesRibbonPageGroup1
        '
        Me.TablePropertiesRibbonPageGroup1.ItemLinks.Add(Me.RenameTableItemCaption1)
        Me.TablePropertiesRibbonPageGroup1.ItemLinks.Add(Me.RenameTableItem1)
        Me.TablePropertiesRibbonPageGroup1.Name = "TablePropertiesRibbonPageGroup1"
        '
        'TableToolsRibbonPageGroup1
        '
        Me.TableToolsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem8)
        Me.TableToolsRibbonPageGroup1.Name = "TableToolsRibbonPageGroup1"
        '
        'TableStyleOptionsRibbonPageGroup1
        '
        Me.TableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem9)
        Me.TableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem10)
        Me.TableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem11)
        Me.TableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem12)
        Me.TableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem13)
        Me.TableStyleOptionsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem14)
        Me.TableStyleOptionsRibbonPageGroup1.Name = "TableStyleOptionsRibbonPageGroup1"
        '
        'TableStylesRibbonPageGroup1
        '
        Me.TableStylesRibbonPageGroup1.ItemLinks.Add(Me.GalleryTableStylesItem1)
        Me.TableStylesRibbonPageGroup1.Name = "TableStylesRibbonPageGroup1"
        '
        'ChartToolsRibbonPageCategory1
        '
        Me.ChartToolsRibbonPageCategory1.Control = Me.spreadsheetControl
        Me.ChartToolsRibbonPageCategory1.Name = "ChartToolsRibbonPageCategory1"
        Me.ChartToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.ChartsDesignRibbonPage1, Me.ChartsLayoutRibbonPage1, Me.ChartsFormatRibbonPage1})
        Me.ChartToolsRibbonPageCategory1.Visible = False
        '
        'ChartsDesignRibbonPage1
        '
        Me.ChartsDesignRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.ChartsDesignTypeRibbonPageGroup1, Me.ChartsDesignDataRibbonPageGroup1, Me.ChartsDesignLayoutsRibbonPageGroup1, Me.ChartsDesignStylesRibbonPageGroup1, Me.ChartsDesignLocationRibbonPageGroup1})
        Me.ChartsDesignRibbonPage1.Name = "ChartsDesignRibbonPage1"
        Me.ChartsDesignRibbonPage1.Visible = False
        '
        'ChartsDesignTypeRibbonPageGroup1
        '
        Me.ChartsDesignTypeRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem39)
        Me.ChartsDesignTypeRibbonPageGroup1.Name = "ChartsDesignTypeRibbonPageGroup1"
        '
        'ChartsDesignDataRibbonPageGroup1
        '
        Me.ChartsDesignDataRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem40)
        Me.ChartsDesignDataRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem41)
        Me.ChartsDesignDataRibbonPageGroup1.Name = "ChartsDesignDataRibbonPageGroup1"
        '
        'ChartsDesignLayoutsRibbonPageGroup1
        '
        Me.ChartsDesignLayoutsRibbonPageGroup1.ItemLinks.Add(Me.GalleryChartLayoutItem1)
        Me.ChartsDesignLayoutsRibbonPageGroup1.Name = "ChartsDesignLayoutsRibbonPageGroup1"
        '
        'ChartsDesignStylesRibbonPageGroup1
        '
        Me.ChartsDesignStylesRibbonPageGroup1.ItemLinks.Add(Me.GalleryChartStyleItem1)
        Me.ChartsDesignStylesRibbonPageGroup1.Name = "ChartsDesignStylesRibbonPageGroup1"
        '
        'ChartsDesignLocationRibbonPageGroup1
        '
        Me.ChartsDesignLocationRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem42)
        Me.ChartsDesignLocationRibbonPageGroup1.Name = "ChartsDesignLocationRibbonPageGroup1"
        '
        'ChartsLayoutRibbonPage1
        '
        Me.ChartsLayoutRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.ChartsLayoutAxesRibbonPageGroup1, Me.ChartsLayoutLabelsRibbonPageGroup1, Me.ChartsLayoutAnalysisRibbonPageGroup1})
        Me.ChartsLayoutRibbonPage1.Name = "ChartsLayoutRibbonPage1"
        Me.ChartsLayoutRibbonPage1.Visible = False
        '
        'ChartsLayoutAxesRibbonPageGroup1
        '
        Me.ChartsLayoutAxesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem11)
        Me.ChartsLayoutAxesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem12)
        Me.ChartsLayoutAxesRibbonPageGroup1.Name = "ChartsLayoutAxesRibbonPageGroup1"
        '
        'ChartsLayoutLabelsRibbonPageGroup1
        '
        Me.ChartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem5)
        Me.ChartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem13)
        Me.ChartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem8)
        Me.ChartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem9)
        Me.ChartsLayoutLabelsRibbonPageGroup1.Name = "ChartsLayoutLabelsRibbonPageGroup1"
        '
        'ChartsLayoutAnalysisRibbonPageGroup1
        '
        Me.ChartsLayoutAnalysisRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem10)
        Me.ChartsLayoutAnalysisRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem11)
        Me.ChartsLayoutAnalysisRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem12)
        Me.ChartsLayoutAnalysisRibbonPageGroup1.Name = "ChartsLayoutAnalysisRibbonPageGroup1"
        '
        'ChartsFormatRibbonPage1
        '
        Me.ChartsFormatRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.ChartsFormatArrangeRibbonPageGroup1})
        Me.ChartsFormatRibbonPage1.Name = "ChartsFormatRibbonPage1"
        Me.ChartsFormatRibbonPage1.Visible = False
        '
        'ChartsFormatArrangeRibbonPageGroup1
        '
        Me.ChartsFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem9)
        Me.ChartsFormatArrangeRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem10)
        Me.ChartsFormatArrangeRibbonPageGroup1.Name = "ChartsFormatArrangeRibbonPageGroup1"
        '
        'FileRibbonPage1
        '
        Me.FileRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.CommonRibbonPageGroup1, Me.InfoRibbonPageGroup1})
        Me.FileRibbonPage1.Name = "FileRibbonPage1"
        '
        'CommonRibbonPageGroup1
        '
        Me.CommonRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem188)
        Me.CommonRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem189)
        Me.CommonRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem190)
        Me.CommonRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem191)
        Me.CommonRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem192)
        Me.CommonRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem193)
        Me.CommonRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem194)
        Me.CommonRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem195)
        Me.CommonRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem196)
        Me.CommonRibbonPageGroup1.Name = "CommonRibbonPageGroup1"
        '
        'InfoRibbonPageGroup1
        '
        Me.InfoRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem197)
        Me.InfoRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem198)
        Me.InfoRibbonPageGroup1.Name = "InfoRibbonPageGroup1"
        '
        'HomeRibbonPage1
        '
        Me.HomeRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.ClipboardRibbonPageGroup1, Me.FontRibbonPageGroup1, Me.AlignmentRibbonPageGroup1, Me.NumberRibbonPageGroup1, Me.StylesRibbonPageGroup1, Me.CellsRibbonPageGroup1, Me.EditingRibbonPageGroup1})
        Me.HomeRibbonPage1.Name = "HomeRibbonPage1"
        ReduceOperation1.Behavior = DevExpress.XtraBars.Ribbon.ReduceOperationBehavior.UntilAvailable
        ReduceOperation1.GroupName = "StylesRibbonPageGroup1"
        ReduceOperation1.ItemLinkIndex = 2
        ReduceOperation1.ItemLinksCount = 0
        ReduceOperation1.Operation = DevExpress.XtraBars.Ribbon.ReduceOperationType.Gallery
        Me.HomeRibbonPage1.ReduceOperations.Add(ReduceOperation1)
        '
        'ClipboardRibbonPageGroup1
        '
        Me.ClipboardRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem94)
        Me.ClipboardRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem95)
        Me.ClipboardRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem96)
        Me.ClipboardRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem97)
        Me.ClipboardRibbonPageGroup1.Name = "ClipboardRibbonPageGroup1"
        '
        'FontRibbonPageGroup1
        '
        Me.FontRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup1)
        Me.FontRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup2)
        Me.FontRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup3)
        Me.FontRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup4)
        Me.FontRibbonPageGroup1.Name = "FontRibbonPageGroup1"
        '
        'AlignmentRibbonPageGroup1
        '
        Me.AlignmentRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup5)
        Me.AlignmentRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup6)
        Me.AlignmentRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup7)
        Me.AlignmentRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem38)
        Me.AlignmentRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem25)
        Me.AlignmentRibbonPageGroup1.Name = "AlignmentRibbonPageGroup1"
        '
        'NumberRibbonPageGroup1
        '
        Me.NumberRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup8)
        Me.NumberRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup9)
        Me.NumberRibbonPageGroup1.ItemLinks.Add(Me.BarButtonGroup10)
        Me.NumberRibbonPageGroup1.Name = "NumberRibbonPageGroup1"
        '
        'StylesRibbonPageGroup1
        '
        Me.StylesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem30)
        Me.StylesRibbonPageGroup1.ItemLinks.Add(Me.GalleryFormatAsTableItem1)
        Me.StylesRibbonPageGroup1.ItemLinks.Add(Me.GalleryChangeStyleItem1)
        Me.StylesRibbonPageGroup1.Name = "StylesRibbonPageGroup1"
        '
        'CellsRibbonPageGroup1
        '
        Me.CellsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem31)
        Me.CellsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem32)
        Me.CellsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem34)
        Me.CellsRibbonPageGroup1.Name = "CellsRibbonPageGroup1"
        '
        'EditingRibbonPageGroup1
        '
        Me.EditingRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem35)
        Me.EditingRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem36)
        Me.EditingRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem37)
        Me.EditingRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem38)
        Me.EditingRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem39)
        Me.EditingRibbonPageGroup1.Name = "EditingRibbonPageGroup1"
        '
        'InsertRibbonPage1
        '
        Me.InsertRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.TablesRibbonPageGroup1, Me.IllustrationsRibbonPageGroup1, Me.ChartsRibbonPageGroup1, Me.LinksRibbonPageGroup1, Me.SymbolsRibbonPageGroup1})
        Me.InsertRibbonPage1.Name = "InsertRibbonPage1"
        '
        'TablesRibbonPageGroup1
        '
        Me.TablesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem89)
        Me.TablesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem90)
        Me.TablesRibbonPageGroup1.Name = "TablesRibbonPageGroup1"
        '
        'IllustrationsRibbonPageGroup1
        '
        Me.IllustrationsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem91)
        Me.IllustrationsRibbonPageGroup1.Name = "IllustrationsRibbonPageGroup1"
        '
        'ChartsRibbonPageGroup1
        '
        Me.ChartsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem13)
        Me.ChartsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem14)
        Me.ChartsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem15)
        Me.ChartsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem16)
        Me.ChartsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem17)
        Me.ChartsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem18)
        Me.ChartsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem19)
        Me.ChartsRibbonPageGroup1.Name = "ChartsRibbonPageGroup1"
        '
        'LinksRibbonPageGroup1
        '
        Me.LinksRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem92)
        Me.LinksRibbonPageGroup1.Name = "LinksRibbonPageGroup1"
        '
        'SymbolsRibbonPageGroup1
        '
        Me.SymbolsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem93)
        Me.SymbolsRibbonPageGroup1.Name = "SymbolsRibbonPageGroup1"
        '
        'PageLayoutRibbonPage1
        '
        Me.PageLayoutRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.PageSetupRibbonPageGroup1, Me.PageSetupShowRibbonPageGroup1, Me.PageSetupPrintRibbonPageGroup1, Me.ArrangeRibbonPageGroup1})
        Me.PageLayoutRibbonPage1.Name = "PageLayoutRibbonPage1"
        '
        'PageSetupRibbonPageGroup1
        '
        Me.PageSetupRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem21)
        Me.PageSetupRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem22)
        Me.PageSetupRibbonPageGroup1.ItemLinks.Add(Me.PageSetupPaperKindItem1)
        Me.PageSetupRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem23)
        Me.PageSetupRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem88)
        Me.PageSetupRibbonPageGroup1.Name = "PageSetupRibbonPageGroup1"
        '
        'PageSetupShowRibbonPageGroup1
        '
        Me.PageSetupShowRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem15)
        Me.PageSetupShowRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem16)
        Me.PageSetupShowRibbonPageGroup1.Name = "PageSetupShowRibbonPageGroup1"
        '
        'PageSetupPrintRibbonPageGroup1
        '
        Me.PageSetupPrintRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem26)
        Me.PageSetupPrintRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem27)
        Me.PageSetupPrintRibbonPageGroup1.Name = "PageSetupPrintRibbonPageGroup1"
        '
        'ArrangeRibbonPageGroup1
        '
        Me.ArrangeRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem9)
        Me.ArrangeRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem10)
        Me.ArrangeRibbonPageGroup1.Name = "ArrangeRibbonPageGroup1"
        '
        'FormulasRibbonPage1
        '
        Me.FormulasRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.FunctionLibraryRibbonPageGroup1, Me.FormulaDefinedNamesRibbonPageGroup1, Me.FormulaAuditingRibbonPageGroup1, Me.FormulaCalculationRibbonPageGroup1})
        Me.FormulasRibbonPage1.Name = "FormulasRibbonPage1"
        '
        'FunctionLibraryRibbonPageGroup1
        '
        Me.FunctionLibraryRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem18)
        Me.FunctionLibraryRibbonPageGroup1.ItemLinks.Add(Me.FunctionsFinancialItem1)
        Me.FunctionLibraryRibbonPageGroup1.ItemLinks.Add(Me.FunctionsLogicalItem1)
        Me.FunctionLibraryRibbonPageGroup1.ItemLinks.Add(Me.FunctionsTextItem1)
        Me.FunctionLibraryRibbonPageGroup1.ItemLinks.Add(Me.FunctionsDateAndTimeItem1)
        Me.FunctionLibraryRibbonPageGroup1.ItemLinks.Add(Me.FunctionsLookupAndReferenceItem1)
        Me.FunctionLibraryRibbonPageGroup1.ItemLinks.Add(Me.FunctionsMathAndTrigonometryItem1)
        Me.FunctionLibraryRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem19)
        Me.FunctionLibraryRibbonPageGroup1.Name = "FunctionLibraryRibbonPageGroup1"
        '
        'FormulaDefinedNamesRibbonPageGroup1
        '
        Me.FormulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem79)
        Me.FormulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem80)
        Me.FormulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(Me.DefinedNameListItem1)
        Me.FormulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem81)
        Me.FormulaDefinedNamesRibbonPageGroup1.Name = "FormulaDefinedNamesRibbonPageGroup1"
        '
        'FormulaAuditingRibbonPageGroup1
        '
        Me.FormulaAuditingRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem18)
        Me.FormulaAuditingRibbonPageGroup1.Name = "FormulaAuditingRibbonPageGroup1"
        '
        'FormulaCalculationRibbonPageGroup1
        '
        Me.FormulaCalculationRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem20)
        Me.FormulaCalculationRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem82)
        Me.FormulaCalculationRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem83)
        Me.FormulaCalculationRibbonPageGroup1.Name = "FormulaCalculationRibbonPageGroup1"
        '
        'DataRibbonPage1
        '
        Me.DataRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.SortAndFilterRibbonPageGroup1, Me.DataToolsRibbonPageGroup1, Me.OutlineRibbonPageGroup1})
        Me.DataRibbonPage1.Name = "DataRibbonPage1"
        '
        'SortAndFilterRibbonPageGroup1
        '
        Me.SortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem60)
        Me.SortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem61)
        Me.SortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem17)
        Me.SortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem62)
        Me.SortAndFilterRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem63)
        Me.SortAndFilterRibbonPageGroup1.Name = "SortAndFilterRibbonPageGroup1"
        '
        'DataToolsRibbonPageGroup1
        '
        Me.DataToolsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem15)
        Me.DataToolsRibbonPageGroup1.Name = "DataToolsRibbonPageGroup1"
        '
        'OutlineRibbonPageGroup1
        '
        Me.OutlineRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem16)
        Me.OutlineRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem17)
        Me.OutlineRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem71)
        Me.OutlineRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem72)
        Me.OutlineRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem73)
        Me.OutlineRibbonPageGroup1.Name = "OutlineRibbonPageGroup1"
        '
        'ReviewRibbonPage1
        '
        Me.ReviewRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.CommentsRibbonPageGroup1, Me.ChangesRibbonPageGroup1})
        Me.ReviewRibbonPage1.Name = "ReviewRibbonPage1"
        '
        'CommentsRibbonPageGroup1
        '
        Me.CommentsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem51)
        Me.CommentsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem52)
        Me.CommentsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem53)
        Me.CommentsRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem54)
        Me.CommentsRibbonPageGroup1.Name = "CommentsRibbonPageGroup1"
        '
        'ChangesRibbonPageGroup1
        '
        Me.ChangesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem55)
        Me.ChangesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem56)
        Me.ChangesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem57)
        Me.ChangesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem58)
        Me.ChangesRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem59)
        Me.ChangesRibbonPageGroup1.Name = "ChangesRibbonPageGroup1"
        '
        'ViewRibbonPage1
        '
        Me.ViewRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.ShowRibbonPageGroup1, Me.ZoomRibbonPageGroup1, Me.WindowRibbonPageGroup1})
        Me.ViewRibbonPage1.Name = "ViewRibbonPage1"
        '
        'ShowRibbonPageGroup1
        '
        Me.ShowRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem15)
        Me.ShowRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarCheckItem16)
        Me.ShowRibbonPageGroup1.Name = "ShowRibbonPageGroup1"
        '
        'ZoomRibbonPageGroup1
        '
        Me.ZoomRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem43)
        Me.ZoomRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem44)
        Me.ZoomRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem45)
        Me.ZoomRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarButtonItem46)
        Me.ZoomRibbonPageGroup1.Name = "ZoomRibbonPageGroup1"
        '
        'WindowRibbonPageGroup1
        '
        Me.WindowRibbonPageGroup1.ItemLinks.Add(Me.SpreadsheetCommandBarSubItem14)
        Me.WindowRibbonPageGroup1.Name = "WindowRibbonPageGroup1"
        '
        'RibbonPageSkins
        '
        Me.RibbonPageSkins.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.skinsRibbonPageGroup})
        Me.RibbonPageSkins.Name = "RibbonPageSkins"
        Me.RibbonPageSkins.Text = "Skins"
        '
        'skinsRibbonPageGroup
        '
        Me.skinsRibbonPageGroup.ItemLinks.Add(Me.rgbiSkins)
        Me.skinsRibbonPageGroup.Name = "skinsRibbonPageGroup"
        Me.skinsRibbonPageGroup.ShowCaptionButton = False
        Me.skinsRibbonPageGroup.Text = "Skins"
        '
        'helpRibbonPage
        '
        Me.helpRibbonPage.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.helpRibbonPageGroup})
        Me.helpRibbonPage.Name = "helpRibbonPage"
        Me.helpRibbonPage.Text = "Help"
        '
        'helpRibbonPageGroup
        '
        Me.helpRibbonPageGroup.ItemLinks.Add(Me.iHelp)
        Me.helpRibbonPageGroup.ItemLinks.Add(Me.iAbout)
        Me.helpRibbonPageGroup.Name = "helpRibbonPageGroup"
        Me.helpRibbonPageGroup.Text = "Help"
        '
        'ribbonStatusBar
        '
        Me.ribbonStatusBar.ItemLinks.Add(Me.siStatus)
        Me.ribbonStatusBar.ItemLinks.Add(Me.siInfo)
        Me.ribbonStatusBar.Location = New System.Drawing.Point(0, 679)
        Me.ribbonStatusBar.Name = "ribbonStatusBar"
        Me.ribbonStatusBar.Ribbon = Me.ribbonControl
        Me.ribbonStatusBar.Size = New System.Drawing.Size(1108, 21)
        '
        'spreadsheetFormulaBarPanel
        '
        Me.spreadsheetFormulaBarPanel.Controls.Add(Me.spreadsheetControl)
        Me.spreadsheetFormulaBarPanel.Controls.Add(Me.splitterControl)
        Me.spreadsheetFormulaBarPanel.Controls.Add(Me.formulaBarNameBoxSplitContainerControl)
        Me.spreadsheetFormulaBarPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spreadsheetFormulaBarPanel.Location = New System.Drawing.Point(0, 146)
        Me.spreadsheetFormulaBarPanel.Name = "spreadsheetFormulaBarPanel"
        Me.spreadsheetFormulaBarPanel.Size = New System.Drawing.Size(1108, 533)
        Me.spreadsheetFormulaBarPanel.TabIndex = 3
        '
        'splitterControl
        '
        Me.splitterControl.Dock = System.Windows.Forms.DockStyle.Top
        Me.splitterControl.Location = New System.Drawing.Point(0, 24)
        Me.splitterControl.MinSize = 20
        Me.splitterControl.Name = "splitterControl"
        Me.splitterControl.Size = New System.Drawing.Size(1108, 12)
        Me.splitterControl.TabIndex = 2
        Me.splitterControl.TabStop = False
        '
        'formulaBarNameBoxSplitContainerControl
        '
        Me.formulaBarNameBoxSplitContainerControl.Dock = System.Windows.Forms.DockStyle.Top
        Me.formulaBarNameBoxSplitContainerControl.Location = New System.Drawing.Point(0, 0)
        Me.formulaBarNameBoxSplitContainerControl.MinimumSize = New System.Drawing.Size(0, 24)
        Me.formulaBarNameBoxSplitContainerControl.Name = "formulaBarNameBoxSplitContainerControl"
        Me.formulaBarNameBoxSplitContainerControl.Panel1.Controls.Add(Me.spreadsheetNameBoxControl)
        Me.formulaBarNameBoxSplitContainerControl.Panel2.Controls.Add(Me.spreadsheetFormulaBarControl1)
        Me.formulaBarNameBoxSplitContainerControl.Size = New System.Drawing.Size(1108, 24)
        Me.formulaBarNameBoxSplitContainerControl.SplitterPosition = 145
        Me.formulaBarNameBoxSplitContainerControl.TabIndex = 3
        '
        'spreadsheetNameBoxControl
        '
        Me.spreadsheetNameBoxControl.Dock = System.Windows.Forms.DockStyle.Top
        Me.spreadsheetNameBoxControl.EditValue = "A1"
        Me.spreadsheetNameBoxControl.Location = New System.Drawing.Point(0, 0)
        Me.spreadsheetNameBoxControl.Name = "spreadsheetNameBoxControl"
        Me.spreadsheetNameBoxControl.Properties.AutoHeight = False
        Me.spreadsheetNameBoxControl.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Down)})
        Me.spreadsheetNameBoxControl.Size = New System.Drawing.Size(145, 24)
        Me.spreadsheetNameBoxControl.SpreadsheetControl = Me.spreadsheetControl
        Me.spreadsheetNameBoxControl.TabIndex = 0
        '
        'spreadsheetFormulaBarControl1
        '
        Me.spreadsheetFormulaBarControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spreadsheetFormulaBarControl1.Location = New System.Drawing.Point(0, 0)
        Me.spreadsheetFormulaBarControl1.MinimumSize = New System.Drawing.Size(0, 20)
        Me.spreadsheetFormulaBarControl1.Name = "spreadsheetFormulaBarControl1"
        Me.spreadsheetFormulaBarControl1.Size = New System.Drawing.Size(951, 24)
        Me.spreadsheetFormulaBarControl1.SpreadsheetControl = Me.spreadsheetControl
        Me.spreadsheetFormulaBarControl1.TabIndex = 0
        '
        'SpreadsheetBarController1
        '
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem2)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem3)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem4)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem5)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem6)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem7)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem2)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem8)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem9)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem10)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem11)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem12)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem3)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem13)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem14)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem4)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem2)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem3)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem4)
        Me.SpreadsheetBarController1.BarItems.Add(Me.GalleryPivotStylesItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem15)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem16)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem17)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem18)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem19)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem20)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem21)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem22)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem23)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem5)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem24)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem25)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem26)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem6)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem27)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem28)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem29)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem7)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem30)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem31)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem32)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem33)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem34)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem8)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem5)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem6)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem7)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem35)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem36)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem9)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem37)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem38)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem10)
        Me.SpreadsheetBarController1.BarItems.Add(Me.RenameTableItemCaption1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.RenameTableItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem8)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem9)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem10)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem11)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem12)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem13)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem14)
        Me.SpreadsheetBarController1.BarItems.Add(Me.GalleryTableStylesItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem2)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem11)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem3)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem4)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem12)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem5)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem6)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem7)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem13)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem8)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem9)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem10)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem11)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem12)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem39)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem40)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem41)
        Me.SpreadsheetBarController1.BarItems.Add(Me.GalleryChartLayoutItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.GalleryChartStyleItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem42)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem15)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem16)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem43)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem44)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem45)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem46)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem47)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem48)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem49)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem50)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem14)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem51)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem52)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem53)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem54)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem55)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem56)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem57)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem58)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem59)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem60)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem61)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem17)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem62)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem63)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem64)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem65)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem66)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem15)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem67)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem68)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem16)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem69)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem70)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem17)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem71)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem72)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem73)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem74)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem75)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem76)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem77)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem78)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem18)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsFinancialItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsLogicalItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsTextItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsDateAndTimeItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsLookupAndReferenceItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsMathAndTrigonometryItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsStatisticalItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsEngineeringItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsInformationItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsCompatibilityItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.FunctionsWebItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem19)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem79)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem80)
        Me.SpreadsheetBarController1.BarItems.Add(Me.DefinedNameListItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem81)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem18)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem19)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem20)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem20)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem82)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem83)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem21)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem22)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem23)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem84)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem21)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem24)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem25)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem22)
        Me.SpreadsheetBarController1.BarItems.Add(Me.PageSetupPaperKindItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem85)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem86)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem87)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem23)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem88)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem26)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem27)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem89)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem90)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem91)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem13)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem14)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem15)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem16)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem17)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem18)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem19)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem92)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem93)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem94)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem95)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem96)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem97)
        Me.SpreadsheetBarController1.BarItems.Add(Me.ChangeFontNameItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.ChangeFontSizeItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem98)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem99)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem28)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem29)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem30)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem31)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem100)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem101)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem102)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem103)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem104)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem105)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem106)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem107)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem108)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem109)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem110)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem111)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem112)
        Me.SpreadsheetBarController1.BarItems.Add(Me.ChangeBorderLineColorItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.ChangeBorderLineStyleItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem24)
        Me.SpreadsheetBarController1.BarItems.Add(Me.ChangeCellFillColorItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.ChangeFontColorItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem32)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem33)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem34)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem35)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem36)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem37)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem113)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem114)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem38)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem39)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem115)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem116)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem117)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem25)
        Me.SpreadsheetBarController1.BarItems.Add(Me.ChangeNumberFormatItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem118)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem119)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem120)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem121)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem122)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem123)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem26)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem124)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem125)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem126)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem127)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem128)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem129)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem130)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem131)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem132)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem133)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem134)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem27)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem135)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem136)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem137)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem138)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem139)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem140)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem28)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem20)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem21)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonGalleryDropDownItem22)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem141)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem142)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem143)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem29)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem144)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem30)
        Me.SpreadsheetBarController1.BarItems.Add(Me.GalleryFormatAsTableItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.GalleryChangeStyleItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem145)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem146)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem147)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem148)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem149)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem150)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem151)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem31)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem152)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem153)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem154)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem155)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem156)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem32)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem157)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem158)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem159)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem160)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem161)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem162)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem163)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem164)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem165)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem166)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem167)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem33)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem168)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem169)
        Me.SpreadsheetBarController1.BarItems.Add(Me.ChangeSheetTabColorItem1)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarCheckItem40)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem170)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem34)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem35)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem171)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem172)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem173)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem174)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem36)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem175)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem176)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem177)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem178)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem179)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem180)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem37)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem38)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem181)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem182)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem183)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem184)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem185)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem186)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem187)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarSubItem39)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem188)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem189)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem190)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem191)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem192)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem193)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem194)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem195)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem196)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem197)
        Me.SpreadsheetBarController1.BarItems.Add(Me.SpreadsheetCommandBarButtonItem198)
        Me.SpreadsheetBarController1.Control = Me.spreadsheetControl
        '
        'Form1
        '
        Me.AllowFormGlass = DevExpress.Utils.DefaultBoolean.[False]
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1108, 700)
        Me.Controls.Add(Me.spreadsheetFormulaBarPanel)
        Me.Controls.Add(Me.popupControlContainer1)
        Me.Controls.Add(Me.popupControlContainer2)
        Me.Controls.Add(Me.ribbonStatusBar)
        Me.Controls.Add(Me.ribbonControl)
        Me.Name = "Form1"
        Me.Ribbon = Me.ribbonControl
        Me.StatusBar = Me.ribbonStatusBar
        Me.Text = "Form1"
        CType(Me.ribbonControl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.appMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.popupControlContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.popupControlContainer2.ResumeLayout(False)
        CType(Me.buttonEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.popupControlContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.popupControlContainer1.ResumeLayout(False)
        Me.popupControlContainer1.PerformLayout()
        CType(Me.ribbonImageCollection, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemTextEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemFontEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemSpreadsheetFontSizeEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemPopupGalleryEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommandBarGalleryDropDown24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ribbonImageCollectionLarge, System.ComponentModel.ISupportInitialize).EndInit()
        Me.spreadsheetFormulaBarPanel.ResumeLayout(False)
        CType(Me.formulaBarNameBoxSplitContainerControl, System.ComponentModel.ISupportInitialize).EndInit()
        Me.formulaBarNameBoxSplitContainerControl.ResumeLayout(False)
        CType(Me.spreadsheetNameBoxControl.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SpreadsheetBarController1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents ribbonControl As DevExpress.XtraBars.Ribbon.RibbonControl
    Private WithEvents iExit As DevExpress.XtraBars.BarButtonItem
    Private WithEvents siStatus As DevExpress.XtraBars.BarStaticItem
    Private WithEvents siInfo As DevExpress.XtraBars.BarStaticItem
    Private WithEvents skinsRibbonPageGroup As DevExpress.XtraBars.Ribbon.RibbonPageGroup
    Private WithEvents rgbiSkins As DevExpress.XtraBars.RibbonGalleryBarItem
    Private WithEvents helpRibbonPage As DevExpress.XtraBars.Ribbon.RibbonPage
    Private WithEvents helpRibbonPageGroup As DevExpress.XtraBars.Ribbon.RibbonPageGroup
    Private WithEvents iHelp As DevExpress.XtraBars.BarButtonItem
    Private WithEvents iAbout As DevExpress.XtraBars.BarButtonItem
    Private WithEvents appMenu As DevExpress.XtraBars.Ribbon.ApplicationMenu
    Private WithEvents popupControlContainer1 As DevExpress.XtraBars.PopupControlContainer
    Private WithEvents someLabelControl2 As DevExpress.XtraEditors.LabelControl
    Private WithEvents someLabelControl1 As DevExpress.XtraEditors.LabelControl
    Private WithEvents popupControlContainer2 As DevExpress.XtraBars.PopupControlContainer
    Private WithEvents buttonEdit As DevExpress.XtraEditors.ButtonEdit
    Private WithEvents ribbonStatusBar As DevExpress.XtraBars.Ribbon.RibbonStatusBar
    Private WithEvents ribbonImageCollection As DevExpress.Utils.ImageCollection
    Private WithEvents ribbonImageCollectionLarge As DevExpress.Utils.ImageCollection
    Private WithEvents spreadsheetFormulaBarPanel As System.Windows.Forms.Panel
    Private WithEvents spreadsheetControl As DevExpress.XtraSpreadsheet.SpreadsheetControl
    Private WithEvents splitterControl As DevExpress.XtraEditors.SplitterControl
    Private WithEvents formulaBarNameBoxSplitContainerControl As DevExpress.XtraEditors.SplitContainerControl
    Private WithEvents spreadsheetNameBoxControl As DevExpress.XtraSpreadsheet.SpreadsheetNameBoxControl
    Private WithEvents spreadsheetFormulaBarControl1 As DevExpress.XtraSpreadsheet.SpreadsheetFormulaBarControl
    Friend WithEvents SpreadsheetCommandBarSubItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarCheckItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents GalleryPivotStylesItem1 As DevExpress.XtraSpreadsheet.UI.GalleryPivotStylesItem
    Friend WithEvents SpreadsheetCommandBarButtonItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarCheckItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarSubItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents RenameTableItemCaption1 As DevExpress.XtraSpreadsheet.UI.RenameTableItemCaption
    Friend WithEvents RenameTableItem1 As DevExpress.XtraSpreadsheet.UI.RenameTableItem
    Friend WithEvents RepositoryItemTextEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemTextEdit
    Friend WithEvents SpreadsheetCommandBarCheckItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents GalleryTableStylesItem1 As DevExpress.XtraSpreadsheet.UI.GalleryTableStylesItem
    Friend WithEvents SpreadsheetCommandBarSubItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown1 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem2 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown2 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarSubItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem3 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown3 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem4 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown4 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem5 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown5 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarSubItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem6 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown6 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem7 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown7 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem8 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown8 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem9 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown9 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem10 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown10 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem11 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown11 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem12 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown12 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem41 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents GalleryChartLayoutItem1 As DevExpress.XtraSpreadsheet.UI.GalleryChartLayoutItem
    Friend WithEvents GalleryChartStyleItem1 As DevExpress.XtraSpreadsheet.UI.GalleryChartStyleItem
    Friend WithEvents SpreadsheetCommandBarButtonItem42 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarCheckItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarButtonItem43 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem44 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem45 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem46 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem47 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem48 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem49 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem50 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem51 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem52 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem53 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem54 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem55 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem56 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem57 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem58 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem59 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem60 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem61 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarCheckItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarButtonItem62 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem63 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem64 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem65 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem66 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem67 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem68 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem69 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem70 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem71 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem72 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem73 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem74 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem75 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem76 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem77 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem78 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents FunctionsFinancialItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsFinancialItem
    Friend WithEvents FunctionsLogicalItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsLogicalItem
    Friend WithEvents FunctionsTextItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsTextItem
    Friend WithEvents FunctionsDateAndTimeItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsDateAndTimeItem
    Friend WithEvents FunctionsLookupAndReferenceItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsLookupAndReferenceItem
    Friend WithEvents FunctionsMathAndTrigonometryItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsMathAndTrigonometryItem
    Friend WithEvents SpreadsheetCommandBarSubItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents FunctionsStatisticalItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsStatisticalItem
    Friend WithEvents FunctionsEngineeringItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsEngineeringItem
    Friend WithEvents FunctionsInformationItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsInformationItem
    Friend WithEvents FunctionsCompatibilityItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsCompatibilityItem
    Friend WithEvents FunctionsWebItem1 As DevExpress.XtraSpreadsheet.UI.FunctionsWebItem
    Friend WithEvents SpreadsheetCommandBarButtonItem79 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem80 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents DefinedNameListItem1 As DevExpress.XtraSpreadsheet.UI.DefinedNameListItem
    Friend WithEvents SpreadsheetCommandBarButtonItem81 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarCheckItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarSubItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarCheckItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarButtonItem82 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem83 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarCheckItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarButtonItem84 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarCheckItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents PageSetupPaperKindItem1 As DevExpress.XtraSpreadsheet.UI.PageSetupPaperKindItem
    Friend WithEvents SpreadsheetCommandBarSubItem23 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem85 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem86 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem87 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem88 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarCheckItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarButtonItem89 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem90 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem91 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem13 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown13 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem14 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown14 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem15 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown15 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem16 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown16 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem17 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown17 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem18 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown18 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem19 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown19 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonItem92 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem93 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem94 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem95 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem96 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem97 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents BarButtonGroup1 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents ChangeFontNameItem1 As DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem
    Friend WithEvents RepositoryItemFontEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemFontEdit
    Friend WithEvents ChangeFontSizeItem1 As DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem
    Friend WithEvents RepositoryItemSpreadsheetFontSizeEdit1 As DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit
    Friend WithEvents SpreadsheetCommandBarButtonItem98 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem99 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents BarButtonGroup2 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents SpreadsheetCommandBarCheckItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents BarButtonGroup3 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents SpreadsheetCommandBarSubItem24 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem100 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem101 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem102 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem103 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem104 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem105 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem106 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem107 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem108 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem109 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem110 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem111 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem112 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents ChangeBorderLineColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem
    Friend WithEvents ChangeBorderLineStyleItem1 As DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem
    Friend WithEvents CommandBarGalleryDropDown20 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents BarButtonGroup4 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents ChangeCellFillColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem
    Friend WithEvents ChangeFontColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem
    Friend WithEvents BarButtonGroup5 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents SpreadsheetCommandBarCheckItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents BarButtonGroup6 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents SpreadsheetCommandBarCheckItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarCheckItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents BarButtonGroup7 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents SpreadsheetCommandBarButtonItem113 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem114 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarCheckItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarSubItem25 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarCheckItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarButtonItem115 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem116 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem117 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents BarButtonGroup8 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents ChangeNumberFormatItem1 As DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem
    Friend WithEvents RepositoryItemPopupGalleryEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit
    Friend WithEvents BarButtonGroup9 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents SpreadsheetCommandBarSubItem26 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem118 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem119 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem120 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem121 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem122 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem123 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem124 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem125 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents BarButtonGroup10 As DevExpress.XtraBars.BarButtonGroup
    Friend WithEvents SpreadsheetCommandBarButtonItem126 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem127 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem30 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarSubItem27 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem128 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem129 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem130 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem131 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem132 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem133 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem134 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem28 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem135 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem136 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem137 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem138 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem139 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem140 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem20 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown21 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem21 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown22 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonGalleryDropDownItem22 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem
    Friend WithEvents CommandBarGalleryDropDown23 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents SpreadsheetCommandBarButtonItem141 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem29 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem142 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem143 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem144 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents GalleryFormatAsTableItem1 As DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem
    Friend WithEvents CommandBarGalleryDropDown24 As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
    Friend WithEvents GalleryChangeStyleItem1 As DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem
    Friend WithEvents SpreadsheetCommandBarSubItem31 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem145 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem146 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem147 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem148 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem149 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem150 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem151 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem32 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem152 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem153 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem154 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem155 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem156 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem34 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem157 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem158 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem159 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem160 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem161 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem33 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem162 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem163 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem164 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem165 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem166 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem167 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem168 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem169 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents ChangeSheetTabColorItem1 As DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem
    Friend WithEvents SpreadsheetCommandBarCheckItem40 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem
    Friend WithEvents SpreadsheetCommandBarButtonItem170 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem35 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarSubItem36 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem171 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem172 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem173 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem174 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem37 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem175 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem176 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem177 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem178 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem179 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem180 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarSubItem38 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarSubItem39 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem
    Friend WithEvents SpreadsheetCommandBarButtonItem181 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem182 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem183 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem184 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem185 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem186 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem187 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem188 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem189 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem190 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem191 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem192 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem193 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem194 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem195 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem196 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem197 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents SpreadsheetCommandBarButtonItem198 As DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem
    Friend WithEvents PivotTableToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.PivotTableToolsRibbonPageCategory
    Friend WithEvents PivotTableAnalyzeRibbonPage1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeRibbonPage
    Friend WithEvents PivotTableAnalyzePivotTableRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzePivotTableRibbonPageGroup
    Friend WithEvents PivotTableAnalyzeActiveFieldRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActiveFieldRibbonPageGroup
    Friend WithEvents PivotTableAnalyzeGroupRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeGroupRibbonPageGroup
    Friend WithEvents PivotTableAnalyzeDataRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeDataRibbonPageGroup
    Friend WithEvents PivotTableAnalyzeActionsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActionsRibbonPageGroup
    Friend WithEvents PivotTableAnalyzeCalculationsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeCalculationsRibbonPageGroup
    Friend WithEvents PivotTableAnalyzeShowRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeShowRibbonPageGroup
    Friend WithEvents PivotTableDesignRibbonPage1 As DevExpress.XtraSpreadsheet.UI.PivotTableDesignRibbonPage
    Friend WithEvents PivotTableDesignLayoutRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableDesignLayoutRibbonPageGroup
    Friend WithEvents PivotTableDesignPivotTableStyleOptionsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup
    Friend WithEvents PivotTableDesignPivotTableStylesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStylesRibbonPageGroup
    Friend WithEvents PictureToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.PictureToolsRibbonPageCategory
    Friend WithEvents PictureFormatRibbonPage1 As DevExpress.XtraSpreadsheet.UI.PictureFormatRibbonPage
    Friend WithEvents PictureFormatArrangeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PictureFormatArrangeRibbonPageGroup
    Friend WithEvents DrawingToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.DrawingToolsRibbonPageCategory
    Friend WithEvents DrawingFormatRibbonPage1 As DevExpress.XtraSpreadsheet.UI.DrawingFormatRibbonPage
    Friend WithEvents DrawingFormatArrangeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.DrawingFormatArrangeRibbonPageGroup
    Friend WithEvents TableToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageCategory
    Friend WithEvents TableToolsDesignRibbonPage1 As DevExpress.XtraSpreadsheet.UI.TableToolsDesignRibbonPage
    Friend WithEvents TablePropertiesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TablePropertiesRibbonPageGroup
    Friend WithEvents TableToolsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageGroup
    Friend WithEvents TableStyleOptionsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TableStyleOptionsRibbonPageGroup
    Friend WithEvents TableStylesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TableStylesRibbonPageGroup
    Friend WithEvents ChartToolsRibbonPageCategory1 As DevExpress.XtraSpreadsheet.UI.ChartToolsRibbonPageCategory
    Friend WithEvents ChartsDesignRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignRibbonPage
    Friend WithEvents ChartsDesignTypeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignTypeRibbonPageGroup
    Friend WithEvents ChartsDesignDataRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignDataRibbonPageGroup
    Friend WithEvents ChartsDesignLayoutsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignLayoutsRibbonPageGroup
    Friend WithEvents ChartsDesignStylesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignStylesRibbonPageGroup
    Friend WithEvents ChartsDesignLocationRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsDesignLocationRibbonPageGroup
    Friend WithEvents ChartsLayoutRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ChartsLayoutRibbonPage
    Friend WithEvents ChartsLayoutAxesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsLayoutAxesRibbonPageGroup
    Friend WithEvents ChartsLayoutLabelsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsLayoutLabelsRibbonPageGroup
    Friend WithEvents ChartsLayoutAnalysisRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsLayoutAnalysisRibbonPageGroup
    Friend WithEvents ChartsFormatRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ChartsFormatRibbonPage
    Friend WithEvents ChartsFormatArrangeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsFormatArrangeRibbonPageGroup
    Friend WithEvents FileRibbonPage1 As DevExpress.XtraSpreadsheet.UI.FileRibbonPage
    Friend WithEvents CommonRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.CommonRibbonPageGroup
    Friend WithEvents InfoRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.InfoRibbonPageGroup
    Friend WithEvents HomeRibbonPage1 As DevExpress.XtraSpreadsheet.UI.HomeRibbonPage
    Friend WithEvents ClipboardRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ClipboardRibbonPageGroup
    Friend WithEvents FontRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FontRibbonPageGroup
    Friend WithEvents AlignmentRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.AlignmentRibbonPageGroup
    Friend WithEvents NumberRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.NumberRibbonPageGroup
    Friend WithEvents StylesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.StylesRibbonPageGroup
    Friend WithEvents CellsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.CellsRibbonPageGroup
    Friend WithEvents EditingRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.EditingRibbonPageGroup
    Friend WithEvents InsertRibbonPage1 As DevExpress.XtraSpreadsheet.UI.InsertRibbonPage
    Friend WithEvents TablesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.TablesRibbonPageGroup
    Friend WithEvents IllustrationsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.IllustrationsRibbonPageGroup
    Friend WithEvents ChartsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChartsRibbonPageGroup
    Friend WithEvents LinksRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.LinksRibbonPageGroup
    Friend WithEvents SymbolsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.SymbolsRibbonPageGroup
    Friend WithEvents PageLayoutRibbonPage1 As DevExpress.XtraSpreadsheet.UI.PageLayoutRibbonPage
    Friend WithEvents PageSetupRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PageSetupRibbonPageGroup
    Friend WithEvents PageSetupShowRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PageSetupShowRibbonPageGroup
    Friend WithEvents PageSetupPrintRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.PageSetupPrintRibbonPageGroup
    Friend WithEvents ArrangeRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ArrangeRibbonPageGroup
    Friend WithEvents FormulasRibbonPage1 As DevExpress.XtraSpreadsheet.UI.FormulasRibbonPage
    Friend WithEvents FunctionLibraryRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FunctionLibraryRibbonPageGroup
    Friend WithEvents FormulaDefinedNamesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FormulaDefinedNamesRibbonPageGroup
    Friend WithEvents FormulaAuditingRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FormulaAuditingRibbonPageGroup
    Friend WithEvents FormulaCalculationRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.FormulaCalculationRibbonPageGroup
    Friend WithEvents DataRibbonPage1 As DevExpress.XtraSpreadsheet.UI.DataRibbonPage
    Friend WithEvents SortAndFilterRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.SortAndFilterRibbonPageGroup
    Friend WithEvents DataToolsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.DataToolsRibbonPageGroup
    Friend WithEvents OutlineRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.OutlineRibbonPageGroup
    Friend WithEvents ReviewRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ReviewRibbonPage
    Friend WithEvents CommentsRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.CommentsRibbonPageGroup
    Friend WithEvents ChangesRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ChangesRibbonPageGroup
    Friend WithEvents ViewRibbonPage1 As DevExpress.XtraSpreadsheet.UI.ViewRibbonPage
    Friend WithEvents ShowRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ShowRibbonPageGroup
    Friend WithEvents ZoomRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.ZoomRibbonPageGroup
    Friend WithEvents WindowRibbonPageGroup1 As DevExpress.XtraSpreadsheet.UI.WindowRibbonPageGroup
    Friend WithEvents SpreadsheetBarController1 As DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController
    Private WithEvents RibbonPageSkins As RibbonPage
End Class

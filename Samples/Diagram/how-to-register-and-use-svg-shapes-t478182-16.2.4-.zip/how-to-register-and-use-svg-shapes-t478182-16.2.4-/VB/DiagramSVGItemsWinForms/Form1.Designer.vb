﻿Namespace DiagramSVGItemsWinForms
	Partial Public Class Form1
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.components = New System.ComponentModel.Container()
			Dim resources As New System.ComponentModel.ComponentResourceManager(GetType(Form1))
			Dim superToolTip1 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem1 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip2 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem2 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip3 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem3 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip4 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem4 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip5 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem5 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip6 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem6 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip7 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem7 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip8 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem8 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip9 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem9 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip10 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem10 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip11 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem11 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip12 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem12 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip13 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem13 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip14 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem14 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip15 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem15 As New DevExpress.Utils.ToolTipTitleItem()
			Dim galleryItemGroup1 As New DevExpress.XtraBars.Ribbon.GalleryItemGroup()
			Dim skinPaddingEdges1 As New DevExpress.Skins.SkinPaddingEdges()
			Dim superToolTip16 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem16 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip17 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem17 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip18 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem18 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip19 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem19 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip20 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem20 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip21 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem21 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip22 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem22 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip23 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem23 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip24 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem24 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip25 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem25 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip26 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem26 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip27 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem27 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip28 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem28 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip29 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem29 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip30 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem30 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip31 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem31 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip32 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem32 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip33 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem33 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip34 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem34 As New DevExpress.Utils.ToolTipTitleItem()
			Dim galleryItemGroup2 As New DevExpress.XtraBars.Ribbon.GalleryItemGroup()
			Dim superToolTip35 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem35 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip36 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem36 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip37 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem37 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip38 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem38 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip39 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem39 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip40 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem40 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip41 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem41 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip42 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem42 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip43 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem43 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip44 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem44 As New DevExpress.Utils.ToolTipTitleItem()
			Dim superToolTip45 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem45 As New DevExpress.Utils.ToolTipTitleItem()
			Dim galleryItemGroup3 As New DevExpress.XtraBars.Ribbon.GalleryItemGroup()
			Dim superToolTip46 As New DevExpress.Utils.SuperToolTip()
			Dim toolTipTitleItem46 As New DevExpress.Utils.ToolTipTitleItem()
			Dim toolTipItem1 As New DevExpress.Utils.ToolTipItem()
			Dim galleryItemGroup4 As New DevExpress.XtraBars.Ribbon.GalleryItemGroup()
			Dim galleryItemGroup5 As New DevExpress.XtraBars.Ribbon.GalleryItemGroup()
			Dim dockingContainer1 As New DevExpress.XtraBars.Docking2010.Views.Tabbed.DockingContainer()
			Me.diagramControl1 = New DevExpress.XtraDiagram.DiagramControl()
			Me.ribbonControl1 = New DevExpress.XtraBars.Ribbon.RibbonControl()
			Me.applicationMenu1 = New DevExpress.XtraBars.Ribbon.ApplicationMenu(Me.components)
			Me.ribbonStatusBar1 = New DevExpress.XtraBars.Ribbon.RibbonStatusBar()
			Me.diagramBarController1 = New DevExpress.XtraDiagram.Bars.DiagramBarController()
			Me.diagramCommandNewFileBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandNewFileBarButtonItem()
			Me.diagramCommandOpenFileBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandOpenFileBarButtonItem()
			Me.diagramCommandSaveFileBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSaveFileBarButtonItem()
			Me.diagramCommandSaveFileAsBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSaveFileAsBarButtonItem()
			Me.diagramCommandShowPrintPreviewBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandShowPrintPreviewBarButtonItem()
			Me.diagramCommandPrintMenuBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPrintMenuBarSplitButtonItem()
			Me.PrintMenuPopupMenu = New DevExpress.XtraBars.PopupMenu(Me.components)
			Me.diagramCommandExportAsBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandExportAsBarSplitButtonItem()
			Me.ExportAsPopupMenu = New DevExpress.XtraBars.PopupMenu(Me.components)
			Me.diagramCommandUndoBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandUndoBarButtonItem()
			Me.diagramCommandRedoBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandRedoBarButtonItem()
			Me.diagramCommandPrintBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPrintBarButtonItem()
			Me.diagramCommandQuickPrintBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandQuickPrintBarButtonItem()
			Me.diagramCommandExportDiagram_PNGBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_PNGBarButtonItem()
			Me.diagramCommandExportDiagram_JPEGBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_JPEGBarButtonItem()
			Me.diagramCommandExportDiagram_BMPBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_BMPBarButtonItem()
			Me.diagramCommandExportDiagram_GIFBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_GIFBarButtonItem()
			Me.diagramStatusBarShapeInfoBarStaticItem1 = New DevExpress.XtraDiagram.Bars.DiagramStatusBarShapeInfoBarStaticItem()
			Me.diagramCommandStatusBarZoomEditorBarEditItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandStatusBarZoomEditorBarEditItem()
			Me.diagramRepositoryItemZoomTrackBar1 = New DevExpress.XtraDiagram.Bars.DiagramCommandStatusBarZoomEditorBarEditItem.DiagramRepositoryItemZoomTrackBar()
			Me.diagramContainerSizeRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramContainerSizeRibbonPageGroup()
			Me.diagramFormatContainerRibbonPage1 = New DevExpress.XtraDiagram.Bars.DiagramFormatContainerRibbonPage()
			Me.diagramContainerToolsRibbonPageCategory1 = New DevExpress.XtraDiagram.Bars.DiagramContainerToolsRibbonPageCategory()
			Me.diagramCommandContainerPaddingBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerPaddingBarDropDownItem()
			Me.diagramCommandContainerHeaderPaddingBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPaddingBarDropDownItem()
			Me.diagramCommandContainerPadding_P0BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P0BarCheckItem()
			Me.diagramCommandContainerPadding_P4BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P4BarCheckItem()
			Me.diagramCommandContainerPadding_P8BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P8BarCheckItem()
			Me.diagramCommandContainerPadding_P12BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P12BarCheckItem()
			Me.diagramCommandContainerPadding_P16BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P16BarCheckItem()
			Me.diagramCommandContainerPadding_P24BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P24BarCheckItem()
			Me.diagramCommandContainerPadding_P32BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P32BarCheckItem()
			Me.diagramCommandContainerHeaderPadding_P0BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P0BarCheckItem()
			Me.diagramCommandContainerHeaderPadding_P4BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P4BarCheckItem()
			Me.diagramCommandContainerHeaderPadding_P8BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P8BarCheckItem()
			Me.diagramCommandContainerHeaderPadding_P12BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P12BarCheckItem()
			Me.diagramCommandContainerHeaderPadding_P16BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P16BarCheckItem()
			Me.diagramCommandContainerHeaderPadding_P24BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P24BarCheckItem()
			Me.diagramCommandContainerHeaderPadding_P32BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P32BarCheckItem()
			Me.diagramContainerStylesRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramContainerStylesRibbonPageGroup()
			Me.diagramCommandContainerStylesBarGalleryItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandContainerStylesBarGalleryItem()
			Me.diagramCommandShowContainerHeaderBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandShowContainerHeaderBarCheckItem()
			Me.diagramImageTools_ArrangeRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramImageTools_ArrangeRibbonPageGroup()
			Me.diagramFormatImageRibbonPage1 = New DevExpress.XtraDiagram.Bars.DiagramFormatImageRibbonPage()
			Me.diagramImageToolsRibbonPageCategory1 = New DevExpress.XtraDiagram.Bars.DiagramImageToolsRibbonPageCategory()
			Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsBringToFrontContainerBarSplitButtonItem()
			Me.ImageToolsBringToFrontContainerPopupMenu = New DevExpress.XtraBars.PopupMenu(Me.components)
			Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSendToBackContainerBarSplitButtonItem()
			Me.ImageToolsSendToBackContainerPopupMenu = New DevExpress.XtraBars.PopupMenu(Me.components)
			Me.diagramCommandBringForwardBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandBringForwardBarButtonItem()
			Me.diagramCommandBringToFrontBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandBringToFrontBarButtonItem()
			Me.diagramCommandSendBackwardBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSendBackwardBarButtonItem()
			Me.diagramCommandSendToBackBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSendToBackBarButtonItem()
			Me.diagramImageTools_PictureRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramImageTools_PictureRibbonPageGroup()
			Me.diagramCommandImageToolsRotateBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsRotateBarDropDownItem()
			Me.diagramCommandImageToolsStretchModeBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsStretchModeBarDropDownItem()
			Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScaleBarDropDownItem()
			Me.diagramCommandResetSelectedImagesBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandResetSelectedImagesBarButtonItem()
			Me.diagramCommandLoadImageBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandLoadImageBarButtonItem()
			Me.diagramCommandRotate_Right90BarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandRotate_Right90BarButtonItem()
			Me.diagramCommandRotate_Left90BarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandRotate_Left90BarButtonItem()
			Me.diagramCommandFlipImage_VerticalBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandFlipImage_VerticalBarButtonItem()
			Me.diagramCommandFlipImage_HorizontalBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandFlipImage_HorizontalBarButtonItem()
			Me.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem()
			Me.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem()
			Me.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem()
			Me.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_25BarCheckItem()
			Me.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_5BarCheckItem()
			Me.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_75BarCheckItem()
			Me.diagramCommandImageToolsSetImageScale_1BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_1BarCheckItem()
			Me.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_1_5BarCheckItem()
			Me.diagramCommandImageToolsSetImageScale_2BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_2BarCheckItem()
			Me.diagramCommandImageToolsSetImageScale_4BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_4BarCheckItem()
			Me.diagramShowRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramShowRibbonPageGroup()
			Me.diagramViewRibbonPage1 = New DevExpress.XtraDiagram.Bars.DiagramViewRibbonPage()
			Me.diagramCommandShowRulersBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandShowRulersBarCheckItem()
			Me.diagramCommandShowGridBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandShowGridBarCheckItem()
			Me.diagramCommandShowPageBreaksBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandShowPageBreaksBarCheckItem()
			Me.diagramCommandPanesBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPanesBarDropDownItem()
			Me.diagramCommandShapesPanelBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandShapesPanelBarCheckItem()
			Me.diagramCommandPropertiesPanelBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPropertiesPanelBarCheckItem()
			Me.diagramZoomRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramZoomRibbonPageGroup()
			Me.diagramCommandFitToPageBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandFitToPageBarButtonItem()
			Me.diagramCommandFitToWidthBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandFitToWidthBarButtonItem()
			Me.diagramPageSetupRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramPageSetupRibbonPageGroup()
			Me.diagramDesignRibbonPage1 = New DevExpress.XtraDiagram.Bars.DiagramDesignRibbonPage()
			Me.diagramCommandPageOrientationBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientationBarDropDownItem()
			Me.diagramCommandPageSizeBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSizeBarDropDownItem()
			Me.diagramCommandAutoSizeBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandAutoSizeBarDropDownItem()
			Me.diagramCommandPageOrientation_HorizontalBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientation_HorizontalBarCheckItem()
			Me.diagramCommandPageOrientation_VerticalBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientation_VerticalBarCheckItem()
			Me.diagramCommandPageSize_LetterBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_LetterBarCheckItem()
			Me.diagramCommandPageSize_TabloidBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_TabloidBarCheckItem()
			Me.diagramCommandPageSize_LegalBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_LegalBarCheckItem()
			Me.diagramCommandPageSize_StatementBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_StatementBarCheckItem()
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_ExecutiveBarCheckItem()
			Me.diagramCommandPageSize_A3BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A3BarCheckItem()
			Me.diagramCommandPageSize_A4BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A4BarCheckItem()
			Me.diagramCommandPageSize_A5BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A5BarCheckItem()
			Me.diagramCommandPageSize_B4BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_B4BarCheckItem()
			Me.diagramCommandPageSize_B5BarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_B5BarCheckItem()
			Me.diagramCommandFitToDrawingBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandFitToDrawingBarButtonItem()
			Me.diagramCommandSetPageParameters_PageSizeBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetPageParameters_PageSizeBarButtonItem()
			Me.diagramCommandAutoSize_NoneBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_NoneBarCheckItem()
			Me.diagramCommandAutoSize_AutoSizeBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_AutoSizeBarCheckItem()
			Me.diagramCommandAutoSize_FillBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_FillBarCheckItem()
			Me.diagramThemesRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramThemesRibbonPageGroup()
			Me.diagramCommandThemesBarGalleryItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandThemesBarGalleryItem()
			Me.diagramOptionsRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramOptionsRibbonPageGroup()
			Me.diagramCommandSnapToItemsBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSnapToItemsBarCheckItem()
			Me.diagramCommandSnapToGridBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSnapToGridBarCheckItem()
			Me.diagramTreeLayoutRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramTreeLayoutRibbonPageGroup()
			Me.diagramCommandReLayoutBarDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandReLayoutBarDropDownItem()
			Me.diagramReLayoutTreeBarHeaderItem1 = New DevExpress.XtraDiagram.Bars.DiagramReLayoutTreeBarHeaderItem()
			Me.diagramCommandTreeLayout_DownBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_DownBarButtonItem()
			Me.diagramCommandTreeLayout_UpBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_UpBarButtonItem()
			Me.diagramCommandTreeLayout_RightBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_RightBarButtonItem()
			Me.diagramCommandTreeLayout_LeftBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_LeftBarButtonItem()
			Me.diagramReLayoutTipOverTreeHeaderBarHeaderItem1 = New DevExpress.XtraDiagram.Bars.DiagramReLayoutTipOverTreeHeaderBarHeaderItem()
			Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayout_LeftToRightBarButtonItem()
			Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayout_RightToLeftBarButtonItem()
			Me.diagramReLayoutSugiyamaBarHeaderItem1 = New DevExpress.XtraDiagram.Bars.DiagramReLayoutSugiyamaBarHeaderItem()
			Me.diagramCommandSugiyamaLayout_DownBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_DownBarButtonItem()
			Me.diagramCommandSugiyamaLayout_UpBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_UpBarButtonItem()
			Me.diagramCommandSugiyamaLayout_RightBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_RightBarButtonItem()
			Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_LeftBarButtonItem()
			Me.diagramReLayoutCircularHeaderBarHeaderItem1 = New DevExpress.XtraDiagram.Bars.DiagramReLayoutCircularHeaderBarHeaderItem()
			Me.diagramCommandCircularLayoutBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandCircularLayoutBarButtonItem()
			Me.diagramDiagramPartsRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramDiagramPartsRibbonPageGroup()
			Me.diagramInsertRibbonPage1 = New DevExpress.XtraDiagram.Bars.DiagramInsertRibbonPage()
			Me.diagramCommandInsertContainerBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandInsertContainerBarSplitButtonItem()
			Me.InsertContainerPopupMenu = New DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(Me.components)
			Me.diagramCommandInsertImageBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandInsertImageBarButtonItem()
			Me.diagramClipboardRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramClipboardRibbonPageGroup()
			Me.diagramHomeRibbonPage1 = New DevExpress.XtraDiagram.Bars.DiagramHomeRibbonPage()
			Me.diagramCommandPasteBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandPasteBarButtonItem()
			Me.diagramCommandCutBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandCutBarButtonItem()
			Me.diagramCommandCopyBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandCopyBarButtonItem()
			Me.diagramFontRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramFontRibbonPageGroup()
			Me.diagramCommandFontFamilyBarEditItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandFontFamilyBarEditItem()
			Me.diagramCommandFontSizeBarEditItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandFontSizeBarEditItem()
			Me.diagramCommandIncreaseFontSizeBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandIncreaseFontSizeBarButtonItem()
			Me.diagramCommandDecreaseFontSizeBarButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandDecreaseFontSizeBarButtonItem()
			Me.diagramCommandToggleFontBoldBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontBoldBarCheckItem()
			Me.diagramCommandToggleFontItalicBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontItalicBarCheckItem()
			Me.diagramCommandToggleFontUnderlineBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontUnderlineBarCheckItem()
			Me.diagramCommandToggleFontStrikethroughBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontStrikethroughBarCheckItem()
			Me.diagramCommandForegroundColorBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandForegroundColorBarSplitButtonItem()
			Me.barButtonGroup1 = New DevExpress.XtraBars.BarButtonGroup()
			Me.repositoryItemFontEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemFontEdit()
			Me.repositoryItemDiagramFontSizeEdit1 = New DevExpress.XtraDiagram.Bars.RepositoryItemDiagramFontSizeEdit()
			Me.barButtonGroup2 = New DevExpress.XtraBars.BarButtonGroup()
			Me.diagramParagraphRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramParagraphRibbonPageGroup()
			Me.diagramCommandSetVerticalAlignment_TopBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_TopBarCheckItem()
			Me.diagramCommandSetVerticalAlignment_CenterBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_CenterBarCheckItem()
			Me.diagramCommandSetVerticalAlignment_BottomBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_BottomBarCheckItem()
			Me.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_LeftBarCheckItem()
			Me.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_CenterBarCheckItem()
			Me.diagramCommandSetHorizontalAlignment_RightBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_RightBarCheckItem()
			Me.barButtonGroup3 = New DevExpress.XtraBars.BarButtonGroup()
			Me.barButtonGroup4 = New DevExpress.XtraBars.BarButtonGroup()
			Me.diagramToolsRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramToolsRibbonPageGroup()
			Me.diagramCommandSelectPointerToolBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSelectPointerToolBarCheckItem()
			Me.diagramCommandSelectConnectorToolBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSelectConnectorToolBarCheckItem()
			Me.diagramCommandToolsContainerCheckDropDownItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandToolsContainerCheckDropDownItem()
			Me.ToolsContainerPopupMenu = New DevExpress.XtraBars.PopupMenu(Me.components)
			Me.diagramCommandSelectRectangleToolBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSelectRectangleToolBarCheckItem()
			Me.diagramCommandSelectEllipseToolBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSelectEllipseToolBarCheckItem()
			Me.diagramCommandSelectRightTriangleToolBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSelectRightTriangleToolBarCheckItem()
			Me.diagramCommandSelectHexagonToolBarCheckItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSelectHexagonToolBarCheckItem()
			Me.diagramShapeStylesRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramShapeStylesRibbonPageGroup()
			Me.diagramCommandShapeStylesBarGalleryItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandShapeStylesBarGalleryItem()
			Me.diagramCommandBackgroundColorBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandBackgroundColorBarSplitButtonItem()
			Me.diagramCommandStrokeColorBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandStrokeColorBarSplitButtonItem()
			Me.diagramArrangeRibbonPageGroup1 = New DevExpress.XtraDiagram.Bars.DiagramArrangeRibbonPageGroup()
			Me.diagramCommandBringToFrontBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandBringToFrontBarSplitButtonItem()
			Me.BringToFrontPopupMenu = New DevExpress.XtraBars.PopupMenu(Me.components)
			Me.diagramCommandSendToBackBarSplitButtonItem1 = New DevExpress.XtraDiagram.Bars.DiagramCommandSendToBackBarSplitButtonItem()
			Me.SendToBackPopupMenu = New DevExpress.XtraBars.PopupMenu(Me.components)
			Me.dockManager1 = New DevExpress.XtraBars.Docking.DockManager(Me.components)
			Me.documentManager1 = New DevExpress.XtraBars.Docking2010.DocumentManager(Me.components)
			Me.tabbedView1 = New DevExpress.XtraBars.Docking2010.Views.Tabbed.TabbedView(Me.components)
			Me.diagramToolboxDockPanel1 = New DevExpress.XtraDiagram.Docking.DiagramToolboxDockPanel()
			Me.hideContainerRight = New DevExpress.XtraBars.Docking.AutoHideContainer()
			Me.diagramPropertyGridDockPanel1 = New DevExpress.XtraDiagram.Docking.DiagramPropertyGridDockPanel()
			Me.document1 = New DevExpress.XtraBars.Docking2010.Views.Tabbed.Document(Me.components)
			Me.documentGroup1 = New DevExpress.XtraBars.Docking2010.Views.Tabbed.DocumentGroup(Me.components)
			Me.diagramControlDockPanel1 = New DevExpress.XtraDiagram.Docking.DiagramControlDockPanel()
			Me.controlContainer1 = New DevExpress.XtraBars.Docking.ControlContainer()
			DirectCast(Me.diagramControl1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.ribbonControl1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.applicationMenu1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.diagramBarController1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.PrintMenuPopupMenu, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.ExportAsPopupMenu, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.diagramRepositoryItemZoomTrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.ImageToolsBringToFrontContainerPopupMenu, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.ImageToolsSendToBackContainerPopupMenu, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.InsertContainerPopupMenu, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.repositoryItemFontEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.repositoryItemDiagramFontSizeEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.ToolsContainerPopupMenu, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.BringToFrontPopupMenu, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.SendToBackPopupMenu, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.dockManager1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.documentManager1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.tabbedView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.hideContainerRight.SuspendLayout()
			DirectCast(Me.diagramPropertyGridDockPanel1.PropertyGrid, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.document1, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.documentGroup1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.diagramControlDockPanel1.SuspendLayout()
			Me.controlContainer1.SuspendLayout()
			Me.SuspendLayout()
			' 
			' diagramControl1
			' 
			Me.diagramControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
			Me.diagramControl1.Dock = System.Windows.Forms.DockStyle.Fill
			Me.diagramControl1.Location = New System.Drawing.Point(0, 0)
			Me.diagramControl1.Name = "diagramControl1"
			Me.diagramControl1.OptionsBehavior.SelectedStencils = New DevExpress.Diagram.Core.StencilCollection(New String(){})
			Me.diagramControl1.OptionsView.PaperKind = System.Drawing.Printing.PaperKind.Letter
			Me.diagramControl1.PropertyGrid = Me.diagramPropertyGridDockPanel1
			Me.diagramControl1.Size = New System.Drawing.Size(684, 537)
			Me.diagramControl1.TabIndex = 0
			Me.diagramControl1.Toolbox = Me.diagramToolboxDockPanel1
			' 
			' ribbonControl1
			' 
			Me.ribbonControl1.ApplicationButtonDropDownControl = Me.applicationMenu1
			Me.ribbonControl1.ExpandCollapseItem.Id = 0
			Me.ribbonControl1.Items.AddRange(New DevExpress.XtraBars.BarItem() { Me.ribbonControl1.ExpandCollapseItem, Me.diagramCommandNewFileBarButtonItem1, Me.diagramCommandOpenFileBarButtonItem1, Me.diagramCommandSaveFileBarButtonItem1, Me.diagramCommandSaveFileAsBarButtonItem1, Me.diagramCommandShowPrintPreviewBarButtonItem1, Me.diagramCommandPrintMenuBarSplitButtonItem1, Me.diagramCommandPrintBarButtonItem1, Me.diagramCommandQuickPrintBarButtonItem1, Me.diagramCommandExportAsBarSplitButtonItem1, Me.diagramCommandExportDiagram_PNGBarButtonItem1, Me.diagramCommandExportDiagram_JPEGBarButtonItem1, Me.diagramCommandExportDiagram_BMPBarButtonItem1, Me.diagramCommandExportDiagram_GIFBarButtonItem1, Me.diagramCommandUndoBarButtonItem1, Me.diagramCommandRedoBarButtonItem1, Me.diagramStatusBarShapeInfoBarStaticItem1, Me.diagramCommandStatusBarZoomEditorBarEditItem1, Me.diagramCommandContainerPaddingBarDropDownItem1, Me.diagramCommandContainerHeaderPaddingBarDropDownItem1, Me.diagramCommandContainerPadding_P0BarCheckItem1, Me.diagramCommandContainerPadding_P4BarCheckItem1, Me.diagramCommandContainerPadding_P8BarCheckItem1, Me.diagramCommandContainerPadding_P12BarCheckItem1, Me.diagramCommandContainerPadding_P16BarCheckItem1, Me.diagramCommandContainerPadding_P24BarCheckItem1, Me.diagramCommandContainerPadding_P32BarCheckItem1, Me.diagramCommandContainerHeaderPadding_P0BarCheckItem1, Me.diagramCommandContainerHeaderPadding_P4BarCheckItem1, Me.diagramCommandContainerHeaderPadding_P8BarCheckItem1, Me.diagramCommandContainerHeaderPadding_P12BarCheckItem1, Me.diagramCommandContainerHeaderPadding_P16BarCheckItem1, Me.diagramCommandContainerHeaderPadding_P24BarCheckItem1, Me.diagramCommandContainerHeaderPadding_P32BarCheckItem1, Me.diagramCommandContainerStylesBarGalleryItem1, Me.diagramCommandShowContainerHeaderBarCheckItem1, Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1, Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1, Me.diagramCommandBringForwardBarButtonItem1, Me.diagramCommandBringToFrontBarButtonItem1, Me.diagramCommandSendBackwardBarButtonItem1, Me.diagramCommandSendToBackBarButtonItem1, Me.diagramCommandImageToolsRotateBarDropDownItem1, Me.diagramCommandImageToolsStretchModeBarDropDownItem1, Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1, Me.diagramCommandResetSelectedImagesBarButtonItem1, Me.diagramCommandLoadImageBarButtonItem1, Me.diagramCommandRotate_Right90BarButtonItem1, Me.diagramCommandRotate_Left90BarButtonItem1, Me.diagramCommandFlipImage_VerticalBarButtonItem1, Me.diagramCommandFlipImage_HorizontalBarButtonItem1, Me.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1, Me.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1, Me.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1, Me.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1, Me.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1, Me.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1, Me.diagramCommandImageToolsSetImageScale_1BarCheckItem1, Me.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1, Me.diagramCommandImageToolsSetImageScale_2BarCheckItem1, Me.diagramCommandImageToolsSetImageScale_4BarCheckItem1, Me.diagramCommandShowRulersBarCheckItem1, Me.diagramCommandShowGridBarCheckItem1, Me.diagramCommandShowPageBreaksBarCheckItem1, Me.diagramCommandPanesBarDropDownItem1, Me.diagramCommandShapesPanelBarCheckItem1, Me.diagramCommandPropertiesPanelBarCheckItem1, Me.diagramCommandFitToPageBarButtonItem1, Me.diagramCommandFitToWidthBarButtonItem1, Me.diagramCommandPageOrientationBarDropDownItem1, Me.diagramCommandPageSizeBarDropDownItem1, Me.diagramCommandAutoSizeBarDropDownItem1, Me.diagramCommandPageOrientation_HorizontalBarCheckItem1, Me.diagramCommandPageOrientation_VerticalBarCheckItem1, Me.diagramCommandPageSize_LetterBarCheckItem1, Me.diagramCommandPageSize_TabloidBarCheckItem1, Me.diagramCommandPageSize_LegalBarCheckItem1, Me.diagramCommandPageSize_StatementBarCheckItem1, Me.diagramCommandPageSize_ExecutiveBarCheckItem1, Me.diagramCommandPageSize_A3BarCheckItem1, Me.diagramCommandPageSize_A4BarCheckItem1, Me.diagramCommandPageSize_A5BarCheckItem1, Me.diagramCommandPageSize_B4BarCheckItem1, Me.diagramCommandPageSize_B5BarCheckItem1, Me.diagramCommandFitToDrawingBarButtonItem1, Me.diagramCommandSetPageParameters_PageSizeBarButtonItem1, Me.diagramCommandAutoSize_NoneBarCheckItem1, Me.diagramCommandAutoSize_AutoSizeBarCheckItem1, Me.diagramCommandAutoSize_FillBarCheckItem1, Me.diagramCommandThemesBarGalleryItem1, Me.diagramCommandSnapToItemsBarCheckItem1, Me.diagramCommandSnapToGridBarCheckItem1, Me.diagramCommandReLayoutBarDropDownItem1, Me.diagramReLayoutTreeBarHeaderItem1, Me.diagramCommandTreeLayout_DownBarButtonItem1, Me.diagramCommandTreeLayout_UpBarButtonItem1, Me.diagramCommandTreeLayout_RightBarButtonItem1, Me.diagramCommandTreeLayout_LeftBarButtonItem1, Me.diagramReLayoutTipOverTreeHeaderBarHeaderItem1, Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1, Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1, Me.diagramReLayoutSugiyamaBarHeaderItem1, Me.diagramCommandSugiyamaLayout_DownBarButtonItem1, Me.diagramCommandSugiyamaLayout_UpBarButtonItem1, Me.diagramCommandSugiyamaLayout_RightBarButtonItem1, Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1, Me.diagramReLayoutCircularHeaderBarHeaderItem1, Me.diagramCommandCircularLayoutBarButtonItem1, Me.diagramCommandInsertContainerBarSplitButtonItem1, Me.diagramCommandInsertImageBarButtonItem1, Me.diagramCommandPasteBarButtonItem1, Me.diagramCommandCutBarButtonItem1, Me.diagramCommandCopyBarButtonItem1, Me.barButtonGroup1, Me.diagramCommandFontFamilyBarEditItem1, Me.diagramCommandFontSizeBarEditItem1, Me.diagramCommandIncreaseFontSizeBarButtonItem1, Me.diagramCommandDecreaseFontSizeBarButtonItem1, Me.barButtonGroup2, Me.diagramCommandToggleFontBoldBarCheckItem1, Me.diagramCommandToggleFontItalicBarCheckItem1, Me.diagramCommandToggleFontUnderlineBarCheckItem1, Me.diagramCommandToggleFontStrikethroughBarCheckItem1, Me.diagramCommandForegroundColorBarSplitButtonItem1, Me.barButtonGroup3, Me.diagramCommandSetVerticalAlignment_TopBarCheckItem1, Me.diagramCommandSetVerticalAlignment_CenterBarCheckItem1, Me.diagramCommandSetVerticalAlignment_BottomBarCheckItem1, Me.barButtonGroup4, Me.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1, Me.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1, Me.diagramCommandSetHorizontalAlignment_RightBarCheckItem1, Me.diagramCommandSelectPointerToolBarCheckItem1, Me.diagramCommandSelectConnectorToolBarCheckItem1, Me.diagramCommandToolsContainerCheckDropDownItem1, Me.diagramCommandSelectRectangleToolBarCheckItem1, Me.diagramCommandSelectEllipseToolBarCheckItem1, Me.diagramCommandSelectRightTriangleToolBarCheckItem1, Me.diagramCommandSelectHexagonToolBarCheckItem1, Me.diagramCommandShapeStylesBarGalleryItem1, Me.diagramCommandBackgroundColorBarSplitButtonItem1, Me.diagramCommandStrokeColorBarSplitButtonItem1, Me.diagramCommandBringToFrontBarSplitButtonItem1, Me.diagramCommandSendToBackBarSplitButtonItem1})
			Me.ribbonControl1.Location = New System.Drawing.Point(0, 0)
			Me.ribbonControl1.MaxItemId = 144
			Me.ribbonControl1.Name = "ribbonControl1"
			Me.ribbonControl1.PageCategories.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageCategory() { Me.diagramContainerToolsRibbonPageCategory1, Me.diagramImageToolsRibbonPageCategory1})
			Me.ribbonControl1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() { Me.diagramHomeRibbonPage1, Me.diagramInsertRibbonPage1, Me.diagramDesignRibbonPage1, Me.diagramViewRibbonPage1})
			Me.ribbonControl1.QuickToolbarItemLinks.Add(Me.diagramCommandSaveFileBarButtonItem1)
			Me.ribbonControl1.QuickToolbarItemLinks.Add(Me.diagramCommandUndoBarButtonItem1)
			Me.ribbonControl1.QuickToolbarItemLinks.Add(Me.diagramCommandRedoBarButtonItem1)
			Me.ribbonControl1.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() { Me.diagramRepositoryItemZoomTrackBar1, Me.repositoryItemFontEdit1, Me.repositoryItemDiagramFontSizeEdit1})
			Me.ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2013
			Me.ribbonControl1.Size = New System.Drawing.Size(1009, 141)
			Me.ribbonControl1.StatusBar = Me.ribbonStatusBar1
			Me.ribbonControl1.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Above
			' 
			' applicationMenu1
			' 
			Me.applicationMenu1.ItemLinks.Add(Me.diagramCommandNewFileBarButtonItem1)
			Me.applicationMenu1.ItemLinks.Add(Me.diagramCommandOpenFileBarButtonItem1)
			Me.applicationMenu1.ItemLinks.Add(Me.diagramCommandSaveFileBarButtonItem1)
			Me.applicationMenu1.ItemLinks.Add(Me.diagramCommandSaveFileAsBarButtonItem1)
			Me.applicationMenu1.ItemLinks.Add(Me.diagramCommandShowPrintPreviewBarButtonItem1)
			Me.applicationMenu1.ItemLinks.Add(Me.diagramCommandPrintMenuBarSplitButtonItem1)
			Me.applicationMenu1.ItemLinks.Add(Me.diagramCommandExportAsBarSplitButtonItem1)
			Me.applicationMenu1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.LargeImagesTextDescription
			Me.applicationMenu1.MinWidth = 350
			Me.applicationMenu1.Name = "applicationMenu1"
			Me.applicationMenu1.Ribbon = Me.ribbonControl1
			' 
			' ribbonStatusBar1
			' 
			Me.ribbonStatusBar1.ItemLinks.Add(Me.diagramStatusBarShapeInfoBarStaticItem1)
			Me.ribbonStatusBar1.ItemLinks.Add(Me.diagramCommandStatusBarZoomEditorBarEditItem1)
			Me.ribbonStatusBar1.Location = New System.Drawing.Point(0, 684)
			Me.ribbonStatusBar1.Name = "ribbonStatusBar1"
			Me.ribbonStatusBar1.Ribbon = Me.ribbonControl1
			Me.ribbonStatusBar1.Size = New System.Drawing.Size(1009, 27)
			' 
			' diagramBarController1
			' 
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandNewFileBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandOpenFileBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSaveFileBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSaveFileAsBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandShowPrintPreviewBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPrintMenuBarSplitButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandExportAsBarSplitButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandUndoBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandRedoBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPrintBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandQuickPrintBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandExportDiagram_PNGBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandExportDiagram_JPEGBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandExportDiagram_BMPBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandExportDiagram_GIFBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramStatusBarShapeInfoBarStaticItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandStatusBarZoomEditorBarEditItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerPaddingBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerHeaderPaddingBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerPadding_P0BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerPadding_P4BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerPadding_P8BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerPadding_P12BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerPadding_P16BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerPadding_P24BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerPadding_P32BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerHeaderPadding_P0BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerHeaderPadding_P4BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerHeaderPadding_P8BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerHeaderPadding_P12BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerHeaderPadding_P16BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerHeaderPadding_P24BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerHeaderPadding_P32BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandContainerStylesBarGalleryItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandShowContainerHeaderBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandBringForwardBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandBringToFrontBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSendBackwardBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSendToBackBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsRotateBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsStretchModeBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandResetSelectedImagesBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandLoadImageBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandRotate_Right90BarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandRotate_Left90BarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandFlipImage_VerticalBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandFlipImage_HorizontalBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsSetImageScale_1BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsSetImageScale_2BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandImageToolsSetImageScale_4BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandShowRulersBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandShowGridBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandShowPageBreaksBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPanesBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandShapesPanelBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPropertiesPanelBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandFitToPageBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandFitToWidthBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageOrientationBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSizeBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandAutoSizeBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageOrientation_HorizontalBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageOrientation_VerticalBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_LetterBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_TabloidBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_LegalBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_StatementBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_ExecutiveBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_A3BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_A4BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_A5BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_B4BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPageSize_B5BarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandFitToDrawingBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetPageParameters_PageSizeBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandAutoSize_NoneBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandAutoSize_AutoSizeBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandAutoSize_FillBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandThemesBarGalleryItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSnapToItemsBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSnapToGridBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandReLayoutBarDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramReLayoutTreeBarHeaderItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandTreeLayout_DownBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandTreeLayout_UpBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandTreeLayout_RightBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandTreeLayout_LeftBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramReLayoutTipOverTreeHeaderBarHeaderItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramReLayoutSugiyamaBarHeaderItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSugiyamaLayout_DownBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSugiyamaLayout_UpBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSugiyamaLayout_RightBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramReLayoutCircularHeaderBarHeaderItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandCircularLayoutBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandInsertContainerBarSplitButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandInsertImageBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandPasteBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandCutBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandCopyBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandFontFamilyBarEditItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandFontSizeBarEditItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandIncreaseFontSizeBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandDecreaseFontSizeBarButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandToggleFontBoldBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandToggleFontItalicBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandToggleFontUnderlineBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandToggleFontStrikethroughBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandForegroundColorBarSplitButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetVerticalAlignment_TopBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetVerticalAlignment_CenterBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetVerticalAlignment_BottomBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSetHorizontalAlignment_RightBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSelectPointerToolBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSelectConnectorToolBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandToolsContainerCheckDropDownItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSelectRectangleToolBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSelectEllipseToolBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSelectRightTriangleToolBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSelectHexagonToolBarCheckItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandShapeStylesBarGalleryItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandBackgroundColorBarSplitButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandStrokeColorBarSplitButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandBringToFrontBarSplitButtonItem1)
			Me.diagramBarController1.BarItems.Add(Me.diagramCommandSendToBackBarSplitButtonItem1)
			Me.diagramBarController1.Control = Me.diagramControl1
			' 
			' diagramCommandNewFileBarButtonItem1
			' 
			Me.diagramCommandNewFileBarButtonItem1.Id = 1
			Me.diagramCommandNewFileBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandNewFileBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandNewFileBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandNewFileBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandNewFileBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandNewFileBarButtonItem1.Name = "diagramCommandNewFileBarButtonItem1"
			' 
			' diagramCommandOpenFileBarButtonItem1
			' 
			Me.diagramCommandOpenFileBarButtonItem1.Id = 2
			Me.diagramCommandOpenFileBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandOpenFileBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandOpenFileBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandOpenFileBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandOpenFileBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandOpenFileBarButtonItem1.Name = "diagramCommandOpenFileBarButtonItem1"
			' 
			' diagramCommandSaveFileBarButtonItem1
			' 
			Me.diagramCommandSaveFileBarButtonItem1.Id = 3
			Me.diagramCommandSaveFileBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSaveFileBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSaveFileBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSaveFileBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandSaveFileBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandSaveFileBarButtonItem1.Name = "diagramCommandSaveFileBarButtonItem1"
			' 
			' diagramCommandSaveFileAsBarButtonItem1
			' 
			Me.diagramCommandSaveFileAsBarButtonItem1.Id = 4
			Me.diagramCommandSaveFileAsBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSaveFileAsBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSaveFileAsBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSaveFileAsBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandSaveFileAsBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandSaveFileAsBarButtonItem1.Name = "diagramCommandSaveFileAsBarButtonItem1"
			' 
			' diagramCommandShowPrintPreviewBarButtonItem1
			' 
			Me.diagramCommandShowPrintPreviewBarButtonItem1.Id = 5
			Me.diagramCommandShowPrintPreviewBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandShowPrintPreviewBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandShowPrintPreviewBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandShowPrintPreviewBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandShowPrintPreviewBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandShowPrintPreviewBarButtonItem1.Name = "diagramCommandShowPrintPreviewBarButtonItem1"
			' 
			' diagramCommandPrintMenuBarSplitButtonItem1
			' 
			Me.diagramCommandPrintMenuBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
			Me.diagramCommandPrintMenuBarSplitButtonItem1.DropDownControl = Me.PrintMenuPopupMenu
			Me.diagramCommandPrintMenuBarSplitButtonItem1.Id = 6
			Me.diagramCommandPrintMenuBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPrintMenuBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPrintMenuBarSplitButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPrintMenuBarSplitButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPrintMenuBarSplitButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPrintMenuBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.Default
			Me.diagramCommandPrintMenuBarSplitButtonItem1.Name = "diagramCommandPrintMenuBarSplitButtonItem1"
			' 
			' PrintMenuPopupMenu
			' 
			Me.PrintMenuPopupMenu.ItemLinks.Add(Me.diagramCommandPrintBarButtonItem1)
			Me.PrintMenuPopupMenu.ItemLinks.Add(Me.diagramCommandQuickPrintBarButtonItem1)
			Me.PrintMenuPopupMenu.Name = "PrintMenuPopupMenu"
			Me.PrintMenuPopupMenu.Ribbon = Me.ribbonControl1
			' 
			' diagramCommandExportAsBarSplitButtonItem1
			' 
			Me.diagramCommandExportAsBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
			Me.diagramCommandExportAsBarSplitButtonItem1.DropDownControl = Me.ExportAsPopupMenu
			Me.diagramCommandExportAsBarSplitButtonItem1.Id = 9
			Me.diagramCommandExportAsBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandExportAsBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandExportAsBarSplitButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandExportAsBarSplitButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandExportAsBarSplitButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandExportAsBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.Default
			Me.diagramCommandExportAsBarSplitButtonItem1.Name = "diagramCommandExportAsBarSplitButtonItem1"
			' 
			' ExportAsPopupMenu
			' 
			Me.ExportAsPopupMenu.ItemLinks.Add(Me.diagramCommandExportDiagram_PNGBarButtonItem1)
			Me.ExportAsPopupMenu.ItemLinks.Add(Me.diagramCommandExportDiagram_JPEGBarButtonItem1)
			Me.ExportAsPopupMenu.ItemLinks.Add(Me.diagramCommandExportDiagram_BMPBarButtonItem1)
			Me.ExportAsPopupMenu.ItemLinks.Add(Me.diagramCommandExportDiagram_GIFBarButtonItem1)
			Me.ExportAsPopupMenu.Name = "ExportAsPopupMenu"
			Me.ExportAsPopupMenu.Ribbon = Me.ribbonControl1
			' 
			' diagramCommandUndoBarButtonItem1
			' 
			Me.diagramCommandUndoBarButtonItem1.Id = 14
			Me.diagramCommandUndoBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandUndoBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandUndoBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandUndoBarButtonItem1.Name = "diagramCommandUndoBarButtonItem1"
			' 
			' diagramCommandRedoBarButtonItem1
			' 
			Me.diagramCommandRedoBarButtonItem1.Id = 15
			Me.diagramCommandRedoBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandRedoBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandRedoBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandRedoBarButtonItem1.Name = "diagramCommandRedoBarButtonItem1"
			' 
			' diagramCommandPrintBarButtonItem1
			' 
			Me.diagramCommandPrintBarButtonItem1.Id = 7
			Me.diagramCommandPrintBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPrintBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPrintBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPrintBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPrintBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPrintBarButtonItem1.Name = "diagramCommandPrintBarButtonItem1"
			' 
			' diagramCommandQuickPrintBarButtonItem1
			' 
			Me.diagramCommandQuickPrintBarButtonItem1.Id = 8
			Me.diagramCommandQuickPrintBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandQuickPrintBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandQuickPrintBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandQuickPrintBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandQuickPrintBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandQuickPrintBarButtonItem1.Name = "diagramCommandQuickPrintBarButtonItem1"
			' 
			' diagramCommandExportDiagram_PNGBarButtonItem1
			' 
			Me.diagramCommandExportDiagram_PNGBarButtonItem1.Id = 10
			Me.diagramCommandExportDiagram_PNGBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandExportDiagram_PNGBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandExportDiagram_PNGBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandExportDiagram_PNGBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandExportDiagram_PNGBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandExportDiagram_PNGBarButtonItem1.Name = "diagramCommandExportDiagram_PNGBarButtonItem1"
			' 
			' diagramCommandExportDiagram_JPEGBarButtonItem1
			' 
			Me.diagramCommandExportDiagram_JPEGBarButtonItem1.Id = 11
			Me.diagramCommandExportDiagram_JPEGBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandExportDiagram_JPEGBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandExportDiagram_JPEGBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandExportDiagram_JPEGBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandExportDiagram_JPEGBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandExportDiagram_JPEGBarButtonItem1.Name = "diagramCommandExportDiagram_JPEGBarButtonItem1"
			Me.diagramCommandExportDiagram_JPEGBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' diagramCommandExportDiagram_BMPBarButtonItem1
			' 
			Me.diagramCommandExportDiagram_BMPBarButtonItem1.Id = 12
			Me.diagramCommandExportDiagram_BMPBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandExportDiagram_BMPBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandExportDiagram_BMPBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandExportDiagram_BMPBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandExportDiagram_BMPBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandExportDiagram_BMPBarButtonItem1.Name = "diagramCommandExportDiagram_BMPBarButtonItem1"
			Me.diagramCommandExportDiagram_BMPBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' diagramCommandExportDiagram_GIFBarButtonItem1
			' 
			Me.diagramCommandExportDiagram_GIFBarButtonItem1.Id = 13
			Me.diagramCommandExportDiagram_GIFBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandExportDiagram_GIFBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandExportDiagram_GIFBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandExportDiagram_GIFBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandExportDiagram_GIFBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandExportDiagram_GIFBarButtonItem1.Name = "diagramCommandExportDiagram_GIFBarButtonItem1"
			Me.diagramCommandExportDiagram_GIFBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' diagramStatusBarShapeInfoBarStaticItem1
			' 
			Me.diagramStatusBarShapeInfoBarStaticItem1.Id = 16
			Me.diagramStatusBarShapeInfoBarStaticItem1.Name = "diagramStatusBarShapeInfoBarStaticItem1"
			toolTipTitleItem1.Text = "Shape Info"
			superToolTip1.Items.Add(toolTipTitleItem1)
			Me.diagramStatusBarShapeInfoBarStaticItem1.SuperTip = superToolTip1
			Me.diagramStatusBarShapeInfoBarStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near
			Me.diagramStatusBarShapeInfoBarStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
			' 
			' diagramCommandStatusBarZoomEditorBarEditItem1
			' 
			Me.diagramCommandStatusBarZoomEditorBarEditItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
			Me.diagramCommandStatusBarZoomEditorBarEditItem1.Edit = Me.diagramRepositoryItemZoomTrackBar1
			Me.diagramCommandStatusBarZoomEditorBarEditItem1.EditWidth = 100
			Me.diagramCommandStatusBarZoomEditorBarEditItem1.Id = 17
			Me.diagramCommandStatusBarZoomEditorBarEditItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandStatusBarZoomEditorBarEditItem1.Name = "diagramCommandStatusBarZoomEditorBarEditItem1"
			' 
			' diagramRepositoryItemZoomTrackBar1
			' 
			Me.diagramRepositoryItemZoomTrackBar1.LabelAppearance.Options.UseTextOptions = True
			Me.diagramRepositoryItemZoomTrackBar1.LabelAppearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
			Me.diagramRepositoryItemZoomTrackBar1.LargeChange = 240
			Me.diagramRepositoryItemZoomTrackBar1.Maximum = 3600
			Me.diagramRepositoryItemZoomTrackBar1.Minimum = -3600
			Me.diagramRepositoryItemZoomTrackBar1.Name = "diagramRepositoryItemZoomTrackBar1"
			Me.diagramRepositoryItemZoomTrackBar1.SmallChange = 120
			Me.diagramRepositoryItemZoomTrackBar1.SmallChangeUseMode = DevExpress.XtraEditors.Repository.SmallChangeUseMode.ArrowKeysAndMouse
			' 
			' diagramContainerSizeRibbonPageGroup1
			' 
			Me.diagramContainerSizeRibbonPageGroup1.AllowTextClipping = False
			Me.diagramContainerSizeRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandContainerPaddingBarDropDownItem1)
			Me.diagramContainerSizeRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandContainerHeaderPaddingBarDropDownItem1)
			Me.diagramContainerSizeRibbonPageGroup1.Name = "diagramContainerSizeRibbonPageGroup1"
			' 
			' diagramFormatContainerRibbonPage1
			' 
			Me.diagramFormatContainerRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.diagramContainerSizeRibbonPageGroup1, Me.diagramContainerStylesRibbonPageGroup1})
			Me.diagramFormatContainerRibbonPage1.Name = "diagramFormatContainerRibbonPage1"
			' 
			' diagramContainerToolsRibbonPageCategory1
			' 
			Me.diagramContainerToolsRibbonPageCategory1.AutoStretchPageHeaders = True
			Me.diagramContainerToolsRibbonPageCategory1.Color = System.Drawing.Color.FromArgb((CInt((CByte(255)))), (CInt((CByte(157)))), (CInt((CByte(0)))))
			Me.diagramContainerToolsRibbonPageCategory1.Control = Me.diagramControl1
			Me.diagramContainerToolsRibbonPageCategory1.Name = "diagramContainerToolsRibbonPageCategory1"
			Me.diagramContainerToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() { Me.diagramFormatContainerRibbonPage1})
			' 
			' diagramCommandContainerPaddingBarDropDownItem1
			' 
			Me.diagramCommandContainerPaddingBarDropDownItem1.Id = 18
			Me.diagramCommandContainerPaddingBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerPaddingBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandContainerPaddingBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
            Me.diagramCommandContainerPaddingBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandContainerPaddingBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandContainerPaddingBarDropDownItem1.Name = "diagramCommandContainerPaddingBarDropDownItem1"
			Me.diagramCommandContainerPaddingBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerPadding_P0BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerPadding_P4BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerPadding_P8BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerPadding_P12BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerPadding_P16BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerPadding_P24BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerPadding_P32BarCheckItem1)
			})
			' 
			' diagramCommandContainerHeaderPaddingBarDropDownItem1
			' 
			Me.diagramCommandContainerHeaderPaddingBarDropDownItem1.Id = 19
			Me.diagramCommandContainerHeaderPaddingBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerHeaderPaddingBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandContainerHeaderPaddingBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
            Me.diagramCommandContainerHeaderPaddingBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandContainerHeaderPaddingBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandContainerHeaderPaddingBarDropDownItem1.Name = "diagramCommandContainerHeaderPaddingBarDropDownItem1"
			Me.diagramCommandContainerHeaderPaddingBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerHeaderPadding_P0BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerHeaderPadding_P4BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerHeaderPadding_P8BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerHeaderPadding_P12BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerHeaderPadding_P16BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerHeaderPadding_P24BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandContainerHeaderPadding_P32BarCheckItem1)
			})
			' 
			' diagramCommandContainerPadding_P0BarCheckItem1
			' 
			Me.diagramCommandContainerPadding_P0BarCheckItem1.Id = 20
			Me.diagramCommandContainerPadding_P0BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerPadding_P0BarCheckItem1.Name = "diagramCommandContainerPadding_P0BarCheckItem1"
			toolTipTitleItem2.Text = "0 px."
			superToolTip2.Items.Add(toolTipTitleItem2)
			Me.diagramCommandContainerPadding_P0BarCheckItem1.SuperTip = superToolTip2
			' 
			' diagramCommandContainerPadding_P4BarCheckItem1
			' 
			Me.diagramCommandContainerPadding_P4BarCheckItem1.Id = 21
			Me.diagramCommandContainerPadding_P4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerPadding_P4BarCheckItem1.Name = "diagramCommandContainerPadding_P4BarCheckItem1"
			toolTipTitleItem3.Text = "4 px."
			superToolTip3.Items.Add(toolTipTitleItem3)
			Me.diagramCommandContainerPadding_P4BarCheckItem1.SuperTip = superToolTip3
			' 
			' diagramCommandContainerPadding_P8BarCheckItem1
			' 
			Me.diagramCommandContainerPadding_P8BarCheckItem1.Id = 22
			Me.diagramCommandContainerPadding_P8BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerPadding_P8BarCheckItem1.Name = "diagramCommandContainerPadding_P8BarCheckItem1"
			toolTipTitleItem4.Text = "8 px."
			superToolTip4.Items.Add(toolTipTitleItem4)
			Me.diagramCommandContainerPadding_P8BarCheckItem1.SuperTip = superToolTip4
			' 
			' diagramCommandContainerPadding_P12BarCheckItem1
			' 
			Me.diagramCommandContainerPadding_P12BarCheckItem1.Id = 23
			Me.diagramCommandContainerPadding_P12BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerPadding_P12BarCheckItem1.Name = "diagramCommandContainerPadding_P12BarCheckItem1"
			toolTipTitleItem5.Text = "12 px."
			superToolTip5.Items.Add(toolTipTitleItem5)
			Me.diagramCommandContainerPadding_P12BarCheckItem1.SuperTip = superToolTip5
			' 
			' diagramCommandContainerPadding_P16BarCheckItem1
			' 
			Me.diagramCommandContainerPadding_P16BarCheckItem1.Id = 24
			Me.diagramCommandContainerPadding_P16BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerPadding_P16BarCheckItem1.Name = "diagramCommandContainerPadding_P16BarCheckItem1"
			toolTipTitleItem6.Text = "16 px."
			superToolTip6.Items.Add(toolTipTitleItem6)
			Me.diagramCommandContainerPadding_P16BarCheckItem1.SuperTip = superToolTip6
			' 
			' diagramCommandContainerPadding_P24BarCheckItem1
			' 
			Me.diagramCommandContainerPadding_P24BarCheckItem1.Id = 25
			Me.diagramCommandContainerPadding_P24BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerPadding_P24BarCheckItem1.Name = "diagramCommandContainerPadding_P24BarCheckItem1"
			toolTipTitleItem7.Text = "24 px."
			superToolTip7.Items.Add(toolTipTitleItem7)
			Me.diagramCommandContainerPadding_P24BarCheckItem1.SuperTip = superToolTip7
			' 
			' diagramCommandContainerPadding_P32BarCheckItem1
			' 
			Me.diagramCommandContainerPadding_P32BarCheckItem1.Id = 26
			Me.diagramCommandContainerPadding_P32BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerPadding_P32BarCheckItem1.Name = "diagramCommandContainerPadding_P32BarCheckItem1"
			toolTipTitleItem8.Text = "32 px."
			superToolTip8.Items.Add(toolTipTitleItem8)
			Me.diagramCommandContainerPadding_P32BarCheckItem1.SuperTip = superToolTip8
			' 
			' diagramCommandContainerHeaderPadding_P0BarCheckItem1
			' 
			Me.diagramCommandContainerHeaderPadding_P0BarCheckItem1.Id = 27
			Me.diagramCommandContainerHeaderPadding_P0BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerHeaderPadding_P0BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P0BarCheckItem1"
			toolTipTitleItem9.Text = "0 px."
			superToolTip9.Items.Add(toolTipTitleItem9)
			Me.diagramCommandContainerHeaderPadding_P0BarCheckItem1.SuperTip = superToolTip9
			' 
			' diagramCommandContainerHeaderPadding_P4BarCheckItem1
			' 
			Me.diagramCommandContainerHeaderPadding_P4BarCheckItem1.Id = 28
			Me.diagramCommandContainerHeaderPadding_P4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerHeaderPadding_P4BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P4BarCheckItem1"
			toolTipTitleItem10.Text = "4 px."
			superToolTip10.Items.Add(toolTipTitleItem10)
			Me.diagramCommandContainerHeaderPadding_P4BarCheckItem1.SuperTip = superToolTip10
			' 
			' diagramCommandContainerHeaderPadding_P8BarCheckItem1
			' 
			Me.diagramCommandContainerHeaderPadding_P8BarCheckItem1.Id = 29
			Me.diagramCommandContainerHeaderPadding_P8BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerHeaderPadding_P8BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P8BarCheckItem1"
			toolTipTitleItem11.Text = "8 px."
			superToolTip11.Items.Add(toolTipTitleItem11)
			Me.diagramCommandContainerHeaderPadding_P8BarCheckItem1.SuperTip = superToolTip11
			' 
			' diagramCommandContainerHeaderPadding_P12BarCheckItem1
			' 
			Me.diagramCommandContainerHeaderPadding_P12BarCheckItem1.Id = 30
			Me.diagramCommandContainerHeaderPadding_P12BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerHeaderPadding_P12BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P12BarCheckItem1"
			toolTipTitleItem12.Text = "12 px."
			superToolTip12.Items.Add(toolTipTitleItem12)
			Me.diagramCommandContainerHeaderPadding_P12BarCheckItem1.SuperTip = superToolTip12
			' 
			' diagramCommandContainerHeaderPadding_P16BarCheckItem1
			' 
			Me.diagramCommandContainerHeaderPadding_P16BarCheckItem1.Id = 31
			Me.diagramCommandContainerHeaderPadding_P16BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerHeaderPadding_P16BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P16BarCheckItem1"
			toolTipTitleItem13.Text = "16 px."
			superToolTip13.Items.Add(toolTipTitleItem13)
			Me.diagramCommandContainerHeaderPadding_P16BarCheckItem1.SuperTip = superToolTip13
			' 
			' diagramCommandContainerHeaderPadding_P24BarCheckItem1
			' 
			Me.diagramCommandContainerHeaderPadding_P24BarCheckItem1.Id = 32
			Me.diagramCommandContainerHeaderPadding_P24BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerHeaderPadding_P24BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P24BarCheckItem1"
			toolTipTitleItem14.Text = "24 px."
			superToolTip14.Items.Add(toolTipTitleItem14)
			Me.diagramCommandContainerHeaderPadding_P24BarCheckItem1.SuperTip = superToolTip14
			' 
			' diagramCommandContainerHeaderPadding_P32BarCheckItem1
			' 
			Me.diagramCommandContainerHeaderPadding_P32BarCheckItem1.Id = 33
			Me.diagramCommandContainerHeaderPadding_P32BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandContainerHeaderPadding_P32BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P32BarCheckItem1"
			toolTipTitleItem15.Text = "32 px."
			superToolTip15.Items.Add(toolTipTitleItem15)
			Me.diagramCommandContainerHeaderPadding_P32BarCheckItem1.SuperTip = superToolTip15
			' 
			' diagramContainerStylesRibbonPageGroup1
			' 
			Me.diagramContainerStylesRibbonPageGroup1.AllowTextClipping = False
			Me.diagramContainerStylesRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandContainerStylesBarGalleryItem1)
			Me.diagramContainerStylesRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandShowContainerHeaderBarCheckItem1)
			Me.diagramContainerStylesRibbonPageGroup1.Name = "diagramContainerStylesRibbonPageGroup1"
			' 
			' diagramCommandContainerStylesBarGalleryItem1
			' 
			' 
			' 
			' 
			Me.diagramCommandContainerStylesBarGalleryItem1.Gallery.ColumnCount = 6
			Me.diagramCommandContainerStylesBarGalleryItem1.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { galleryItemGroup1})
			Me.diagramCommandContainerStylesBarGalleryItem1.Gallery.ImageSize = New System.Drawing.Size(65, 46)
			Me.diagramCommandContainerStylesBarGalleryItem1.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio
			skinPaddingEdges1.Left = 5
			skinPaddingEdges1.Right = 5
			Me.diagramCommandContainerStylesBarGalleryItem1.Gallery.ItemImagePadding = skinPaddingEdges1
			Me.diagramCommandContainerStylesBarGalleryItem1.Gallery.RowCount = 1
			Me.diagramCommandContainerStylesBarGalleryItem1.Id = 34
			Me.diagramCommandContainerStylesBarGalleryItem1.Name = "diagramCommandContainerStylesBarGalleryItem1"
			' 
			' diagramCommandShowContainerHeaderBarCheckItem1
			' 
			Me.diagramCommandShowContainerHeaderBarCheckItem1.Id = 35
			Me.diagramCommandShowContainerHeaderBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandShowContainerHeaderBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandShowContainerHeaderBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandShowContainerHeaderBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandShowContainerHeaderBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandShowContainerHeaderBarCheckItem1.Name = "diagramCommandShowContainerHeaderBarCheckItem1"
			' 
			' diagramImageTools_ArrangeRibbonPageGroup1
			' 
			Me.diagramImageTools_ArrangeRibbonPageGroup1.AllowTextClipping = False
			Me.diagramImageTools_ArrangeRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1)
			Me.diagramImageTools_ArrangeRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1)
			Me.diagramImageTools_ArrangeRibbonPageGroup1.Name = "diagramImageTools_ArrangeRibbonPageGroup1"
			' 
			' diagramFormatImageRibbonPage1
			' 
			Me.diagramFormatImageRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.diagramImageTools_ArrangeRibbonPageGroup1, Me.diagramImageTools_PictureRibbonPageGroup1})
			Me.diagramFormatImageRibbonPage1.Name = "diagramFormatImageRibbonPage1"
			' 
			' diagramImageToolsRibbonPageCategory1
			' 
			Me.diagramImageToolsRibbonPageCategory1.AutoStretchPageHeaders = True
			Me.diagramImageToolsRibbonPageCategory1.Color = System.Drawing.Color.FromArgb((CInt((CByte(73)))), (CInt((CByte(163)))), (CInt((CByte(73)))))
			Me.diagramImageToolsRibbonPageCategory1.Control = Me.diagramControl1
			Me.diagramImageToolsRibbonPageCategory1.Name = "diagramImageToolsRibbonPageCategory1"
			Me.diagramImageToolsRibbonPageCategory1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() { Me.diagramFormatImageRibbonPage1})
			' 
			' diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1
			' 
			Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
			Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.DropDownControl = Me.ImageToolsBringToFrontContainerPopupMenu
			Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.Id = 36
			Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.ImageOptions.Ima" & "ge"), System.Drawing.Image))
			Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.ImageOptions.Lar" & "geImage"), System.Drawing.Image))
			Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.Default
			Me.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.Name = "diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1"
			' 
			' ImageToolsBringToFrontContainerPopupMenu
			' 
			Me.ImageToolsBringToFrontContainerPopupMenu.ItemLinks.Add(Me.diagramCommandBringForwardBarButtonItem1)
			Me.ImageToolsBringToFrontContainerPopupMenu.ItemLinks.Add(Me.diagramCommandBringToFrontBarButtonItem1)
			Me.ImageToolsBringToFrontContainerPopupMenu.Name = "ImageToolsBringToFrontContainerPopupMenu"
			Me.ImageToolsBringToFrontContainerPopupMenu.Ribbon = Me.ribbonControl1
			' 
			' diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1
			' 
			Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
			Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.DropDownControl = Me.ImageToolsSendToBackContainerPopupMenu
			Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.Id = 37
			Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.ImageOptions.Image" & ""), System.Drawing.Image))
			Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.ImageOptions.Large" & "Image"), System.Drawing.Image))
			Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.Default
			Me.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.Name = "diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1"
			' 
			' ImageToolsSendToBackContainerPopupMenu
			' 
			Me.ImageToolsSendToBackContainerPopupMenu.ItemLinks.Add(Me.diagramCommandSendBackwardBarButtonItem1)
			Me.ImageToolsSendToBackContainerPopupMenu.ItemLinks.Add(Me.diagramCommandSendToBackBarButtonItem1)
			Me.ImageToolsSendToBackContainerPopupMenu.Name = "ImageToolsSendToBackContainerPopupMenu"
			Me.ImageToolsSendToBackContainerPopupMenu.Ribbon = Me.ribbonControl1
			' 
			' diagramCommandBringForwardBarButtonItem1
			' 
			Me.diagramCommandBringForwardBarButtonItem1.Id = 38
			Me.diagramCommandBringForwardBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandBringForwardBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandBringForwardBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandBringForwardBarButtonItem1.Name = "diagramCommandBringForwardBarButtonItem1"
			' 
			' diagramCommandBringToFrontBarButtonItem1
			' 
			Me.diagramCommandBringToFrontBarButtonItem1.Id = 39
			Me.diagramCommandBringToFrontBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandBringToFrontBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandBringToFrontBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandBringToFrontBarButtonItem1.Name = "diagramCommandBringToFrontBarButtonItem1"
			' 
			' diagramCommandSendBackwardBarButtonItem1
			' 
			Me.diagramCommandSendBackwardBarButtonItem1.Id = 40
			Me.diagramCommandSendBackwardBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSendBackwardBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSendBackwardBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSendBackwardBarButtonItem1.Name = "diagramCommandSendBackwardBarButtonItem1"
			' 
			' diagramCommandSendToBackBarButtonItem1
			' 
			Me.diagramCommandSendToBackBarButtonItem1.Id = 41
			Me.diagramCommandSendToBackBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSendToBackBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSendToBackBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSendToBackBarButtonItem1.Name = "diagramCommandSendToBackBarButtonItem1"
			' 
			' diagramImageTools_PictureRibbonPageGroup1
			' 
			Me.diagramImageTools_PictureRibbonPageGroup1.AllowTextClipping = False
			Me.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandImageToolsRotateBarDropDownItem1)
			Me.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandImageToolsStretchModeBarDropDownItem1)
			Me.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1)
			Me.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandResetSelectedImagesBarButtonItem1)
			Me.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandLoadImageBarButtonItem1)
			Me.diagramImageTools_PictureRibbonPageGroup1.Name = "diagramImageTools_PictureRibbonPageGroup1"
			' 
			' diagramCommandImageToolsRotateBarDropDownItem1
			' 
			Me.diagramCommandImageToolsRotateBarDropDownItem1.Id = 42
			Me.diagramCommandImageToolsRotateBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsRotateBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandImageToolsRotateBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
            Me.diagramCommandImageToolsRotateBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandImageToolsRotateBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandImageToolsRotateBarDropDownItem1.Name = "diagramCommandImageToolsRotateBarDropDownItem1"
			Me.diagramCommandImageToolsRotateBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandRotate_Right90BarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandRotate_Left90BarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandFlipImage_VerticalBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandFlipImage_HorizontalBarButtonItem1)
			})
			' 
			' diagramCommandImageToolsStretchModeBarDropDownItem1
			' 
			Me.diagramCommandImageToolsStretchModeBarDropDownItem1.Id = 43
			Me.diagramCommandImageToolsStretchModeBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsStretchModeBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandImageToolsStretchModeBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
            Me.diagramCommandImageToolsStretchModeBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandImageToolsStretchModeBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandImageToolsStretchModeBarDropDownItem1.Name = "diagramCommandImageToolsStretchModeBarDropDownItem1"
			Me.diagramCommandImageToolsStretchModeBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1)
			})
			' 
			' diagramCommandImageToolsSetImageScaleBarDropDownItem1
			' 
			Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1.Enabled = False
			Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1.Id = 44
			Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandImageToolsSetImageScaleBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
            Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandImageToolsSetImageScaleBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1.Name = "diagramCommandImageToolsSetImageScaleBarDropDownItem1"
			Me.diagramCommandImageToolsSetImageScaleBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandImageToolsSetImageScale_1BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandImageToolsSetImageScale_2BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandImageToolsSetImageScale_4BarCheckItem1)
			})
			' 
			' diagramCommandResetSelectedImagesBarButtonItem1
			' 
			Me.diagramCommandResetSelectedImagesBarButtonItem1.Id = 45
			Me.diagramCommandResetSelectedImagesBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandResetSelectedImagesBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandResetSelectedImagesBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandResetSelectedImagesBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandResetSelectedImagesBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandResetSelectedImagesBarButtonItem1.Name = "diagramCommandResetSelectedImagesBarButtonItem1"
			' 
			' diagramCommandLoadImageBarButtonItem1
			' 
			Me.diagramCommandLoadImageBarButtonItem1.Id = 46
			Me.diagramCommandLoadImageBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandLoadImageBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandLoadImageBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandLoadImageBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandLoadImageBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandLoadImageBarButtonItem1.Name = "diagramCommandLoadImageBarButtonItem1"
			' 
			' diagramCommandRotate_Right90BarButtonItem1
			' 
			Me.diagramCommandRotate_Right90BarButtonItem1.Id = 47
			Me.diagramCommandRotate_Right90BarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandRotate_Right90BarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandRotate_Right90BarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandRotate_Right90BarButtonItem1.Name = "diagramCommandRotate_Right90BarButtonItem1"
			' 
			' diagramCommandRotate_Left90BarButtonItem1
			' 
			Me.diagramCommandRotate_Left90BarButtonItem1.Id = 48
			Me.diagramCommandRotate_Left90BarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandRotate_Left90BarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandRotate_Left90BarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandRotate_Left90BarButtonItem1.Name = "diagramCommandRotate_Left90BarButtonItem1"
			' 
			' diagramCommandFlipImage_VerticalBarButtonItem1
			' 
			Me.diagramCommandFlipImage_VerticalBarButtonItem1.Id = 49
			Me.diagramCommandFlipImage_VerticalBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandFlipImage_VerticalBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandFlipImage_VerticalBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandFlipImage_VerticalBarButtonItem1.Name = "diagramCommandFlipImage_VerticalBarButtonItem1"
			' 
			' diagramCommandFlipImage_HorizontalBarButtonItem1
			' 
			Me.diagramCommandFlipImage_HorizontalBarButtonItem1.Id = 50
			Me.diagramCommandFlipImage_HorizontalBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandFlipImage_HorizontalBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandFlipImage_HorizontalBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandFlipImage_HorizontalBarButtonItem1.Name = "diagramCommandFlipImage_HorizontalBarButtonItem1"
			' 
			' diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1
			' 
			Me.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1.Id = 51
			Me.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1.ImageOptions.Imag" & "e"), System.Drawing.Image))
			Me.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1.Name = "diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1"
			' 
			' diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1
			' 
			Me.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1.Id = 52
			Me.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1.ImageOptions.Imag" & "e"), System.Drawing.Image))
			Me.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1.Name = "diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1"
			' 
			' diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1
			' 
			Me.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1.Id = 53
			Me.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1.ImageOption" & "s.Image"), System.Drawing.Image))
			Me.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1.Name = "diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1"
			' 
			' diagramCommandImageToolsSetImageScale_0_25BarCheckItem1
			' 
			Me.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1.Id = 54
			Me.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_0_25BarCheckItem1"
			toolTipTitleItem16.Text = "25 %"
			superToolTip16.Items.Add(toolTipTitleItem16)
			Me.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1.SuperTip = superToolTip16
			' 
			' diagramCommandImageToolsSetImageScale_0_5BarCheckItem1
			' 
			Me.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1.Id = 55
			Me.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_0_5BarCheckItem1"
			toolTipTitleItem17.Text = "50 %"
			superToolTip17.Items.Add(toolTipTitleItem17)
			Me.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1.SuperTip = superToolTip17
			' 
			' diagramCommandImageToolsSetImageScale_0_75BarCheckItem1
			' 
			Me.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1.Id = 56
			Me.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_0_75BarCheckItem1"
			toolTipTitleItem18.Text = "75 %"
			superToolTip18.Items.Add(toolTipTitleItem18)
			Me.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1.SuperTip = superToolTip18
			' 
			' diagramCommandImageToolsSetImageScale_1BarCheckItem1
			' 
			Me.diagramCommandImageToolsSetImageScale_1BarCheckItem1.Id = 57
			Me.diagramCommandImageToolsSetImageScale_1BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsSetImageScale_1BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_1BarCheckItem1"
			toolTipTitleItem19.Text = "100 %"
			superToolTip19.Items.Add(toolTipTitleItem19)
			Me.diagramCommandImageToolsSetImageScale_1BarCheckItem1.SuperTip = superToolTip19
			' 
			' diagramCommandImageToolsSetImageScale_1_5BarCheckItem1
			' 
			Me.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1.Id = 58
			Me.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_1_5BarCheckItem1"
			toolTipTitleItem20.Text = "150 %"
			superToolTip20.Items.Add(toolTipTitleItem20)
			Me.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1.SuperTip = superToolTip20
			' 
			' diagramCommandImageToolsSetImageScale_2BarCheckItem1
			' 
			Me.diagramCommandImageToolsSetImageScale_2BarCheckItem1.Id = 59
			Me.diagramCommandImageToolsSetImageScale_2BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsSetImageScale_2BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_2BarCheckItem1"
			toolTipTitleItem21.Text = "200 %"
			superToolTip21.Items.Add(toolTipTitleItem21)
			Me.diagramCommandImageToolsSetImageScale_2BarCheckItem1.SuperTip = superToolTip21
			' 
			' diagramCommandImageToolsSetImageScale_4BarCheckItem1
			' 
			Me.diagramCommandImageToolsSetImageScale_4BarCheckItem1.Id = 60
			Me.diagramCommandImageToolsSetImageScale_4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandImageToolsSetImageScale_4BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_4BarCheckItem1"
			toolTipTitleItem22.Text = "400 %"
			superToolTip22.Items.Add(toolTipTitleItem22)
			Me.diagramCommandImageToolsSetImageScale_4BarCheckItem1.SuperTip = superToolTip22
			' 
			' diagramShowRibbonPageGroup1
			' 
			Me.diagramShowRibbonPageGroup1.AllowTextClipping = False
			Me.diagramShowRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandShowRulersBarCheckItem1)
			Me.diagramShowRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandShowGridBarCheckItem1)
			Me.diagramShowRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandShowPageBreaksBarCheckItem1)
			Me.diagramShowRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandPanesBarDropDownItem1)
			Me.diagramShowRibbonPageGroup1.Name = "diagramShowRibbonPageGroup1"
			' 
			' diagramViewRibbonPage1
			' 
			Me.diagramViewRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.diagramShowRibbonPageGroup1, Me.diagramZoomRibbonPageGroup1})
			Me.diagramViewRibbonPage1.Name = "diagramViewRibbonPage1"
			' 
			' diagramCommandShowRulersBarCheckItem1
			' 
			Me.diagramCommandShowRulersBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
			Me.diagramCommandShowRulersBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.diagramCommandShowRulersBarCheckItem1.Id = 61
			Me.diagramCommandShowRulersBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandShowRulersBarCheckItem1.Name = "diagramCommandShowRulersBarCheckItem1"
			Me.diagramCommandShowRulersBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandShowGridBarCheckItem1
			' 
			Me.diagramCommandShowGridBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
			Me.diagramCommandShowGridBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.diagramCommandShowGridBarCheckItem1.Id = 62
			Me.diagramCommandShowGridBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandShowGridBarCheckItem1.Name = "diagramCommandShowGridBarCheckItem1"
			Me.diagramCommandShowGridBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandShowPageBreaksBarCheckItem1
			' 
			Me.diagramCommandShowPageBreaksBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
			Me.diagramCommandShowPageBreaksBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.diagramCommandShowPageBreaksBarCheckItem1.Id = 63
			Me.diagramCommandShowPageBreaksBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandShowPageBreaksBarCheckItem1.Name = "diagramCommandShowPageBreaksBarCheckItem1"
			Me.diagramCommandShowPageBreaksBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandPanesBarDropDownItem1
			' 
			Me.diagramCommandPanesBarDropDownItem1.Id = 64
			Me.diagramCommandPanesBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPanesBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPanesBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
            Me.diagramCommandPanesBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPanesBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandPanesBarDropDownItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.LargeImagesText
			Me.diagramCommandPanesBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandShapesPanelBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPropertiesPanelBarCheckItem1)
			})
			Me.diagramCommandPanesBarDropDownItem1.Name = "diagramCommandPanesBarDropDownItem1"
			Me.diagramCommandPanesBarDropDownItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' diagramCommandShapesPanelBarCheckItem1
			' 
			Me.diagramCommandShapesPanelBarCheckItem1.Id = 65
			Me.diagramCommandShapesPanelBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandShapesPanelBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandShapesPanelBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandShapesPanelBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandShapesPanelBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandShapesPanelBarCheckItem1.Name = "diagramCommandShapesPanelBarCheckItem1"
			Me.diagramCommandShapesPanelBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' diagramCommandPropertiesPanelBarCheckItem1
			' 
			Me.diagramCommandPropertiesPanelBarCheckItem1.Id = 66
			Me.diagramCommandPropertiesPanelBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPropertiesPanelBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPropertiesPanelBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPropertiesPanelBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPropertiesPanelBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPropertiesPanelBarCheckItem1.Name = "diagramCommandPropertiesPanelBarCheckItem1"
			Me.diagramCommandPropertiesPanelBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' diagramZoomRibbonPageGroup1
			' 
			Me.diagramZoomRibbonPageGroup1.AllowTextClipping = False
			Me.diagramZoomRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandFitToPageBarButtonItem1)
			Me.diagramZoomRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandFitToWidthBarButtonItem1)
			Me.diagramZoomRibbonPageGroup1.Name = "diagramZoomRibbonPageGroup1"
			' 
			' diagramCommandFitToPageBarButtonItem1
			' 
			Me.diagramCommandFitToPageBarButtonItem1.Id = 67
			Me.diagramCommandFitToPageBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandFitToPageBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandFitToPageBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandFitToPageBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandFitToPageBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandFitToPageBarButtonItem1.Name = "diagramCommandFitToPageBarButtonItem1"
			Me.diagramCommandFitToPageBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandFitToWidthBarButtonItem1
			' 
			Me.diagramCommandFitToWidthBarButtonItem1.Id = 68
			Me.diagramCommandFitToWidthBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandFitToWidthBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandFitToWidthBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandFitToWidthBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandFitToWidthBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandFitToWidthBarButtonItem1.Name = "diagramCommandFitToWidthBarButtonItem1"
			Me.diagramCommandFitToWidthBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramPageSetupRibbonPageGroup1
			' 
			Me.diagramPageSetupRibbonPageGroup1.AllowTextClipping = False
			Me.diagramPageSetupRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandPageOrientationBarDropDownItem1)
			Me.diagramPageSetupRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandPageSizeBarDropDownItem1)
			Me.diagramPageSetupRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandAutoSizeBarDropDownItem1)
			Me.diagramPageSetupRibbonPageGroup1.Name = "diagramPageSetupRibbonPageGroup1"
			' 
			' diagramDesignRibbonPage1
			' 
			Me.diagramDesignRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.diagramPageSetupRibbonPageGroup1, Me.diagramThemesRibbonPageGroup1, Me.diagramOptionsRibbonPageGroup1, Me.diagramTreeLayoutRibbonPageGroup1})
			Me.diagramDesignRibbonPage1.Name = "diagramDesignRibbonPage1"
			' 
			' diagramCommandPageOrientationBarDropDownItem1
			' 
			Me.diagramCommandPageOrientationBarDropDownItem1.Id = 69
			Me.diagramCommandPageOrientationBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageOrientationBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageOrientationBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageOrientationBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageOrientationBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandPageOrientationBarDropDownItem1.Name = "diagramCommandPageOrientationBarDropDownItem1"
            Me.diagramCommandPageOrientationBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
                New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageOrientation_HorizontalBarCheckItem1),
                New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageOrientation_VerticalBarCheckItem1)
            })
			' 
			' diagramCommandPageSizeBarDropDownItem1
			' 
			Me.diagramCommandPageSizeBarDropDownItem1.Id = 70
			Me.diagramCommandPageSizeBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSizeBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSizeBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
            Me.diagramCommandPageSizeBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSizeBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandPageSizeBarDropDownItem1.Name = "diagramCommandPageSizeBarDropDownItem1"
			Me.diagramCommandPageSizeBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_LetterBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_TabloidBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_LegalBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_StatementBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_ExecutiveBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_A3BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_A4BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_A5BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_B4BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandPageSize_B5BarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandFitToDrawingBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandSetPageParameters_PageSizeBarButtonItem1)
			})
			' 
			' diagramCommandAutoSizeBarDropDownItem1
			' 
			Me.diagramCommandAutoSizeBarDropDownItem1.Id = 71
			Me.diagramCommandAutoSizeBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandAutoSizeBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandAutoSizeBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
            Me.diagramCommandAutoSizeBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandAutoSizeBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandAutoSizeBarDropDownItem1.Name = "diagramCommandAutoSizeBarDropDownItem1"
			Me.diagramCommandAutoSizeBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandAutoSize_NoneBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandAutoSize_AutoSizeBarCheckItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandAutoSize_FillBarCheckItem1)
			})
			' 
			' diagramCommandPageOrientation_HorizontalBarCheckItem1
			' 
			Me.diagramCommandPageOrientation_HorizontalBarCheckItem1.Id = 72
			Me.diagramCommandPageOrientation_HorizontalBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageOrientation_HorizontalBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageOrientation_HorizontalBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageOrientation_HorizontalBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageOrientation_HorizontalBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageOrientation_HorizontalBarCheckItem1.Name = "diagramCommandPageOrientation_HorizontalBarCheckItem1"
			toolTipTitleItem23.Text = "Landscape"
			superToolTip23.Items.Add(toolTipTitleItem23)
			Me.diagramCommandPageOrientation_HorizontalBarCheckItem1.SuperTip = superToolTip23
			' 
			' diagramCommandPageOrientation_VerticalBarCheckItem1
			' 
			Me.diagramCommandPageOrientation_VerticalBarCheckItem1.Id = 73
			Me.diagramCommandPageOrientation_VerticalBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageOrientation_VerticalBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageOrientation_VerticalBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageOrientation_VerticalBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageOrientation_VerticalBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageOrientation_VerticalBarCheckItem1.Name = "diagramCommandPageOrientation_VerticalBarCheckItem1"
			toolTipTitleItem24.Text = "Portrait"
			superToolTip24.Items.Add(toolTipTitleItem24)
			Me.diagramCommandPageOrientation_VerticalBarCheckItem1.SuperTip = superToolTip24
			' 
			' diagramCommandPageSize_LetterBarCheckItem1
			' 
			Me.diagramCommandPageSize_LetterBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_LetterBarCheckItem1.Id = 74
			Me.diagramCommandPageSize_LetterBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_LetterBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_LetterBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_LetterBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_LetterBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_LetterBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_LetterBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_LetterBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_LetterBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_LetterBarCheckItem1.Name = "diagramCommandPageSize_LetterBarCheckItem1"
			superToolTip25.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem25.Text = "<b>Letter</b><br>8,5"" x 11"""
			superToolTip25.Items.Add(toolTipTitleItem25)
			Me.diagramCommandPageSize_LetterBarCheckItem1.SuperTip = superToolTip25
			' 
			' diagramCommandPageSize_TabloidBarCheckItem1
			' 
			Me.diagramCommandPageSize_TabloidBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_TabloidBarCheckItem1.Id = 75
			Me.diagramCommandPageSize_TabloidBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_TabloidBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_TabloidBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_TabloidBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_TabloidBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_TabloidBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_TabloidBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_TabloidBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_TabloidBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_TabloidBarCheckItem1.Name = "diagramCommandPageSize_TabloidBarCheckItem1"
			superToolTip26.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem26.Text = "<b>Tabloid</b><br>11"" x 17"""
			superToolTip26.Items.Add(toolTipTitleItem26)
			Me.diagramCommandPageSize_TabloidBarCheckItem1.SuperTip = superToolTip26
			' 
			' diagramCommandPageSize_LegalBarCheckItem1
			' 
			Me.diagramCommandPageSize_LegalBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_LegalBarCheckItem1.Id = 76
			Me.diagramCommandPageSize_LegalBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_LegalBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_LegalBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_LegalBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_LegalBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_LegalBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_LegalBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_LegalBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_LegalBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_LegalBarCheckItem1.Name = "diagramCommandPageSize_LegalBarCheckItem1"
			superToolTip27.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem27.Text = "<b>Legal</b><br>8,5"" x 14"""
			superToolTip27.Items.Add(toolTipTitleItem27)
			Me.diagramCommandPageSize_LegalBarCheckItem1.SuperTip = superToolTip27
			' 
			' diagramCommandPageSize_StatementBarCheckItem1
			' 
			Me.diagramCommandPageSize_StatementBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_StatementBarCheckItem1.Id = 77
			Me.diagramCommandPageSize_StatementBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_StatementBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_StatementBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_StatementBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_StatementBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_StatementBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_StatementBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_StatementBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_StatementBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_StatementBarCheckItem1.Name = "diagramCommandPageSize_StatementBarCheckItem1"
			superToolTip28.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem28.Text = "<b>Statement</b><br>5,5"" x 8,5"""
			superToolTip28.Items.Add(toolTipTitleItem28)
			Me.diagramCommandPageSize_StatementBarCheckItem1.SuperTip = superToolTip28
			' 
			' diagramCommandPageSize_ExecutiveBarCheckItem1
			' 
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.Id = 78
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_ExecutiveBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_ExecutiveBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.Name = "diagramCommandPageSize_ExecutiveBarCheckItem1"
			superToolTip29.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem29.Text = "<b>Executive</b><br>7,25"" x 10,5"""
			superToolTip29.Items.Add(toolTipTitleItem29)
			Me.diagramCommandPageSize_ExecutiveBarCheckItem1.SuperTip = superToolTip29
			' 
			' diagramCommandPageSize_A3BarCheckItem1
			' 
			Me.diagramCommandPageSize_A3BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_A3BarCheckItem1.Id = 79
			Me.diagramCommandPageSize_A3BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_A3BarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_A3BarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_A3BarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_A3BarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_A3BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_A3BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_A3BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_A3BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_A3BarCheckItem1.Name = "diagramCommandPageSize_A3BarCheckItem1"
			superToolTip30.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem30.Text = "<b>A3</b><br>11,7"" x 16,53"""
			superToolTip30.Items.Add(toolTipTitleItem30)
			Me.diagramCommandPageSize_A3BarCheckItem1.SuperTip = superToolTip30
			' 
			' diagramCommandPageSize_A4BarCheckItem1
			' 
			Me.diagramCommandPageSize_A4BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_A4BarCheckItem1.Id = 80
			Me.diagramCommandPageSize_A4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_A4BarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_A4BarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_A4BarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_A4BarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_A4BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_A4BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_A4BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_A4BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_A4BarCheckItem1.Name = "diagramCommandPageSize_A4BarCheckItem1"
			superToolTip31.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem31.Text = "<b>A4</b><br>8,27"" x 11,7"""
			superToolTip31.Items.Add(toolTipTitleItem31)
			Me.diagramCommandPageSize_A4BarCheckItem1.SuperTip = superToolTip31
			' 
			' diagramCommandPageSize_A5BarCheckItem1
			' 
			Me.diagramCommandPageSize_A5BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_A5BarCheckItem1.Id = 81
			Me.diagramCommandPageSize_A5BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_A5BarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_A5BarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_A5BarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_A5BarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_A5BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_A5BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_A5BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_A5BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_A5BarCheckItem1.Name = "diagramCommandPageSize_A5BarCheckItem1"
			superToolTip32.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem32.Text = "<b>A5</b><br>5,82"" x 8,27"""
			superToolTip32.Items.Add(toolTipTitleItem32)
			Me.diagramCommandPageSize_A5BarCheckItem1.SuperTip = superToolTip32
			' 
			' diagramCommandPageSize_B4BarCheckItem1
			' 
			Me.diagramCommandPageSize_B4BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_B4BarCheckItem1.Id = 82
			Me.diagramCommandPageSize_B4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_B4BarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_B4BarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_B4BarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_B4BarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_B4BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_B4BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_B4BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_B4BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_B4BarCheckItem1.Name = "diagramCommandPageSize_B4BarCheckItem1"
			superToolTip33.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem33.Text = "<b>B4 (JIS)</b><br>10,11"" x 14,33"""
			superToolTip33.Items.Add(toolTipTitleItem33)
			Me.diagramCommandPageSize_B4BarCheckItem1.SuperTip = superToolTip33
			' 
			' diagramCommandPageSize_B5BarCheckItem1
			' 
			Me.diagramCommandPageSize_B5BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandPageSize_B5BarCheckItem1.Id = 83
			Me.diagramCommandPageSize_B5BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPageSize_B5BarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPageSize_B5BarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPageSize_B5BarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPageSize_B5BarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPageSize_B5BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = True
			Me.diagramCommandPageSize_B5BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_B5BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = True
			Me.diagramCommandPageSize_B5BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
			Me.diagramCommandPageSize_B5BarCheckItem1.Name = "diagramCommandPageSize_B5BarCheckItem1"
			superToolTip34.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True
			toolTipTitleItem34.Text = "<b>B5 (JIS)</b><br>7,17"" x 10,11"""
			superToolTip34.Items.Add(toolTipTitleItem34)
			Me.diagramCommandPageSize_B5BarCheckItem1.SuperTip = superToolTip34
			' 
			' diagramCommandFitToDrawingBarButtonItem1
			' 
			Me.diagramCommandFitToDrawingBarButtonItem1.Id = 84
			Me.diagramCommandFitToDrawingBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandFitToDrawingBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandFitToDrawingBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandFitToDrawingBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandFitToDrawingBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandFitToDrawingBarButtonItem1.Name = "diagramCommandFitToDrawingBarButtonItem1"
			' 
			' diagramCommandSetPageParameters_PageSizeBarButtonItem1
			' 
			Me.diagramCommandSetPageParameters_PageSizeBarButtonItem1.Id = 85
			Me.diagramCommandSetPageParameters_PageSizeBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetPageParameters_PageSizeBarButtonItem1.Name = "diagramCommandSetPageParameters_PageSizeBarButtonItem1"
			' 
			' diagramCommandAutoSize_NoneBarCheckItem1
			' 
			Me.diagramCommandAutoSize_NoneBarCheckItem1.Id = 86
			Me.diagramCommandAutoSize_NoneBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandAutoSize_NoneBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandAutoSize_NoneBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandAutoSize_NoneBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandAutoSize_NoneBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandAutoSize_NoneBarCheckItem1.Name = "diagramCommandAutoSize_NoneBarCheckItem1"
			' 
			' diagramCommandAutoSize_AutoSizeBarCheckItem1
			' 
			Me.diagramCommandAutoSize_AutoSizeBarCheckItem1.Id = 87
			Me.diagramCommandAutoSize_AutoSizeBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandAutoSize_AutoSizeBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandAutoSize_AutoSizeBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandAutoSize_AutoSizeBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandAutoSize_AutoSizeBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandAutoSize_AutoSizeBarCheckItem1.Name = "diagramCommandAutoSize_AutoSizeBarCheckItem1"
			' 
			' diagramCommandAutoSize_FillBarCheckItem1
			' 
			Me.diagramCommandAutoSize_FillBarCheckItem1.Id = 88
			Me.diagramCommandAutoSize_FillBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandAutoSize_FillBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandAutoSize_FillBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandAutoSize_FillBarCheckItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandAutoSize_FillBarCheckItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandAutoSize_FillBarCheckItem1.Name = "diagramCommandAutoSize_FillBarCheckItem1"
			' 
			' diagramThemesRibbonPageGroup1
			' 
			Me.diagramThemesRibbonPageGroup1.AllowTextClipping = False
			Me.diagramThemesRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandThemesBarGalleryItem1)
			Me.diagramThemesRibbonPageGroup1.Name = "diagramThemesRibbonPageGroup1"
			' 
			' diagramCommandThemesBarGalleryItem1
			' 
			' 
			' 
			' 
			Me.diagramCommandThemesBarGalleryItem1.Gallery.ColumnCount = 8
			Me.diagramCommandThemesBarGalleryItem1.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { galleryItemGroup2})
			Me.diagramCommandThemesBarGalleryItem1.Gallery.ImageSize = New System.Drawing.Size(65, 46)
			Me.diagramCommandThemesBarGalleryItem1.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio
			Me.diagramCommandThemesBarGalleryItem1.Gallery.RowCount = 1
			Me.diagramCommandThemesBarGalleryItem1.Id = 89
			Me.diagramCommandThemesBarGalleryItem1.Name = "diagramCommandThemesBarGalleryItem1"
			' 
			' diagramOptionsRibbonPageGroup1
			' 
			Me.diagramOptionsRibbonPageGroup1.AllowTextClipping = False
			Me.diagramOptionsRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandSnapToItemsBarCheckItem1)
			Me.diagramOptionsRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandSnapToGridBarCheckItem1)
			Me.diagramOptionsRibbonPageGroup1.Name = "diagramOptionsRibbonPageGroup1"
			' 
			' diagramCommandSnapToItemsBarCheckItem1
			' 
			Me.diagramCommandSnapToItemsBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
			Me.diagramCommandSnapToItemsBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.diagramCommandSnapToItemsBarCheckItem1.Id = 90
			Me.diagramCommandSnapToItemsBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSnapToItemsBarCheckItem1.Name = "diagramCommandSnapToItemsBarCheckItem1"
			' 
			' diagramCommandSnapToGridBarCheckItem1
			' 
			Me.diagramCommandSnapToGridBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
			Me.diagramCommandSnapToGridBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText
			Me.diagramCommandSnapToGridBarCheckItem1.Id = 91
			Me.diagramCommandSnapToGridBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSnapToGridBarCheckItem1.Name = "diagramCommandSnapToGridBarCheckItem1"
			' 
			' diagramTreeLayoutRibbonPageGroup1
			' 
			Me.diagramTreeLayoutRibbonPageGroup1.AllowTextClipping = False
			Me.diagramTreeLayoutRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandReLayoutBarDropDownItem1)
			Me.diagramTreeLayoutRibbonPageGroup1.Name = "diagramTreeLayoutRibbonPageGroup1"
			' 
			' diagramCommandReLayoutBarDropDownItem1
			' 
			Me.diagramCommandReLayoutBarDropDownItem1.Id = 92
			Me.diagramCommandReLayoutBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandReLayoutBarDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandReLayoutBarDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
            Me.diagramCommandReLayoutBarDropDownItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandReLayoutBarDropDownItem1.ImageOptions.LargeImage"), System.Drawing.Image))
            Me.diagramCommandReLayoutBarDropDownItem1.MultiColumn = DevExpress.Utils.DefaultBoolean.True
			Me.diagramCommandReLayoutBarDropDownItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramReLayoutTreeBarHeaderItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandTreeLayout_DownBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandTreeLayout_UpBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandTreeLayout_RightBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandTreeLayout_LeftBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramReLayoutTipOverTreeHeaderBarHeaderItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramReLayoutSugiyamaBarHeaderItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandSugiyamaLayout_DownBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandSugiyamaLayout_UpBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandSugiyamaLayout_RightBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramReLayoutCircularHeaderBarHeaderItem1),
				New DevExpress.XtraBars.LinkPersistInfo(Me.diagramCommandCircularLayoutBarButtonItem1)
			})
			Me.diagramCommandReLayoutBarDropDownItem1.Name = "diagramCommandReLayoutBarDropDownItem1"
			' 
			' diagramReLayoutTreeBarHeaderItem1
			' 
			Me.diagramReLayoutTreeBarHeaderItem1.Id = 93
			Me.diagramReLayoutTreeBarHeaderItem1.Name = "diagramReLayoutTreeBarHeaderItem1"
			' 
			' diagramCommandTreeLayout_DownBarButtonItem1
			' 
			Me.diagramCommandTreeLayout_DownBarButtonItem1.Id = 94
			Me.diagramCommandTreeLayout_DownBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandTreeLayout_DownBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandTreeLayout_DownBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandTreeLayout_DownBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandTreeLayout_DownBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandTreeLayout_DownBarButtonItem1.Name = "diagramCommandTreeLayout_DownBarButtonItem1"
			toolTipTitleItem35.Text = "Top To Bottom"
			superToolTip35.Items.Add(toolTipTitleItem35)
			Me.diagramCommandTreeLayout_DownBarButtonItem1.SuperTip = superToolTip35
			' 
			' diagramCommandTreeLayout_UpBarButtonItem1
			' 
			Me.diagramCommandTreeLayout_UpBarButtonItem1.Id = 95
			Me.diagramCommandTreeLayout_UpBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandTreeLayout_UpBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandTreeLayout_UpBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandTreeLayout_UpBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandTreeLayout_UpBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandTreeLayout_UpBarButtonItem1.Name = "diagramCommandTreeLayout_UpBarButtonItem1"
			toolTipTitleItem36.Text = "Bottom To Top"
			superToolTip36.Items.Add(toolTipTitleItem36)
			Me.diagramCommandTreeLayout_UpBarButtonItem1.SuperTip = superToolTip36
			' 
			' diagramCommandTreeLayout_RightBarButtonItem1
			' 
			Me.diagramCommandTreeLayout_RightBarButtonItem1.Id = 96
			Me.diagramCommandTreeLayout_RightBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandTreeLayout_RightBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandTreeLayout_RightBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandTreeLayout_RightBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandTreeLayout_RightBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandTreeLayout_RightBarButtonItem1.Name = "diagramCommandTreeLayout_RightBarButtonItem1"
			toolTipTitleItem37.Text = "Left To Right"
			superToolTip37.Items.Add(toolTipTitleItem37)
			Me.diagramCommandTreeLayout_RightBarButtonItem1.SuperTip = superToolTip37
			' 
			' diagramCommandTreeLayout_LeftBarButtonItem1
			' 
			Me.diagramCommandTreeLayout_LeftBarButtonItem1.Id = 97
			Me.diagramCommandTreeLayout_LeftBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandTreeLayout_LeftBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandTreeLayout_LeftBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandTreeLayout_LeftBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandTreeLayout_LeftBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandTreeLayout_LeftBarButtonItem1.Name = "diagramCommandTreeLayout_LeftBarButtonItem1"
			toolTipTitleItem38.Text = "Right To Left"
			superToolTip38.Items.Add(toolTipTitleItem38)
			Me.diagramCommandTreeLayout_LeftBarButtonItem1.SuperTip = superToolTip38
			' 
			' diagramReLayoutTipOverTreeHeaderBarHeaderItem1
			' 
			Me.diagramReLayoutTipOverTreeHeaderBarHeaderItem1.Id = 98
			Me.diagramReLayoutTipOverTreeHeaderBarHeaderItem1.Name = "diagramReLayoutTipOverTreeHeaderBarHeaderItem1"
			' 
			' diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1
			' 
			Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.Id = 99
			Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.ImageOptions.LargeImage" & ""), System.Drawing.Image))
			Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.Name = "diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1"
			toolTipTitleItem39.Text = "Left To Right"
			superToolTip39.Items.Add(toolTipTitleItem39)
			Me.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.SuperTip = superToolTip39
			' 
			' diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1
			' 
			Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.Id = 100
			Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.ImageOptions.LargeImage" & ""), System.Drawing.Image))
			Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.Name = "diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1"
			toolTipTitleItem40.Text = "Right To Left"
			superToolTip40.Items.Add(toolTipTitleItem40)
			Me.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.SuperTip = superToolTip40
			' 
			' diagramReLayoutSugiyamaBarHeaderItem1
			' 
			Me.diagramReLayoutSugiyamaBarHeaderItem1.Id = 101
			Me.diagramReLayoutSugiyamaBarHeaderItem1.Name = "diagramReLayoutSugiyamaBarHeaderItem1"
			' 
			' diagramCommandSugiyamaLayout_DownBarButtonItem1
			' 
			Me.diagramCommandSugiyamaLayout_DownBarButtonItem1.Id = 102
			Me.diagramCommandSugiyamaLayout_DownBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSugiyamaLayout_DownBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSugiyamaLayout_DownBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSugiyamaLayout_DownBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandSugiyamaLayout_DownBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandSugiyamaLayout_DownBarButtonItem1.Name = "diagramCommandSugiyamaLayout_DownBarButtonItem1"
			toolTipTitleItem41.Text = "Top To Bottom"
			superToolTip41.Items.Add(toolTipTitleItem41)
			Me.diagramCommandSugiyamaLayout_DownBarButtonItem1.SuperTip = superToolTip41
			' 
			' diagramCommandSugiyamaLayout_UpBarButtonItem1
			' 
			Me.diagramCommandSugiyamaLayout_UpBarButtonItem1.Id = 103
			Me.diagramCommandSugiyamaLayout_UpBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSugiyamaLayout_UpBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSugiyamaLayout_UpBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSugiyamaLayout_UpBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandSugiyamaLayout_UpBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandSugiyamaLayout_UpBarButtonItem1.Name = "diagramCommandSugiyamaLayout_UpBarButtonItem1"
			toolTipTitleItem42.Text = "Bottom To Top"
			superToolTip42.Items.Add(toolTipTitleItem42)
			Me.diagramCommandSugiyamaLayout_UpBarButtonItem1.SuperTip = superToolTip42
			' 
			' diagramCommandSugiyamaLayout_RightBarButtonItem1
			' 
			Me.diagramCommandSugiyamaLayout_RightBarButtonItem1.Id = 104
			Me.diagramCommandSugiyamaLayout_RightBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSugiyamaLayout_RightBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSugiyamaLayout_RightBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSugiyamaLayout_RightBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandSugiyamaLayout_RightBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandSugiyamaLayout_RightBarButtonItem1.Name = "diagramCommandSugiyamaLayout_RightBarButtonItem1"
			toolTipTitleItem43.Text = "Left To Right"
			superToolTip43.Items.Add(toolTipTitleItem43)
			Me.diagramCommandSugiyamaLayout_RightBarButtonItem1.SuperTip = superToolTip43
			' 
			' diagramCommandSugiyamaLayout_LeftBarButtonItem1
			' 
			Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1.Id = 105
			Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSugiyamaLayout_LeftBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandSugiyamaLayout_LeftBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1.Name = "diagramCommandSugiyamaLayout_LeftBarButtonItem1"
			toolTipTitleItem44.Text = "Right To Left"
			superToolTip44.Items.Add(toolTipTitleItem44)
			Me.diagramCommandSugiyamaLayout_LeftBarButtonItem1.SuperTip = superToolTip44
			' 
			' diagramReLayoutCircularHeaderBarHeaderItem1
			' 
			Me.diagramReLayoutCircularHeaderBarHeaderItem1.Id = 106
			Me.diagramReLayoutCircularHeaderBarHeaderItem1.Name = "diagramReLayoutCircularHeaderBarHeaderItem1"
			' 
			' diagramCommandCircularLayoutBarButtonItem1
			' 
			Me.diagramCommandCircularLayoutBarButtonItem1.Id = 107
			Me.diagramCommandCircularLayoutBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandCircularLayoutBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandCircularLayoutBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandCircularLayoutBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandCircularLayoutBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandCircularLayoutBarButtonItem1.Name = "diagramCommandCircularLayoutBarButtonItem1"
			toolTipTitleItem45.Text = "Circular"
			superToolTip45.Items.Add(toolTipTitleItem45)
			Me.diagramCommandCircularLayoutBarButtonItem1.SuperTip = superToolTip45
			' 
			' diagramDiagramPartsRibbonPageGroup1
			' 
			Me.diagramDiagramPartsRibbonPageGroup1.AllowTextClipping = False
			Me.diagramDiagramPartsRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandInsertContainerBarSplitButtonItem1)
			Me.diagramDiagramPartsRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandInsertImageBarButtonItem1)
			Me.diagramDiagramPartsRibbonPageGroup1.Name = "diagramDiagramPartsRibbonPageGroup1"
			' 
			' diagramInsertRibbonPage1
			' 
			Me.diagramInsertRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.diagramDiagramPartsRibbonPageGroup1})
			Me.diagramInsertRibbonPage1.Name = "diagramInsertRibbonPage1"
			' 
			' diagramCommandInsertContainerBarSplitButtonItem1
			' 
			Me.diagramCommandInsertContainerBarSplitButtonItem1.DropDownControl = Me.InsertContainerPopupMenu
			Me.diagramCommandInsertContainerBarSplitButtonItem1.Id = 108
			Me.diagramCommandInsertContainerBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandInsertContainerBarSplitButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandInsertContainerBarSplitButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandInsertContainerBarSplitButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandInsertContainerBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.LargeImagesText
			Me.diagramCommandInsertContainerBarSplitButtonItem1.Name = "diagramCommandInsertContainerBarSplitButtonItem1"
			Me.diagramCommandInsertContainerBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' InsertContainerPopupMenu
			' 
			' 
			' 
			' 
			Me.InsertContainerPopupMenu.Gallery.AllowFilter = False
			Me.InsertContainerPopupMenu.Gallery.ColumnCount = 4
			Me.InsertContainerPopupMenu.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { galleryItemGroup3})
			Me.InsertContainerPopupMenu.Gallery.ImageSize = New System.Drawing.Size(65, 46)
			Me.InsertContainerPopupMenu.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio
			Me.InsertContainerPopupMenu.Gallery.RowCount = 2
			Me.InsertContainerPopupMenu.Gallery.ShowGroupCaption = False
			Me.InsertContainerPopupMenu.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Auto
			Me.InsertContainerPopupMenu.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.LargeImagesText
			Me.InsertContainerPopupMenu.Name = "InsertContainerPopupMenu"
			Me.InsertContainerPopupMenu.Ribbon = Me.ribbonControl1
			' 
			' diagramCommandInsertImageBarButtonItem1
			' 
			Me.diagramCommandInsertImageBarButtonItem1.Id = 109
			Me.diagramCommandInsertImageBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandInsertImageBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandInsertImageBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandInsertImageBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandInsertImageBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandInsertImageBarButtonItem1.Name = "diagramCommandInsertImageBarButtonItem1"
			Me.diagramCommandInsertImageBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' diagramClipboardRibbonPageGroup1
			' 
			Me.diagramClipboardRibbonPageGroup1.AllowTextClipping = False
			Me.diagramClipboardRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandPasteBarButtonItem1)
			Me.diagramClipboardRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandCutBarButtonItem1)
			Me.diagramClipboardRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandCopyBarButtonItem1)
			Me.diagramClipboardRibbonPageGroup1.Name = "diagramClipboardRibbonPageGroup1"
			' 
			' diagramHomeRibbonPage1
			' 
			Me.diagramHomeRibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() { Me.diagramClipboardRibbonPageGroup1, Me.diagramFontRibbonPageGroup1, Me.diagramParagraphRibbonPageGroup1, Me.diagramToolsRibbonPageGroup1, Me.diagramShapeStylesRibbonPageGroup1, Me.diagramArrangeRibbonPageGroup1})
			Me.diagramHomeRibbonPage1.Name = "diagramHomeRibbonPage1"
			' 
			' diagramCommandPasteBarButtonItem1
			' 
			Me.diagramCommandPasteBarButtonItem1.Id = 114
			Me.diagramCommandPasteBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandPasteBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandPasteBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandPasteBarButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandPasteBarButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandPasteBarButtonItem1.Name = "diagramCommandPasteBarButtonItem1"
			Me.diagramCommandPasteBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large
			' 
			' diagramCommandCutBarButtonItem1
			' 
			Me.diagramCommandCutBarButtonItem1.Id = 115
			Me.diagramCommandCutBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandCutBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandCutBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandCutBarButtonItem1.Name = "diagramCommandCutBarButtonItem1"
			Me.diagramCommandCutBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandCopyBarButtonItem1
			' 
			Me.diagramCommandCopyBarButtonItem1.Id = 116
			Me.diagramCommandCopyBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandCopyBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandCopyBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandCopyBarButtonItem1.Name = "diagramCommandCopyBarButtonItem1"
			Me.diagramCommandCopyBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramFontRibbonPageGroup1
			' 
			Me.diagramFontRibbonPageGroup1.AllowTextClipping = False
			Me.diagramFontRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup1)
			Me.diagramFontRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup2)
			Me.diagramFontRibbonPageGroup1.Name = "diagramFontRibbonPageGroup1"
			' 
			' diagramCommandFontFamilyBarEditItem1
			' 
			Me.diagramCommandFontFamilyBarEditItem1.Edit = Me.repositoryItemFontEdit1
			Me.diagramCommandFontFamilyBarEditItem1.EditWidth = 130
			Me.diagramCommandFontFamilyBarEditItem1.Id = 117
			Me.diagramCommandFontFamilyBarEditItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandFontFamilyBarEditItem1.Name = "diagramCommandFontFamilyBarEditItem1"
			' 
			' diagramCommandFontSizeBarEditItem1
			' 
			Me.diagramCommandFontSizeBarEditItem1.Edit = Me.repositoryItemDiagramFontSizeEdit1
			Me.diagramCommandFontSizeBarEditItem1.Id = 118
			Me.diagramCommandFontSizeBarEditItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandFontSizeBarEditItem1.Name = "diagramCommandFontSizeBarEditItem1"
			' 
			' diagramCommandIncreaseFontSizeBarButtonItem1
			' 
			Me.diagramCommandIncreaseFontSizeBarButtonItem1.Id = 119
			Me.diagramCommandIncreaseFontSizeBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandIncreaseFontSizeBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandIncreaseFontSizeBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandIncreaseFontSizeBarButtonItem1.Name = "diagramCommandIncreaseFontSizeBarButtonItem1"
			Me.diagramCommandIncreaseFontSizeBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandDecreaseFontSizeBarButtonItem1
			' 
			Me.diagramCommandDecreaseFontSizeBarButtonItem1.Id = 120
			Me.diagramCommandDecreaseFontSizeBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandDecreaseFontSizeBarButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandDecreaseFontSizeBarButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandDecreaseFontSizeBarButtonItem1.Name = "diagramCommandDecreaseFontSizeBarButtonItem1"
			Me.diagramCommandDecreaseFontSizeBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandToggleFontBoldBarCheckItem1
			' 
			Me.diagramCommandToggleFontBoldBarCheckItem1.Id = 121
			Me.diagramCommandToggleFontBoldBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandToggleFontBoldBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandToggleFontBoldBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandToggleFontBoldBarCheckItem1.Name = "diagramCommandToggleFontBoldBarCheckItem1"
			Me.diagramCommandToggleFontBoldBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandToggleFontItalicBarCheckItem1
			' 
			Me.diagramCommandToggleFontItalicBarCheckItem1.Id = 122
			Me.diagramCommandToggleFontItalicBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandToggleFontItalicBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandToggleFontItalicBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandToggleFontItalicBarCheckItem1.Name = "diagramCommandToggleFontItalicBarCheckItem1"
			Me.diagramCommandToggleFontItalicBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandToggleFontUnderlineBarCheckItem1
			' 
			Me.diagramCommandToggleFontUnderlineBarCheckItem1.Id = 123
			Me.diagramCommandToggleFontUnderlineBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandToggleFontUnderlineBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandToggleFontUnderlineBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandToggleFontUnderlineBarCheckItem1.Name = "diagramCommandToggleFontUnderlineBarCheckItem1"
			Me.diagramCommandToggleFontUnderlineBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandToggleFontStrikethroughBarCheckItem1
			' 
			Me.diagramCommandToggleFontStrikethroughBarCheckItem1.Id = 124
			Me.diagramCommandToggleFontStrikethroughBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandToggleFontStrikethroughBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandToggleFontStrikethroughBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandToggleFontStrikethroughBarCheckItem1.Name = "diagramCommandToggleFontStrikethroughBarCheckItem1"
			Me.diagramCommandToggleFontStrikethroughBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandForegroundColorBarSplitButtonItem1
			' 
			Me.diagramCommandForegroundColorBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
			Me.diagramCommandForegroundColorBarSplitButtonItem1.Color = System.Drawing.Color.Empty
			Me.diagramCommandForegroundColorBarSplitButtonItem1.Id = 125
			Me.diagramCommandForegroundColorBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandForegroundColorBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandForegroundColorBarSplitButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandForegroundColorBarSplitButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandForegroundColorBarSplitButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandForegroundColorBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.Default
			Me.diagramCommandForegroundColorBarSplitButtonItem1.Name = "diagramCommandForegroundColorBarSplitButtonItem1"
			Me.diagramCommandForegroundColorBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' barButtonGroup1
			' 
			Me.barButtonGroup1.Id = 110
			Me.barButtonGroup1.ItemLinks.Add(Me.diagramCommandFontFamilyBarEditItem1)
			Me.barButtonGroup1.ItemLinks.Add(Me.diagramCommandFontSizeBarEditItem1)
			Me.barButtonGroup1.ItemLinks.Add(Me.diagramCommandIncreaseFontSizeBarButtonItem1)
			Me.barButtonGroup1.ItemLinks.Add(Me.diagramCommandDecreaseFontSizeBarButtonItem1)
			Me.barButtonGroup1.Name = "barButtonGroup1"
			Me.barButtonGroup1.Tag = "bgFontSizeAndFamily"
			' 
			' repositoryItemFontEdit1
			' 
			Me.repositoryItemFontEdit1.AutoHeight = False
			Me.repositoryItemFontEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() { New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
			Me.repositoryItemFontEdit1.Name = "repositoryItemFontEdit1"
			' 
			' repositoryItemDiagramFontSizeEdit1
			' 
			Me.repositoryItemDiagramFontSizeEdit1.AutoHeight = False
			Me.repositoryItemDiagramFontSizeEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() { New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
			Me.repositoryItemDiagramFontSizeEdit1.Diagram = Me.diagramControl1
			Me.repositoryItemDiagramFontSizeEdit1.Name = "repositoryItemDiagramFontSizeEdit1"
			' 
			' barButtonGroup2
			' 
			Me.barButtonGroup2.Id = 111
			Me.barButtonGroup2.ItemLinks.Add(Me.diagramCommandToggleFontBoldBarCheckItem1)
			Me.barButtonGroup2.ItemLinks.Add(Me.diagramCommandToggleFontItalicBarCheckItem1)
			Me.barButtonGroup2.ItemLinks.Add(Me.diagramCommandToggleFontUnderlineBarCheckItem1)
			Me.barButtonGroup2.ItemLinks.Add(Me.diagramCommandToggleFontStrikethroughBarCheckItem1)
			Me.barButtonGroup2.ItemLinks.Add(Me.diagramCommandForegroundColorBarSplitButtonItem1)
			Me.barButtonGroup2.Name = "barButtonGroup2"
			Me.barButtonGroup2.Tag = "bgFontTypeAndColor"
			' 
			' diagramParagraphRibbonPageGroup1
			' 
			Me.diagramParagraphRibbonPageGroup1.AllowTextClipping = False
			Me.diagramParagraphRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup3)
			Me.diagramParagraphRibbonPageGroup1.ItemLinks.Add(Me.barButtonGroup4)
			Me.diagramParagraphRibbonPageGroup1.Name = "diagramParagraphRibbonPageGroup1"
			' 
			' diagramCommandSetVerticalAlignment_TopBarCheckItem1
			' 
			Me.diagramCommandSetVerticalAlignment_TopBarCheckItem1.Id = 126
			Me.diagramCommandSetVerticalAlignment_TopBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetVerticalAlignment_TopBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSetVerticalAlignment_TopBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSetVerticalAlignment_TopBarCheckItem1.Name = "diagramCommandSetVerticalAlignment_TopBarCheckItem1"
			Me.diagramCommandSetVerticalAlignment_TopBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandSetVerticalAlignment_CenterBarCheckItem1
			' 
			Me.diagramCommandSetVerticalAlignment_CenterBarCheckItem1.Id = 127
			Me.diagramCommandSetVerticalAlignment_CenterBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetVerticalAlignment_CenterBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSetVerticalAlignment_CenterBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSetVerticalAlignment_CenterBarCheckItem1.Name = "diagramCommandSetVerticalAlignment_CenterBarCheckItem1"
			Me.diagramCommandSetVerticalAlignment_CenterBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandSetVerticalAlignment_BottomBarCheckItem1
			' 
			Me.diagramCommandSetVerticalAlignment_BottomBarCheckItem1.Id = 128
			Me.diagramCommandSetVerticalAlignment_BottomBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetVerticalAlignment_BottomBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSetVerticalAlignment_BottomBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSetVerticalAlignment_BottomBarCheckItem1.Name = "diagramCommandSetVerticalAlignment_BottomBarCheckItem1"
			Me.diagramCommandSetVerticalAlignment_BottomBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandSetHorizontalAlignment_LeftBarCheckItem1
			' 
			Me.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.Id = 129
			Me.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.Name = "diagramCommandSetHorizontalAlignment_LeftBarCheckItem1"
			Me.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandSetHorizontalAlignment_CenterBarCheckItem1
			' 
			Me.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.Id = 130
			Me.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.Name = "diagramCommandSetHorizontalAlignment_CenterBarCheckItem1"
			Me.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' diagramCommandSetHorizontalAlignment_RightBarCheckItem1
			' 
			Me.diagramCommandSetHorizontalAlignment_RightBarCheckItem1.Id = 131
			Me.diagramCommandSetHorizontalAlignment_RightBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSetHorizontalAlignment_RightBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSetHorizontalAlignment_RightBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSetHorizontalAlignment_RightBarCheckItem1.Name = "diagramCommandSetHorizontalAlignment_RightBarCheckItem1"
			Me.diagramCommandSetHorizontalAlignment_RightBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
			' 
			' barButtonGroup3
			' 
			Me.barButtonGroup3.Id = 112
			Me.barButtonGroup3.ItemLinks.Add(Me.diagramCommandSetVerticalAlignment_TopBarCheckItem1)
			Me.barButtonGroup3.ItemLinks.Add(Me.diagramCommandSetVerticalAlignment_CenterBarCheckItem1)
			Me.barButtonGroup3.ItemLinks.Add(Me.diagramCommandSetVerticalAlignment_BottomBarCheckItem1)
			Me.barButtonGroup3.Name = "barButtonGroup3"
			Me.barButtonGroup3.Tag = "bgVerticalTextAlignment"
			' 
			' barButtonGroup4
			' 
			Me.barButtonGroup4.Id = 113
			Me.barButtonGroup4.ItemLinks.Add(Me.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1)
			Me.barButtonGroup4.ItemLinks.Add(Me.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1)
			Me.barButtonGroup4.ItemLinks.Add(Me.diagramCommandSetHorizontalAlignment_RightBarCheckItem1)
			Me.barButtonGroup4.Name = "barButtonGroup4"
			Me.barButtonGroup4.Tag = "bgHorizontalTextAlignment"
			' 
			' diagramToolsRibbonPageGroup1
			' 
			Me.diagramToolsRibbonPageGroup1.AllowTextClipping = False
			Me.diagramToolsRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandSelectPointerToolBarCheckItem1)
			Me.diagramToolsRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandSelectConnectorToolBarCheckItem1)
			Me.diagramToolsRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandToolsContainerCheckDropDownItem1)
			Me.diagramToolsRibbonPageGroup1.Name = "diagramToolsRibbonPageGroup1"
			' 
			' diagramCommandSelectPointerToolBarCheckItem1
			' 
			Me.diagramCommandSelectPointerToolBarCheckItem1.Id = 132
			Me.diagramCommandSelectPointerToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSelectPointerToolBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSelectPointerToolBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSelectPointerToolBarCheckItem1.Name = "diagramCommandSelectPointerToolBarCheckItem1"
			Me.diagramCommandSelectPointerToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandSelectConnectorToolBarCheckItem1
			' 
			Me.diagramCommandSelectConnectorToolBarCheckItem1.Id = 133
			Me.diagramCommandSelectConnectorToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSelectConnectorToolBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSelectConnectorToolBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSelectConnectorToolBarCheckItem1.Name = "diagramCommandSelectConnectorToolBarCheckItem1"
			Me.diagramCommandSelectConnectorToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandToolsContainerCheckDropDownItem1
			' 
			Me.diagramCommandToolsContainerCheckDropDownItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.CheckDropDown
			Me.diagramCommandToolsContainerCheckDropDownItem1.Caption = "Rectangle"
			Me.diagramCommandToolsContainerCheckDropDownItem1.Description = "Drag to draw a rectangle."
			Me.diagramCommandToolsContainerCheckDropDownItem1.DropDownControl = Me.ToolsContainerPopupMenu
			Me.diagramCommandToolsContainerCheckDropDownItem1.Id = 134
			Me.diagramCommandToolsContainerCheckDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandToolsContainerCheckDropDownItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandToolsContainerCheckDropDownItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandToolsContainerCheckDropDownItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText
			Me.diagramCommandToolsContainerCheckDropDownItem1.Name = "diagramCommandToolsContainerCheckDropDownItem1"
			Me.diagramCommandToolsContainerCheckDropDownItem1.RememberLastCommand = True
			Me.diagramCommandToolsContainerCheckDropDownItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			toolTipTitleItem46.Text = "Rectangle (Ctrl+8)"
			toolTipItem1.Text = "Drag to draw a rectangle."
			superToolTip46.Items.Add(toolTipTitleItem46)
			superToolTip46.Items.Add(toolTipItem1)
			Me.diagramCommandToolsContainerCheckDropDownItem1.SuperTip = superToolTip46
			' 
			' ToolsContainerPopupMenu
			' 
			Me.ToolsContainerPopupMenu.ItemLinks.Add(Me.diagramCommandSelectRectangleToolBarCheckItem1)
			Me.ToolsContainerPopupMenu.ItemLinks.Add(Me.diagramCommandSelectEllipseToolBarCheckItem1)
			Me.ToolsContainerPopupMenu.ItemLinks.Add(Me.diagramCommandSelectRightTriangleToolBarCheckItem1)
			Me.ToolsContainerPopupMenu.ItemLinks.Add(Me.diagramCommandSelectHexagonToolBarCheckItem1)
			Me.ToolsContainerPopupMenu.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText
			Me.ToolsContainerPopupMenu.Name = "ToolsContainerPopupMenu"
			Me.ToolsContainerPopupMenu.Ribbon = Me.ribbonControl1
			' 
			' diagramCommandSelectRectangleToolBarCheckItem1
			' 
			Me.diagramCommandSelectRectangleToolBarCheckItem1.Id = 135
			Me.diagramCommandSelectRectangleToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSelectRectangleToolBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSelectRectangleToolBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSelectRectangleToolBarCheckItem1.Name = "diagramCommandSelectRectangleToolBarCheckItem1"
			Me.diagramCommandSelectRectangleToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandSelectEllipseToolBarCheckItem1
			' 
			Me.diagramCommandSelectEllipseToolBarCheckItem1.Id = 136
			Me.diagramCommandSelectEllipseToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSelectEllipseToolBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSelectEllipseToolBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSelectEllipseToolBarCheckItem1.Name = "diagramCommandSelectEllipseToolBarCheckItem1"
			Me.diagramCommandSelectEllipseToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandSelectRightTriangleToolBarCheckItem1
			' 
			Me.diagramCommandSelectRightTriangleToolBarCheckItem1.Id = 137
			Me.diagramCommandSelectRightTriangleToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSelectRightTriangleToolBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSelectRightTriangleToolBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSelectRightTriangleToolBarCheckItem1.Name = "diagramCommandSelectRightTriangleToolBarCheckItem1"
			Me.diagramCommandSelectRightTriangleToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandSelectHexagonToolBarCheckItem1
			' 
			Me.diagramCommandSelectHexagonToolBarCheckItem1.Id = 138
			Me.diagramCommandSelectHexagonToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSelectHexagonToolBarCheckItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSelectHexagonToolBarCheckItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSelectHexagonToolBarCheckItem1.Name = "diagramCommandSelectHexagonToolBarCheckItem1"
			Me.diagramCommandSelectHexagonToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramShapeStylesRibbonPageGroup1
			' 
			Me.diagramShapeStylesRibbonPageGroup1.AllowTextClipping = False
			Me.diagramShapeStylesRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandShapeStylesBarGalleryItem1)
			Me.diagramShapeStylesRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandBackgroundColorBarSplitButtonItem1)
			Me.diagramShapeStylesRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandStrokeColorBarSplitButtonItem1)
			Me.diagramShapeStylesRibbonPageGroup1.Name = "diagramShapeStylesRibbonPageGroup1"
			' 
			' diagramCommandShapeStylesBarGalleryItem1
			' 
			Me.diagramCommandShapeStylesBarGalleryItem1.Enabled = False
			' 
			' 
			' 
			Me.diagramCommandShapeStylesBarGalleryItem1.Gallery.ColumnCount = 7
			galleryItemGroup4.Caption = "Variant Styles"
			galleryItemGroup4.Tag = "Variant Styles"
			galleryItemGroup5.Caption = "Theme Styles"
			galleryItemGroup5.Tag = "Theme Styles"
			Me.diagramCommandShapeStylesBarGalleryItem1.Gallery.Groups.AddRange(New DevExpress.XtraBars.Ribbon.GalleryItemGroup() { galleryItemGroup4, galleryItemGroup5})
			Me.diagramCommandShapeStylesBarGalleryItem1.Gallery.ImageSize = New System.Drawing.Size(43, 43)
			Me.diagramCommandShapeStylesBarGalleryItem1.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio
			Me.diagramCommandShapeStylesBarGalleryItem1.Gallery.RowCount = 7
			Me.diagramCommandShapeStylesBarGalleryItem1.Id = 139
			Me.diagramCommandShapeStylesBarGalleryItem1.Name = "diagramCommandShapeStylesBarGalleryItem1"
			' 
			' diagramCommandBackgroundColorBarSplitButtonItem1
			' 
			Me.diagramCommandBackgroundColorBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
			Me.diagramCommandBackgroundColorBarSplitButtonItem1.Color = System.Drawing.Color.Empty
			Me.diagramCommandBackgroundColorBarSplitButtonItem1.Id = 140
			Me.diagramCommandBackgroundColorBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandBackgroundColorBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandBackgroundColorBarSplitButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandBackgroundColorBarSplitButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandBackgroundColorBarSplitButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandBackgroundColorBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.Default
			Me.diagramCommandBackgroundColorBarSplitButtonItem1.Name = "diagramCommandBackgroundColorBarSplitButtonItem1"
			Me.diagramCommandBackgroundColorBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramCommandStrokeColorBarSplitButtonItem1
			' 
			Me.diagramCommandStrokeColorBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
			Me.diagramCommandStrokeColorBarSplitButtonItem1.Color = System.Drawing.Color.Empty
			Me.diagramCommandStrokeColorBarSplitButtonItem1.Id = 141
			Me.diagramCommandStrokeColorBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandStrokeColorBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandStrokeColorBarSplitButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandStrokeColorBarSplitButtonItem1.ImageOptions.LargeImage = (DirectCast(resources.GetObject("diagramCommandStrokeColorBarSplitButtonItem1.ImageOptions.LargeImage"), System.Drawing.Image))
			Me.diagramCommandStrokeColorBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.Default
			Me.diagramCommandStrokeColorBarSplitButtonItem1.Name = "diagramCommandStrokeColorBarSplitButtonItem1"
			Me.diagramCommandStrokeColorBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' diagramArrangeRibbonPageGroup1
			' 
			Me.diagramArrangeRibbonPageGroup1.AllowTextClipping = False
			Me.diagramArrangeRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandBringToFrontBarSplitButtonItem1)
			Me.diagramArrangeRibbonPageGroup1.ItemLinks.Add(Me.diagramCommandSendToBackBarSplitButtonItem1)
			Me.diagramArrangeRibbonPageGroup1.Name = "diagramArrangeRibbonPageGroup1"
			' 
			' diagramCommandBringToFrontBarSplitButtonItem1
			' 
			Me.diagramCommandBringToFrontBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
			Me.diagramCommandBringToFrontBarSplitButtonItem1.DropDownControl = Me.BringToFrontPopupMenu
			Me.diagramCommandBringToFrontBarSplitButtonItem1.Id = 142
			Me.diagramCommandBringToFrontBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandBringToFrontBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandBringToFrontBarSplitButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandBringToFrontBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText
			Me.diagramCommandBringToFrontBarSplitButtonItem1.Name = "diagramCommandBringToFrontBarSplitButtonItem1"
			Me.diagramCommandBringToFrontBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' BringToFrontPopupMenu
			' 
			Me.BringToFrontPopupMenu.ItemLinks.Add(Me.diagramCommandBringForwardBarButtonItem1)
			Me.BringToFrontPopupMenu.ItemLinks.Add(Me.diagramCommandBringToFrontBarButtonItem1)
			Me.BringToFrontPopupMenu.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText
			Me.BringToFrontPopupMenu.Name = "BringToFrontPopupMenu"
			Me.BringToFrontPopupMenu.Ribbon = Me.ribbonControl1
			' 
			' diagramCommandSendToBackBarSplitButtonItem1
			' 
			Me.diagramCommandSendToBackBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
			Me.diagramCommandSendToBackBarSplitButtonItem1.DropDownControl = Me.SendToBackPopupMenu
			Me.diagramCommandSendToBackBarSplitButtonItem1.Id = 143
			Me.diagramCommandSendToBackBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False
			Me.diagramCommandSendToBackBarSplitButtonItem1.ImageOptions.Image = (DirectCast(resources.GetObject("diagramCommandSendToBackBarSplitButtonItem1.ImageOptions.Image"), System.Drawing.Image))
			Me.diagramCommandSendToBackBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText
			Me.diagramCommandSendToBackBarSplitButtonItem1.Name = "diagramCommandSendToBackBarSplitButtonItem1"
			Me.diagramCommandSendToBackBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
			' 
			' SendToBackPopupMenu
			' 
			Me.SendToBackPopupMenu.ItemLinks.Add(Me.diagramCommandSendBackwardBarButtonItem1)
			Me.SendToBackPopupMenu.ItemLinks.Add(Me.diagramCommandSendToBackBarButtonItem1)
			Me.SendToBackPopupMenu.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText
			Me.SendToBackPopupMenu.Name = "SendToBackPopupMenu"
			Me.SendToBackPopupMenu.Ribbon = Me.ribbonControl1
			' 
			' dockManager1
			' 
			Me.dockManager1.AutoHideContainers.AddRange(New DevExpress.XtraBars.Docking.AutoHideContainer() { Me.hideContainerRight})
			Me.dockManager1.Form = Me
			Me.dockManager1.RootPanels.AddRange(New DevExpress.XtraBars.Docking.DockPanel() { Me.diagramToolboxDockPanel1, Me.diagramControlDockPanel1})
			Me.dockManager1.TopZIndexControls.AddRange(New String() { "DevExpress.XtraBars.BarDockControl", "DevExpress.XtraBars.StandaloneBarDockControl", "System.Windows.Forms.StatusBar", "System.Windows.Forms.MenuStrip", "System.Windows.Forms.StatusStrip", "DevExpress.XtraBars.Ribbon.RibbonStatusBar", "DevExpress.XtraBars.Ribbon.RibbonControl", "DevExpress.XtraBars.Navigation.OfficeNavigationBar", "DevExpress.XtraBars.Navigation.TileNavPane", "DevExpress.XtraBars.TabFormControl"})
			' 
			' documentManager1
			' 
			Me.documentManager1.ContainerControl = Me
			Me.documentManager1.View = Me.tabbedView1
			Me.documentManager1.ViewCollection.AddRange(New DevExpress.XtraBars.Docking2010.Views.BaseView() { Me.tabbedView1})
			' 
			' tabbedView1
			' 
			Me.tabbedView1.DocumentGroupProperties.ShowTabHeader = False
			Me.tabbedView1.DocumentGroups.AddRange(New DevExpress.XtraBars.Docking2010.Views.Tabbed.DocumentGroup() { Me.documentGroup1})
			Me.tabbedView1.Documents.AddRange(New DevExpress.XtraBars.Docking2010.Views.BaseDocument() { Me.document1})
			Me.tabbedView1.RootContainer.Element = Nothing
			dockingContainer1.Element = Me.documentGroup1
			Me.tabbedView1.RootContainer.Nodes.AddRange(New DevExpress.XtraBars.Docking2010.Views.Tabbed.DockingContainer() { dockingContainer1})
			' 
			' diagramToolboxDockPanel1
			' 
			Me.diagramToolboxDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Left
			Me.diagramToolboxDockPanel1.FloatSize = New System.Drawing.Size(200, 500)
			Me.diagramToolboxDockPanel1.ID = New System.Guid("3d177bb0-5ec4-4d81-8f8b-a3f6c3b4140a")
			Me.diagramToolboxDockPanel1.Location = New System.Drawing.Point(0, 141)
			Me.diagramToolboxDockPanel1.Name = "diagramToolboxDockPanel1"
			Me.diagramToolboxDockPanel1.Options.AllowFloating = False
			Me.diagramToolboxDockPanel1.OriginalSize = New System.Drawing.Size(300, 200)
			Me.diagramToolboxDockPanel1.Size = New System.Drawing.Size(300, 543)
			' 
			' 
			' 
			Me.diagramToolboxDockPanel1.Toolbox.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
			Me.diagramToolboxDockPanel1.Toolbox.Caption = "Shapes"
			Me.diagramToolboxDockPanel1.Toolbox.Dock = System.Windows.Forms.DockStyle.Fill
			Me.diagramToolboxDockPanel1.Toolbox.Location = New System.Drawing.Point(0, 0)
			Me.diagramToolboxDockPanel1.Toolbox.Name = ""
			Me.diagramToolboxDockPanel1.Toolbox.OptionsBehavior.ItemSelectMode = DevExpress.XtraToolbox.ToolboxItemSelectMode.Single
			Me.diagramToolboxDockPanel1.Toolbox.OptionsView.ItemImageSize = New System.Drawing.Size(32, 32)
			Me.diagramToolboxDockPanel1.Toolbox.OptionsView.MenuButtonCaption = "More Shapes"
			Me.diagramToolboxDockPanel1.Toolbox.OptionsView.ShowToolboxCaption = True
			Me.diagramToolboxDockPanel1.Toolbox.Size = New System.Drawing.Size(291, 516)
			Me.diagramToolboxDockPanel1.Toolbox.TabIndex = 0
			Me.diagramToolboxDockPanel1.Toolbox.Text = "Shapes"
			' 
			' hideContainerRight
			' 
			Me.hideContainerRight.BackColor = System.Drawing.Color.FromArgb((CInt((CByte(235)))), (CInt((CByte(236)))), (CInt((CByte(239)))))
			Me.hideContainerRight.Controls.Add(Me.diagramPropertyGridDockPanel1)
			Me.hideContainerRight.Dock = System.Windows.Forms.DockStyle.Right
			Me.hideContainerRight.Location = New System.Drawing.Point(990, 141)
			Me.hideContainerRight.Name = "hideContainerRight"
			Me.hideContainerRight.Size = New System.Drawing.Size(19, 543)
			' 
			' diagramPropertyGridDockPanel1
			' 
			Me.diagramPropertyGridDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Right
			Me.diagramPropertyGridDockPanel1.ID = New System.Guid("b2c59e73-2f6a-4d7c-85bb-7ba29c50ab8f")
			Me.diagramPropertyGridDockPanel1.Location = New System.Drawing.Point(0, 0)
			Me.diagramPropertyGridDockPanel1.Name = "diagramPropertyGridDockPanel1"
			Me.diagramPropertyGridDockPanel1.Options.AllowFloating = False
			Me.diagramPropertyGridDockPanel1.OriginalSize = New System.Drawing.Size(300, 200)
			' 
			' 
			' 
			Me.diagramPropertyGridDockPanel1.PropertyGrid.AutoGenerateRows = True
			Me.diagramPropertyGridDockPanel1.PropertyGrid.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
			Me.diagramPropertyGridDockPanel1.PropertyGrid.Dock = System.Windows.Forms.DockStyle.Fill
			Me.diagramPropertyGridDockPanel1.PropertyGrid.Location = New System.Drawing.Point(0, 31)
			Me.diagramPropertyGridDockPanel1.PropertyGrid.Name = "propertyGrid"
			Me.diagramPropertyGridDockPanel1.PropertyGrid.OptionsMenu.EnableContextMenu = True
			Me.diagramPropertyGridDockPanel1.PropertyGrid.Size = New System.Drawing.Size(291, 52)
			Me.diagramPropertyGridDockPanel1.PropertyGrid.TabIndex = 6
			Me.diagramPropertyGridDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Right
			Me.diagramPropertyGridDockPanel1.SavedIndex = 1
			Me.diagramPropertyGridDockPanel1.Size = New System.Drawing.Size(300, 110)
			Me.diagramPropertyGridDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide
			' 
			' document1
			' 
			Me.document1.Caption = ""
			Me.document1.ControlName = "diagramControlDockPanel1"
			Me.document1.FloatLocation = New System.Drawing.Point(0, 0)
			Me.document1.FloatSize = New System.Drawing.Size(300, 200)
			Me.document1.Properties.AllowClose = DevExpress.Utils.DefaultBoolean.False
			Me.document1.Properties.AllowFloat = DevExpress.Utils.DefaultBoolean.False
			Me.document1.Properties.AllowFloatOnDoubleClick = DevExpress.Utils.DefaultBoolean.False
			' 
			' documentGroup1
			' 
			Me.documentGroup1.Items.AddRange(New DevExpress.XtraBars.Docking2010.Views.Tabbed.Document() { Me.document1})
			' 
			' diagramControlDockPanel1
			' 
			Me.diagramControlDockPanel1.Controls.Add(Me.controlContainer1)
			Me.diagramControlDockPanel1.DockedAsTabbedDocument = True
			Me.diagramControlDockPanel1.FloatSize = New System.Drawing.Size(300, 200)
			Me.diagramControlDockPanel1.ID = New System.Guid("13e711a1-04e3-4350-818f-060a9c00e03b")
			Me.diagramControlDockPanel1.Name = "diagramControlDockPanel1"
			Me.diagramControlDockPanel1.Options.AllowFloating = False
			Me.diagramControlDockPanel1.Options.ShowCloseButton = False
			Me.diagramControlDockPanel1.OriginalSize = New System.Drawing.Size(300, 200)
			Me.diagramControlDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Left
			Me.diagramControlDockPanel1.SavedIndex = 1
			' 
			' controlContainer1
			' 
			Me.controlContainer1.Controls.Add(Me.diagramControl1)
			Me.controlContainer1.Location = New System.Drawing.Point(0, 0)
			Me.controlContainer1.Name = "controlContainer1"
			Me.controlContainer1.Size = New System.Drawing.Size(684, 537)
			Me.controlContainer1.TabIndex = 0
			' 
			' Form1
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(1009, 711)
			Me.Controls.Add(Me.diagramToolboxDockPanel1)
			Me.Controls.Add(Me.hideContainerRight)
			Me.Controls.Add(Me.ribbonStatusBar1)
			Me.Controls.Add(Me.ribbonControl1)
			Me.Name = "Form1"
			Me.Text = "Form1"
			DirectCast(Me.diagramControl1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.ribbonControl1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.applicationMenu1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.diagramBarController1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.PrintMenuPopupMenu, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.ExportAsPopupMenu, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.diagramRepositoryItemZoomTrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.ImageToolsBringToFrontContainerPopupMenu, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.ImageToolsSendToBackContainerPopupMenu, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.InsertContainerPopupMenu, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.repositoryItemFontEdit1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.repositoryItemDiagramFontSizeEdit1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.ToolsContainerPopupMenu, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.BringToFrontPopupMenu, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.SendToBackPopupMenu, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.dockManager1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.documentManager1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.tabbedView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.hideContainerRight.ResumeLayout(False)
			DirectCast(Me.diagramPropertyGridDockPanel1.PropertyGrid, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.document1, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.documentGroup1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.diagramControlDockPanel1.ResumeLayout(False)
			Me.controlContainer1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private diagramControl1 As DevExpress.XtraDiagram.DiagramControl
		Private diagramPropertyGridDockPanel1 As DevExpress.XtraDiagram.Docking.DiagramPropertyGridDockPanel
		Private diagramToolboxDockPanel1 As DevExpress.XtraDiagram.Docking.DiagramToolboxDockPanel
		Private ribbonControl1 As DevExpress.XtraBars.Ribbon.RibbonControl
		Private applicationMenu1 As DevExpress.XtraBars.Ribbon.ApplicationMenu
		Private diagramCommandNewFileBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandNewFileBarButtonItem
		Private diagramCommandOpenFileBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandOpenFileBarButtonItem
		Private diagramCommandSaveFileBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSaveFileBarButtonItem
		Private diagramCommandSaveFileAsBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSaveFileAsBarButtonItem
		Private diagramCommandShowPrintPreviewBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandShowPrintPreviewBarButtonItem
		Private diagramCommandPrintMenuBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPrintMenuBarSplitButtonItem
		Private PrintMenuPopupMenu As DevExpress.XtraBars.PopupMenu
		Private diagramCommandPrintBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPrintBarButtonItem
		Private diagramCommandQuickPrintBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandQuickPrintBarButtonItem
		Private diagramCommandExportAsBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandExportAsBarSplitButtonItem
		Private ExportAsPopupMenu As DevExpress.XtraBars.PopupMenu
		Private diagramCommandExportDiagram_PNGBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_PNGBarButtonItem
		Private diagramCommandExportDiagram_JPEGBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_JPEGBarButtonItem
		Private diagramCommandExportDiagram_BMPBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_BMPBarButtonItem
		Private diagramCommandExportDiagram_GIFBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_GIFBarButtonItem
		Private diagramCommandUndoBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandUndoBarButtonItem
		Private diagramCommandRedoBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandRedoBarButtonItem
		Private diagramStatusBarShapeInfoBarStaticItem1 As DevExpress.XtraDiagram.Bars.DiagramStatusBarShapeInfoBarStaticItem
		Private diagramCommandStatusBarZoomEditorBarEditItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandStatusBarZoomEditorBarEditItem
		Private diagramRepositoryItemZoomTrackBar1 As DevExpress.XtraDiagram.Bars.DiagramCommandStatusBarZoomEditorBarEditItem.DiagramRepositoryItemZoomTrackBar
		Private diagramCommandContainerPaddingBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerPaddingBarDropDownItem
		Private diagramCommandContainerPadding_P0BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P0BarCheckItem
		Private diagramCommandContainerPadding_P4BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P4BarCheckItem
		Private diagramCommandContainerPadding_P8BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P8BarCheckItem
		Private diagramCommandContainerPadding_P12BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P12BarCheckItem
		Private diagramCommandContainerPadding_P16BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P16BarCheckItem
		Private diagramCommandContainerPadding_P24BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P24BarCheckItem
		Private diagramCommandContainerPadding_P32BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P32BarCheckItem
		Private diagramCommandContainerHeaderPaddingBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPaddingBarDropDownItem
		Private diagramCommandContainerHeaderPadding_P0BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P0BarCheckItem
		Private diagramCommandContainerHeaderPadding_P4BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P4BarCheckItem
		Private diagramCommandContainerHeaderPadding_P8BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P8BarCheckItem
		Private diagramCommandContainerHeaderPadding_P12BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P12BarCheckItem
		Private diagramCommandContainerHeaderPadding_P16BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P16BarCheckItem
		Private diagramCommandContainerHeaderPadding_P24BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P24BarCheckItem
		Private diagramCommandContainerHeaderPadding_P32BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P32BarCheckItem
		Private diagramCommandContainerStylesBarGalleryItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandContainerStylesBarGalleryItem
		Private diagramCommandShowContainerHeaderBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandShowContainerHeaderBarCheckItem
		Private diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsBringToFrontContainerBarSplitButtonItem
		Private ImageToolsBringToFrontContainerPopupMenu As DevExpress.XtraBars.PopupMenu
		Private diagramCommandBringForwardBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandBringForwardBarButtonItem
		Private diagramCommandBringToFrontBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandBringToFrontBarButtonItem
		Private diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSendToBackContainerBarSplitButtonItem
		Private ImageToolsSendToBackContainerPopupMenu As DevExpress.XtraBars.PopupMenu
		Private diagramCommandSendBackwardBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSendBackwardBarButtonItem
		Private diagramCommandSendToBackBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSendToBackBarButtonItem
		Private diagramCommandImageToolsRotateBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsRotateBarDropDownItem
		Private diagramCommandRotate_Right90BarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandRotate_Right90BarButtonItem
		Private diagramCommandRotate_Left90BarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandRotate_Left90BarButtonItem
		Private diagramCommandFlipImage_VerticalBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandFlipImage_VerticalBarButtonItem
		Private diagramCommandFlipImage_HorizontalBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandFlipImage_HorizontalBarButtonItem
		Private diagramCommandImageToolsStretchModeBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsStretchModeBarDropDownItem
		Private diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem
		Private diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem
		Private diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem
		Private diagramCommandImageToolsSetImageScaleBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScaleBarDropDownItem
		Private diagramCommandImageToolsSetImageScale_0_25BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_25BarCheckItem
		Private diagramCommandImageToolsSetImageScale_0_5BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_5BarCheckItem
		Private diagramCommandImageToolsSetImageScale_0_75BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_75BarCheckItem
		Private diagramCommandImageToolsSetImageScale_1BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_1BarCheckItem
		Private diagramCommandImageToolsSetImageScale_1_5BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_1_5BarCheckItem
		Private diagramCommandImageToolsSetImageScale_2BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_2BarCheckItem
		Private diagramCommandImageToolsSetImageScale_4BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_4BarCheckItem
		Private diagramCommandResetSelectedImagesBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandResetSelectedImagesBarButtonItem
		Private diagramCommandLoadImageBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandLoadImageBarButtonItem
		Private diagramCommandShowRulersBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandShowRulersBarCheckItem
		Private diagramCommandShowGridBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandShowGridBarCheckItem
		Private diagramCommandShowPageBreaksBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandShowPageBreaksBarCheckItem
		Private diagramCommandPanesBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPanesBarDropDownItem
		Private diagramCommandShapesPanelBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandShapesPanelBarCheckItem
		Private diagramCommandPropertiesPanelBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPropertiesPanelBarCheckItem
		Private diagramCommandFitToPageBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandFitToPageBarButtonItem
		Private diagramCommandFitToWidthBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandFitToWidthBarButtonItem
		Private diagramCommandPageOrientationBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientationBarDropDownItem
		Private diagramCommandPageOrientation_HorizontalBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientation_HorizontalBarCheckItem
		Private diagramCommandPageOrientation_VerticalBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientation_VerticalBarCheckItem
		Private diagramCommandPageSizeBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSizeBarDropDownItem
		Private diagramCommandPageSize_LetterBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_LetterBarCheckItem
		Private diagramCommandPageSize_TabloidBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_TabloidBarCheckItem
		Private diagramCommandPageSize_LegalBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_LegalBarCheckItem
		Private diagramCommandPageSize_StatementBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_StatementBarCheckItem
		Private diagramCommandPageSize_ExecutiveBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_ExecutiveBarCheckItem
		Private diagramCommandPageSize_A3BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A3BarCheckItem
		Private diagramCommandPageSize_A4BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A4BarCheckItem
		Private diagramCommandPageSize_A5BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A5BarCheckItem
		Private diagramCommandPageSize_B4BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_B4BarCheckItem
		Private diagramCommandPageSize_B5BarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_B5BarCheckItem
		Private diagramCommandFitToDrawingBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandFitToDrawingBarButtonItem
		Private diagramCommandSetPageParameters_PageSizeBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetPageParameters_PageSizeBarButtonItem
		Private diagramCommandAutoSizeBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandAutoSizeBarDropDownItem
		Private diagramCommandAutoSize_NoneBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_NoneBarCheckItem
		Private diagramCommandAutoSize_AutoSizeBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_AutoSizeBarCheckItem
		Private diagramCommandAutoSize_FillBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_FillBarCheckItem
		Private diagramCommandThemesBarGalleryItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandThemesBarGalleryItem
		Private diagramCommandSnapToItemsBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSnapToItemsBarCheckItem
		Private diagramCommandSnapToGridBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSnapToGridBarCheckItem
		Private diagramCommandReLayoutBarDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandReLayoutBarDropDownItem
		Private diagramReLayoutTreeBarHeaderItem1 As DevExpress.XtraDiagram.Bars.DiagramReLayoutTreeBarHeaderItem
		Private diagramCommandTreeLayout_DownBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_DownBarButtonItem
		Private diagramCommandTreeLayout_UpBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_UpBarButtonItem
		Private diagramCommandTreeLayout_RightBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_RightBarButtonItem
		Private diagramCommandTreeLayout_LeftBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_LeftBarButtonItem
		Private diagramReLayoutTipOverTreeHeaderBarHeaderItem1 As DevExpress.XtraDiagram.Bars.DiagramReLayoutTipOverTreeHeaderBarHeaderItem
		Private diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayout_LeftToRightBarButtonItem
		Private diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayout_RightToLeftBarButtonItem
		Private diagramReLayoutSugiyamaBarHeaderItem1 As DevExpress.XtraDiagram.Bars.DiagramReLayoutSugiyamaBarHeaderItem
		Private diagramCommandSugiyamaLayout_DownBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_DownBarButtonItem
		Private diagramCommandSugiyamaLayout_UpBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_UpBarButtonItem
		Private diagramCommandSugiyamaLayout_RightBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_RightBarButtonItem
		Private diagramCommandSugiyamaLayout_LeftBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_LeftBarButtonItem
		Private diagramReLayoutCircularHeaderBarHeaderItem1 As DevExpress.XtraDiagram.Bars.DiagramReLayoutCircularHeaderBarHeaderItem
		Private diagramCommandCircularLayoutBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandCircularLayoutBarButtonItem
		Private diagramCommandInsertContainerBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandInsertContainerBarSplitButtonItem
		Private InsertContainerPopupMenu As DevExpress.XtraBars.Commands.CommandBarGalleryDropDown
		Private diagramCommandInsertImageBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandInsertImageBarButtonItem
		Private diagramCommandPasteBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandPasteBarButtonItem
		Private diagramCommandCutBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandCutBarButtonItem
		Private diagramCommandCopyBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandCopyBarButtonItem
		Private barButtonGroup1 As DevExpress.XtraBars.BarButtonGroup
		Private diagramCommandFontFamilyBarEditItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandFontFamilyBarEditItem
		Private repositoryItemFontEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemFontEdit
		Private diagramCommandFontSizeBarEditItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandFontSizeBarEditItem
		Private repositoryItemDiagramFontSizeEdit1 As DevExpress.XtraDiagram.Bars.RepositoryItemDiagramFontSizeEdit
		Private diagramCommandIncreaseFontSizeBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandIncreaseFontSizeBarButtonItem
		Private diagramCommandDecreaseFontSizeBarButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandDecreaseFontSizeBarButtonItem
		Private barButtonGroup2 As DevExpress.XtraBars.BarButtonGroup
		Private diagramCommandToggleFontBoldBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontBoldBarCheckItem
		Private diagramCommandToggleFontItalicBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontItalicBarCheckItem
		Private diagramCommandToggleFontUnderlineBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontUnderlineBarCheckItem
		Private diagramCommandToggleFontStrikethroughBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontStrikethroughBarCheckItem
		Private diagramCommandForegroundColorBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandForegroundColorBarSplitButtonItem
		Private barButtonGroup3 As DevExpress.XtraBars.BarButtonGroup
		Private diagramCommandSetVerticalAlignment_TopBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_TopBarCheckItem
		Private diagramCommandSetVerticalAlignment_CenterBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_CenterBarCheckItem
		Private diagramCommandSetVerticalAlignment_BottomBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_BottomBarCheckItem
		Private barButtonGroup4 As DevExpress.XtraBars.BarButtonGroup
		Private diagramCommandSetHorizontalAlignment_LeftBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_LeftBarCheckItem
		Private diagramCommandSetHorizontalAlignment_CenterBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_CenterBarCheckItem
		Private diagramCommandSetHorizontalAlignment_RightBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_RightBarCheckItem
		Private diagramCommandSelectPointerToolBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSelectPointerToolBarCheckItem
		Private diagramCommandSelectConnectorToolBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSelectConnectorToolBarCheckItem
		Private diagramCommandToolsContainerCheckDropDownItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandToolsContainerCheckDropDownItem
		Private ToolsContainerPopupMenu As DevExpress.XtraBars.PopupMenu
		Private diagramCommandSelectRectangleToolBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSelectRectangleToolBarCheckItem
		Private diagramCommandSelectEllipseToolBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSelectEllipseToolBarCheckItem
		Private diagramCommandSelectRightTriangleToolBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSelectRightTriangleToolBarCheckItem
		Private diagramCommandSelectHexagonToolBarCheckItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSelectHexagonToolBarCheckItem
		Private diagramCommandShapeStylesBarGalleryItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandShapeStylesBarGalleryItem
		Private diagramCommandBackgroundColorBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandBackgroundColorBarSplitButtonItem
		Private diagramCommandStrokeColorBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandStrokeColorBarSplitButtonItem
		Private diagramCommandBringToFrontBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandBringToFrontBarSplitButtonItem
		Private BringToFrontPopupMenu As DevExpress.XtraBars.PopupMenu
		Private diagramCommandSendToBackBarSplitButtonItem1 As DevExpress.XtraDiagram.Bars.DiagramCommandSendToBackBarSplitButtonItem
		Private SendToBackPopupMenu As DevExpress.XtraBars.PopupMenu
		Private diagramContainerToolsRibbonPageCategory1 As DevExpress.XtraDiagram.Bars.DiagramContainerToolsRibbonPageCategory
		Private diagramFormatContainerRibbonPage1 As DevExpress.XtraDiagram.Bars.DiagramFormatContainerRibbonPage
		Private diagramContainerSizeRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramContainerSizeRibbonPageGroup
		Private diagramContainerStylesRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramContainerStylesRibbonPageGroup
		Private diagramImageToolsRibbonPageCategory1 As DevExpress.XtraDiagram.Bars.DiagramImageToolsRibbonPageCategory
		Private diagramFormatImageRibbonPage1 As DevExpress.XtraDiagram.Bars.DiagramFormatImageRibbonPage
		Private diagramImageTools_ArrangeRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramImageTools_ArrangeRibbonPageGroup
		Private diagramImageTools_PictureRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramImageTools_PictureRibbonPageGroup
		Private diagramHomeRibbonPage1 As DevExpress.XtraDiagram.Bars.DiagramHomeRibbonPage
		Private diagramClipboardRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramClipboardRibbonPageGroup
		Private diagramFontRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramFontRibbonPageGroup
		Private diagramParagraphRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramParagraphRibbonPageGroup
		Private diagramToolsRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramToolsRibbonPageGroup
		Private diagramShapeStylesRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramShapeStylesRibbonPageGroup
		Private diagramArrangeRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramArrangeRibbonPageGroup
		Private diagramInsertRibbonPage1 As DevExpress.XtraDiagram.Bars.DiagramInsertRibbonPage
		Private diagramDiagramPartsRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramDiagramPartsRibbonPageGroup
		Private diagramDesignRibbonPage1 As DevExpress.XtraDiagram.Bars.DiagramDesignRibbonPage
		Private diagramPageSetupRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramPageSetupRibbonPageGroup
		Private diagramThemesRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramThemesRibbonPageGroup
		Private diagramOptionsRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramOptionsRibbonPageGroup
		Private diagramTreeLayoutRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramTreeLayoutRibbonPageGroup
		Private diagramViewRibbonPage1 As DevExpress.XtraDiagram.Bars.DiagramViewRibbonPage
		Private diagramShowRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramShowRibbonPageGroup
		Private diagramZoomRibbonPageGroup1 As DevExpress.XtraDiagram.Bars.DiagramZoomRibbonPageGroup
		Private ribbonStatusBar1 As DevExpress.XtraBars.Ribbon.RibbonStatusBar
		Private diagramBarController1 As DevExpress.XtraDiagram.Bars.DiagramBarController
		Private dockManager1 As DevExpress.XtraBars.Docking.DockManager
		Private hideContainerRight As DevExpress.XtraBars.Docking.AutoHideContainer
		Private diagramControlDockPanel1 As DevExpress.XtraDiagram.Docking.DiagramControlDockPanel
		Private controlContainer1 As DevExpress.XtraBars.Docking.ControlContainer
		Private documentManager1 As DevExpress.XtraBars.Docking2010.DocumentManager
		Private tabbedView1 As DevExpress.XtraBars.Docking2010.Views.Tabbed.TabbedView
		Private documentGroup1 As DevExpress.XtraBars.Docking2010.Views.Tabbed.DocumentGroup
		Private document1 As DevExpress.XtraBars.Docking2010.Views.Tabbed.Document

	End Class
End Namespace

